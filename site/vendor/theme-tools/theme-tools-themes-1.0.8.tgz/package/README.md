# `@theme.tools/themes`

> **DTCG 2025.10 OKLCH Theme & Token Engine** (core-workspace · layer: `contracts`)

42 curated OKLCH dark/light themes, WCAG AA/AAA contrast validation, and CSS/JSON/TS token generators.

## Narrow Entry Points

- `@theme.tools/themes/contracts` — Pure TypeScript contracts, schemas, and event descriptors (zero DOM/Worker globals).
- `@theme.tools/themes/core` — Deterministic domain state machines and validation logic.
- `@theme.tools/themes/cloudflare` — Cloudflare Workers / Hono route descriptors and binding requirements (KV).
- `@theme.tools/themes/react` — React 19 surface descriptors (`ThemeTokenSwatches`).
- `@theme.tools/themes/elements` — Custom Element registration (`<tt-theme-switcher>`).
- `@theme.tools/themes/testing` — Deterministic conformance suite and test fixtures.
