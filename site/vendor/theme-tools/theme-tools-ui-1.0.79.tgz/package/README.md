# `@theme.tools/ui`

> **675-Component Design System, UniversalSite & Editorial Engine** (core-workspace · layer: `foundations`)

675 bespoke UI components across 31 categories, UniversalSite 100 presets, and 100 editorial contracts.

## Narrow Entry Points

- `@theme.tools/ui/contracts` — Pure TypeScript contracts, schemas, and event descriptors (zero DOM/Worker globals).
- `@theme.tools/ui/core` — Deterministic domain state machines and validation logic.
- `@theme.tools/ui/cloudflare` — Cloudflare Workers / Hono route descriptors and binding requirements (KV, R2).
- `@theme.tools/ui/react` — React 19 surface descriptors (`UniversalSite`).
- `@theme.tools/ui/elements` — Custom Element registration (`<tt-universal-site>`).
- `@theme.tools/ui/testing` — Deterministic conformance suite and test fixtures.
