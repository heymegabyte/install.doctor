import { useEffect, useRef } from 'react';

const MAX_CONCURRENT = 6;

// Module-scoped registry — every hook instance shares one Set so two pages
// both predicting `/quote` don't double-prefetch.
const prefetched = new Set<string>();

type IdleHandle = (cb: () => void, opts?: { timeout: number }) => number;
type CancelIdle = (id: number) => void;

/**
 * Schedule `cb` on idle if the browser supports it; fall back to a 200ms
 * `setTimeout`. Returns a disposer that cancels whichever scheduler ran.
 */
function onIdle(cb: () => void): () => void {
  if (typeof window === 'undefined') return () => {};
  const rIC = (window as unknown as { requestIdleCallback?: IdleHandle }).requestIdleCallback;
  const cIC = (window as unknown as { cancelIdleCallback?: CancelIdle }).cancelIdleCallback;
  if (typeof rIC === 'function') {
    const id = rIC(cb, { timeout: 2000 });
    return () => cIC?.(id);
  }
  const id = window.setTimeout(cb, 200);
  return () => window.clearTimeout(id);
}

/**
 * Insert `<link rel="prefetch">` tags for the given routes on browser idle.
 * De-dupes across the whole app so the same URL is fetched at most once per
 * session. Caps at 6 concurrent prefetches per render to respect Save-Data
 * users + slow connections.
 *
 * The links are NOT removed on unmount — once the browser has the bytes
 * cached, unloading the tag wouldn't free the cache anyway.
 *
 * @example
 *   usePrefetch(['/quote', '/work/dashboard', '/blog']);
 */
export function usePrefetch(routes: string[]): void {
  // Stable ref so the effect doesn't churn on every render when the parent
  // passes a fresh array literal.
  const routesRef = useRef<string[]>(routes);
  routesRef.current = routes;

  useEffect(() => {
    if (typeof document === 'undefined') return;
    const dispose = onIdle(() => {
      const fresh = routesRef.current.filter((r) => !prefetched.has(r)).slice(0, MAX_CONCURRENT);
      for (const href of fresh) {
        prefetched.add(href);
        const link = document.createElement('link');
        link.rel = 'prefetch';
        link.href = href;
        link.setAttribute('data-bcl-prefetch', '');
        document.head.appendChild(link);
      }
    });
    return dispose;
  }, []);
}
