/**
 * useGeolocation — battery-aware high-accuracy GPS stream for crew devices.
 *
 * Wraps `navigator.geolocation.watchPosition` with three live throttles:
 *   - default cadence:               5s   (battery ≥ 0.2 OR charging OR API absent)
 *   - low-battery throttle:          30s  (battery < 0.2)
 *   - critical-battery throttle:     60s  (battery < 0.1)
 *
 * Plus a 10m distance filter — samples within 10m of the last reported
 * position are dropped to save bandwidth + battery on idle stationary devices.
 *
 * Battery Status API is gated: Firefox + Safari don't support
 * `navigator.getBattery` so we gracefully degrade to the default cadence and
 * never throttle. When battery is supported, `chargingchange` + `levelchange`
 * listeners restart the watch with the appropriate `maximumAge`.
 *
 * Returns `{position, error, isStreaming, start, stop}`. Always cleans up
 * watch + listeners on unmount.
 */
import { useCallback, useEffect, useRef, useState } from 'react';

interface BatteryManager extends EventTarget {
  readonly level: number;
  readonly charging: boolean;
}

interface NavigatorWithBattery extends Navigator {
  getBattery?: () => Promise<BatteryManager>;
}

const DEFAULT_MAX_AGE_MS = 5_000;
const LOW_BATTERY_MAX_AGE_MS = 30_000;
const CRITICAL_BATTERY_MAX_AGE_MS = 60_000;
const TIMEOUT_MS = 15_000;
const DISTANCE_FILTER_M = 10;

export interface UseGeolocationReturn {
  position: GeolocationPosition | null;
  error: GeolocationPositionError | null;
  isStreaming: boolean;
  start: () => void;
  stop: () => void;
}

/**
 * Compute great-circle distance between two lat/lng pairs in meters
 * using the Haversine formula. Used to drop sub-10m jitter samples.
 */
function haversineMeters(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6_371_000; // Earth radius in meters
  const toRad = (deg: number): number => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Pick the right `maximumAge` based on current battery state. Charging
 * devices always get the fast cadence regardless of level (plugged-in
 * drivers are the common in-vehicle case).
 */
function cadenceFor(battery: BatteryManager | null): number {
  if (!battery) return DEFAULT_MAX_AGE_MS;
  if (battery.charging) return DEFAULT_MAX_AGE_MS;
  if (battery.level < 0.1) return CRITICAL_BATTERY_MAX_AGE_MS;
  if (battery.level < 0.2) return LOW_BATTERY_MAX_AGE_MS;
  return DEFAULT_MAX_AGE_MS;
}

export function useGeolocation(): UseGeolocationReturn {
  const [position, setPosition] = useState<GeolocationPosition | null>(null);
  const [error, setError] = useState<GeolocationPositionError | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);

  const watchIdRef = useRef<number | null>(null);
  const batteryRef = useRef<BatteryManager | null>(null);
  const lastPosRef = useRef<{ lat: number; lng: number } | null>(null);
  const wantStreamingRef = useRef(false);

  /**
   * Start (or restart) the watch with the current battery-derived cadence.
   * Safe to call repeatedly — clears any prior watch first.
   */
  const startWatch = useCallback(() => {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      setError({
        code: 2,
        message: 'Geolocation not supported in this browser.',
        PERMISSION_DENIED: 1,
        POSITION_UNAVAILABLE: 2,
        TIMEOUT: 3,
      } as GeolocationPositionError);
      return;
    }
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    const maximumAge = cadenceFor(batteryRef.current);
    watchIdRef.current = navigator.geolocation.watchPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        const last = lastPosRef.current;
        // Drop sub-10m jitter — saves bandwidth + battery on stationary crews.
        if (last && haversineMeters(last.lat, last.lng, latitude, longitude) < DISTANCE_FILTER_M) {
          return;
        }
        lastPosRef.current = { lat: latitude, lng: longitude };
        setPosition(pos);
        setError(null);
      },
      (err) => {
        setError(err);
      },
      {
        enableHighAccuracy: true,
        maximumAge,
        timeout: TIMEOUT_MS,
      },
    );
  }, []);

  const start = useCallback(() => {
    wantStreamingRef.current = true;
    setIsStreaming(true);
    startWatch();
  }, [startWatch]);

  const stop = useCallback(() => {
    wantStreamingRef.current = false;
    setIsStreaming(false);
    if (watchIdRef.current !== null && typeof navigator !== 'undefined' && navigator.geolocation) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    lastPosRef.current = null;
  }, []);

  // Battery API gating: subscribe to level/charging changes and restart the
  // watch with a fresh cadence whenever the relevant thresholds cross. The
  // API is only present in Chromium-based browsers — Firefox + Safari fall
  // through to the default cadence with no observer attached.
  useEffect(() => {
    if (typeof navigator === 'undefined') return;
    const nav = navigator as NavigatorWithBattery;
    if (typeof nav.getBattery !== 'function') return;

    let cancelled = false;
    let battery: BatteryManager | null = null;
    let prevCadence = DEFAULT_MAX_AGE_MS;

    const onChange = (): void => {
      if (!battery) return;
      batteryRef.current = battery;
      const next = cadenceFor(battery);
      if (next !== prevCadence && wantStreamingRef.current) {
        prevCadence = next;
        startWatch();
      }
    };

    void nav
      .getBattery()
      .then((b) => {
        if (cancelled) return;
        battery = b;
        batteryRef.current = b;
        prevCadence = cadenceFor(b);
        b.addEventListener('levelchange', onChange);
        b.addEventListener('chargingchange', onChange);
      })
      .catch(() => {
        // Browser pretended to support getBattery but rejected — silently
        // degrade to the default cadence.
      });

    return () => {
      cancelled = true;
      if (battery) {
        battery.removeEventListener('levelchange', onChange);
        battery.removeEventListener('chargingchange', onChange);
      }
    };
  }, [startWatch]);

  // Hard cleanup on unmount — clear the watch even if `stop` was never
  // called. Prevents zombie GPS listeners after a hot-reload or route nav.
  useEffect(() => {
    return () => {
      if (
        watchIdRef.current !== null &&
        typeof navigator !== 'undefined' &&
        navigator.geolocation
      ) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
    };
  }, []);

  return { position, error, isStreaming, start, stop };
}
