import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SettingsAddressBookComponent — saved addresses on the live Angular /dashboard.
 * Angular port of the React `customer/AddressBookCard`.
 *
 * Backends (all session-cookie scoped, all resolve under /api/customer-address-book):
 *   GET    /mine            → { ok, addresses[] }   (new session-scoped list)
 *   POST   /add             → { ok, address }
 *   PATCH  /:id             → { ok, address }
 *   DELETE /:id             → { ok }
 *   POST   /:id/set-default → { ok }
 *
 * Self-gates: 404 (flag off) → hide; 401 → "sign in" empty state. Dark-cockpit
 * Spartan styling. Pure helpers (formatAddress/isAddressFormValid/defaultIdOf/
 * EMPTY_FORM) are unit-tested in address-book.component.spec.ts.
 */
import { ChangeDetectionStrategy, Component, OnInit, signal } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HlmCardImports, HlmButton, HlmInput, HlmSpinner, StateBlockComponent, ConfirmDialog } from '../../shared/ui-spartan';

export interface AddressRow {
  readonly id: string;
  readonly label: string;
  readonly address_line_1: string;
  readonly address_line_2: string | null;
  readonly city: string;
  readonly state: string;
  readonly zip: string;
  readonly is_default: number;
}

export interface AddressForm {
  label: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  zip: string;
  setDefault: boolean;
}

export const EMPTY_FORM: AddressForm = {
  label: 'Home',
  addressLine1: '',
  addressLine2: '',
  city: '',
  state: 'NJ',
  zip: '',
  setDefault: false,
};

/** Pure: single-line address rendering. */
export function formatAddress(r: AddressRow): string {
  const l1 = r.address_line_2 ? `${r.address_line_1}, ${r.address_line_2}` : r.address_line_1;
  return `${l1} · ${r.city}, ${r.state} ${r.zip}`;
}

/** Pure: all required fields present (trimmed). */
export function isAddressFormValid(f: AddressForm): boolean {
  return (
    f.label.trim() !== '' &&
    f.addressLine1.trim() !== '' &&
    f.city.trim() !== '' &&
    f.state.trim() !== '' &&
    f.zip.trim() !== ''
  );
}

/** Pure: id of the default row, if any. */
export function defaultIdOf(rows: readonly AddressRow[]): string | null {
  return rows.find((r) => r.is_default === 1)?.id ?? null;
}

@Component({
  selector: 'app-settings-address-book',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, HlmInput, HlmSpinner, StateBlockComponent, FormsModule, NgTemplateOutlet, ConfirmDialog],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (available()) {
      <div hlmCard data-testid="address-book">
        <div hlmCardHeader class="flex flex-row items-baseline justify-between gap-3">
          <div>
            <h3 hlmCardTitle>Saved addresses</h3>
            <p hlmCardDescription>Reuse these to prefill future bookings.</p>
          </div>
          @if (!adding() && !editingId()) {
            <button hlmBtn variant="ghost" class="text-sm" (click)="startAdd()" data-testid="address-add">+ Add address</button>
          }
        </div>
        <div hlmCardContent>
          @if (signedOut()) {
            <app-state-block state="empty" emptyTitle="Sign in to manage your addresses" />
          } @else {
            @if (loading()) {
              <app-spinner [size]="20" />
            } @else if (rows().length === 0 && !adding()) {
              <p class="text-sm text-bcl-ink-muted">No saved addresses yet. Add one to prefill future bookings.</p>
            } @else {
              <ul class="grid gap-2">
                @for (r of rows(); track r.id) {
                  <li class="rounded-md border border-bcl-border bg-bcl-bg-elev p-3" [attr.data-testid]="'address-row-' + r.id">
                    @if (editingId() === r.id) {
                      <ng-container [ngTemplateOutlet]="formTpl" />
                    } @else {
                      <div class="flex flex-wrap items-start justify-between gap-2">
                        <div class="min-w-0 flex-1">
                          <div class="flex items-center gap-2">
                            <span class="font-semibold text-bcl-ink">{{ r.label }}</span>
                            @if (r.id === defaultId()) {
                              <span class="rounded-full bg-bcl-success/40 px-2 py-0.5 text-xs text-bcl-success">Default</span>
                            }
                          </div>
                          <p class="mt-1 text-sm text-bcl-ink-muted">{{ fmt(r) }}</p>
                        </div>
                        <div class="flex shrink-0 gap-2 text-xs">
                          @if (r.id !== defaultId()) {
                            <button hlmBtn variant="ghost" class="text-xs" [disabled]="busy()" (click)="makeDefault(r.id)">Set default</button>
                          }
                          <button hlmBtn variant="ghost" class="text-xs" (click)="startEdit(r)">Edit</button>
                          <button hlmBtn variant="ghost" class="text-xs text-destructive" [disabled]="busy()" (click)="askRemove(r.id)">Remove</button>
                        </div>
                      </div>
                    }
                  </li>
                }
              </ul>
            }

            @if (adding()) {
              <div class="mt-4 rounded-md border border-bcl-border bg-bcl-bg-elev p-3">
                <ng-container [ngTemplateOutlet]="formTpl" />
              </div>
            }

            @if (error(); as e) {
              <p class="mt-3 text-sm text-destructive" role="alert">{{ e }}</p>
            }
          }
        </div>
      </div>

      <ng-template #formTpl>
        <form class="grid gap-3" (ngSubmit)="submit()">
          <div class="grid grid-cols-2 gap-2">
            <label class="text-xs text-bcl-ink-muted">Label
              <input hlmInput class="mt-1" [(ngModel)]="form.label" name="label" maxlength="40"
                (blur)="markTouched('label')"
                [attr.aria-invalid]="isMissing('label', form.label) ? 'true' : null"
                [attr.aria-describedby]="isMissing('label', form.label) ? 'addr-form-err' : null" />
            </label>
            <label class="text-xs text-bcl-ink-muted">ZIP
              <input hlmInput class="mt-1" [(ngModel)]="form.zip" name="zip" maxlength="10" inputmode="numeric"
                (blur)="markTouched('zip')"
                [attr.aria-invalid]="isMissing('zip', form.zip) ? 'true' : null"
                [attr.aria-describedby]="isMissing('zip', form.zip) ? 'addr-form-err' : null" />
            </label>
          </div>
          <label class="text-xs text-bcl-ink-muted">Address line 1
            <input hlmInput class="mt-1" [(ngModel)]="form.addressLine1" name="addressLine1" maxlength="120"
              (blur)="markTouched('addressLine1')"
              [attr.aria-invalid]="isMissing('addressLine1', form.addressLine1) ? 'true' : null"
              [attr.aria-describedby]="isMissing('addressLine1', form.addressLine1) ? 'addr-form-err' : null" />
          </label>
          <label class="text-xs text-bcl-ink-muted">Address line 2 (apt, suite)
            <input hlmInput class="mt-1" [(ngModel)]="form.addressLine2" name="addressLine2" maxlength="120" />
          </label>
          <div class="grid grid-cols-3 gap-2">
            <label class="col-span-2 text-xs text-bcl-ink-muted">City
              <input hlmInput class="mt-1" [(ngModel)]="form.city" name="city" maxlength="60"
                (blur)="markTouched('city')"
                [attr.aria-invalid]="isMissing('city', form.city) ? 'true' : null"
                [attr.aria-describedby]="isMissing('city', form.city) ? 'addr-form-err' : null" />
            </label>
            <label class="text-xs text-bcl-ink-muted">State
              <input hlmInput class="mt-1 uppercase" [(ngModel)]="form.state" name="state" maxlength="3"
                (blur)="markTouched('state')"
                [attr.aria-invalid]="isMissing('state', form.state) ? 'true' : null"
                [attr.aria-describedby]="isMissing('state', form.state) ? 'addr-form-err' : null" />
            </label>
          </div>
          @if (adding()) {
            <label class="flex items-center gap-2 text-xs text-bcl-ink-muted">
              <input type="checkbox" [(ngModel)]="form.setDefault" name="setDefault" />
              Make this my default address
            </label>
          }
          @if (requiredMissingLabels(); as missing) {
            <p id="addr-form-err" class="text-xs font-medium text-destructive" role="alert">
              Required: {{ missing }}
            </p>
          }
          <div class="flex gap-2">
            <button hlmBtn type="submit" [disabled]="busy() || !valid()" data-testid="address-save">
              {{ busy() ? 'Saving…' : editingId() ? 'Save changes' : 'Add address' }}
            </button>
            <button hlmBtn type="button" variant="ghost" (click)="cancelEdit()">Cancel</button>
          </div>
        </form>
      </ng-template>
    }

    <app-confirm-dialog
      [open]="pendingRemoveId() !== null"
      title="Remove address"
      description="This removes the address from your saved list. You can add it again anytime."
      confirmLabel="Remove"
      (confirmed)="confirmRemove()"
      (cancelled)="pendingRemoveId.set(null)"
    />
  `,
})
export class SettingsAddressBookComponent implements OnInit {
  readonly rows = signal<AddressRow[]>([]);
  readonly available = signal(true);
  readonly signedOut = signal(false);
  readonly loading = signal(true);
  readonly busy = signal(false);
  readonly error = signal<string>('');
  readonly adding = signal(false);
  readonly editingId = signal<string | null>(null);
  readonly defaultId = signal<string | null>(null);
  /** The address id awaiting a focus-trapped delete confirmation (null = dialog closed). */
  readonly pendingRemoveId = signal<string | null>(null);
  /** Required fields the user has blurred — drives per-field error surfacing (Save is disabled
   * while invalid, so errors gate on BLUR/touched, never submit). Reset when the form opens/closes. */
  readonly touchedFields = signal<ReadonlySet<string>>(new Set<string>());

  form: AddressForm = { ...EMPTY_FORM };

  readonly fmt = formatAddress;

  ngOnInit(): void {
    void this.reload();
  }

  /** Required fields, in display order — the source for per-field + summary error surfacing. */
  private static readonly REQUIRED: ReadonlyArray<{ field: keyof AddressForm; label: string }> = [
    { field: 'label', label: 'Label' },
    { field: 'addressLine1', label: 'Address line 1' },
    { field: 'city', label: 'City' },
    { field: 'state', label: 'State' },
    { field: 'zip', label: 'ZIP' },
  ];

  /** Mark a field blurred so its empty-required error can surface (not before — never scream pristine). */
  markTouched(field: string): void {
    this.touchedFields.update((s) => new Set(s).add(field));
  }

  /** A blurred required field left blank is invalid (drives aria-invalid + the summary alert). */
  isMissing(field: string, value: string): boolean {
    return this.touchedFields().has(field) && value.trim() === '';
  }

  /** Comma-joined labels of the blurred-and-blank required fields, for the role=alert summary. */
  requiredMissingLabels(): string {
    const t = this.touchedFields();
    return SettingsAddressBookComponent.REQUIRED.filter(
      (r) => t.has(r.field) && String(this.form[r.field] ?? '').trim() === '',
    )
      .map((r) => r.label)
      .join(', ');
  }

  valid(): boolean {
    return isAddressFormValid(this.form);
  }

  async reload(): Promise<void> {
    this.error.set('');
    try {
      const res = await fetch('/api/customer-address-book/mine', { credentials: 'include' });
      if (res.status === 404) {
        this.available.set(false);
        this.loading.set(false);
        return;
      }
      if (res.status === 401) {
        this.signedOut.set(true);
        this.loading.set(false);
        return;
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json().catch(() => null)) as { addresses?: AddressRow[] } | null;
      const list = data?.addresses ?? [];
      this.rows.set(list);
      this.defaultId.set(defaultIdOf(list));
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Failed to load');
    } finally {
      this.loading.set(false);
    }
  }

  startAdd(): void {
    this.editingId.set(null);
    this.adding.set(true);
    this.form = { ...EMPTY_FORM };
    this.touchedFields.set(new Set());
  }

  startEdit(r: AddressRow): void {
    this.adding.set(false);
    this.editingId.set(r.id);
    this.form = {
      label: r.label,
      addressLine1: r.address_line_1,
      addressLine2: r.address_line_2 ?? '',
      city: r.city,
      state: r.state,
      zip: r.zip,
      setDefault: r.is_default === 1,
    };
    this.touchedFields.set(new Set());
  }

  cancelEdit(): void {
    this.adding.set(false);
    this.editingId.set(null);
    this.form = { ...EMPTY_FORM };
    this.touchedFields.set(new Set());
  }

  async submit(): Promise<void> {
    if (!this.valid()) return;
    this.busy.set(true);
    this.error.set('');
    const payload: Record<string, unknown> = {
      label: this.form.label,
      addressLine1: this.form.addressLine1,
      addressLine2: this.form.addressLine2 || undefined,
      city: this.form.city,
      state: this.form.state,
      zip: this.form.zip,
    };
    try {
      const editing = this.editingId();
      let res: Response;
      if (this.adding()) {
        if (this.form.setDefault) payload['setDefault'] = true;
        res = await fetch('/api/customer-address-book/add', {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      } else if (editing) {
        res = await fetch(`/api/customer-address-book/${encodeURIComponent(editing)}`, {
          method: 'PATCH',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      } else {
        return;
      }
      const data = (await res.json().catch(() => null)) as { ok?: boolean; error?: string } | null;
      if (!data?.ok) throw new Error(data?.error ?? 'save_failed');
      this.cancelEdit();
      await this.reload();
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Save failed');
    } finally {
      this.busy.set(false);
    }
  }

  /** Open the focus-trapped confirm dialog for a destructive address removal (replaces native confirm). */
  askRemove(id: string): void {
    this.pendingRemoveId.set(id);
  }

  /** Confirmed removal — DELETE the pending address, close the dialog, then reload. */
  async confirmRemove(): Promise<void> {
    const id = this.pendingRemoveId();
    if (id === null) return;
    this.pendingRemoveId.set(null);
    this.busy.set(true);
    try {
      const res = await fetch(`/api/customer-address-book/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      const data = (await res.json().catch(() => null)) as { ok?: boolean; error?: string } | null;
      if (!data?.ok) throw new Error(data?.error ?? 'remove_failed');
      await this.reload();
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Remove failed');
    } finally {
      this.busy.set(false);
    }
  }

  async makeDefault(id: string): Promise<void> {
    this.busy.set(true);
    try {
      const res = await fetch(`/api/customer-address-book/${encodeURIComponent(id)}/set-default`, {
        method: 'POST',
        credentials: 'include',
      });
      const data = (await res.json().catch(() => null)) as { ok?: boolean; error?: string } | null;
      if (!data?.ok) throw new Error(data?.error ?? 'set_default_failed');
      await this.reload();
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Failed');
    } finally {
      this.busy.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'address-book-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
