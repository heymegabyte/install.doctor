import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * TenantsComponent — list + create. Slug is auto-derived from name unless
 * the operator supplies one. Failures surface inline with the standard
 * `role="alert"` pattern.
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { firstValueFrom } from 'rxjs';
import { type ColumnDef } from '@tanstack/angular-table';
import {
  HlmButton,
  HlmInput,
  HlmFormField,
  SmartTableComponent,
} from '../../shared/ui-spartan';

interface TenantRow extends Record<string, unknown> {
  readonly id: string;
  readonly name: string;
  readonly slug: string;
  readonly created_at: number;
}

@Component({
  selector: 'app-admin-tenants',
  standalone: true,
  imports: [ReactiveFormsModule, HlmButton, HlmInput, HlmFormField, SmartTableComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="mb-6">
      <h1 class="text-2xl font-bold text-foreground">Tenants</h1>
      <p class="text-sm text-muted-foreground">
        Each tenant owns its own data + branding. Pin a tenant via the switcher.
      </p>
    </header>

    <section class="mb-8 rounded-xl border border-border bg-card p-5" aria-labelledby="create-h">
      <h2 id="create-h" class="mb-3 text-base font-semibold text-foreground">Create tenant</h2>
      <form [formGroup]="form" (ngSubmit)="submit()" class="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <app-form-field label="Name">
          <input hlmInput id="tenant-name" type="text" formControlName="name" autocomplete="organization" aria-label="Tenant name" />
        </app-form-field>
        <app-form-field label="Slug (optional)">
          <input hlmInput id="tenant-slug" type="text" formControlName="slug" autocomplete="off" class="font-mono" aria-label="Tenant slug" />
          <p class="mt-1 text-xs text-muted-foreground">Auto-derived from name if blank.</p>
        </app-form-field>
        <div class="flex items-end">
          <button hlmBtn type="submit" [disabled]="form.invalid || submitting()">
            {{ submitting() ? 'Creating…' : 'Create tenant' }}
          </button>
        </div>
      </form>
      @if (formError(); as e) {
        <p role="alert" class="mt-3 text-sm text-destructive">{{ e }}</p>
      }
      @if (formOk()) {
        <p role="status" class="mt-3 text-sm text-bcl-success">Tenant created.</p>
      }
    </section>

    @if (tenants().length === 0 && !loading()) {
      <div class="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
        No tenants yet — create your first above. The default tenant is seeded by migration 0072.
      </div>
    } @else {
      <app-smart-table
        [data]="tenantsArray()"
        [columns]="cols"
        [filterable]="true"
        [rowsActivatable]="false"
        filterPlaceholder="Filter tenants…"
      />
    }
  `,
})
export class TenantsComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly tenants = signal<readonly TenantRow[]>([]);
  /** Mutable copy for SmartTable's data input. */
  readonly tenantsArray = computed<TenantRow[]>(() => [...this.tenants()]);
  readonly loading = signal<boolean>(false);
  readonly submitting = signal<boolean>(false);
  readonly formError = signal<string | null>(null);
  readonly formOk = signal<boolean>(false);

  readonly form = new FormGroup({
    name: new FormControl<string>('', {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(2)],
    }),
    slug: new FormControl<string>('', { nonNullable: true }),
  });

  readonly cols: ColumnDef<TenantRow>[] = [
    { accessorKey: 'name', header: 'Name' },
    { accessorKey: 'slug', header: 'Slug' },
    { accessorKey: 'id', header: 'ID' },
    {
      accessorKey: 'created_at',
      header: 'Created',
      cell: (info) => new Date(info.getValue<number>() * 1000).toLocaleString(),
    },
  ];

  ngOnInit(): void {
    void this.refresh();
  }

  async refresh(): Promise<void> {
    this.loading.set(true);
    try {
      const r = await firstValueFrom(
        this.http.get<{ ok: boolean; tenants?: readonly TenantRow[] }>('/api/admin/tenants', {
          withCredentials: true,
        }),
      );
      this.tenants.set(r.tenants ?? []);
    } catch (err) {
      this.formError.set(`Failed to load tenants: ${(err as Error).message}`);
    } finally {
      this.loading.set(false);
    }
  }

  async submit(): Promise<void> {
    this.formError.set(null);
    this.formOk.set(false);
    if (this.form.invalid) return;
    this.submitting.set(true);
    const { name, slug } = this.form.getRawValue();
    try {
      await firstValueFrom(
        this.http.post<{ ok: boolean; error?: string }>(
          '/api/admin/tenants',
          { name, slug: slug || undefined },
          { withCredentials: true },
        ),
      );
      this.formOk.set(true);
      this.form.reset({ name: '', slug: '' });
      await this.refresh();
    } catch (err) {
      const e = err as { error?: { error?: string }; message?: string };
      const msg =
        e.error?.error === 'slug_exists' ? 'That slug is taken.' : (e.message ?? 'Create failed.');
      this.formError.set(msg);
    } finally {
      this.submitting.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'tenants-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
