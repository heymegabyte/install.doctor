import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CrewInboxCardComponent — worker notification inbox on the crew surface.
 * Angular port of React `work/InboxPanel`. Live surface = Angular /dashboard, crew.
 *
 * Verified by mount (`app.route('/api/work/inbox', workerInbox)`):
 *   GET  /api/work/inbox?limit=50 → { items:[{id,kind,subject,body,action_url,priority,read_at,created_at}], unread }
 *   POST /api/work/inbox/:id/read
 *   POST /api/work/inbox/bulk-read
 * System-populated → list + mark-read is a complete management loop. Self-gates
 * 401/empty → hide. Pure helpers isUnread/unreadCount/itemTitle unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, signal } from '@angular/core';
import { HlmCardImports, HlmButton } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export interface InboxItem {
  readonly id: string;
  readonly kind: string;
  readonly subject: string | null;
  readonly body: string | null;
  readonly action_url: string | null;
  readonly read_at: string | null;
  readonly created_at: string;
}

/** Pure: an item is unread when read_at is empty. */
export function isUnread(item: InboxItem): boolean {
  return !item.read_at;
}

/** Pure: count unread items. */
export function unreadCount(items: readonly InboxItem[]): number {
  return items.filter(isUnread).length;
}

/** Pure: one-line title — subject → body → kind. */
export function itemTitle(item: InboxItem): string {
  return (item.subject ?? item.body ?? item.kind ?? 'Notification').trim() || 'Notification';
}

interface InboxResponse {
  readonly items?: readonly InboxItem[];
  readonly unread?: number;
}

@Component({
  selector: 'app-crew-inbox-card',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <div hlmCard bclReveal data-testid="crew-inbox-card">
        <div hlmCardHeader class="flex flex-row items-center justify-between gap-3">
          <div>
            <h3 hlmCardTitle>
              Inbox
              @if (unread() > 0) {
                <span class="ml-2 rounded-full bg-bcl-accent/20 px-2 py-0.5 text-xs text-bcl-accent">{{ unread() }}</span>
              }
            </h3>
            <p hlmCardDescription>Dispatch + account notifications.</p>
          </div>
          @if (unread() > 0) {
            <button hlmBtn variant="ghost" class="text-xs" [disabled]="busy()" (click)="markAll()" data-testid="inbox-bulk-read">
              Mark all read
            </button>
          }
        </div>
        <div hlmCardContent>
          <ul class="grid gap-2">
            @for (it of items(); track it.id) {
              <li
                class="rounded-md border px-3 py-2 text-sm"
                [class.border-bcl-accent\/40]="unreadOf(it)"
                [class.bg-bcl-accent\/5]="unreadOf(it)"
                [class.border-bcl-border]="!unreadOf(it)"
                [class.bg-bcl-bg-elev]="!unreadOf(it)"
              >
                <div class="flex items-start justify-between gap-2">
                  <div class="min-w-0">
                    <span class="font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">{{ it.kind }}</span>
                    <p class="text-bcl-ink" [class.font-semibold]="unreadOf(it)">{{ title(it) }}</p>
                    @if (it.body && it.subject) { <p class="mt-0.5 text-xs text-bcl-ink-muted">{{ it.body }}</p> }
                    @if (it.action_url) {
                      <a [href]="it.action_url" class="mt-1 inline-block text-xs text-bcl-accent">Open →</a>
                    }
                  </div>
                  @if (unreadOf(it)) {
                    <button hlmBtn variant="ghost" class="shrink-0 text-xs" [disabled]="pending().has(it.id)" (click)="markRead(it.id)">Mark read</button>
                  }
                </div>
              </li>
            }
          </ul>
          @if (error(); as e) {
            <p class="mt-3 text-sm text-destructive" role="alert">{{ e }}</p>
          }
        </div>
      </div>
    }
  `,
})
export class CrewInboxCardComponent implements OnInit {
  readonly visible = signal(false);
  readonly items = signal<readonly InboxItem[]>([]);
  readonly unread = computed(() => unreadCount(this.items()));
  readonly pending = signal<Set<string>>(new Set());
  readonly busy = signal(false);
  readonly error = signal<string>('');

  readonly title = itemTitle;
  readonly unreadOf = isUnread;

  ngOnInit(): void {
    void this.reload();
  }

  async reload(): Promise<void> {
    this.error.set('');
    try {
      const res = await fetch('/api/work/inbox?limit=50', { credentials: 'include' });
      if (!res.ok) {
        this.visible.set(false); // 401 anon
        return;
      }
      const data = (await res.json().catch(() => null)) as InboxResponse | null;
      const items = data?.items ?? [];
      this.items.set(items);
      this.visible.set(items.length > 0); // empty → hide
    } catch {
      this.visible.set(false);
    }
  }

  async markRead(id: string): Promise<void> {
    const next = new Set(this.pending()).add(id);
    this.pending.set(next);
    try {
      const res = await fetch(`/api/work/inbox/${encodeURIComponent(id)}/read`, {
        method: 'POST',
        credentials: 'include',
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      // optimistic local mark
      this.items.set(
        this.items().map((it) => (it.id === id ? { ...it, read_at: new Date().toISOString() } : it)),
      );
    } catch {
      this.error.set('Could not mark that read. Try again.');
    } finally {
      const p = new Set(this.pending());
      p.delete(id);
      this.pending.set(p);
    }
  }

  async markAll(): Promise<void> {
    this.busy.set(true);
    try {
      const res = await fetch('/api/work/inbox/bulk-read', { method: 'POST', credentials: 'include' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const now = new Date().toISOString();
      this.items.set(this.items().map((it) => (it.read_at ? it : { ...it, read_at: now })));
    } catch {
      this.error.set('Could not mark all read. Try again.');
    } finally {
      this.busy.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'inbox-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
