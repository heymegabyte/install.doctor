import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * hlm-label — form label directive (vendored helm). Themed muted-foreground
 * with disabled-peer handling.
 */
import { Directive, computed, input } from '@angular/core';
import { cn } from '../utils/cn';

@Directive({
  selector: 'label[hlmLabel]',
  standalone: true,
  host: { '[class]': '_computedClass()' },
})
export class HlmLabel {
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly _computedClass = computed(() =>
    cn(
      'text-sm font-medium leading-none text-foreground peer-disabled:cursor-not-allowed peer-disabled:opacity-70',
      this.userClass(),
    ),
  );
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'hlm-label',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
