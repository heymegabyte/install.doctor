import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * MinimalFooter — the dashboard's tiny chrome footer. Matches the Wave 25
 * brief: company / © / Privacy · Terms · Status · Support / version. Never
 * import the marketing footer on a dashboard route.
 */
import { ChangeDetectionStrategy, Component, computed } from '@angular/core';

@Component({
  selector: 'app-minimal-footer',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <footer
      class="border-t border-bcl-border bg-bcl-bg text-xs text-bcl-ink-muted"
      aria-label="Dashboard footer"
    >
      <div class="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3">
        <span class="font-mono">Brick Labor &middot; &copy; {{ year() }}</span>
        <ul class="flex flex-wrap items-center gap-3">
          <li><a href="/privacy" class="hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent">Privacy</a></li>
          <li><a href="/terms" class="hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent">Terms</a></li>
          <li><a href="/status" class="hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent">Status</a></li>
          <li><a href="/help" class="hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent">Support</a></li>
        </ul>
        <span class="font-mono">v{{ version }}</span>
      </div>
    </footer>
  `,
})
export class MinimalFooterComponent {
  protected readonly version = '0.1.0';
  protected readonly year = computed(() => new Date().getFullYear());
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'minimal-footer-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
