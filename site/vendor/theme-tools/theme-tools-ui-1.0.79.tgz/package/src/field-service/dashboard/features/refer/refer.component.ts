import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * ReferComponent — customer self-serve neighbor referral mint UI.
 * Mirrors the React NeighborReferralCard at apps/web/components/customer/.
 * Reads /api/customer-referrals/me for existing state, POSTs to
 * /api/neighbor-referrals/mint to mint a new slug.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  effect,
  inject,
  signal,
  untracked,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, finalize, of } from 'rxjs';
import { AuthService } from '../../core/auth.service';
import { StateBlockComponent } from '../../shared/ui-spartan';
import { routeFade, reducedMotion } from '../../shared/animations';

const CITY_OPTIONS = [
  { slug: 'newark', label: 'Newark' },
  { slug: 'jersey-city', label: 'Jersey City' },
  { slug: 'hoboken', label: 'Hoboken' },
  { slug: 'elizabeth', label: 'Elizabeth' },
  { slug: 'east-orange', label: 'East Orange' },
  { slug: 'paterson', label: 'Paterson' },
  { slug: 'union-city', label: 'Union City' },
  { slug: 'bayonne', label: 'Bayonne' },
  { slug: 'irvington', label: 'Irvington' },
  { slug: 'montclair', label: 'Montclair' },
  { slug: 'bloomfield', label: 'Bloomfield' },
  { slug: 'west-orange', label: 'West Orange' },
];

interface NeighborLanding {
  slug: string;
  displayName: string | null;
  city: string | null;
  views: number;
  code: string;
}

interface MeReferralResponse {
  ok: boolean;
  neighborLanding: NeighborLanding | null;
}

@Component({
  selector: 'app-refer',
  standalone: true,
  imports: [FormsModule, RouterLink, StateBlockComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header class="bcl-rise mb-6 rounded-2xl border border-bcl-border bcl-grain p-6">
      <p class="bcl-eyebrow mb-2">Wave 27 · Neighbor Referrals</p>
      <h1 class="font-display text-3xl font-extrabold tracking-tight text-bcl-ink">
        Send a neighbor a $25-off link
      </h1>
      <p class="mt-2 max-w-2xl text-sm text-bcl-ink-muted">
        Mint a personalized <span class="font-mono">/by/your-name-newark</span>
        URL. They get $25 off; you get $25 credit when their job finishes.
      </p>
    </header>

    @if (needsAuth()) {
      <div
        class="rounded-2xl border border-dashed border-bcl-border p-10 text-center"
        data-testid="refer-signin"
      >
        <p class="text-2xl" aria-hidden="true">🎁</p>
        <p class="mt-2 text-base font-semibold text-bcl-ink">Sign in to mint your link</p>
        <p class="mx-auto mt-1 max-w-md text-sm text-bcl-ink-muted">
          Log in to generate your personal $25-off referral link and track its views.
        </p>
        <a
          [routerLink]="['/login']"
          [queryParams]="{ as: 'customer', next: '/refer' }"
          class="mt-4 inline-flex items-center justify-center rounded-md bg-bcl-accent px-4 py-2 text-sm font-extrabold text-bcl-bg focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        >
          Sign in →
        </a>
      </div>
    } @else if (loading()) {
      <p class="text-sm text-bcl-ink-muted">Loading…</p>
    } @else if (loadError(); as err) {
      <app-state-block
        [state]="'error'"
        errorTitle="Couldn't load your referral link"
        [errorDetail]="err"
        (retry)="reload()"
      />
    } @else if (landing(); as l) {
      <section class="bcl-glass bcl-fade-in p-6">
        <p class="bcl-eyebrow mb-1">Your live link</p>
        <p class="font-mono text-bcl-accent break-all">{{ liveUrl(l) }}</p>
        <div class="mt-3 grid grid-cols-2 gap-3 text-sm text-bcl-ink">
          <div>
            <span class="block text-bcl-ink-muted text-xs">Code</span>
            <span class="font-mono">{{ l.code }}</span>
          </div>
          <div>
            <span class="block text-bcl-ink-muted text-xs">Views</span>
            <span class="bcl-tabular font-bold">{{ l.views }}</span>
          </div>
        </div>
        <div class="mt-4 flex flex-wrap gap-2">
          <button
            type="button"
            (click)="copy(l)"
            class="rounded-md bg-bcl-accent px-4 py-2 text-sm font-extrabold text-bcl-bg focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
          >
            {{ copied() ? 'Copied ✓' : 'Copy link' }}
          </button>
          <a
            [href]="smsHref(l)"
            class="rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-4 py-2 text-sm font-bold text-bcl-ink"
          >
            Share via SMS
          </a>
          <a
            [href]="mailHref(l)"
            class="rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-4 py-2 text-sm font-bold text-bcl-ink"
          >
            Share via email
          </a>
        </div>
      </section>
    } @else {
      <section class="bcl-glass bcl-fade-in p-6">
        <p class="bcl-eyebrow mb-1">Generate your link</p>
        <h2 class="font-display text-xl font-extrabold">Pick a display name + city</h2>
        <form (submit)="mint($event)" class="mt-4 grid gap-3 sm:grid-cols-2">
          <label class="flex flex-col gap-1">
            <span class="bcl-eyebrow">Display name</span>
            <input
              type="text"
              [(ngModel)]="form.displayName"
              name="displayName"
              required
              minlength="1"
              maxlength="40"
              placeholder="e.g. Maria S"
              class="rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-3 py-2 text-sm text-bcl-ink"
            />
          </label>
          <label class="flex flex-col gap-1">
            <span class="bcl-eyebrow">City</span>
            <select
              [(ngModel)]="form.city"
              name="city"
              class="rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-3 py-2 text-sm text-bcl-ink"
            >
              @for (c of cityOptions; track c.slug) {
                <option [value]="c.slug">{{ c.label }}</option>
              }
            </select>
          </label>
          <button
            type="submit"
            [disabled]="busy() || !form.displayName.trim()"
            class="sm:col-span-2 inline-flex items-center justify-center rounded-md bg-bcl-accent px-4 py-2 text-sm font-extrabold text-bcl-bg disabled:opacity-60"
          >
            {{ busy() ? 'Creating…' : 'Generate link →' }}
          </button>
        </form>
        @if (error()) {
          <p class="mt-3 text-sm text-amber-300">{{ error() }}</p>
        }
      </section>
    }

    <span class="sr-only" role="status" aria-live="polite">{{ copied() ? 'Referral link copied to clipboard' : '' }}</span>
  `,
})
export class ReferComponent {
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);
  private readonly auth = inject(AuthService);

  readonly cityOptions = CITY_OPTIONS;
  readonly form = { displayName: '', city: 'newark' };
  readonly loading = signal(true);
  readonly busy = signal(false);
  readonly copied = signal(false);
  readonly landing = signal<NeighborLanding | null>(null);
  readonly error = signal<string | null>(null);
  /** Initial-load failure (distinct from `error`, which is the mint-form POST error). */
  readonly loadError = signal<string | null>(null);

  /**
   * /dashboard/refer has no role guard, so the shell renders for a guest.
   * `/api/customer-referrals/me` 401s a signed-out visitor → a red console
   * error. Skip the fetch when signed out; show a sign-in affordance instead.
   */
  protected readonly needsAuth = computed(() => !this.auth.authenticated());

  constructor() {
    let wasAuthed = !this.needsAuth();
    effect(() => {
      const now = !this.needsAuth();
      if (now && !wasAuthed) {
        untracked(() => this.reload());
      }
      wasAuthed = now;
    });
    if (this.needsAuth()) {
      this.loading.set(false);
      return;
    }
    this.reload();
  }

  /**
   * (Re)fetch the customer's referral state. A FAILED load now surfaces a
   * distinct error + retry (via <app-state-block>) instead of silently falling
   * through to the blank mint form — the create-form is reserved for a genuine
   * no-link-yet empty, never a fetch failure (the lying-empty this fixes).
   */
  reload(): void {
    this.loading.set(true);
    this.loadError.set(null);
    this.http
      .get<MeReferralResponse>('/api/customer-referrals/me', { withCredentials: true })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((err: { status?: number }) => {
          this.loadError.set(
            err?.status
              ? `We couldn't reach the referral service (HTTP ${err.status}). Try again.`
              : "We couldn't reach the referral service. Try again.",
          );
          return of<MeReferralResponse>({ ok: false, neighborLanding: null });
        }),
        finalize(() => this.loading.set(false)),
      )
      .subscribe((r) => {
        if (!this.loadError()) this.landing.set(r.neighborLanding ?? null);
      });
  }

  liveUrl(l: NeighborLanding): string {
    return `https://bricklabor.com/by/${l.slug}`;
  }

  smsHref(l: NeighborLanding): string {
    const body = `Use my Brick Labor code ${l.code} for $25 off your first move: ${this.liveUrl(l)}`;
    return `sms:?body=${encodeURIComponent(body)}`;
  }

  mailHref(l: NeighborLanding): string {
    const body = `Use my Brick Labor code ${l.code} for $25 off your first move: ${this.liveUrl(l)}`;
    return `mailto:?subject=${encodeURIComponent('Brick Labor — $25 off')}&body=${encodeURIComponent(body)}`;
  }

  async copy(l: NeighborLanding): Promise<void> {
    try {
      await navigator.clipboard.writeText(this.liveUrl(l));
      this.copied.set(true);
      setTimeout(() => this.copied.set(false), 2000);
    } catch {
      /* ignore */
    }
  }

  mint(evt: Event): void {
    evt.preventDefault();
    if (!this.form.displayName.trim() || this.busy()) return;
    this.busy.set(true);
    this.error.set(null);
    this.http
      .post<{
        ok: boolean;
        slug?: string;
        code?: string;
        displayName?: string;
        city?: string;
        error?: string;
      }>('/api/neighbor-referrals/mint', this.form, { withCredentials: true })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((err: { status?: number; error?: { error?: string } }) =>
          of({ ok: false, error: err.error?.error ?? `HTTP ${err.status}` }),
        ),
        finalize(() => this.busy.set(false)),
      )
      .subscribe((raw) => {
        const r = raw as {
          ok: boolean;
          slug?: string;
          code?: string;
          displayName?: string;
          city?: string;
          error?: string;
        };
        if (r.ok && r.slug && r.code) {
          this.landing.set({
            slug: r.slug,
            code: r.code,
            displayName: r.displayName ?? this.form.displayName,
            city: r.city ?? this.form.city,
            views: 0,
          });
        } else {
          this.error.set(
            r.error === 'no_referral_code'
              ? 'Book your next job first — we mint a code automatically.'
              : r.error === 'unauthorized'
                ? 'Sign in to generate a link.'
                : `Couldn't create your link (${r.error ?? 'unknown'}). Try again.`,
          );
        }
      });
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'refer-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
