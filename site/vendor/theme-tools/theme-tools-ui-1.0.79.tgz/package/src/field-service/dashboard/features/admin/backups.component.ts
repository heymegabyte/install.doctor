import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminBackupsComponent — D1 backup snapshots (R2) on the admin console.
 * Live surface = Angular /dashboard/admin.
 *
 * Unblocked 2026-06-03: `/api/admin/backup` migrated from OWNER_INVOICE_KEY
 * Bearer-only to the shared `ownerOrSuperAdmin` gate.
 *   GET /api/admin/backup/d1/list → { ok, items:[{key,size,uploaded}] }
 *   GET /api/admin/backup/d1/object?key=… → download (link only)
 * READ-ONLY: the POST that RUNS a fresh backup is an operator action. Pure
 * helpers formatBytes/backupName/downloadHref unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmCardImports } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export interface BackupItem {
  readonly key: string;
  readonly size: number;
  readonly uploaded: string;
}

/** Pure: bytes → human size. */
export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  let n = bytes;
  let u = 0;
  while (n >= 1024 && u < units.length - 1) {
    n /= 1024;
    u++;
  }
  return `${n.toFixed(u === 0 ? 0 : 1)} ${units[u]}`;
}

/** Pure: the filename portion of an R2 backup key. */
export function backupName(key: string): string {
  return (key ?? '').split('/').pop() || key || '—';
}

/** Pure: the download endpoint for a backup object. */
export function downloadHref(key: string): string {
  return `/api/admin/backup/d1/object?key=${encodeURIComponent(key)}`;
}

interface ListResponse {
  readonly ok: boolean;
  readonly items?: readonly BackupItem[];
}

@Component({
  selector: 'app-admin-backups',
  standalone: true,
  imports: [...HlmCardImports, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard bclReveal data-testid="admin-backups">
      <div hlmCardHeader>
        <h3 hlmCardTitle>D1 backups</h3>
        <p hlmCardDescription>Database snapshots in R2. Running a fresh backup is an operator action.</p>
      </div>
      <div hlmCardContent>
        @if (loading()) {
          <p class="text-sm text-bcl-ink-muted">Loading backups…</p>
        } @else if (error()) {
          <p class="text-sm text-bcl-warn" role="status">{{ error() }}</p>
        } @else if (items().length === 0) {
          <p class="text-sm text-bcl-ink-muted">No backups found.</p>
        } @else {
          <ul class="grid gap-2">
            @for (b of items(); track b.key) {
              <li class="flex items-center justify-between gap-2 rounded-md border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm">
                <span class="min-w-0">
                  <span class="truncate font-mono text-bcl-ink">{{ name(b.key) }}</span>
                  <span class="ml-2 text-xs text-bcl-ink-muted">{{ size(b.size) }} · {{ when(b.uploaded) }}</span>
                </span>
                <a [href]="href(b.key)" class="shrink-0 text-xs text-bcl-accent" data-testid="backup-download">Download</a>
              </li>
            }
          </ul>
        }
      </div>
    </div>
  `,
})
export class AdminBackupsComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly items = signal<readonly BackupItem[]>([]);
  readonly loading = signal(true);
  readonly error = signal<string>('');

  readonly size = formatBytes;
  readonly name = backupName;
  readonly href = downloadHref;

  ngOnInit(): void {
    void this.load();
  }

  when(iso: string): string {
    const t = Date.parse(iso);
    return Number.isNaN(t)
      ? iso
      : new Date(t).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  }

  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set('');
    try {
      const r = await firstValueFrom(
        this.http.get<ListResponse>('/api/admin/backup/d1/list', { withCredentials: true }),
      );
      // newest first
      const items = [...(r?.ok ? (r.items ?? []) : [])].sort((a, b) => b.uploaded.localeCompare(a.uploaded));
      this.items.set(items);
    } catch {
      this.error.set('Sign in as an operator to view backups.');
    } finally {
      this.loading.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'backups-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
