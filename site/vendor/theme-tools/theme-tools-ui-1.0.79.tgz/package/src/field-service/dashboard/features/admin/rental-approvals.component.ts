import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * RentalApprovalsComponent — U-Haul Risk Center at /admin/rental-approvals.
 *
 * Surfaces GET /api/admin/rental-approvals: every upcoming, non-terminal booking
 * that carries a U-Haul/vehicle rental, enriched with the SHARED `assessRentalRisk`
 * verdict (security-deposit tier, risk level, `requiresApproval` gate). The booking
 * form already DISCLOSES the deposit + terms to the customer (backlog item 12 slice
 * a); this is the operator's matching view of the SAME deterministic engine — so the
 * customer and the dispatcher see the identical verdict.
 *
 * A box truck is the single highest-liability thing Brick Labor puts in a customer's
 * hands. High/severe rentals (≥$500 deposit) carry an "approval needed" pill so an
 * operator reviews before dispatch. Read-only — REPORTS the risk; enforcing the gate
 * on dispatch is the follow-on behavior slice.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HlmCardImports } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

/** One operator-facing truck line (mirrors the worker's ApprovalTruck). */
export interface ApprovalTruck {
  readonly id: string;
  readonly label: string;
  readonly qty: number;
}

/** Combined operator-gate state (mirrors the worker's RentalApprovalState). */
export type RentalApprovalState = 'not_required' | 'blocked' | 'approved' | 'rejected';

/** The operator's persisted ruling on one rental booking (mirrors the worker). */
export interface RentalApprovalRuling {
  readonly decision: 'approved' | 'rejected' | null;
  readonly by: string | null;
  readonly at: string | null;
  readonly note: string | null;
  readonly state: RentalApprovalState;
}

/** One rental booking the operator reviews (mirrors the worker's RentalApproval). */
export interface RentalApproval {
  readonly bookingId: string;
  readonly customerName: string;
  readonly preferredDate: string;
  readonly preferredTime: string;
  readonly city: string;
  readonly status: string;
  readonly trucks: ReadonlyArray<ApprovalTruck>;
  readonly truckCount: number;
  readonly depositCents: number;
  readonly riskLevel: 'none' | 'low' | 'medium' | 'high' | 'severe';
  readonly requiresApproval: boolean;
  readonly rentalsCents: number;
  readonly approval: RentalApprovalRuling;
  /** Count of liability terms this rental required the customer to accept. */
  readonly requiredAcks: number;
  /** The acknowledgment ids the customer accepted at booking (consent record, item 12b). */
  readonly acceptedAcks: ReadonlyArray<string>;
}

interface ApprovalsResponse {
  readonly ok: boolean;
  readonly approvals?: ReadonlyArray<RentalApproval>;
  readonly counts?: { total: number; needingApproval: number; heldDepositCents: number };
  readonly error?: string;
}

interface RulingResponse {
  readonly ok: boolean;
  readonly error?: string;
  readonly approval?: { decision: 'approved' | 'rejected'; by: string | null; at: string | null; note: string | null };
}

/**
 * Pure: the operator-gate state → a contrast-safe badge ({ label, class }), or null when
 * no badge belongs on the card (a `not_required` low-risk rental shows nothing). Tested.
 */
export function approvalStateBadge(
  state: RentalApprovalState,
): { label: string; class: string } | null {
  switch (state) {
    case 'approved':
      return { label: 'Approved for dispatch', class: 'bg-green-500/15 text-green-300' };
    case 'rejected':
      return { label: 'Declined', class: 'bg-destructive/15 text-destructive' };
    case 'blocked':
      return { label: 'Awaiting operator review', class: 'bg-amber-500/15 text-amber-300' };
    default:
      return null;
  }
}

/**
 * Pure: the customer's liability-consent record → a contrast-safe badge. The booking form
 * gates submit on accepting every term and the server re-validates + persists the accepted
 * ids (item 12b), so a live booking always shows complete; this surfaces the durable proof
 * for the operator + audit trail. Returns null when the rental required no terms. Tested.
 */
export function consentBadge(
  acceptedCount: number,
  requiredCount: number,
): { label: string; class: string } | null {
  if (requiredCount <= 0) return null;
  const complete = acceptedCount >= requiredCount;
  return {
    label: complete
      ? `${requiredCount} liability term${requiredCount === 1 ? '' : 's'} accepted`
      : `${acceptedCount}/${requiredCount} terms accepted`,
    class: complete ? 'bg-green-500/15 text-green-300' : 'bg-amber-500/15 text-amber-300',
  };
}

/** Pure: cents → "$250" (whole-dollar, no trailing .00). Tested. */
export function formatDeposit(cents: number): string {
  return `$${Math.round(cents / 100).toLocaleString('en-US')}`;
}

/** Pure: a risk level → a contrast-safe pill class on the dark panel. Tested. */
export function riskPillClass(level: RentalApproval['riskLevel']): string {
  switch (level) {
    case 'severe':
      return 'bg-destructive/15 text-destructive';
    case 'high':
      return 'bg-amber-500/15 text-amber-300';
    case 'medium':
      return 'bg-yellow-500/15 text-yellow-200';
    default:
      return 'bg-green-500/15 text-green-300';
  }
}

/**
 * Pure: the header verdict for the operator. Names the count needing review so the
 * dispatcher knows at a glance whether anything is blocked. Tested.
 */
export function approvalsHeadline(needingApproval: number, total: number): string {
  if (total === 0) return 'No upcoming rentals';
  if (needingApproval === 0) return `${total} upcoming rental${total === 1 ? '' : 's'} — none need approval`;
  return `${needingApproval} of ${total} need operator approval before dispatch`;
}

@Component({
  selector: 'app-admin-rental-approvals',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [...HlmCardImports, BclRevealDirective],
  template: `
    <header class="mb-4 flex items-center justify-between">
      <div>
        <h1 class="text-2xl font-bold text-foreground">U-Haul risk center</h1>
        <p class="text-sm text-muted-foreground">
          Upcoming rentals with their security-deposit tier — high/severe need approval before dispatch.
        </p>
      </div>
      <button
        type="button"
        class="rounded-md border border-border px-3 py-1.5 text-sm text-muted-foreground transition-all duration-[333ms] hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        (click)="refresh()"
      >
        Refresh
      </button>
    </header>

    @if (error(); as e) {
      <div hlmCard class="p-4"><p class="text-sm text-destructive">{{ e }}</p></div>
    } @else if (loaded()) {
      <div class="mb-4 flex flex-wrap items-center gap-3">
        <span
          class="rounded-full px-3 py-1 text-xs font-semibold transition-all duration-[333ms]"
          [class]="needingApproval() > 0 ? 'bg-amber-500/15 text-amber-300' : 'bg-green-500/15 text-green-300'"
          data-testid="rental-approvals-headline"
        >
          {{ headline() }}
        </span>
        @if (heldDepositCents() > 0) {
          <span class="rounded-full bg-muted px-3 py-1 text-xs font-medium text-muted-foreground">
            {{ deposit(heldDepositCents()) }} in security deposits held
          </span>
        }
      </div>

      @if (approvals().length === 0) {
        <div hlmCard class="p-6 text-center">
          <p class="text-sm text-muted-foreground">No upcoming bookings carry a U-Haul rental.</p>
        </div>
      } @else {
        <ul class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3" aria-label="Upcoming rental bookings">
          @for (a of approvals(); track a.bookingId; let i = $index) {
            <li hlmCard bclReveal [revealDelay]="i * 60" class="p-4" data-testid="rental-approval-card">
              <div class="flex items-start justify-between gap-2">
                <div>
                  <h3 class="text-sm font-semibold text-foreground">{{ a.customerName }}</h3>
                  <p class="text-xs text-muted-foreground">
                    {{ a.preferredDate }}{{ a.preferredTime ? ' · ' + a.preferredTime : '' }}{{ a.city ? ' · ' + a.city : '' }}
                  </p>
                </div>
                <span
                  class="shrink-0 rounded-full px-2.5 py-0.5 text-xs font-medium capitalize transition-all duration-[333ms]"
                  [class]="pill(a.riskLevel)"
                >
                  {{ a.riskLevel }}
                </span>
              </div>

              <ul class="mt-3 flex flex-wrap gap-2" aria-label="Trucks">
                @for (t of a.trucks; track t.id) {
                  <li class="rounded-full bg-muted px-2.5 py-0.5 text-xs font-medium text-muted-foreground">
                    {{ t.label }}
                  </li>
                }
              </ul>

              <dl class="mt-3 space-y-1 text-sm">
                <div class="flex justify-between">
                  <dt class="text-muted-foreground">Security deposit</dt>
                  <dd class="font-semibold tabular-nums text-foreground">{{ deposit(a.depositCents) }}</dd>
                </div>
                <div class="flex justify-between">
                  <dt class="text-muted-foreground">Status</dt>
                  <dd class="text-foreground">{{ a.status }}</dd>
                </div>
              </dl>

              @if (consent(a.acceptedAcks.length, a.requiredAcks); as c) {
                <p
                  class="mt-3 inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium transition-all duration-[333ms]"
                  [class]="c.class"
                  data-testid="rental-consent-badge"
                >
                  {{ c.label }}
                </p>
              }

              @if (badge(a.approval.state); as b) {
                <p
                  class="mt-3 rounded-md px-2.5 py-1.5 text-xs font-medium transition-all duration-[333ms]"
                  [class]="b.class"
                  data-testid="rental-approval-badge"
                >
                  {{ b.label }}@if (a.approval.by) { · {{ a.approval.by }} }
                </p>
              }

              @if (a.requiresApproval) {
                <div class="mt-3 flex flex-wrap gap-2" role="group" aria-label="Operator ruling" data-testid="rental-approval-actions">
                  <button
                    type="button"
                    [disabled]="deciding() === a.bookingId"
                    (click)="decide(a.bookingId, 'approved')"
                    class="flex-1 rounded-md bg-green-500/15 px-3 py-1.5 text-xs font-semibold text-green-300 transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-green-500/25 focus-visible:outline focus-visible:outline-2 focus-visible:outline-green-400 disabled:opacity-50"
                    data-testid="rental-approve-btn"
                  >
                    Approve
                  </button>
                  <button
                    type="button"
                    [disabled]="deciding() === a.bookingId"
                    (click)="decide(a.bookingId, 'rejected')"
                    class="flex-1 rounded-md bg-destructive/15 px-3 py-1.5 text-xs font-semibold text-destructive transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-destructive/25 focus-visible:outline focus-visible:outline-2 focus-visible:outline-destructive disabled:opacity-50"
                    data-testid="rental-reject-btn"
                  >
                    Decline
                  </button>
                </div>
              }
            </li>
          }
        </ul>
      }
    } @else {
      <p class="text-sm text-muted-foreground">Loading upcoming rentals…</p>
    }
  `,
})
export class RentalApprovalsComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly approvals = signal<ReadonlyArray<RentalApproval>>([]);
  readonly loaded = signal(false);
  readonly error = signal<string | null>(null);
  readonly needingApproval = signal(0);
  readonly heldDepositCents = signal(0);
  /** Booking id whose ruling POST is in flight (disables its buttons), or null. */
  readonly deciding = signal<string | null>(null);

  readonly headline = computed(() => approvalsHeadline(this.needingApproval(), this.approvals().length));

  deposit(cents: number): string {
    return formatDeposit(cents);
  }
  pill(level: RentalApproval['riskLevel']): string {
    return riskPillClass(level);
  }
  badge(state: RentalApprovalState): { label: string; class: string } | null {
    return approvalStateBadge(state);
  }
  consent(accepted: number, required: number): { label: string; class: string } | null {
    return consentBadge(accepted, required);
  }

  ngOnInit(): void {
    void this.refresh();
  }

  /**
   * Record an operator ruling on one high-liability rental, then re-sync from the
   * server so the gate state + sort order reflect the persisted decision. Self-gates
   * on 401/failure to a quiet inline message — never a console error.
   */
  async decide(bookingId: string, decision: 'approved' | 'rejected'): Promise<void> {
    if (this.deciding()) return;
    this.deciding.set(bookingId);
    const r = await firstValueFrom(
      this.http
        .post<RulingResponse>(`/api/admin/rental-approvals/${encodeURIComponent(bookingId)}`, { decision })
        .pipe(catchError(() => of({ ok: false, error: 'Could not record the ruling' } as RulingResponse))),
    );
    this.deciding.set(null);
    if (r.ok) {
      await this.refresh();
    } else {
      this.error.set(r.error ?? 'You need operator access to rule on rentals.');
    }
  }

  async refresh(): Promise<void> {
    this.error.set(null);
    const r = await firstValueFrom(
      this.http
        .get<ApprovalsResponse>('/api/admin/rental-approvals')
        .pipe(catchError(() => of({ ok: false, error: 'Failed to reach the rental-approvals endpoint' } as ApprovalsResponse))),
    );
    if (r.ok) {
      this.approvals.set(r.approvals ?? []);
      this.needingApproval.set(r.counts?.needingApproval ?? 0);
      this.heldDepositCents.set(r.counts?.heldDepositCents ?? 0);
      this.loaded.set(true);
    } else {
      // 401 for a signed-out / non-operator session self-gates to a quiet message,
      // never a console error (the requireRole-passes-for-guests class).
      this.error.set(r.error ?? 'You need operator access to view rental risk.');
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'rental-approvals-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
