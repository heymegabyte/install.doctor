import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * PredictNextCardComponent — AI-suggested next service on the booking detail.
 * Angular port of the React `customer/PredictNextCard`. Live surface = Angular
 * /dashboard.
 *
 * Fetches GET /api/loyalty/predict-next (Haiku when configured, deterministic
 * seasonal fallback otherwise; flag-gated → 404 when dark). Self-gates: hides
 * when there's no suggestion. One-tap "Book it" → /book?service=<slug>.
 */
import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmCardImports, HlmButton } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export interface Prediction {
  readonly slug: string;
  readonly headline: string;
  readonly body?: string;
  readonly source?: 'haiku' | 'fallback';
}

interface PredictResponse extends Partial<Prediction> {
  readonly ok?: boolean;
}

/** Pure: a renderable prediction needs a slug + headline. */
export function hasPrediction(p: Prediction | null): boolean {
  return !!p && !!p.slug && !!p.headline;
}

/** Pure: prefill URL for the booking flow. */
export function prefillUrl(slug: string): string {
  return `/book?service=${encodeURIComponent(slug)}`;
}

@Component({
  selector: 'app-predict-next-card',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <div
        hlmCard
        bclReveal
        class="mt-4 border-bcl-accent/30 bg-gradient-to-br from-bcl-accent/8 to-transparent"
        data-testid="predict-next-card"
      >
        <div hlmCardHeader>
          <h3 hlmCardTitle>
            ✨ Predicted for you{{ pred()!.source === 'haiku' ? ' · AI' : '' }}
          </h3>
          <p hlmCardDescription>{{ pred()!.headline }}</p>
        </div>
        <div hlmCardContent>
          @if (pred()!.body) {
            <p class="mb-3 text-sm text-muted-foreground">{{ pred()!.body }}</p>
          }
          <a hlmBtn [href]="url()">Book it →</a>
        </div>
      </div>
    }
  `,
})
export class PredictNextCardComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly pred = signal<Prediction | null>(null);
  readonly visible = computed(() => hasPrediction(this.pred()));
  readonly url = computed(() => {
    const p = this.pred();
    return p ? prefillUrl(p.slug) : '/book';
  });

  ngOnInit(): void {
    void this.refresh();
  }

  async refresh(): Promise<void> {
    try {
      const r = await firstValueFrom(
        this.http.get<PredictResponse>('/api/loyalty/predict-next', { withCredentials: true }),
      );
      if (r?.ok && r.slug && r.headline) {
        this.pred.set({ slug: r.slug, headline: r.headline, body: r.body, source: r.source });
      } else {
        this.pred.set(null);
      }
    } catch {
      this.pred.set(null);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'predict-next-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
