import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SystemHealthComponent — super-admin binding health probe at /admin/system-health.
 *
 * Surfaces GET /api/super-admin/system-health (D1 read/write latency, AI/KV/R2
 * reachability, uptime tallies) — previously a bearer-only endpoint with no
 * dashboard surface, so operators couldn't see whether the worker's bindings were
 * healthy. Auth migrated to the shared ownerOrSuperAdmin gate 2026-06-07.
 *
 * 2026-06-11: now ALSO renders the money-path launch-readiness block the route
 * already returns (`health.payments`) — Square/Stripe/Twilio/Resend live-credential
 * verdicts. The booking route degrades gracefully when Square is misconfigured
 * (confirmation-only, $0 collected), so this panel is the only place an operator
 * can SEE whether real cards will actually charge before flipping the launch
 * switch. The backend computed these probes already; the panel was blind to them.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HlmCardImports } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

/** One money-path dependency's launch-readiness verdict (mirrors the worker's ProbeResult). */
export interface PaymentProbe {
  readonly service: string;
  readonly ok: boolean;
  readonly configured: boolean;
  readonly detail: string;
  readonly meta?: Readonly<Record<string, string | number | boolean>>;
}

export interface SystemHealth {
  readonly d1: { writeMs: number; readMs: number; lastBackupAgo: string | null };
  readonly ai: { reachable: boolean; lastError: string | null };
  readonly kv: { reachable: boolean; latencyMs: number };
  readonly r2: { reachable: boolean; latencyMs: number };
  readonly payments?: {
    ready: boolean;
    formSecurityReady?: boolean;
    notificationsReady?: boolean;
    expressCheckoutReady?: boolean;
    launchGo?: boolean;
    blockers?: ReadonlyArray<string>;
    probes: ReadonlyArray<PaymentProbe>;
  };
  readonly uptime: { ok: number; degraded: number; error: number };
}

interface HealthResponse {
  readonly ok: boolean;
  readonly health?: SystemHealth;
  readonly generatedAt?: string;
  readonly error?: string;
}

/** Pure: latency → status tier (for the dot color). Tested. */
export function latencyTier(ms: number): 'ok' | 'warn' | 'down' {
  if (ms < 0) return 'down';
  if (ms > 400) return 'warn';
  return 'ok';
}

export type ProbeTier = 'ready' | 'attention' | 'missing';

/**
 * Pure: a money-path probe → a launch-readiness tier. `ready` only when the
 * credential is live (`ok`); `attention` when configured-but-rejected (sandbox
 * token, expired key, inactive location); `missing` when the secret is unset.
 * Tested.
 */
export function probeTier(p: { ok: boolean; configured: boolean }): ProbeTier {
  if (p.ok) return 'ready';
  return p.configured ? 'attention' : 'missing';
}

/** Pure: a service key → an operator-facing label naming what the leg DOES. Tested. */
export function serviceLabel(service: string): string {
  const map: Record<string, string> = {
    square: 'Square — accept cards',
    stripe: 'Stripe — crew payouts',
    twilio: 'Twilio — SMS confirmations',
    resend: 'Resend — email confirmations',
    turnstile: 'Turnstile — form bot protection',
    notifications: 'Notification engine — in-app · email · SMS · push',
  };
  return map[service] ?? service.charAt(0).toUpperCase() + service.slice(1);
}

/** Pure: a probe tier → a contrast-safe text-color token on the dark panel. Tested. */
export function probeTierDot(t: ProbeTier): string {
  return t === 'ready' ? 'text-green-300' : t === 'attention' ? 'text-amber-300' : 'text-destructive';
}

/**
 * Pure: the color of a recent-uptime sample COUNT (ok / degraded / error). A `degraded`
 * sample means a health check came back impaired — NOT healthy — so it must read as a WARNING
 * (amber), never the ok-green it wore before (fire-124): an operator glancing at the uptime card
 * must not mistake degradation for health (and the known payments:degraded baseline would reinforce
 * a false green). `ok` is a neutral raw count (not an affirmative verdict); `error` is destructive. Tested.
 */
export function uptimeTone(kind: 'ok' | 'degraded' | 'error'): string {
  return kind === 'error' ? 'text-destructive' : kind === 'degraded' ? 'text-amber-300' : 'text-foreground';
}

/**
 * Pure: the form-security (Turnstile) headline verdict. Surfaced as its OWN
 * badge — not folded into "Ready to charge" — because Turnstile soft-fails OPEN:
 * a green money-path badge must never hide a booking form taking unlimited
 * unprotected bot submissions. Tested.
 */
export function formSecurityVerdict(ready: boolean): { readonly text: string; readonly cls: string } {
  return ready
    ? { text: 'Forms bot-protected', cls: 'bg-green-500/15 text-green-300' }
    : { text: 'Forms OPEN — Turnstile not live (bots can flood bookings)', cls: 'bg-destructive/15 text-destructive' };
}

/**
 * Pure: the notifications headline verdict. Surfaced as its OWN badge — not
 * folded into "Ready to charge" — because notifications are a distinct launch
 * leg. Backed by the CF-native, in-repo notification engine (the Novu-cloud
 * retirement): it reports live whenever its workflow catalog is built, needs no
 * external secret, and never silently mock-degrades. Tested.
 */
export function notificationsVerdict(ready: boolean): { readonly text: string; readonly cls: string } {
  return ready
    ? { text: 'Notifications live', cls: 'bg-green-500/15 text-green-300' }
    : { text: 'Notifications OFF — engine has no workflows registered', cls: 'bg-destructive/15 text-destructive' };
}

/**
 * Pure: the express-checkout verdict — the Apple/Google Pay wallet + Stripe Link
 * ONLINE-ACCEPT path. Its OWN badge because it's a distinct conversion lever and is
 * INDEPENDENT of both the Square accept rail AND Stripe Connect payouts: the
 * `apple-google-pay-express` PaymentIntent path needs only a live `STRIPE_SECRET_KEY`,
 * so a Connect-dark platform still resolves express wallets. Backed by the stripe
 * probe's `meta.acceptReady`. Amber (not red) when off — express is an optional faster
 * checkout, never a launch blocker. Tested.
 */
export function expressCheckoutVerdict(ready: boolean): { readonly text: string; readonly cls: string } {
  return ready
    ? { text: 'Apple/Google Pay + Link express live', cls: 'bg-green-500/15 text-green-300' }
    : { text: 'Express wallets off — Stripe key not live-accepting', cls: 'bg-amber-500/15 text-amber-300' };
}

/**
 * Pure: the SINGLE GO/NO-GO launch headline. The three booleans above
 * (ready/formSecurity/notifications) make an operator mentally AND them to answer
 * "can I launch?"; this rolls the customer money path (accept + SMS/email confirm +
 * bot-protection) into one verdict and, on NO-GO, NAMES the blocking legs via their
 * operator labels — the exact checklist standing between HEAD and a live money path.
 * Fail-closed: undefined `go` (older worker without the field) reads NO-GO. Tested.
 */
export function launchGoVerdict(
  go: boolean | undefined,
  blockers: ReadonlyArray<string> | undefined,
): { readonly text: string; readonly cls: string } {
  if (go) {
    return { text: 'GO — customer money path is live end-to-end', cls: 'bg-green-500/20 text-green-300' };
  }
  const legs = (blockers ?? []).map(serviceLabel).join(' · ');
  return {
    text: legs ? `NO-GO — blocked on: ${legs}` : 'NO-GO — launch readiness unknown',
    cls: 'bg-destructive/20 text-destructive',
  };
}

@Component({
  selector: 'app-admin-system-health',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [...HlmCardImports, BclRevealDirective],
  template: `
    <header class="mb-4 flex items-center justify-between">
      <div>
        <h1 class="text-2xl font-bold text-foreground">System health</h1>
        <p class="text-sm text-muted-foreground">Live binding probes — D1, AI, KV, R2 + the money path.</p>
      </div>
      <button
        type="button"
        class="rounded-md border border-border px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        (click)="refresh()"
      >
        Refresh
      </button>
    </header>

    @if (error(); as e) {
      <div hlmCard class="p-4"><p class="text-sm text-destructive">{{ e }}</p></div>
    } @else if (health(); as h) {
      <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <div hlmCard bclReveal class="p-4">
          <h3 class="text-sm font-semibold text-foreground">D1 database</h3>
          <dl class="mt-2 space-y-1 text-sm">
            <div class="flex justify-between"><dt class="text-muted-foreground">Write</dt><dd [class]="dot(h.d1.writeMs)">{{ ms(h.d1.writeMs) }}</dd></div>
            <div class="flex justify-between"><dt class="text-muted-foreground">Read</dt><dd [class]="dot(h.d1.readMs)">{{ ms(h.d1.readMs) }}</dd></div>
            <div class="flex justify-between"><dt class="text-muted-foreground">Last backup</dt><dd class="text-foreground">{{ h.d1.lastBackupAgo ?? '—' }}</dd></div>
          </dl>
        </div>
        <div hlmCard bclReveal class="p-4">
          <h3 class="text-sm font-semibold text-foreground">Workers AI</h3>
          <p class="mt-2 text-sm" [class]="h.ai.reachable ? okText : downText">
            {{ h.ai.reachable ? 'Reachable' : 'Unreachable' }}
          </p>
          @if (h.ai.lastError) { <p class="mt-1 text-xs text-muted-foreground">{{ h.ai.lastError }}</p> }
        </div>
        <div hlmCard bclReveal class="p-4">
          <h3 class="text-sm font-semibold text-foreground">KV</h3>
          <p class="mt-2 text-sm" [class]="dot(h.kv.latencyMs)">
            {{ h.kv.reachable ? ms(h.kv.latencyMs) : 'Unreachable' }}
          </p>
        </div>
        <div hlmCard bclReveal class="p-4">
          <h3 class="text-sm font-semibold text-foreground">R2 storage</h3>
          <p class="mt-2 text-sm" [class]="dot(h.r2.latencyMs)">
            {{ h.r2.reachable ? ms(h.r2.latencyMs) : 'Unreachable' }}
          </p>
        </div>
        <div hlmCard bclReveal class="p-4">
          <h3 class="text-sm font-semibold text-foreground">Uptime (recent)</h3>
          <dl class="mt-2 space-y-1 text-sm">
            <div class="flex justify-between"><dt class="text-muted-foreground">OK</dt><dd class="tabular-nums" [class]="uptimeCls('ok')">{{ h.uptime.ok }}</dd></div>
            <div class="flex justify-between"><dt class="text-muted-foreground">Degraded</dt><dd class="tabular-nums" [class]="uptimeCls('degraded')">{{ h.uptime.degraded }}</dd></div>
            <div class="flex justify-between"><dt class="text-muted-foreground">Error</dt><dd class="tabular-nums" [class]="uptimeCls('error')">{{ h.uptime.error }}</dd></div>
          </dl>
        </div>
      </div>

      @if (h.payments; as pay) {
        <section class="mt-6" aria-labelledby="money-path-heading">
          <div
            role="status"
            class="mb-4 rounded-lg px-4 py-3 text-base font-bold transition-all duration-[333ms]"
            [class]="launchVerdict(pay.launchGo, pay.blockers).cls"
          >
            {{ launchVerdict(pay.launchGo, pay.blockers).text }}
          </div>
          <div class="mb-3 flex flex-wrap items-center gap-3">
            <h2 id="money-path-heading" class="text-lg font-bold text-foreground">Money-path launch readiness</h2>
            <span
              class="rounded-full px-3 py-1 text-xs font-semibold transition-all duration-[333ms]"
              [class]="pay.ready ? 'bg-green-500/15 text-green-300' : 'bg-destructive/15 text-destructive'"
            >
              {{ pay.ready ? 'Ready to charge real cards' : 'NOT launch-ready — $0 will be collected' }}
            </span>
            <span
              class="rounded-full px-3 py-1 text-xs font-semibold transition-all duration-[333ms]"
              [class]="formSecurity(pay.formSecurityReady).cls"
            >
              {{ formSecurity(pay.formSecurityReady).text }}
            </span>
            <span
              class="rounded-full px-3 py-1 text-xs font-semibold transition-all duration-[333ms]"
              [class]="notifications(pay.notificationsReady).cls"
            >
              {{ notifications(pay.notificationsReady).text }}
            </span>
            <span
              class="rounded-full px-3 py-1 text-xs font-semibold transition-all duration-[333ms]"
              [class]="expressCheckout(pay.expressCheckoutReady).cls"
            >
              {{ expressCheckout(pay.expressCheckoutReady).text }}
            </span>
          </div>
          <p class="mb-3 text-xs text-muted-foreground">
            Booking falls through to confirmation-only when Square is misconfigured — these live probes are the only
            launch-gate that proves a real card actually charges. Read-only; no charge, booking, or send.
          </p>
          <ul class="grid gap-4 sm:grid-cols-2" aria-label="Money-path dependency probes">
            @for (p of pay.probes; track p.service; let i = $index) {
              <li hlmCard bclReveal [revealDelay]="i * 60" class="p-4">
                <div class="flex items-center justify-between gap-2">
                  <h3 class="text-sm font-semibold text-foreground">{{ label(p.service) }}</h3>
                  <span
                    class="rounded-full px-2.5 py-0.5 text-xs font-medium transition-all duration-[333ms]"
                    [class]="tierPill(p)"
                  >
                    {{ tierWord(p) }}
                  </span>
                </div>
                <p class="mt-2 text-sm" [class]="tierText(p)">{{ p.detail }}</p>
              </li>
            }
          </ul>
        </section>
      }

      @if (generatedAt()) { <p class="mt-3 text-xs text-muted-foreground">Probed {{ generatedAt() }}</p> }
    } @else {
      <p class="text-sm text-muted-foreground">Probing bindings…</p>
    }
  `,
})
export class SystemHealthComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly health = signal<SystemHealth | null>(null);
  readonly generatedAt = signal<string | null>(null);
  readonly error = signal<string | null>(null);

  protected readonly okText = 'text-green-300';
  protected readonly downText = 'text-destructive';

  ms(v: number): string {
    return v < 0 ? '—' : `${v} ms`;
  }
  dot(ms: number): string {
    const t = latencyTier(ms);
    return t === 'down' ? 'text-destructive' : t === 'warn' ? 'text-amber-300' : 'text-green-300';
  }
  /** Template bridge to the tested pure {@link uptimeTone} — degraded reads amber, not ok-green. */
  uptimeCls(kind: 'ok' | 'degraded' | 'error'): string {
    return uptimeTone(kind);
  }

  /** Operator-facing leg label (Square — accept cards, …). */
  label(service: string): string {
    return serviceLabel(service);
  }
  /** One-word status pill copy per readiness tier. */
  tierWord(p: PaymentProbe): string {
    const t = probeTier(p);
    return t === 'ready' ? 'Live' : t === 'attention' ? 'Check' : 'Unset';
  }
  /** Contrast-safe text color for the detail line. */
  tierText(p: PaymentProbe): string {
    return probeTierDot(probeTier(p));
  }
  /** Form-security (Turnstile) headline badge — its own verdict (soft-fails OPEN). */
  formSecurity(ready: boolean | undefined): { text: string; cls: string } {
    return formSecurityVerdict(ready ?? false);
  }
  /** Notifications headline badge — its own verdict (CF-native engine readiness). */
  notifications(ready: boolean | undefined): { text: string; cls: string } {
    return notificationsVerdict(ready ?? false);
  }
  /** Express-checkout headline badge — Apple/Google Pay + Link online accept (Stripe key live-accepting, independent of payouts). */
  expressCheckout(ready: boolean | undefined): { text: string; cls: string } {
    return expressCheckoutVerdict(ready ?? false);
  }
  /** Single GO/NO-GO launch headline — names the blocking legs on NO-GO. */
  launchVerdict(go: boolean | undefined, blockers: ReadonlyArray<string> | undefined): { text: string; cls: string } {
    return launchGoVerdict(go, blockers);
  }
  /** Brand-token pill background + text per readiness tier (contrast-safe on dark). */
  tierPill(p: PaymentProbe): string {
    const t = probeTier(p);
    return t === 'ready'
      ? 'bg-green-500/15 text-green-300'
      : t === 'attention'
        ? 'bg-amber-500/15 text-amber-300'
        : 'bg-destructive/15 text-destructive';
  }

  ngOnInit(): void {
    void this.refresh();
  }

  async refresh(): Promise<void> {
    this.error.set(null);
    const r = await firstValueFrom(
      this.http
        .get<HealthResponse>('/api/super-admin/system-health')
        .pipe(catchError(() => of({ ok: false, error: 'Failed to reach health endpoint' } as HealthResponse))),
    );
    if (r.ok && r.health) {
      this.health.set(r.health);
      this.generatedAt.set(r.generatedAt ?? null);
    } else {
      this.error.set(r.error ?? 'Unknown error');
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'system-health-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
