import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * WeekViewComponent — the week time-grid of the Brick Labor dispatch calendar
 * (/dashboard/calendar/week).
 *
 * A Google-Calendar-style week grid: an hour-label column + 7 day columns
 * (Mon–Sun), with every scheduled job from /api/admin/bookings placed in its
 * day column at its start hour, its height scaled by booked `hours`, color-coded
 * by service. Jobs with no parseable time fall into an "Untimed" rail above the
 * grid. Prev/next-week + Today navigation, URL-synced range (?w=YYYY-MM-DD = the
 * week's Monday), and a per-week operations strip (jobs · crew-hours · labor
 * revenue) computed straight from the server's canonical fields — the calendar
 * NEVER recomputes or invents pricing.
 *
 * The $50/hour-per-crew-member legend mirrors the canonical worker
 * HOURLY_RATE_CENTS var (see CLAUDE.md); it is display-only — server totals are
 * authoritative. A guard unit test pins the mirror to the canonical value.
 *
 * Crew/resource LANES (one column per assigned crew member) are intentionally
 * deferred: /api/admin/bookings returns crew COUNT, not crew identity, so real
 * lanes are backend-first (the endpoint must return assigned crew) and ship
 * under the calendar_crew_resource_view flag in a later increment.
 *
 * Dependency-free (no calendar lib) per the repo's bundle discipline + Spartan
 * black/orange. Flag-gated by `dashboard_calendar` at the route level.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, finalize, of } from 'rxjs';
import { A11yModule } from '@angular/cdk/a11y';
import { JobDetailDrawerComponent } from './job-detail-drawer.component';
import { QuickCreateComponent, type CreatedBooking } from './quick-create.component';
import { detectConflicts, parseHourValue } from '@theme.tools/scheduling/field-service/calendar-conflicts';
import { RecurringContractsService } from './recurring-contracts.service';
import { projectOccurrences, occurrencePriceCents, type Occurrence } from '@theme.tools/scheduling/field-service/recurring-occurrences';
import { FreeBusyService } from './free-busy.service';
import { CrewAssignmentsService } from './crew-assignments.service';
import { routeFade, reducedMotion } from '../../shared/animations';
import { HlmSkeleton } from '../../shared/ui-spartan';
import { FeatureFlagService } from '../../core/feature-flag.service';

/** Canonical Brick Labor labor rate (cents/hour/crew-member). Mirrors the worker
 *  HOURLY_RATE_CENTS var documented in CLAUDE.md. Display-only — server-computed
 *  total_cents is authoritative; this drives an informational legend only. The
 *  guard test asserts it stays 5000. */
export const HOURLY_RATE_CENTS = 5000;

interface Booking {
  readonly id: string;
  readonly status: string;
  readonly customer_name: string | null;
  readonly city: string | null;
  readonly preferred_date: string | null;
  readonly preferred_time: string | null;
  readonly services_csv: string | null;
  readonly hours: number | null;
  readonly crew: number | null;
  readonly total_cents: number | null;
}

interface PlacedBooking {
  readonly booking: Booking;
  readonly startHour: number; // fractional, e.g. 14.5 for 2:30pm
  readonly rowSpan: number; // grid rows (1 row = 1 hour), min 1
}

interface DayColumn {
  readonly iso: string;
  readonly label: string; // "Mon 16"
  readonly isToday: boolean;
  readonly untimed: readonly Booking[];
  /** start-hour → bookings beginning in that hour cell. */
  readonly byHour: ReadonlyMap<number, readonly PlacedBooking[]>;
}

const DAY_NAMES = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] as const;
const HOUR_START = 6; // 6am
const HOUR_END = 21; // 9pm (inclusive label row)

@Component({
  selector: 'app-calendar-week',
  standalone: true,
  imports: [RouterLink, A11yModule, JobDetailDrawerComponent, QuickCreateComponent, HlmSkeleton],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header
      class="bcl-rise mb-5 flex flex-wrap items-end justify-between gap-4 rounded-2xl border border-bcl-border bcl-grain p-6"
    >
      <div class="min-w-0">
        <p class="bcl-eyebrow mb-2">Dispatch · Calendar</p>
        <h1 class="font-display text-3xl font-extrabold tracking-tight text-bcl-ink">
          {{ rangeLabel() }}
        </h1>
        <p class="mt-2 text-sm text-bcl-ink-muted">
          {{ tz() }} · $50/hr per crew member · 1-hr min · 15-min blocks
        </p>
      </div>

      <div class="flex flex-wrap items-center gap-2">
        <nav
          class="flex overflow-hidden rounded-lg border border-bcl-border"
          aria-label="Calendar views"
        >
          <a
            routerLink="/calendar/month"
            class="px-3 py-1.5 text-xs text-bcl-ink-muted hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            >Month</a
          >
          <a
            routerLink="/calendar/week"
            class="border-l border-bcl-border bg-bcl-accent px-3 py-1.5 text-xs font-semibold text-bcl-bg focus-visible:outline focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-bcl-bg"
            aria-current="page"
            >Week</a
          >
          <a
            routerLink="/calendar/day"
            class="border-l border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            >Day</a
          >
          <a
            routerLink="/calendar/schedule"
            class="border-l border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            >Schedule</a
          >
        </nav>
        <div class="flex items-center gap-1">
          <button
            type="button"
            (click)="prevWeek()"
            class="grid size-9 place-items-center rounded-lg border border-bcl-border text-bcl-ink-muted transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            aria-label="Previous week"
          >
            ‹
          </button>
          <button
            type="button"
            (click)="goToday()"
            class="rounded-lg border border-bcl-border px-3 py-1.5 text-xs font-semibold text-bcl-ink transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            data-testid="cal-week-today"
          >
            Today
          </button>
          <button
            type="button"
            (click)="nextWeek()"
            class="grid size-9 place-items-center rounded-lg border border-bcl-border text-bcl-ink-muted transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            aria-label="Next week"
          >
            ›
          </button>
        </div>
        <button
          type="button"
          (click)="quickOpen.set(true)"
          class="rounded-lg bg-bcl-accent px-3 py-1.5 text-xs font-semibold text-bcl-bg transition-all duration-[333ms] hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bcl-bg"
          data-testid="cal-week-new"
        >
          + New job
        </button>
      </div>
    </header>

    <section class="mb-5 grid grid-cols-3 gap-3" data-testid="cal-week-metrics">
      <div class="bcl-glass p-4">
        <p class="bcl-eyebrow text-[10px]">Scheduled jobs</p>
        <p
          class="bcl-tabular mt-1 font-display text-2xl font-extrabold text-bcl-ink"
          data-testid="cal-week-jobs"
        >
          {{ jobCount() }}
        </p>
      </div>
      <div class="bcl-glass p-4">
        <p class="bcl-eyebrow text-[10px]">Crew-hours</p>
        <p class="bcl-tabular mt-1 font-display text-2xl font-extrabold text-bcl-ink">
          {{ crewHours() }}
        </p>
      </div>
      <div class="bcl-glass p-4">
        <p class="bcl-eyebrow text-[10px]">Labor revenue</p>
        <p
          class="bcl-tabular mt-1 font-display text-2xl font-extrabold text-bcl-accent"
          data-testid="cal-week-revenue"
        >
          {{ revenueLabel() }}
        </p>
      </div>
    </section>

    @if (error()) {
      <p
        class="mb-3 rounded-2xl border border-amber-500/30 bg-amber-500/5 p-4 text-sm text-amber-300"
        role="alert"
      >
        {{ error() }}
      </p>
    }

    @if (conflictIds().size > 0) {
      <p
        class="mb-3 rounded-2xl border border-amber-500/40 bg-amber-500/10 p-3 text-sm text-amber-200"
        role="status"
        data-testid="cal-week-conflicts"
      >
        @if (crewAware()) {
          ⚠ {{ conflictIds().size }} job(s) double-book the same crew member this week — reassign
          or reschedule.
        } @else {
          ⚠ {{ conflictIds().size }} job(s) overlap in time this week — confirm crew coverage.
        }
      </p>
    }

    @if (crewRoster().length) {
      <div
        class="mb-3 flex flex-wrap items-center gap-2"
        role="group"
        aria-label="Filter by crew member"
        data-testid="cal-week-crew-filter"
      >
        <button
          type="button"
          (click)="setCrewFilter(null)"
          class="rounded-full border px-3 py-1 text-xs font-medium transition-all duration-[333ms] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
          [class]="
            crewFilter() === null
              ? 'border-bcl-accent bg-bcl-accent text-bcl-bg'
              : 'border-bcl-border text-bcl-ink-muted hover:border-bcl-accent hover:text-bcl-accent'
          "
          [attr.aria-pressed]="crewFilter() === null"
        >
          All crew
        </button>
        @for (m of crewRoster(); track m.id) {
          <button
            type="button"
            (click)="setCrewFilter(m.id)"
            class="rounded-full border px-3 py-1 text-xs font-medium transition-all duration-[333ms] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            [class]="
              crewFilter() === m.id
                ? 'border-bcl-accent bg-bcl-accent text-bcl-bg'
                : 'border-bcl-border text-bcl-ink-muted hover:border-bcl-accent hover:text-bcl-accent'
            "
            [attr.aria-pressed]="crewFilter() === m.id"
          >
            {{ m.name }}
          </button>
        }
      </div>
    }

    @if (pendingMove(); as mv) {
      <div
        class="mb-3 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-bcl-accent/40 bg-bcl-accent/10 p-3 text-sm text-bcl-ink"
        role="alertdialog"
        aria-label="Confirm reschedule"
        data-testid="cal-week-move"
        cdkTrapFocus
        [cdkTrapFocusAutoCapture]="true"
        (keydown.escape)="cancelMove()"
      >
        <span
          >Move <strong>{{ mv.customer }}</strong> from {{ mv.from }} to <strong>{{ mv.to }}</strong
          >?</span
        >
        <span class="flex gap-2">
          <button
            type="button"
            (click)="confirmMove()"
            [disabled]="moving()"
            class="rounded-lg bg-bcl-accent px-3 py-1.5 text-xs font-semibold text-bcl-bg transition-all duration-[333ms] disabled:opacity-50 hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            data-testid="cal-week-move-confirm"
          >
            {{ moving() ? 'Moving…' : 'Confirm' }}
          </button>
          <button
            type="button"
            (click)="cancelMove()"
            class="rounded-lg border border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
          >
            Cancel
          </button>
        </span>
      </div>
    }
    @if (moveError()) {
      <p
        class="mb-3 rounded-2xl border border-rose-500/30 bg-rose-500/5 p-3 text-xs text-rose-300"
        role="alert"
      >
        {{ moveError() }}
      </p>
    }

    @if (movingId()) {
      <p
        class="mb-3 flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-bcl-accent/40 bg-bcl-accent/10 p-3 text-sm text-bcl-ink"
        role="status"
        data-testid="cal-week-arm-hint"
      >
        <span>Pick a day and time to reschedule this job — no dragging needed.</span>
        <button
          type="button"
          (click)="cancelArm()"
          class="rounded-lg border border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
        >
          Cancel
        </button>
      </p>
    }

    <!-- Day headers -->
    <div
      class="grid overflow-hidden rounded-t-2xl border border-bcl-border bg-bcl-border"
      style="grid-template-columns: 3.5rem repeat(7, 1fr); gap: 1px"
      aria-hidden="true"
    >
      <div class="bg-bcl-bg px-1 py-2"></div>
      @for (d of days(); track d.iso) {
        <div class="bg-bcl-bg px-1 py-2 text-center" [class.bg-bcl-bg-elev]="d.isToday">
          <span class="bcl-eyebrow text-[10px]" [class.text-bcl-accent]="d.isToday">{{
            d.label
          }}</span>
        </div>
      }
    </div>

    <!-- Untimed rail -->
    @if (hasUntimed()) {
      <div
        class="grid border-x border-bcl-border bg-bcl-border"
        style="grid-template-columns: 3.5rem repeat(7, 1fr); gap: 1px"
      >
        <div
          class="grid place-items-center bg-bcl-bg py-1.5 text-[9px] uppercase tracking-wider text-bcl-ink-muted"
        >
          Any
        </div>
        @for (d of days(); track d.iso) {
          <div class="bg-bcl-bg p-1">
            <ul class="space-y-1">
              @for (b of d.untimed; track b.id) {
                <li>
                  <button
                    type="button"
                    [class]="chipClass(b) + ' w-full text-left'"
                    [title]="chipTitle(b)"
                    (click)="open(b)"
                  >
                    {{ primaryService(b) }}
                  </button>
                </li>
              }
            </ul>
          </div>
        }
      </div>
    }

    @if (hasRecurring()) {
      <div
        class="grid border-x border-bcl-border bg-bcl-border"
        style="grid-template-columns: 3.5rem repeat(7, 1fr); gap: 1px"
        data-testid="cal-week-recurring"
      >
        <div
          class="grid place-items-center bg-bcl-bg py-1.5 text-[9px] uppercase tracking-wider text-bcl-accent/70"
        >
          ↻
        </div>
        @for (d of days(); track d.iso) {
          <div class="bg-bcl-bg p-1">
            <ul class="space-y-1">
              @for (o of recurringForDay(d.iso); track o.contractId) {
                <li>
                  <span
                    class="block truncate rounded-md border border-dashed border-bcl-accent/50 bg-bcl-accent/5 px-1.5 py-1 text-[11px] leading-tight text-bcl-accent/80"
                    [title]="occTitle(o)"
                    >↻ {{ o.service }}</span
                  >
                </li>
              }
            </ul>
          </div>
        }
      </div>
    }

    @if (hasBusy()) {
      <div
        class="grid border-x border-bcl-border bg-bcl-border"
        style="grid-template-columns: 3.5rem repeat(7, 1fr); gap: 1px"
        data-testid="cal-week-busy"
      >
        <div
          class="grid place-items-center bg-bcl-bg py-1.5 text-[9px] uppercase tracking-wider text-bcl-ink-muted"
        >
          ⊘
        </div>
        @for (d of days(); track d.iso) {
          <div class="bg-bcl-bg p-1">
            <ul class="space-y-1">
              @for (iv of busyForDay(d.iso); track iv.start) {
                <li>
                  <span
                    class="block truncate rounded-md bg-bcl-ink-muted/10 px-1.5 py-1 text-[11px] leading-tight text-bcl-ink-muted"
                    [title]="'Busy on Google Calendar'"
                    >busy {{ fmtRange(iv) }}</span
                  >
                </li>
              }
            </ul>
          </div>
        }
      </div>
    }

    <!-- Time grid: hour-label col + 7 day cols, one row per hour -->
    <div
      class="grid overflow-hidden rounded-b-2xl border-x border-b border-bcl-border bg-bcl-border"
      style="grid-template-columns: 3.5rem repeat(7, 1fr); gap: 1px"
      role="group"
      [attr.aria-label]="'Week time grid for ' + rangeLabel()"
      data-testid="cal-week-grid"
    >
      @for (h of hours; track h) {
        <div class="bg-bcl-bg px-1 py-1 text-right bcl-tabular text-[10px] text-bcl-ink-muted">
          {{ hourLabel(h) }}
        </div>
        @for (d of days(); track d.iso) {
          <div
            class="min-h-[40px] bg-bcl-bg p-0.5 transition-colors"
            [class.bg-bcl-bg-elev]="d.isToday"
            [class.ring-2]="dropCell() === d.iso + 'T' + h || isMoveTarget(d.iso, h)"
            [class.ring-inset]="dropCell() === d.iso + 'T' + h || isMoveTarget(d.iso, h)"
            [class.ring-bcl-accent]="dropCell() === d.iso + 'T' + h || isMoveTarget(d.iso, h)"
            [class.cursor-pointer]="isMoveTarget(d.iso, h)"
            [class.focus-visible:outline-none]="isMoveTarget(d.iso, h)"
            [class.focus-visible:ring-2]="isMoveTarget(d.iso, h)"
            [attr.role]="isMoveTarget(d.iso, h) ? 'button' : null"
            [attr.tabindex]="isMoveTarget(d.iso, h) ? 0 : null"
            [attr.data-testid]="isMoveTarget(d.iso, h) ? 'cal-move-target' : null"
            [attr.aria-label]="
              isMoveTarget(d.iso, h)
                ? 'Reschedule the selected job to ' + d.iso + ' ' + hourLabel(h)
                : null
            "
            (click)="isMoveTarget(d.iso, h) && activateCell(d.iso, h)"
            (keydown.enter)="isMoveTarget(d.iso, h) && activateCell(d.iso, h)"
            (keydown.space)="isMoveTarget(d.iso, h) && $event.preventDefault(); isMoveTarget(d.iso, h) && activateCell(d.iso, h)"
            (dragover)="onDragOver($event, d.iso, h)"
            (dragleave)="onDragLeave(d.iso, h)"
            (drop)="onDrop($event, d.iso, h)"
          >
            <ul class="space-y-0.5">
              @for (p of d.byHour.get(h) ?? []; track p.booking.id) {
                <li class="flex items-stretch gap-0.5" [style.min-height.px]="p.rowSpan * 36">
                  <button
                    type="button"
                    draggable="true"
                    (dragstart)="onDragStart($event, p.booking.id)"
                    [class]="
                      chipClass(p.booking) +
                      ' min-w-0 flex-1 cursor-grab text-left active:cursor-grabbing' +
                      conflictCls(p.booking)
                    "
                    [title]="chipTitle(p.booking)"
                    (click)="open(p.booking)"
                  >
                    {{ fmtTime(p.startHour) }} {{ primaryService(p.booking) }}
                    @if (p.booking.hours) {
                      · {{ p.booking.hours }}h
                    }
                  </button>
                  <!-- Single-pointer + keyboard reschedule alternative to drag
                       (WCAG 2.5.7 / 2.1.1): arms the job, then a (day, hour) cell
                       becomes a click/Enter target. ≥24px (2.5.8). -->
                  <button
                    type="button"
                    (click)="armMove(p.booking.id)"
                    (keydown.enter)="$event.preventDefault(); armMove(p.booking.id)"
                    (keydown.space)="$event.preventDefault(); armMove(p.booking.id)"
                    [attr.aria-pressed]="movingId() === p.booking.id"
                    [attr.aria-label]="
                      movingId() === p.booking.id
                        ? 'Cancel moving ' + (p.booking.customer_name ?? 'job') + ' — pick a day/time, or press to cancel'
                        : 'Move ' + (p.booking.customer_name ?? 'job') + ' to another day or time without dragging'
                    "
                    [title]="movingId() === p.booking.id ? 'Cancel move' : 'Move to another day/time (no drag)'"
                    class="grid min-h-[24px] w-5 shrink-0 place-items-center rounded-md border text-[10px] leading-none transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                    [class.border-bcl-accent]="movingId() === p.booking.id"
                    [class.bg-bcl-accent]="movingId() === p.booking.id"
                    [class.text-bcl-bg]="movingId() === p.booking.id"
                    [class.border-bcl-border]="movingId() !== p.booking.id"
                    [class.text-bcl-ink-muted]="movingId() !== p.booking.id"
                    [class.hover:border-bcl-accent]="movingId() !== p.booking.id"
                    [class.hover:text-bcl-accent]="movingId() !== p.booking.id"
                    data-testid="cal-move-chip"
                  >
                    @if (movingId() === p.booking.id) {
                      ✕
                    } @else {
                      ⇄
                    }
                  </button>
                </li>
              }
            </ul>
          </div>
        }
      }
    </div>

    @if (loading()) {
      <div
        class="mt-3 space-y-2"
        data-testid="cal-week-loading"
        aria-busy="true"
        aria-label="Loading schedule"
      >
        @for (row of [1, 2, 3]; track row) {
          <div class="bcl-glass flex items-center gap-3 p-3">
            <div hlmSkeleton class="h-4 w-14 shrink-0"></div>
            <div hlmSkeleton class="h-4 flex-1"></div>
          </div>
        }
      </div>
    } @else if (jobCount() === 0 && !error()) {
      <p
        class="mt-3 rounded-2xl border border-bcl-border bg-bcl-bg-elev/40 p-6 text-center text-sm text-bcl-ink-muted"
        data-testid="cal-week-empty"
      >
        No jobs scheduled this week. Booked jobs and recurring contracts appear here in their time
        slots.
      </p>
    }

    <app-job-detail-drawer
      [booking]="selected()"
      (updated)="onUpdated($event)"
      (closed)="selected.set(null)"
    />
    <app-quick-create
      [open]="quickOpen()"
      [defaultDate]="mondayIso()"
      (created)="onCreated($event)"
      (closed)="quickOpen.set(false)"
    />
  `,
})
export class WeekViewComponent {
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);

  readonly hours = Array.from({ length: HOUR_END - HOUR_START + 1 }, (_, i) => HOUR_START + i);
  readonly bookings = signal<Booking[]>([]);
  /** The job whose detail drawer is open (null = closed). */
  readonly selected = signal<Booking | null>(null);
  /** Whether the quick-create popover is open. */
  readonly quickOpen = signal(false);
  private readonly crewAssignments = inject(CrewAssignmentsService);
  private readonly flags = inject(FeatureFlagService);
  /** When on, conflict detection tightens to per-crew (same worker double-booked). */
  readonly crewAware = this.flags.isOn('calendar_crew_resource_view');
  /**
   * Booking ids that conflict on the same day. Default: any time overlap
   * (coverage warning). Crew-aware (flag on): only when overlapping jobs share
   * an assigned worker — a real per-crew double-booking.
   */
  readonly conflictIds = computed(() => {
    if (!this.crewAware()) return detectConflicts(this.bookings());
    const byBooking = this.crewAssignments.byBooking();
    const items = this.bookings().map((b) => ({ ...b, workerIds: byBooking.get(b.id) ?? [] }));
    return detectConflicts(items, { crewAware: true });
  });

  /** Amber conflict ring appended to a chip when it overlaps another job. */
  conflictCls(b: Booking): string {
    return this.conflictIds().has(b.id) ? ' ring-2 ring-inset ring-amber-400/70' : '';
  }

  /** Active-crew roster for the filter chips (empty when the flag is off). */
  readonly crewRoster = computed(() => (this.crewAware() ? this.crewAssignments.roster() : []));
  /** Selected crew member to filter the week by (null = all crew). */
  readonly crewFilter = signal<string | null>(null);
  setCrewFilter(id: string | null): void {
    this.crewFilter.set(this.crewFilter() === id ? null : id);
  }
  /** Bookings after the crew filter — every per-day/total computed derives from this. */
  private readonly visibleBookings = computed<Booking[]>(() => {
    const filterId = this.crewFilter();
    if (!filterId || !this.crewAware()) return this.bookings();
    const byBooking = this.crewAssignments.byBooking();
    return this.bookings().filter((b) => (byBooking.get(b.id) ?? []).includes(filterId));
  });

  private readonly recurring = inject(RecurringContractsService);
  private readonly recurringByDate = computed<Map<string, Occurrence[]>>(() => {
    const isos = this.weekIsos();
    if (isos.length === 0) return new Map();
    const map = new Map<string, Occurrence[]>();
    for (const ct of this.recurring.contracts()) {
      for (const occ of projectOccurrences(ct, isos[0]!, isos[isos.length - 1]!)) {
        const arr = map.get(occ.date) ?? [];
        arr.push(occ);
        map.set(occ.date, arr);
      }
    }
    return map;
  });
  readonly hasRecurring = computed<boolean>(() => this.recurringByDate().size > 0);
  recurringForDay(iso: string): Occurrence[] {
    return this.recurringByDate().get(iso) ?? [];
  }

  private readonly freeBusy = inject(FreeBusyService);
  /** Google free/busy intervals grouped by their start date for the busy rail. */
  private readonly busyByDate = computed<Map<string, { start: string; end: string }[]>>(() => {
    const map = new Map<string, { start: string; end: string }[]>();
    for (const iv of this.freeBusy.busy()) {
      const iso = (iv.start ?? '').slice(0, 10);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) continue;
      const arr = map.get(iso) ?? [];
      arr.push(iv);
      map.set(iso, arr);
    }
    return map;
  });
  readonly hasBusy = computed<boolean>(() => this.busyByDate().size > 0);
  busyForDay(iso: string): { start: string; end: string }[] {
    return this.busyByDate().get(iso) ?? [];
  }
  fmtRange(iv: { start: string; end: string }): string {
    const t = (iso: string) => {
      const m = iso.slice(11, 16); // HH:MM (UTC slice; display-only)
      return m || '';
    };
    return `${t(iv.start)}–${t(iv.end)}`;
  }
  occTitle(o: Occurrence): string {
    const price = occurrencePriceCents(HOURLY_RATE_CENTS, o.hours, o.crew, o.frequency);
    const who = o.customer_name ?? 'Recurring';
    return `${who} — ${o.service} · ${o.hours}h × ${o.crew} crew · ~$${(price / 100).toFixed(0)} (${o.frequency} contract)`;
  }
  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly mondayIso = signal<string>(this.initialMonday());
  readonly tz = signal<string>(this.resolveTz());

  /** The 7 ISO dates of the visible week (Mon→Sun). */
  private readonly weekIsos = computed<string[]>(() => {
    const start = this.parseIso(this.mondayIso());
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      return this.isoDate(d);
    });
  });

  private readonly byDate = computed<Map<string, Booking[]>>(() => {
    const map = new Map<string, Booking[]>();
    for (const b of this.visibleBookings()) {
      const iso = (b.preferred_date ?? '').slice(0, 10);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) continue;
      const arr = map.get(iso) ?? [];
      arr.push(b);
      map.set(iso, arr);
    }
    return map;
  });

  readonly days = computed<DayColumn[]>(() => {
    const todayIso = this.isoDate(new Date());
    return this.weekIsos().map((iso) => {
      const dayBookings = this.byDate().get(iso) ?? [];
      const untimed: Booking[] = [];
      const byHour = new Map<number, PlacedBooking[]>();
      for (const b of dayBookings) {
        const startHour = this.parseHour(b.preferred_time);
        if (startHour === null || startHour < HOUR_START || startHour > HOUR_END) {
          untimed.push(b);
          continue;
        }
        const cell = Math.floor(startHour);
        const rowSpan = Math.max(1, Math.round(b.hours ?? 1));
        const arr = byHour.get(cell) ?? [];
        arr.push({ booking: b, startHour, rowSpan });
        byHour.set(cell, arr);
      }
      const d = this.parseIso(iso);
      return {
        iso,
        label: `${DAY_NAMES[(d.getDay() + 6) % 7]} ${d.getDate()}`,
        isToday: iso === todayIso,
        untimed,
        byHour,
      };
    });
  });

  private readonly weekBookings = computed<Booking[]>(() =>
    this.weekIsos().flatMap((iso) => this.byDate().get(iso) ?? []),
  );

  readonly jobCount = computed<number>(() => this.weekBookings().length);
  readonly crewHours = computed<number>(() =>
    this.weekBookings().reduce((n, b) => n + (b.hours ?? 0) * Math.max(1, b.crew ?? 1), 0),
  );
  readonly revenueLabel = computed<string>(() => {
    const cents = this.weekBookings().reduce((n, b) => n + (b.total_cents ?? 0), 0);
    return `$${(cents / 100).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
  });
  readonly hasUntimed = computed<boolean>(() => this.days().some((d) => d.untimed.length > 0));

  readonly rangeLabel = computed<string>(() => {
    const isos = this.weekIsos();
    const start = this.parseIso(isos[0] ?? this.mondayIso());
    const end = this.parseIso(isos[6] ?? this.mondayIso());
    const opts: Intl.DateTimeFormatOptions = { month: 'short', day: 'numeric' };
    const sameMonth = start.getMonth() === end.getMonth();
    const left = start.toLocaleDateString(undefined, opts);
    const right = end.toLocaleDateString(undefined, sameMonth ? { day: 'numeric' } : opts);
    return `${left} – ${right}, ${end.getFullYear()}`;
  });

  constructor() {
    this.recurring.load(); // recurring overlay (no-op when flag off → 404 → [])
    // Google free/busy overlay — re-query whenever the visible week changes
    // (sync-on-open per range; 404/off → empty rail).
    effect(() => {
      const isos = this.weekIsos();
      if (isos.length === 7) {
        this.freeBusy.load(`${isos[0]}T00:00:00Z`, `${isos[6]}T23:59:59Z`);
      }
    });
    // Per-crew conflict data — load the visible week's assignments when the flag
    // is on (server 404s when off → empty map → time-overlap warning fallback).
    effect(() => {
      const isos = this.weekIsos();
      if (this.crewAware() && isos.length === 7) this.crewAssignments.load(isos[0]!, isos[6]!);
    });
    this.http
      .get<{ ok: boolean; bookings: Booking[] }>('/api/admin/bookings?limit=500', {
        withCredentials: true,
      })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((err: { status?: number }) => {
          this.error.set(
            err.status === 401
              ? 'Sign in as an operator to view the dispatch calendar.'
              : `Failed to load the schedule (HTTP ${err.status}).`,
          );
          return of({ ok: false, bookings: [] as Booking[] });
        }),
        finalize(() => this.loading.set(false)),
      )
      .subscribe((r) => this.bookings.set(r.bookings ?? []));
  }

  prevWeek(): void {
    this.shiftWeek(-7);
  }
  nextWeek(): void {
    this.shiftWeek(7);
  }
  goToday(): void {
    this.setMonday(this.mondayOf(new Date()));
  }

  /** Open the job-detail drawer for a chip. */
  open(b: Booking): void {
    this.selected.set(b);
  }

  /** Drawer saved a status change — reflect it in the loaded list. */
  onUpdated(updated: {
    id: string;
    status: string;
    hours: number | null;
    total_cents: number | null;
  }): void {
    this.bookings.update((list) =>
      list.map((b) =>
        b.id === updated.id
          ? { ...b, status: updated.status, hours: updated.hours, total_cents: updated.total_cents }
          : b,
      ),
    );
    this.selected.set(null);
  }

  /** Quick-create returned a new booking — add it to the loaded list. */
  onCreated(b: CreatedBooking): void {
    this.bookings.update((list) => [...list, b as unknown as Booking]);
    this.quickOpen.set(false);
  }

  // ── Cross-day + time drag-reschedule (drop a chip on a (day, hour) cell) ──
  private readonly draggingId = signal<string | null>(null);
  readonly dropCell = signal<string | null>(null); // `${iso}T${hour}`
  /**
   * Keyboard + single-pointer reschedule (WCAG 2.5.7 / 2.1.1). `movingId` is the
   * booking a "Move" button armed — while set, every (day, hour) cell becomes a
   * focusable click/Enter target reaching the SAME `pendingMove` the drag reaches.
   */
  readonly movingId = signal<string | null>(null);
  readonly pendingMove = signal<{
    id: string;
    customer: string;
    from: string;
    to: string;
    date: string;
    hour: number;
  } | null>(null);
  readonly moving = signal(false);
  readonly moveError = signal<string | null>(null);

  onDragStart(ev: DragEvent, id: string): void {
    this.draggingId.set(id);
    ev.dataTransfer?.setData('text/plain', id);
    if (ev.dataTransfer) ev.dataTransfer.effectAllowed = 'move';
  }
  onDragOver(ev: DragEvent, iso: string, hour: number): void {
    ev.preventDefault();
    const key = `${iso}T${hour}`;
    if (this.dropCell() !== key) this.dropCell.set(key);
  }
  onDragLeave(iso: string, hour: number): void {
    if (this.dropCell() === `${iso}T${hour}`) this.dropCell.set(null);
  }
  onDrop(ev: DragEvent, iso: string, hour: number): void {
    ev.preventDefault();
    this.dropCell.set(null);
    const id = ev.dataTransfer?.getData('text/plain') || this.draggingId();
    this.draggingId.set(null);
    if (!id) return;
    const b = this.bookings().find((x) => x.id === id);
    if (!b) return;
    const curDate = (b.preferred_date ?? '').slice(0, 10);
    const curHour = this.parseHour(b.preferred_time);
    if (curDate === iso && curHour !== null && Math.floor(curHour) === hour) return; // same cell
    this.stageMove(b, iso, hour);
  }

  // ── Keyboard / single-pointer reschedule (no drag) ────────────────────────
  /** Arm a job for a no-drag (day, hour) move ("Move" button click OR Enter/Space). */
  armMove(id: string): void {
    this.movingId.set(this.movingId() === id ? null : id);
    this.dropCell.set(null);
    this.moveError.set(null);
  }
  /** Cancel an armed move without rescheduling. */
  cancelArm(): void {
    this.movingId.set(null);
  }
  /** True while a (day, hour) cell should act as a click/keyboard reschedule target. */
  isMoveTarget(iso: string, hour: number): boolean {
    const id = this.movingId();
    if (!id) return false;
    const b = this.bookings().find((x) => x.id === id);
    if (!b) return false;
    const curDate = (b.preferred_date ?? '').slice(0, 10);
    const curHour = this.parseHour(b.preferred_time);
    return !(curDate === iso && curHour !== null && Math.floor(curHour) === hour); // not its own cell
  }
  /** Activate a target cell (click or Enter/Space) → stage the same reschedule. */
  activateCell(iso: string, hour: number): void {
    const id = this.movingId();
    if (!id) return;
    const b = this.bookings().find((x) => x.id === id);
    this.movingId.set(null);
    if (!b) return;
    const curDate = (b.preferred_date ?? '').slice(0, 10);
    const curHour = this.parseHour(b.preferred_time);
    if (curDate === iso && curHour !== null && Math.floor(curHour) === hour) return; // same cell — no-op
    this.stageMove(b, iso, hour);
  }
  /** Shared: stage a pending reschedule (used by BOTH drop and keyboard/click). */
  private stageMove(b: Booking, iso: string, hour: number): void {
    const curDate = (b.preferred_date ?? '').slice(0, 10);
    const curHour = this.parseHour(b.preferred_time);
    this.pendingMove.set({
      id: b.id,
      customer: b.customer_name ?? 'Customer',
      from: `${curDate || '—'} ${curHour !== null ? this.fmtTime(curHour) : ''}`.trim(),
      to: `${iso} ${this.fmtTime(hour)}`,
      date: iso,
      hour,
    });
    this.moveError.set(null);
  }

  /** Confirm the pending reschedule → PATCH preferred_date + preferred_time.
   *  Pricing (hours/crew/total) is untouched server-side. */
  confirmMove(): void {
    const mv = this.pendingMove();
    if (!mv) return;
    const hhmm = `${String(mv.hour).padStart(2, '0')}:00`;
    this.moving.set(true);
    this.moveError.set(null);
    this.http
      .patch<{ ok: boolean }>(
        `/api/admin/bookings/${mv.id}`,
        { preferred_date: mv.date, preferred_time: hhmm },
        { withCredentials: true },
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() => of({ ok: false })),
        finalize(() => this.moving.set(false)),
      )
      .subscribe((r) => {
        if (!r.ok) {
          this.moveError.set('Could not reschedule. Check your operator session and try again.');
          return;
        }
        this.bookings.update((list) =>
          list.map((b) =>
            b.id === mv.id ? { ...b, preferred_date: mv.date, preferred_time: hhmm } : b,
          ),
        );
        this.pendingMove.set(null);
      });
  }
  cancelMove(): void {
    this.pendingMove.set(null);
    this.moveError.set(null);
  }

  primaryService(b: Booking): string {
    return (b.services_csv ?? '').split(',')[0]?.trim().replace(/-/g, ' ') || 'job';
  }

  /** Full Tailwind class string for a job chip, color-coded by primary service. */
  chipClass(b: Booking): string {
    const base = 'block truncate rounded-md px-1.5 py-1 text-[11px] leading-tight ';
    const svc = this.primaryService(b).toLowerCase();
    // Order matters: "junk removal" contains "mov" — match haul/junk first.
    if (svc.includes('haul') || svc.includes('junk'))
      return base + 'bg-emerald-500/15 text-emerald-200';
    if (svc.includes('clean')) return base + 'bg-sky-500/15 text-sky-200';
    if (svc.includes('yard') || svc.includes('lawn')) return base + 'bg-lime-500/15 text-lime-200';
    if (svc.includes('moving') || svc.includes('move'))
      return base + 'bg-bcl-accent/15 text-bcl-accent';
    // Fallback chip — text-bcl-ink (bright) not the muted tone (WCAG AA: muted-on-
    // muted-tint was ~2.2:1; bcl-ink clears 4.5:1).
    return base + 'bg-bcl-ink-muted/15 text-bcl-ink';
  }

  chipTitle(b: Booking): string {
    const who = b.customer_name ?? 'Customer';
    const where = b.city ? ` · ${b.city}` : '';
    const hrs = b.hours ? ` · ${b.hours}h` : '';
    const crew = b.crew ? ` · ${b.crew} crew` : '';
    return `${who}${where} — ${this.primaryService(b)}${hrs}${crew} · ${b.status}`;
  }

  hourLabel(h: number): string {
    const period = h < 12 ? 'a' : 'p';
    const hour12 = h % 12 === 0 ? 12 : h % 12;
    return `${hour12}${period}`;
  }

  fmtTime(startHour: number): string {
    const h = Math.floor(startHour);
    const m = Math.round((startHour - h) * 60);
    const period = h < 12 ? 'am' : 'pm';
    const hour12 = h % 12 === 0 ? 12 : h % 12;
    return m === 0 ? `${hour12}${period}` : `${hour12}:${String(m).padStart(2, '0')}${period}`;
  }

  /** Parse "14:30", "2:30 PM", "9am", "08:00:00" → fractional hour, or null.
   *  Delegates to the shared calendar parser (single source of truth). */
  parseHour(raw: string | null): number | null {
    return parseHourValue(raw);
  }

  private shiftWeek(deltaDays: number): void {
    const d = this.parseIso(this.mondayIso());
    d.setDate(d.getDate() + deltaDays);
    this.setMonday(this.isoDate(d));
  }

  private setMonday(iso: string): void {
    this.mondayIso.set(iso);
    void this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { w: iso },
      queryParamsHandling: 'merge',
      replaceUrl: true,
    });
  }

  private mondayOf(d: Date): string {
    const copy = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const offset = (copy.getDay() + 6) % 7; // 0 = Monday
    copy.setDate(copy.getDate() - offset);
    return this.isoDate(copy);
  }

  private initialMonday(): string {
    const raw = new URLSearchParams(
      typeof window === 'undefined' ? '' : window.location.search,
    ).get('w');
    if (raw && /^\d{4}-\d{2}-\d{2}$/.test(raw)) return this.mondayOf(this.parseIso(raw));
    return this.mondayOf(new Date());
  }

  private parseIso(iso: string): Date {
    const [y, m, d] = iso.split('-').map(Number);
    return new Date(y ?? 1970, (m ?? 1) - 1, d ?? 1);
  }

  private isoDate(d: Date): string {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }

  private resolveTz(): string {
    try {
      return Intl.DateTimeFormat().resolvedOptions().timeZone || 'local';
    } catch {
      return 'local';
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'week-view-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
