import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * TeamService — directory + invites backed by `/api/team/*`.
 */
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import type { BclRole } from '../_shared/role-badge.component';

export interface TeamMember {
  readonly id: string;
  readonly email: string;
  readonly displayName: string;
  readonly avatarUrl: string | null;
  readonly role: BclRole;
  readonly status: 'active' | 'pending' | 'suspended';
  readonly lastActiveAt: string | null;
}

export interface PendingInvite {
  readonly id: string;
  readonly email: string;
  readonly role: BclRole;
  readonly invitedAt: string;
  readonly invitedBy: string;
}

export interface AuditEntry {
  readonly id: string;
  readonly action: string;
  readonly detail: string;
  readonly at: string;
}

interface ErrEnvelope {
  readonly ok: false;
  readonly error: string;
}

@Injectable({ providedIn: 'root' })
export class TeamService {
  private readonly http = inject(HttpClient);

  readonly members = signal<readonly TeamMember[]>([]);
  readonly invites = signal<readonly PendingInvite[]>([]);
  readonly loading = signal<boolean>(false);
  readonly error = signal<string | null>(null);

  async loadAll(): Promise<void> {
    this.loading.set(true);
    try {
      const r = await firstValueFrom(
        this.http.get<{ ok: true; members: TeamMember[]; invites: PendingInvite[] } | ErrEnvelope>(
          '/api/team',
        ),
      );
      if (r.ok) {
        this.members.set(r.members);
        this.invites.set(r.invites);
      } else {
        this.error.set(r.error);
      }
    } catch (e) {
      this.error.set(this.extract(e));
    } finally {
      this.loading.set(false);
    }
  }

  async invite(email: string, role: BclRole): Promise<void> {
    const r = await firstValueFrom(
      this.http.post<{ ok: true; invite: PendingInvite } | ErrEnvelope>('/api/team/invite', {
        email,
        role,
      }),
    );
    if (!r.ok) throw new Error(r.error);
    this.invites.update((arr) => [...arr, r.invite]);
  }

  async resendInvite(id: string): Promise<void> {
    const r = await firstValueFrom(
      this.http.post<{ ok: true } | ErrEnvelope>(
        `/api/team/invite/${encodeURIComponent(id)}/resend`,
        {},
      ),
    );
    if (!r.ok) throw new Error(r.error);
  }

  async revokeInvite(id: string): Promise<void> {
    const r = await firstValueFrom(
      this.http.delete<{ ok: true } | ErrEnvelope>(`/api/team/invite/${encodeURIComponent(id)}`),
    );
    if (!r.ok) throw new Error(r.error);
    this.invites.update((arr) => arr.filter((i) => i.id !== id));
  }

  async loadMember(id: string): Promise<{
    member: TeamMember;
    audit: readonly AuditEntry[];
  } | null> {
    try {
      const r = await firstValueFrom(
        this.http.get<{ ok: true; member: TeamMember; audit: AuditEntry[] } | ErrEnvelope>(
          `/api/team/${encodeURIComponent(id)}`,
        ),
      );
      if (r.ok) return { member: r.member, audit: r.audit };
      this.error.set(r.error);
    } catch (e) {
      this.error.set(this.extract(e));
    }
    return null;
  }

  async updateRole(id: string, role: BclRole): Promise<void> {
    const r = await firstValueFrom(
      this.http.put<{ ok: true } | ErrEnvelope>(`/api/team/${encodeURIComponent(id)}/role`, {
        role,
      }),
    );
    if (!r.ok) throw new Error(r.error);
    this.members.update((arr) => arr.map((m) => (m.id === id ? { ...m, role } : m)));
  }

  async remove(id: string): Promise<void> {
    const r = await firstValueFrom(
      this.http.delete<{ ok: true } | ErrEnvelope>(`/api/team/${encodeURIComponent(id)}`),
    );
    if (!r.ok) throw new Error(r.error);
    this.members.update((arr) => arr.filter((m) => m.id !== id));
  }

  private extract(e: unknown): string {
    if (e instanceof HttpErrorResponse) {
      const body = e.error as ErrEnvelope | null;
      return body?.error ?? `HTTP ${e.status}`;
    }
    return e instanceof Error ? e.message : 'Unknown error';
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'team-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
