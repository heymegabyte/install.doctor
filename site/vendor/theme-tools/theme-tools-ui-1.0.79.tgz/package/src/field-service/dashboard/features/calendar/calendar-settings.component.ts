import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * CalendarSettingsComponent — the dispatch calendar settings + sync surface
 * (/dashboard/calendar/settings).
 *
 * Documents the calendar provider architecture (internal Brick Labor calendar +
 * Google Calendar adapter + ICS + future CalDAV), surfaces the Google Calendar
 * connection status from /api/google-calendar/status, and starts the
 * server-side OAuth flow via /api/google-calendar/oauth/start (tokens are stored
 * server-side only in integration_calendar_syncs — never exposed to the
 * browser). Gated by `google_calendar_2way`. Disconnect/revoke + free-busy +
 * incremental sync land in later increments.
 */
import { ChangeDetectionStrategy, Component, DestroyRef, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, finalize, of } from 'rxjs';
import { FeatureFlagService } from '../../core/feature-flag.service';
import { routeFade, reducedMotion } from '../../shared/animations';

interface SyncStatus {
  readonly ok: boolean;
  readonly connected: boolean;
  readonly sync?: { status?: string; last_synced_at?: string; created_at?: string } | null;
}

interface IcsPreviewEvent {
  readonly startIso: string;
  readonly endIso?: string;
  readonly summary: string;
  readonly location?: string;
}

@Component({
  selector: 'app-calendar-settings',
  standalone: true,
  imports: [RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header
      class="bcl-rise mb-5 flex flex-wrap items-end justify-between gap-4 rounded-2xl border border-bcl-border bcl-grain p-6"
    >
      <div class="min-w-0">
        <p class="bcl-eyebrow mb-2">Dispatch · Calendar settings</p>
        <h1 class="font-display text-3xl font-extrabold tracking-tight text-bcl-ink">
          Sync &amp; settings
        </h1>
        <p class="mt-2 max-w-2xl text-sm text-bcl-ink-muted">
          Connect Google Calendar, export jobs as iCalendar, and review the provider architecture.
        </p>
      </div>
      <a
        routerLink="/calendar/month"
        class="rounded-lg border border-bcl-border px-3 py-1.5 text-xs text-bcl-ink-muted transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
        >‹ Back to calendar</a
      >
    </header>

    <!-- Google Calendar -->
    <section class="bcl-glass mb-5 p-5" data-testid="cal-google-card">
      <div class="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 class="font-display text-lg font-bold text-bcl-ink">Google Calendar</h2>
          <p class="mt-1 text-sm" [class]="statusClass()" data-testid="cal-google-status">
            {{ statusLabel() }}
          </p>
        </div>
        <div class="flex flex-wrap items-center gap-2">
          @if (connected()) {
            <button
              type="button"
              (click)="disconnect()"
              [disabled]="disconnecting()"
              class="rounded-lg border border-bcl-border px-4 py-2 text-sm font-semibold text-bcl-ink-muted transition-all duration-[333ms] disabled:opacity-60 hover:border-rose-400/60 hover:text-rose-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-400 focus-visible:ring-offset-2 focus-visible:ring-offset-bcl-bg"
              data-testid="cal-google-disconnect"
            >
              {{ disconnecting() ? 'Disconnecting…' : 'Disconnect' }}
            </button>
          }
          <button
            type="button"
            (click)="connect()"
            [disabled]="connecting()"
            class="rounded-lg bg-bcl-accent px-4 py-2 text-sm font-semibold text-bcl-bg transition-all duration-[333ms] disabled:opacity-60 hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bcl-bg"
            data-testid="cal-google-connect"
          >
            {{
              connecting()
                ? 'Opening Google…'
                : connected()
                  ? 'Reconnect'
                  : 'Connect Google Calendar'
            }}
          </button>
        </div>
      </div>
      @if (connectError()) {
        <p
          class="mt-3 rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 text-xs text-amber-300"
          role="alert"
        >
          {{ connectError() }}
        </p>
      }
      @if (disconnectError()) {
        <p
          class="mt-3 rounded-lg border border-rose-500/30 bg-rose-500/5 p-3 text-xs text-rose-300"
          role="alert"
        >
          {{ disconnectError() }}
        </p>
      }
      <p class="mt-3 text-xs text-bcl-ink-muted">
        Two-way sync pushes Brick Labor jobs to your Google Calendar and reads free/busy so dispatch
        avoids double-booking. Tokens are stored server-side only — never in the browser.
      </p>
    </section>

    <!-- iCalendar / CalDAV -->
    <section class="bcl-glass mb-5 p-5">
      <h2 class="font-display text-lg font-bold text-bcl-ink">iCalendar (.ics) &amp; CalDAV</h2>
      <p class="mt-1 text-sm text-bcl-ink-muted">
        Export the next 90 days of dispatch jobs as a single .ics to subscribe in Google, Apple, or
        Outlook. Per-booking invites already ship on confirmation; feed import + CalDAV come next.
      </p>
      @if (icsEnabled()) {
        <a
          [href]="icsHref()"
          download="bricklabor-dispatch.ics"
          class="mt-3 inline-flex items-center gap-2 rounded-lg border border-bcl-border px-4 py-2 text-sm font-semibold text-bcl-ink transition-all duration-[333ms] hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bcl-bg"
          data-testid="cal-ics-export"
          >↓ Export dispatch calendar (.ics)</a
        >

        <!-- Import -->
        <div class="mt-4 border-t border-bcl-border pt-4">
          <label
            class="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-bcl-border px-4 py-2 text-sm font-semibold text-bcl-ink transition-all duration-[333ms] hover:border-bcl-accent hover:text-bcl-accent focus-within:border-bcl-accent focus-within:ring-2 focus-within:ring-bcl-accent"
            data-testid="cal-ics-import-label"
          >
            ↥ Import .ics (preview)
            <input
              type="file"
              accept=".ics,text/calendar"
              class="sr-only"
              (change)="onIcsFile($event)"
              data-testid="cal-ics-import-input"
            />
          </label>
          @if (importError()) {
            <p class="mt-2 text-xs text-rose-300" role="alert">{{ importError() }}</p>
          }
          @if (importResult()) {
            <p class="mt-2 text-xs text-emerald-300" role="status">
              Imported {{ importResult() }} job(s).
            </p>
          }
          @if (previewEvents().length) {
            <div class="mt-3 rounded-lg border border-bcl-border bg-bcl-bg-elev/40 p-3">
              <p class="bcl-eyebrow text-[10px] mb-2">
                {{ previewEvents().length }} event(s) — select to import as jobs
              </p>
              <ul class="max-h-48 space-y-1 overflow-y-auto" role="list">
                @for (ev of previewEvents(); track $index) {
                  <li class="flex items-center gap-2 text-xs text-bcl-ink">
                    <input
                      type="checkbox"
                      [checked]="selected().has($index)"
                      (change)="toggleSel($index)"
                      [attr.aria-label]="ev.summary"
                    />
                    <span class="truncate"
                      >{{ ev.startIso.slice(0, 16).replace('T', ' ') }} · {{ ev.summary }}</span
                    >
                  </li>
                }
              </ul>
              <button
                type="button"
                (click)="applyImport()"
                [disabled]="importing() || selected().size === 0"
                class="mt-3 rounded-lg bg-bcl-accent px-4 py-2 text-sm font-semibold text-bcl-bg transition-all duration-[333ms] disabled:opacity-50 hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                data-testid="cal-ics-import-apply"
              >
                {{ importing() ? 'Importing…' : 'Import ' + selected().size + ' selected' }}
              </button>
            </div>
          }
        </div>
      } @else {
        <p class="mt-3 text-xs text-bcl-ink-muted">
          Enable the <code class="text-bcl-accent">calendar_ics_import_export</code> flag in
          <a routerLink="/admin/flags" class="text-bcl-accent underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent">Flags</a> to export/import.
        </p>
      }
    </section>

    <!-- Architecture + env docs -->
    <section class="bcl-glass p-5">
      <h2 class="font-display text-lg font-bold text-bcl-ink">Setup &amp; architecture</h2>
      <ul class="mt-2 space-y-1.5 text-sm text-bcl-ink-muted">
        <li>
          · Providers: internal Brick Labor calendar · Google Calendar adapter · ICS import/export ·
          CalDAV (future).
        </li>
        <li>
          · Required env vars (server-side only):
          <code class="text-bcl-accent">GOOGLE_OAUTH_CLIENT_ID</code>,
          <code class="text-bcl-accent">GOOGLE_OAUTH_CLIENT_SECRET</code>.
        </li>
        <li>
          · Obtain them at the
          <a
            href="https://console.cloud.google.com/apis/credentials"
            target="_blank"
            rel="noopener noreferrer"
            class="text-bcl-accent underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            >Google Cloud Console → Credentials</a
          >
          (enable the Google Calendar API, create an OAuth client, add the worker callback as an
          authorized redirect URI).
        </li>
        <li>
          · Pricing stays hourly (HOURLY_RATE_CENTS) — calendar events are operational only, never
          billing.
        </li>
      </ul>
    </section>
  `,
})
export class CalendarSettingsComponent {
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);
  private readonly flags = inject(FeatureFlagService);

  /** ICS export is gated by the calendar_ics_import_export flag. */
  readonly icsEnabled = this.flags.isOn('calendar_ics_import_export');
  /** Download URL for the next 90 days of dispatch jobs as a single .ics. */
  icsHref(): string {
    const today = new Date();
    const to = new Date(today.getTime() + 90 * 86_400_000);
    const ymd = (d: Date) =>
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    return `/api/admin/bookings.ics?from=${ymd(today)}&to=${ymd(to)}`;
  }

  // ── ICS import (upload → preview → apply) ─────────────────────────────────
  readonly previewEvents = signal<IcsPreviewEvent[]>([]);
  readonly selected = signal<Set<number>>(new Set());
  readonly importing = signal(false);
  readonly importError = signal<string | null>(null);
  readonly importResult = signal<number | null>(null);

  onIcsFile(ev: Event): void {
    const file = (ev.target as HTMLInputElement).files?.[0];
    if (!file) return;
    this.importError.set(null);
    this.importResult.set(null);
    void file.text().then((text) => {
      this.http
        .post<{ ok: boolean; events?: IcsPreviewEvent[] }>('/api/admin/calendar-ics/import', text, {
          headers: { 'content-type': 'text/calendar' },
          withCredentials: true,
        })
        .pipe(
          takeUntilDestroyed(this.destroyRef),
          catchError(() => of({ ok: false, events: [] as IcsPreviewEvent[] })),
        )
        .subscribe((r) => {
          if (!r.ok) {
            this.importError.set('Could not parse that .ics file.');
            return;
          }
          const events = r.events ?? [];
          this.previewEvents.set(events);
          this.selected.set(new Set(events.map((_, i) => i))); // default: all selected
        });
    });
  }

  toggleSel(i: number): void {
    this.selected.update((s) => {
      const next = new Set(s);
      next.has(i) ? next.delete(i) : next.add(i);
      return next;
    });
  }

  applyImport(): void {
    const sel = this.selected();
    const events = this.previewEvents().filter((_, i) => sel.has(i));
    if (events.length === 0) return;
    this.importing.set(true);
    this.importError.set(null);
    this.http
      .post<{ ok: boolean; created?: number }>(
        '/api/admin/calendar-ics/apply',
        { events },
        { withCredentials: true },
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() => of({ ok: false, created: 0 })),
        finalize(() => this.importing.set(false)),
      )
      .subscribe((r) => {
        if (!r.ok) {
          this.importError.set('Could not import the selected events.');
          return;
        }
        this.importResult.set(r.created ?? 0);
        this.previewEvents.set([]);
        this.selected.set(new Set());
      });
  }

  readonly connected = signal(false);
  readonly statusText = signal<string>('Checking connection…');
  readonly connecting = signal(false);
  readonly connectError = signal<string | null>(null);
  readonly disconnecting = signal(false);
  readonly disconnectError = signal<string | null>(null);

  constructor() {
    this.loadStatus();
  }

  /** Fetch the live Google sync status for the SESSION operator (no userId — the
   *  worker resolves it from the bcl_admin_sid / bcl_work_sid cookie). */
  private loadStatus(): void {
    this.http
      .get<SyncStatus>('/api/google-calendar/status', { withCredentials: true })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() => of<SyncStatus>({ ok: false, connected: false, sync: null })),
      )
      .subscribe((s) => {
        this.connected.set(!!s.connected);
        this.statusText.set(
          s.connected
            ? `Connected${s.sync?.last_synced_at ? ` · last synced ${this.fmt(s.sync.last_synced_at)}` : ''}`
            : 'Not connected',
        );
      });
  }

  statusLabel(): string {
    return this.statusText();
  }
  statusClass(): string {
    return this.connected() ? 'text-emerald-300' : 'text-bcl-ink-muted';
  }

  connect(): void {
    this.connecting.set(true);
    this.connectError.set(null);
    this.http
      .get<{ ok: boolean; authorizeUrl?: string; error?: string }>(
        '/api/google-calendar/oauth/start',
        { withCredentials: true },
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() =>
          of<{ ok: boolean; authorizeUrl?: string; error?: string }>({
            ok: false,
            error: 'request_failed',
          }),
        ),
        finalize(() => this.connecting.set(false)),
      )
      .subscribe((r) => {
        if (r.ok && r.authorizeUrl) {
          window.location.href = r.authorizeUrl;
        } else {
          this.connectError.set(
            'Could not start Google sign-in. Confirm GOOGLE_OAUTH_CLIENT_ID / SECRET are set and the google_calendar_2way flag is on.',
          );
        }
      });
  }

  /** Revoke + delete the session operator's Google sync server-side, then refresh
   *  status. The worker derives the operator from the session cookie — no id is
   *  sent from the browser, and the token never touches the client. */
  disconnect(): void {
    this.disconnecting.set(true);
    this.disconnectError.set(null);
    this.http
      .post<{ ok: boolean; disconnected?: boolean; error?: string }>(
        '/api/google-calendar/disconnect',
        {},
        { withCredentials: true },
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() =>
          of<{ ok: boolean; disconnected?: boolean; error?: string }>({
            ok: false,
            error: 'request_failed',
          }),
        ),
        finalize(() => this.disconnecting.set(false)),
      )
      .subscribe((r) => {
        if (r.ok) {
          this.connected.set(false);
          this.statusText.set('Not connected');
          this.loadStatus();
        } else {
          this.disconnectError.set('Could not disconnect Google Calendar. Please try again.');
        }
      });
  }

  private fmt(iso: string): string {
    try {
      return new Date(iso).toLocaleString(undefined, {
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
      });
    } catch {
      return iso;
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'calendar-settings-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
