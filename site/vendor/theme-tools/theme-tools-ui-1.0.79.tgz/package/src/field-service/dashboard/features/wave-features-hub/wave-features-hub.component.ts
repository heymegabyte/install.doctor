import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * WaveFeaturesHubComponent — single dashboard page that shows EVERY
 * wave-feature shipped to the worker. Super-admin only. Lets brian@megabyte.space
 * see every flag, status, endpoint, direct UI link, and "live probe" verifier
 * in one screen.
 *
 * Reads `/api/feature-flags` for the public allowlisted set + falls back to
 * the canonical hardcoded catalog so unlisted (admin-only) flags still show.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, of } from 'rxjs';
import { RoleService } from '../../core/role.service';
import { routeFade, reducedMotion } from '../../shared/animations';

interface WaveFeature {
  readonly key: string;
  readonly wave: 'wave27' | 'wave30' | 'wave31';
  readonly label: string;
  readonly description: string;
  readonly endpoint?: string;
  readonly uiHref?: string;
  readonly uiLabel?: string;
  readonly probePath?: string;
  readonly probeMethod?: 'GET' | 'POST';
  readonly status: 'shipped' | 'scaffolded';
}

// Canonical catalog — every feature we've shipped or scaffolded.
// Order: most user-impactful first.
const CATALOG: readonly WaveFeature[] = [
  {
    key: 'mid_job_nps',
    wave: 'wave31',
    label: 'Mid-Job NPS Interception',
    description:
      'Catches unhappy customers 90 min before they post a 1-star review. Auto-SMS at 50% gig elapsed; dispatcher alert on score ≤ 6.',
    endpoint: '/api/mid-job-nps',
    uiHref: '/ops/nps-queue',
    uiLabel: 'Open dispatcher queue',
    probePath: '/api/mid-job-nps/admin/queue',
    probeMethod: 'GET',
    status: 'shipped',
  },
  {
    key: 'reverse_auction',
    wave: 'wave31',
    label: 'Reverse-Auction Marketplace',
    description:
      'Customers post off-peak jobs (Sun/Mon 11-14); crews bid DOWN. Inverts surge to capture slow-day demand.',
    endpoint: '/api/reverse-auction',
    uiHref: '/auctions',
    uiLabel: 'Open auctions',
    probePath: '/api/reverse-auction/open',
    probeMethod: 'GET',
    status: 'shipped',
  },
  {
    key: 'inventory_insurance',
    wave: 'wave31',
    label: 'AI Inventory Insurance',
    description:
      'Vision-estimate photo inventory → instant rider via Hiscox/NEXT (stub today). 3 tiers, $9 floor.',
    endpoint: '/api/inventory-insurance',
    uiHref: '/insurance',
    uiLabel: 'Get an insurance quote',
    probePath: '/api/inventory-insurance/carrier',
    probeMethod: 'GET',
    status: 'shipped',
  },
  {
    key: 'ai_move_plan_pdf',
    wave: 'wave30',
    label: 'AI Move-Plan PDF',
    description:
      'Customer submits move details → Workers AI generates a custom 3-page packing plan; emailed via Resend.',
    endpoint: '/api/move-plan-lead-magnet',
    status: 'shipped',
  },
  {
    key: 'weather_discount_push',
    wave: 'wave30',
    label: 'Weather-Driven Discount Push',
    description:
      'NOAA Weather API for service ZIPs. When today is rain + tomorrow clear, queue a "book tomorrow" SMS to opt-in subscribers.',
    endpoint: '/api/weather-discount',
    probePath: '/api/weather-discount/forecast?zip=07102',
    probeMethod: 'GET',
    status: 'shipped',
  },
  {
    key: 'neighbor_referrals',
    wave: 'wave27',
    label: 'Neighbor Referrals',
    description:
      'Customer mints a /by/<slug> landing page. Code auto-applies on click-through; $25 credit on completed referral.',
    endpoint: '/api/neighbor-referrals',
    uiHref: 'https://bricklabor.com/me',
    uiLabel: 'Mint your link on /me',
    status: 'shipped',
  },
  {
    key: 'same_day_transparency',
    wave: 'wave27',
    label: 'Same-Day Surge Transparency',
    description:
      'On the booking page, when the customer picks today, shows a side-by-side card: today (+35%) vs tomorrow (no surge) with a one-tap "switch to tomorrow" button.',
    uiHref: 'https://bricklabor.com/book',
    uiLabel: 'Try on /book (pick today)',
    status: 'shipped',
  },
  {
    key: 'photo_to_quote',
    wave: 'wave27',
    label: 'SMS-First Photo Quote',
    description:
      'Customer texts a photo to Twilio. AI vision estimates the job; SMS replies with a quote band + deposit link.',
    endpoint: '/api/sms-inbound',
    status: 'shipped',
  },
];

interface ProbeResult {
  readonly key: string;
  readonly status: number | 'error';
  readonly latencyMs: number;
}

@Component({
  selector: 'app-wave-features-hub',
  standalone: true,
  imports: [RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header class="bcl-rise mb-8 rounded-2xl border border-bcl-border bcl-grain p-6 sm:p-10">
      <p class="bcl-eyebrow mb-3">Super Admin · Feature Hub</p>
      <h1
        class="font-display font-extrabold tracking-tight"
        style="font-size: var(--bcl-text-3xl);"
      >
        Everything that's shipped to <span class="bcl-text-gradient">bricklabor.com</span>
      </h1>
      <p class="mt-2 max-w-2xl text-sm text-bcl-ink-muted">
        Every feature module wired into the worker. Flag state, endpoint, direct UI link, and a live
        probe verifier for each. Click "Probe live" to hit the prod endpoint.
      </p>
    </header>

    <section class="bcl-bento">
      @for (f of catalog; track f.key) {
        <article class="bcl-glass bcl-fade-in relative overflow-hidden p-5">
          <header class="mb-2 flex items-start justify-between gap-3">
            <div>
              <p class="bcl-eyebrow">{{ f.wave }} · {{ f.status }}</p>
              <h3 class="mt-1 font-display text-lg font-extrabold text-bcl-ink">
                {{ f.label }}
              </h3>
            </div>
            @if (flagState()[f.key]) {
              <span
                class="inline-flex items-center gap-1 rounded-full bg-emerald-400/15 px-2.5 py-0.5 text-[11px] font-mono font-bold text-emerald-300"
              >
                <span class="bcl-live-dot"></span>
                LIVE
              </span>
            } @else {
              <span
                class="rounded-full bg-amber-400/15 px-2.5 py-0.5 text-[11px] font-mono font-bold text-amber-300"
              >
                FLAG OFF
              </span>
            }
          </header>

          <p class="mb-4 text-sm text-bcl-ink-muted leading-relaxed">{{ f.description }}</p>

          <div class="flex flex-wrap items-center gap-2">
            @if (f.uiHref) {
              <a
                [routerLink]="f.uiHref.startsWith('http') ? null : f.uiHref"
                [attr.href]="f.uiHref.startsWith('http') ? f.uiHref : null"
                [attr.target]="f.uiHref.startsWith('http') ? '_blank' : null"
                class="inline-flex items-center gap-1 rounded-md bg-bcl-accent px-3 py-1.5 text-xs font-extrabold text-bcl-bg focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              >
                {{ f.uiLabel ?? 'Open UI' }} →
              </a>
            }
            @if (f.probePath) {
              <button
                type="button"
                (click)="probe(f)"
                class="inline-flex items-center gap-1 rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-3 py-1.5 text-xs font-bold text-bcl-ink hover:bg-bcl-bg-elev focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              >
                Probe live
              </button>
            }
            @if (f.endpoint) {
              <code class="text-[11px] text-bcl-ink-muted font-mono">{{ f.endpoint }}</code>
            }
          </div>

          @if (probesByKey()[f.key]; as p) {
            <p
              class="mt-3 text-xs font-mono"
              [class.text-emerald-300]="p.status === 200"
              [class.text-amber-300]="p.status === 404 || p.status === 401"
              [class.text-red-300]="p.status === 'error'"
            >
              ↳ status {{ p.status }} · {{ p.latencyMs }}ms
              @if (p.status === 404) {
                <span class="text-bcl-ink-muted">(flag off — expected)</span>
              } @else if (p.status === 401) {
                <span class="text-bcl-ink-muted">(auth required — expected for admin paths)</span>
              }
            </p>
          }
        </article>
      }
    </section>

    <p class="mt-8 max-w-3xl text-xs text-bcl-ink-muted leading-relaxed">
      Flag state is read from <code>/api/feature-flags</code> which only returns the
      browser-allowlisted set. Admin-only flags appear as "FLAG OFF" here even when enabled in D1 —
      visit <a routerLink="/admin/feature-flags" class="text-bcl-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring">/admin/feature-flags</a>
      for the source of truth.
    </p>
  `,
})
export class WaveFeaturesHubComponent {
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);
  private readonly role = inject(RoleService);

  readonly catalog = CATALOG;

  readonly flagState = signal<Record<string, boolean>>({});
  readonly probesByKey = signal<Record<string, ProbeResult>>({});

  constructor() {
    this.refreshFlags();
  }

  private refreshFlags(): void {
    this.http
      .get<{ ok: boolean; flags: Record<string, boolean> }>('/api/feature-flags')
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() => of({ ok: false, flags: {} })),
      )
      .subscribe((r) => this.flagState.set(r.flags ?? {}));
  }

  async probe(f: WaveFeature): Promise<void> {
    if (!f.probePath) return;
    const t0 = performance.now();
    try {
      const res = await fetch(f.probePath, {
        method: f.probeMethod ?? 'GET',
        credentials: 'include',
      });
      const latencyMs = Math.round(performance.now() - t0);
      this.probesByKey.update((p) => ({
        ...p,
        [f.key]: { key: f.key, status: res.status, latencyMs },
      }));
    } catch {
      const latencyMs = Math.round(performance.now() - t0);
      this.probesByKey.update((p) => ({
        ...p,
        [f.key]: { key: f.key, status: 'error', latencyMs },
      }));
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'wave-features-hub-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
