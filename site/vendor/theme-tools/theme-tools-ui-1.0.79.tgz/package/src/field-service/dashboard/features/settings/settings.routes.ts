import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { Route } from '@angular/router';

/**
 * Settings — child routes per area. Each lazy-loaded to keep boot fast.
 */
export const SETTINGS_ROUTES: Route[] = [
  {
    path: '',
    loadComponent: () => import('./settings.component').then((m) => m.SettingsComponent),
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'profile' },
      {
        path: 'profile',
        loadComponent: () => import('./profile.component').then((m) => m.SettingsProfileComponent),
      },
      {
        // Workspace (org name/domain/logo/brand-color) was SaaS multi-tenant whitelabel cruft from the
        // starter scaffold — Brick Labor is one business, a customer can't rebrand it (fire-51 removed it).
        // Redirect stale bookmarks to the profile tab.
        path: 'workspace',
        redirectTo: 'profile',
        pathMatch: 'full',
      },
      {
        path: 'security',
        loadComponent: () =>
          import('./security.component').then((m) => m.SettingsSecurityComponent),
      },
      {
        path: 'notifications',
        loadComponent: () =>
          import('./notifications.component').then((m) => m.SettingsNotificationsComponent),
      },
      {
        path: 'appearance',
        loadComponent: () =>
          import('./appearance.component').then((m) => m.SettingsAppearanceComponent),
      },
      {
        path: 'api-webhooks',
        loadComponent: () =>
          import('./api-webhooks.component').then((m) => m.SettingsApiWebhooksComponent),
      },
      {
        path: 'integrations',
        loadComponent: () =>
          import('./integrations.component').then((m) => m.SettingsIntegrationsComponent),
      },
      {
        path: 'data-rights',
        loadComponent: () =>
          import('./data-rights.component').then((m) => m.SettingsDataRightsComponent),
      },
      {
        path: 'address-book',
        loadComponent: () =>
          import('./address-book.component').then((m) => m.SettingsAddressBookComponent),
      },
      {
        path: 'danger-zone',
        loadComponent: () =>
          import('./danger-zone.component').then((m) => m.SettingsDangerZoneComponent),
      },
    ],
  },
];
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'settings-routes',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
