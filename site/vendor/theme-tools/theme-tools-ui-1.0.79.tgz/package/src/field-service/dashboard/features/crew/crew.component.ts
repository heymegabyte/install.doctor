import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CrewComponent — Wave 26 crew control center.
 *
 * Online-toggle drives the geolocation watcher + the crew-stream WebSocket.
 * Earnings ticker, surge heatmap, gig-offer bottom-sheet (broadcast wired),
 * instant-payout dialog, and mileage CSV export all live here.
 */
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  ElementRef,
  computed,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { RouterLink } from '@angular/router';
import { interval, startWith } from 'rxjs';
import { AuthService } from '../../core/auth.service';
import { RoleService } from '../../core/role.service';
import { GeolocationService, type CrewPosition } from '../../core/geolocation.service';
import { WsService } from '../../core/ws.service';
import { OSM_DARK_STYLE, type MapLibreMapHandle } from '../../core/osm-map-style';
import { HlmCardImports, HlmButton } from '../../shared/ui-spartan';
import { OnlineToggleComponent, type CrewOnlineState } from '../_shared/online-toggle.component';
import { EarningsTickerComponent } from '../_shared/earnings-ticker.component';
import { GigOfferCardComponent, type GigOffer } from '../_shared/gig-offer-card.component';
import { CrewCommLogCardComponent } from './crew-comm-log-card.component';
import { CrewCompletenessCardComponent } from './completeness-card.component';
import { CrewPayoutsStatusCardComponent } from './payouts-status-card.component';
import { CrewBlocklistCardComponent } from './blocklist-card.component';
import { CrewBlackoutsCardComponent } from './blackouts-card.component';
import { CrewInboxCardComponent } from './inbox-card.component';
import { CrewPanicCardComponent } from './panic-card.component';
import { CrewMileageCardComponent } from './mileage-card.component';
import { CrewDisputesCardComponent } from './disputes-card.component';
import { CrewChatThreadsCardComponent } from './chat-threads-card.component';
import { CrewBriefingsCardComponent } from './briefings-card.component';
import { CrewCloseOutCardComponent } from './close-out-card.component';
import { CrewTax1099CardComponent } from './tax-1099-card.component';
import { routeFade, reducedMotion } from '../../shared/animations';

interface SurgeCell {
  readonly h3: string;
  readonly lat: number;
  readonly lng: number;
  readonly score: number; // 0..1
}

@Component({
  selector: 'app-crew',
  standalone: true,
  imports: [
    ...HlmCardImports,
    HlmButton,
    RouterLink,
    OnlineToggleComponent,
    EarningsTickerComponent,
    GigOfferCardComponent,
    CrewCommLogCardComponent,
    CrewCompletenessCardComponent,
    CrewPayoutsStatusCardComponent,
    CrewBlocklistCardComponent,
    CrewBlackoutsCardComponent,
    CrewInboxCardComponent,
    CrewPanicCardComponent,
    CrewMileageCardComponent,
    CrewDisputesCardComponent,
    CrewChatThreadsCardComponent,
    CrewBriefingsCardComponent,
    CrewCloseOutCardComponent,
    CrewTax1099CardComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    @if (!isCrewView()) {
      <div class="flex min-h-[60vh] items-center justify-center px-4">
        <div hlmCard class="w-full max-w-md text-center">
          <div hlmCardHeader>
            <h3 hlmCardTitle>Crew console</h3>
            <p hlmCardDescription>This surface is the field view crews see when they're online.</p>
          </div>
          <div hlmCardContent>
            <p class="mb-5 text-sm text-muted-foreground">
              You're viewing as <span class="font-medium text-foreground">{{ roleLabel() }}</span
              >. Open it in the crew persona to see live gigs, earnings, and payouts.
            </p>
            @if (canSwitchRole()) {
              <button
                hlmBtn
                type="button"
                class="transition-all duration-[333ms] hover:-translate-y-0.5"
                [disabled]="switching()"
                (click)="switchToCrew()"
              >
                {{ switching() ? 'Switching…' : 'Switch to Crew view' }}
              </button>
            }
          </div>
        </div>
      </div>
    } @else {
      <header class="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 class="text-2xl font-bold text-foreground">Crew console</h1>
          <p class="text-sm text-muted-foreground">Stay online to receive auto-matched gigs.</p>
        </div>
        <bcl-earnings-ticker />
      </header>

      <div class="mb-4 grid gap-4 md:grid-cols-2">
        <app-crew-completeness-card />
        <app-crew-payouts-status-card />
      </div>

      <div class="grid gap-4 lg:grid-cols-[1fr_2fr]">
        <div hlmCard>
          <div hlmCardHeader><h3 hlmCardTitle>Availability</h3></div>
          <div hlmCardContent>
            <bcl-online-toggle [state]="onlineState()" (changed)="setOnline($event)" />
            @if (positionLabel(); as p) {
              <p class="mt-3 text-xs text-muted-foreground">
                GPS: <span class="font-mono text-foreground">{{ p }}</span> · battery
                {{ batteryLabel() }}
              </p>
            }
            @if (geo.error(); as e) {
              <p class="mt-2 text-xs text-destructive">{{ e }}</p>
            }

            <div class="mt-5 space-y-2">
              <a hlmBtn routerLink="/crew/payout" class="w-full">Instant payout</a>

              <div>
                <p class="mb-1.5 text-xs font-medium text-muted-foreground">
                  Mileage CSV — tax year
                </p>
                <ul
                  role="list"
                  aria-label="Mileage export tax year"
                  class="mb-2 flex flex-wrap gap-2"
                >
                  @for (y of exportYears; track y) {
                    <li>
                      <button
                        type="button"
                        [attr.aria-pressed]="taxYear() === y"
                        (click)="taxYear.set(y)"
                        class="rounded-full border px-3 py-1 text-sm font-medium transition-all duration-[333ms] hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                        [class.bg-primary]="taxYear() === y"
                        [class.text-primary-foreground]="taxYear() === y"
                        [class.border-transparent]="taxYear() === y"
                        [class.border-border]="taxYear() !== y"
                        [class.text-foreground]="taxYear() !== y"
                        [class.hover:bg-muted]="taxYear() !== y"
                      >
                        {{ y }}
                      </button>
                    </li>
                  }
                </ul>
                <a hlmBtn variant="outline" [attr.href]="mileageExportHref()" class="w-full"
                  >Download {{ taxYear() }} mileage CSV</a
                >
              </div>
            </div>
          </div>
        </div>

        <div hlmCard>
          <div hlmCardHeader>
            <h3 hlmCardTitle>Surge map</h3>
            <p hlmCardDescription>Cells colored by demand pressure (updates every 60s).</p>
          </div>
          <div hlmCardContent>
            <div class="relative h-[360px] w-full overflow-hidden rounded-lg ring-1 ring-border">
              <div #surgeMapEl data-testid="surge-map" class="absolute inset-0 bg-background"></div>
              @if (mapStatus() !== 'ready') {
                <div
                  class="absolute inset-0 flex flex-col items-center justify-center gap-1 bg-background/80 p-4 text-center"
                  role="status"
                >
                  @if (mapStatus() === 'loading') {
                    <span class="text-sm text-muted-foreground">Loading surge map…</span>
                  } @else {
                    <span class="text-sm font-medium text-foreground">Surge map unavailable</span>
                    <span class="text-xs text-muted-foreground">
                      Mapbox isn't configured yet — demand cells still drive matching in the
                      background.
                    </span>
                  }
                </div>
              }
            </div>
          </div>
        </div>
      </div>

      <bcl-gig-offer-card
        [offer]="currentOffer()"
        (accepted)="onOfferDone($event)"
        (declined)="onOfferDone($event)"
        (expired)="onOfferDone($event)"
      />

      <!-- Panic stays full-width + prominent (safety-critical). -->
      <app-crew-panic-card />

      <!-- Secondary cards in a dense 2-col grid on desktop (cockpit density
           doctrine), single-column on mobile. mt-4 separates from panic. -->
      <div class="mt-4 grid gap-4 md:grid-cols-2">
        <app-crew-close-out-card />
        <app-crew-chat-threads-card />
        <app-crew-briefings-card />
        <app-crew-tax-1099-card />
        <app-crew-disputes-card />
        <app-crew-inbox-card />
        <app-crew-comm-log-card />
        <app-crew-blackouts-card />
        <app-crew-mileage-card />
        <app-crew-blocklist-card />
      </div>
    }
  `,
})
export class CrewComponent implements AfterViewInit {
  /** Bound to host [@.disabled] — skips the route-entrance fade for reduced-motion users. */
  protected readonly reducedMotion = reducedMotion;
  private readonly auth = inject(AuthService);
  private readonly roleSvc = inject(RoleService);
  private readonly ws = inject(WsService);
  private readonly destroyRef = inject(DestroyRef);
  readonly geo = inject(GeolocationService);

  readonly surgeMapEl = viewChild<ElementRef<HTMLDivElement>>('surgeMapEl');

  readonly onlineState = signal<CrewOnlineState>('offline');
  readonly currentOffer = signal<GigOffer | null>(null);

  /**
   * Tax years a crew can export logged mileage for: the current calendar year
   * plus the two prior (the practical IRS late-filing / amended-return window).
   * Replaces a hardcoded `year=2026` that would strand crews on a stale year the
   * moment the calendar turns. Derived from NOW once at construction.
   */
  private readonly currentYear = new Date().getFullYear();
  readonly exportYears: readonly number[] = [
    this.currentYear,
    this.currentYear - 1,
    this.currentYear - 2,
  ];
  /** Selected mileage-export tax year (defaults to the current year). */
  readonly taxYear = signal(this.currentYear);
  /** Download href for the selected tax year's mileage CSV. */
  readonly mileageExportHref = computed(
    () => `/api/earnings/mileage-export?year=${this.taxYear()}`,
  );
  readonly surge = signal<readonly SurgeCell[]>([]);
  /** Surge-map init state — drives a visible overlay instead of a blank box. */
  readonly mapStatus = signal<'loading' | 'ready' | 'unavailable'>('loading');

  readonly isCrewView = computed(() => this.roleSvc.viewAs() === 'crew');
  readonly canSwitchRole = this.roleSvc.canSwitchRole;
  /** Human label for the active persona, shown in the non-crew empty state. */
  readonly roleLabel = computed(() => {
    const map: Record<string, string> = {
      super_admin: 'Super-admin',
      customer: 'Customer',
      crew: 'Crew',
    };
    return map[this.roleSvc.viewAs()] ?? 'this role';
  });
  /** Transient spinner state while the view-as POST is in flight. */
  readonly switching = signal(false);

  /** Flip the active persona to crew so the console renders for the operator. */
  switchToCrew(): void {
    this.switching.set(true);
    this.roleSvc
      .setViewAs('crew')
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => this.switching.set(false),
        error: () => this.switching.set(false),
      });
  }

  readonly positionLabel = computed(() => {
    const p = this.geo.position();
    return p ? `${p.lat.toFixed(4)}, ${p.lng.toFixed(4)}` : null;
  });
  readonly batteryLabel = computed(() => {
    const p = this.geo.position();
    if (!p?.battery) return '—';
    return `${p.battery}%${p.charging ? '⚡' : ''}`;
  });

  private wsHandle: ReturnType<WsService['connect']> | null = null;
  private surgeMap: unknown = null;
  private surgeMarkers: { remove: () => void }[] = [];

  constructor() {
    interval(60_000)
      .pipe(startWith(0), takeUntilDestroyed(this.destroyRef))
      .subscribe(() => this.refreshSurge());

    if (typeof BroadcastChannel !== 'undefined') {
      const offers = new BroadcastChannel('bcl-offers');
      offers.onmessage = (ev) => {
        const data = ev?.data as GigOffer | undefined;
        if (data && data.gigId) this.currentOffer.set(data);
      };
      this.destroyRef.onDestroy(() => offers.close());
    }

    this.destroyRef.onDestroy(() => {
      this.wsHandle?.close();
      this.geo.stop();
      this.surgeMarkers.forEach((m) => m.remove());
    });
  }

  async ngAfterViewInit(): Promise<void> {
    await this.initSurgeMap();
  }

  async setOnline(next: CrewOnlineState): Promise<void> {
    const prev = this.onlineState();
    this.onlineState.set(next);
    if (next === 'offline') {
      this.geo.stop();
      this.wsHandle?.close();
      this.wsHandle = null;
      return;
    }
    // Online or On Trip — open WS + start geo if not already.
    if (prev === 'offline') {
      const crewId = this.auth.whoami().userId ?? 'me';
      const proto = globalThis.location?.protocol === 'https:' ? 'wss' : 'ws';
      const host = globalThis.location?.host ?? '';
      const url = `${proto}://${host}/api/crew/stream?crewId=${encodeURIComponent(crewId)}`;
      this.wsHandle = this.ws.connect(url);
      await this.geo.start((p: CrewPosition) => {
        this.wsHandle?.send({
          type: 'gps',
          lat: p.lat,
          lng: p.lng,
          heading: p.heading,
          speed: p.speed,
          accuracy: p.accuracy,
          battery: p.battery,
          charging: p.charging,
          ts: p.ts,
        });
      });
    }
  }

  onOfferDone(offer: GigOffer | null): void {
    if (offer && this.currentOffer()?.gigId === offer.gigId) this.currentOffer.set(null);
  }

  private async refreshSurge(): Promise<void> {
    // `/api/surge` is a CREW endpoint (worker-session gated). Skip the poll for
    // a non-crew persona (e.g. a super-admin who hasn't switched to crew view) —
    // firing it 401'd on every authed walk and the heatmap never renders anyway.
    if (!this.isCrewView()) return;
    try {
      const res = await fetch('/api/surge?hex_resolution=8', { credentials: 'include' });
      if (!res.ok) return;
      const body = (await res.json()) as { cells?: SurgeCell[] };
      this.surge.set(body.cells ?? []);
      this.drawSurge();
    } catch {
      // ignore
    }
  }

  private async initSurgeMap(): Promise<void> {
    const el = this.surgeMapEl()?.nativeElement;
    if (!el) return;
    let maplibregl: typeof import('maplibre-gl');
    try {
      maplibregl = await import('maplibre-gl');
      if (!maplibregl?.Map) {
        this.mapStatus.set('unavailable');
        return;
      }
    } catch {
      this.mapStatus.set('unavailable');
      return;
    }
    try {
      // Token-free OSM raster basemap — no API key, no /api/mapbox-token fetch.
      this.surgeMap = new maplibregl.Map({
        container: el,
        style: OSM_DARK_STYLE,
        center: [-74.1723, 40.7357],
        zoom: 11,
      });
      this.mapStatus.set('ready');
    } catch {
      this.mapStatus.set('unavailable');
    }
  }

  private drawSurge(): void {
    if (!this.surgeMap) return;
    void import('maplibre-gl').then((mod) => {
      this.surgeMarkers.forEach((m) => m.remove());
      this.surgeMarkers = [];
      for (const c of this.surge()) {
        const el = document.createElement('div');
        el.setAttribute('aria-label', `Surge cell ${c.h3}`);
        el.style.cssText = `width:32px;height:32px;border-radius:6px;background:${surgeColor(c.score)};opacity:0.55;`;
        const marker = new mod.Marker({ element: el })
          .setLngLat([c.lng, c.lat])
          .addTo(this.surgeMap as unknown as MapLibreMapHandle);
        this.surgeMarkers.push(marker as unknown as { remove: () => void });
      }
    });
  }
}

function surgeColor(score: number): string {
  if (score >= 0.75) return '#ef4444';
  if (score >= 0.5) return '#f59e0b';
  if (score >= 0.25) return '#facc15';
  return '#22c55e';
}

// Map types are pulled from maplibre-gl's own type-only import.
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'crew-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
