import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * StatusPillComponent — the gorgeous, brand-tokened rendering of a wire status.
 *
 * Wraps HlmBadge with the §5 gorgeous standard (0.333s motion, bcl-rise
 * entrance, hover lift, 24px target floor, aria-labelled) and the shared
 * `statusBadge` vocabulary so every list — bookings/quotes/jobs AND the billing
 * invoices table (which previously showed raw lowercase `paid`/`open` text in a
 * plain SmartTable cell) — renders ONE consistent pill. Built to be dropped into
 * a TanStack column via `flexRenderComponent(StatusPillComponent, { inputs })`.
 */
import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';
import { HlmBadge } from '../../shared/ui-spartan';
import { statusBadge } from '@theme.tools/crm/field-service/status-badge';

@Component({
  selector: 'app-status-pill',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [HlmBadge],
  template: `
    <span
      hlmBadge
      [variant]="badge().variant"
      [attr.aria-label]="'Status: ' + badge().label"
      data-testid="status-pill"
      class="bcl-rise inline-flex min-h-[24px] items-center transition-[transform,background-color,box-shadow] duration-[333ms] hover:-translate-y-0.5"
      >{{ badge().label }}</span
    >
  `,
})
export class StatusPillComponent {
  /** Wire status (case/space/dash-insensitive); mapped via the shared vocabulary. */
  readonly status = input<string | null | undefined>('');
  protected readonly badge = computed(() => statusBadge(this.status()));
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'status-pill-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
