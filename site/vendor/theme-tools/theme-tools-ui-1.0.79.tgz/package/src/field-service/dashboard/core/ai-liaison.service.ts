import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { WAVE4_PARTNER_SPECS } from '@theme.tools/integrations/field-service-partner-adapters';
/**
 * AiLiaisonService — crew↔AI↔customer messaging data layer for the Job Detail page.
 *
 * The crew composes a message (a one-tap quick-intent or free text); the worker's
 * AI liaison rewrites it into a polished, on-brand, customer-facing message and
 * relays it. When Workers AI is unavailable the worker returns a deterministic
 * templated message (never a dead surface), so this service always resolves a
 * non-empty `message`.
 *
 * Per [[rxjs-first-angular]]: each backend call returns Observable<T>, retries
 * once, and normalizes errors into a typed result the component renders. The
 * worker routes 404 when the `crew_job_detail_v2` flag is off.
 *
 * Backend routes:
 *   POST /api/ai/liaison/relay      { gigId, intent, text?, etaMinutes? }
 *   POST /api/ai/liaison/summarize  { gigId, text }
 */
import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, catchError, of, retry } from 'rxjs';

/** Quick-message intents mirrored from shared/ai-liaison.ts LIAISON_QUICK_INTENTS. */
export type LiaisonIntent =
  | 'on_my_way'
  | 'running_late'
  | 'arrived'
  | 'need_access'
  | 'almost_done'
  | 'custom';

export interface LiaisonRelayResult {
  readonly ok: boolean;
  readonly message?: string;
  readonly aiUsed?: boolean;
  readonly error?: string;
}

export interface LiaisonSummaryResult {
  readonly ok: boolean;
  readonly summary?: string;
  readonly aiUsed?: boolean;
  readonly error?: string;
}

@Injectable({ providedIn: 'root' })
export class AiLiaisonService {
  private readonly http = inject(HttpClient);

  /** Rewrite + relay a crew message to the customer. */
  relay$(
    gigId: string,
    intent: LiaisonIntent,
    text: string,
    etaMinutes?: number,
  ): Observable<LiaisonRelayResult> {
    const body: Record<string, unknown> = { gigId, intent, text };
    if (typeof etaMinutes === 'number') body['etaMinutes'] = etaMinutes;
    return this.http
      .post<LiaisonRelayResult>('/api/ai/liaison/relay', body, { withCredentials: true })
      .pipe(
        retry({ count: 1, delay: 600 }),
        catchError((err) =>
          of<LiaisonRelayResult>({
            ok: false,
            error: err?.status === 404 ? 'unavailable' : (err?.error?.error ?? 'relay_failed'),
          }),
        ),
      );
  }

  /** Summarize an inbound customer message for the crew. */
  summarize$(gigId: string, text: string): Observable<LiaisonSummaryResult> {
    return this.http
      .post<LiaisonSummaryResult>('/api/ai/liaison/summarize', { gigId, text }, { withCredentials: true })
      .pipe(
        retry({ count: 1, delay: 600 }),
        catchError((err) =>
          of<LiaisonSummaryResult>({
            ok: false,
            error: err?.status === 404 ? 'unavailable' : (err?.error?.error ?? 'summarize_failed'),
          }),
        ),
      );
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'ai-liaison-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_PARTNER_SPECS_COUNT = Object.keys(WAVE4_PARTNER_SPECS).length;
