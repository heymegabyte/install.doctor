import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * ReferSwitchComponent — persona router for `/dashboard/refer`.
 *
 * The unified dashboard is one route; what a visitor SEES is driven by
 * `RoleService.viewAs`. `/work/refer` 308-redirects here for crew, while
 * customers reach `/dashboard/refer` directly — both must land on the referral
 * program that pays THEM:
 *  - crew  → CrewReferComponent  ($100 Stripe-Connect bonus per referred crew)
 *  - else  → ReferComponent      ($25-off neighbor referral)
 *
 * Both child views self-gate on auth (guest → sign-in, no authed fetch), so this
 * switch only chooses which program to render. Lazy children stay tree-shaken
 * apart via `@defer (when …)` is unnecessary here — both are tiny; we mount the
 * one the persona needs and never the other.
 */
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RoleService } from '../../core/role.service';
import { routeFade, reducedMotion } from '../../shared/animations';
import { CrewReferComponent } from '../crew/crew-refer.component';
import { ReferComponent } from './refer.component';

@Component({
  selector: 'app-refer-switch',
  standalone: true,
  imports: [CrewReferComponent, ReferComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    @if (role.isCrew()) {
      <app-crew-refer />
    } @else {
      <app-refer />
    }
  `,
})
export class ReferSwitchComponent {
  protected readonly reducedMotion = reducedMotion;
  protected readonly role = inject(RoleService);
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'refer-switch-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
