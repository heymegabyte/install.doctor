import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CrewDisputesCardComponent — crew safety surface. Angular port of the React
 * worker-disputes view. Live surface = Angular /dashboard, crew audience.
 *
 * Workers contest unfair claim outcomes (no-show flags, rude-customer reports,
 * property-damage allegations, safety issues, quality complaints, "other")
 * within a 48-hour window. While a dispute is open/investigating the rating
 * impact is frozen and the card surfaces a live SLA countdown.
 *
 * Contract (worker-cookie gated → 401 anon):
 *  - GET  /api/work/disputes              → { disputes[], slaHours }
 *  - POST /api/work/disputes              { claimId, reason, notes? } → 201 | 409 already_filed
 *  - POST /api/work/disputes/:id/withdraw { reason? } → withdrawn | 409 closed
 *
 * Full 4-state (loading / empty / error+retry / data), confirm-dialog for the
 * risky withdraw + a reason-capture file dialog (no window.prompt). Dark cockpit,
 * bclReveal entrance, tabular SLA digits.
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { DestroyRef } from '@angular/core';
import { interval, startWith, firstValueFrom } from 'rxjs';
import { HlmButton, HlmInput, HlmSkeleton, HlmDialog, ToastService } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

/** The 6 contestable reasons, matching the worker `fileSchema` enum. */
export type DisputeReason = 'no_show' | 'rude' | 'unsafe' | 'property_damage' | 'quality' | 'other';

export interface DisputeRow {
  readonly id: string;
  readonly gig_claim_id: string;
  readonly gig_id?: string;
  readonly reason: DisputeReason | string;
  readonly notes: string | null;
  readonly status: string;
  readonly sla_due_at: string;
  readonly resolution_notes: string | null;
  readonly resolved_at: string | null;
  readonly start_at?: string;
  readonly service_zip?: string | null;
  readonly created_at: string;
}

interface ListResponse {
  readonly disputes?: readonly DisputeRow[];
  readonly slaHours?: number;
}

/** Human label for each contestable reason. Pure — unit-tested. */
export function reasonLabel(reason: string): string {
  switch (reason) {
    case 'no_show':
      return 'No-show flag';
    case 'rude':
      return 'Rude-customer report';
    case 'unsafe':
      return 'Unsafe conditions';
    case 'property_damage':
      return 'Property-damage claim';
    case 'quality':
      return 'Quality complaint';
    case 'other':
      return 'Other';
    default:
      return reason;
  }
}

/** Whether a dispute is still in flight (rating impact frozen). Pure. */
export function slaActive(status: string): boolean {
  return status === 'open' || status === 'investigating';
}

/** Tailwind chip classes for a dispute status. Pure — unit-tested. */
export function disputeStatusChip(status: string): string {
  switch (status) {
    case 'open':
    case 'investigating':
      return 'bg-bcl-warn/10 text-bcl-warn ring-bcl-warn/30';
    case 'upheld':
    case 'resolved':
      return 'bg-bcl-success/10 text-bcl-success ring-bcl-success/30';
    case 'withdrawn':
      return 'bg-bcl-bg-elev text-bcl-ink-muted ring-bcl-border';
    case 'denied':
    case 'rejected':
      return 'bg-destructive/10 text-destructive ring-destructive/30';
    default:
      return 'bg-bcl-bg-elev text-bcl-ink-muted ring-bcl-border';
  }
}

/**
 * Live SLA countdown label from an ISO due-date relative to `nowMs`. Returns
 * "Decision overdue" when past due, else "Decision in Nh" / "Decision in Nm".
 * Pure (now injected) so it's deterministic in tests.
 */
export function slaCountdownLabel(slaDueAtIso: string, nowMs: number): string {
  const due = Date.parse(slaDueAtIso);
  if (Number.isNaN(due)) return '';
  const remainingMs = due - nowMs;
  if (remainingMs <= 0) return 'Decision overdue';
  const mins = Math.round(remainingMs / 60_000);
  if (mins < 60) return `Decision in ${mins}m`;
  const hours = Math.round(mins / 60);
  return `Decision in ${hours}h`;
}

@Component({
  selector: 'app-crew-disputes-card',
  standalone: true,
  imports: [HlmButton, HlmInput, HlmSkeleton, HlmDialog, FormsModule, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section
      bclReveal
      data-testid="crew-disputes-card"
      class="rounded-xl border border-bcl-border bg-bcl-bg-elev/40 p-5"
      aria-labelledby="crew-disputes-title"
    >
      <header class="mb-3 flex flex-wrap items-start justify-between gap-3">
        <div>
          <p class="font-mono text-xs uppercase tracking-wide text-bcl-accent">Fair pay</p>
          <h3 id="crew-disputes-title" class="text-lg font-semibold text-bcl-ink">Claim disputes</h3>
          <p class="text-sm text-bcl-ink-muted">
            Contest an unfair claim within 48h — your rating is frozen until a decision.
          </p>
        </div>
        <button hlmBtn variant="secondary" size="sm" (click)="openFile()" data-testid="dispute-file-open">
          File a dispute
        </button>
      </header>

      @if (error(); as e) {
        <div
          class="mb-3 flex items-center justify-between gap-3 rounded-lg border border-destructive/40 bg-destructive/5 px-3 py-2"
          role="alert"
        >
          <p class="text-sm text-bcl-ink">{{ e }}</p>
          <button hlmBtn variant="outline" size="sm" (click)="refresh()">Try again</button>
        </div>
      }

      @if (loading() && rows().length === 0) {
        <div class="space-y-2" aria-label="Loading disputes">
          <div hlmSkeleton class="h-16 w-full"></div>
          <div hlmSkeleton class="h-16 w-full"></div>
        </div>
      } @else if (rows().length === 0 && !error()) {
        <div
          class="rounded-lg border border-dashed border-bcl-border p-6 text-center text-sm text-bcl-ink-muted"
          data-testid="dispute-empty"
        >
          No disputes on file — your ratings are clean. Spotted an unfair claim? File one above.
        </div>
      } @else {
        <ul class="space-y-2">
          @for (d of rows(); track d.id) {
            <li
              class="rounded-lg border border-bcl-border bg-bcl-bg/40 p-3"
              [attr.data-status]="d.status"
            >
              <div class="flex flex-wrap items-center gap-2">
                <span class="text-sm font-medium text-bcl-ink">{{ label(d.reason) }}</span>
                <span
                  class="rounded-full px-2 py-0.5 text-xs font-semibold ring-1"
                  [class]="chip(d.status)"
                  >{{ d.status }}</span
                >
                @if (active(d.status)) {
                  <span class="ml-auto font-mono text-xs tabular-nums text-bcl-warn">
                    {{ countdown(d.sla_due_at) }}
                  </span>
                }
              </div>
              @if (d.gig_id) {
                <p class="mt-1 text-xs text-bcl-ink-muted">Gig {{ d.gig_id }}</p>
              }
              @if (d.notes) {
                <p class="mt-1 text-sm text-bcl-ink">{{ d.notes }}</p>
              }
              @if (d.resolution_notes) {
                <p class="mt-1 text-xs text-bcl-ink-muted">Resolution: {{ d.resolution_notes }}</p>
              }
              @if (active(d.status)) {
                <div class="mt-2">
                  <button
                    hlmBtn
                    variant="outline"
                    size="sm"
                    [disabled]="busy() === d.id"
                    (click)="askWithdraw(d.id)"
                    [attr.data-testid]="'dispute-withdraw-' + d.id"
                  >
                    Withdraw
                  </button>
                </div>
              }
            </li>
          }
        </ul>
      }
    </section>

    <!-- File-a-dispute dialog. -->
    <app-dialog [open]="filing()" (openChange)="$event ? null : closeFile()" ariaLabel="File a claim dispute">
      <div class="flex flex-col gap-3">
        <div>
          <h2 class="text-lg font-bold text-bcl-ink">File a claim dispute</h2>
          <p class="text-sm text-bcl-ink-muted">Reference the claim ID from your job history. Operator responds within 48h.</p>
        </div>
        <label class="text-sm text-bcl-ink">
          Claim ID
          <input
            hlmInput
            class="mt-1 w-full"
            [(ngModel)]="claimIdValue"
            placeholder="claim id…"
            aria-label="Claim ID"
            data-testid="dispute-claim-id"
          />
        </label>
        <label class="text-sm text-bcl-ink">
          Reason
          <select
            class="mt-1 w-full rounded-md border border-input bg-background px-2 py-2 text-sm text-foreground"
            [(ngModel)]="reasonValue"
            aria-label="Dispute reason"
            data-testid="dispute-reason"
          >
            @for (r of reasons; track r) {
              <option [value]="r">{{ label(r) }}</option>
            }
          </select>
        </label>
        <textarea
          hlmInput
          rows="3"
          [(ngModel)]="notesValue"
          placeholder="What happened? (optional)"
          aria-label="Dispute notes"
          data-testid="dispute-notes"
        ></textarea>
        <div class="flex justify-end gap-2">
          <button hlmBtn variant="outline" (click)="closeFile()">Cancel</button>
          <button
            hlmBtn
            [disabled]="!claimIdValue.trim() || busy() === 'file'"
            (click)="submitFile()"
            data-testid="dispute-file-confirm"
          >
            File dispute
          </button>
        </div>
      </div>
    </app-dialog>

    <!-- Withdraw confirm dialog. -->
    <app-dialog [open]="!!withdrawing()" (openChange)="$event ? null : cancelWithdraw()" ariaLabel="Withdraw dispute">
      @if (withdrawing(); as id) {
        <div class="flex flex-col gap-3">
          <div>
            <h2 class="text-lg font-bold text-bcl-ink">Withdraw this dispute?</h2>
            <p class="text-sm text-bcl-ink-muted">
              Withdrawing accepts the original claim outcome. This can't be undone.
            </p>
          </div>
          <div class="flex justify-end gap-2">
            <button hlmBtn variant="outline" (click)="cancelWithdraw()">Keep open</button>
            <button
              hlmBtn
              variant="destructive"
              [disabled]="busy() === id"
              (click)="confirmWithdraw()"
              data-testid="dispute-withdraw-confirm"
            >
              Withdraw
            </button>
          </div>
        </div>
      }
    </app-dialog>
  `,
})
export class CrewDisputesCardComponent implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly toast = inject(ToastService);
  private readonly destroyRef = inject(DestroyRef);

  readonly reasons: readonly DisputeReason[] = [
    'no_show',
    'rude',
    'unsafe',
    'property_damage',
    'quality',
    'other',
  ];

  readonly loading = signal(false);
  readonly rows = signal<readonly DisputeRow[]>([]);
  readonly error = signal<string | null>(null);
  readonly busy = signal<string | null>(null);
  /** Ticks every 60s so SLA countdowns stay live without per-row timers. */
  private readonly nowMs = signal<number>(0);

  readonly filing = signal(false);
  readonly withdrawing = signal<string | null>(null);
  claimIdValue = '';
  reasonValue: DisputeReason = 'no_show';
  notesValue = '';

  readonly hasOpen = computed(() => this.rows().some((d) => slaActive(d.status)));

  constructor() {
    interval(60_000)
      .pipe(startWith(0), takeUntilDestroyed(this.destroyRef))
      .subscribe(() => this.nowMs.set(Date.now()));
  }

  ngOnInit(): void {
    void this.refresh();
  }

  async refresh(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    try {
      const r = await firstValueFrom(
        this.http.get<ListResponse>('/api/work/disputes', { withCredentials: true }),
      );
      this.rows.set(r?.disputes ?? []);
    } catch (err) {
      this.error.set(`Couldn't load disputes: ${(err as Error).message}`);
      this.rows.set([]);
    } finally {
      this.loading.set(false);
    }
  }

  label(reason: string): string {
    return reasonLabel(reason);
  }
  chip(status: string): string {
    return disputeStatusChip(status);
  }
  active(status: string): boolean {
    return slaActive(status);
  }
  countdown(slaDueAt: string): string {
    return slaCountdownLabel(slaDueAt, this.nowMs() || Date.now());
  }

  openFile(): void {
    this.claimIdValue = '';
    this.reasonValue = 'no_show';
    this.notesValue = '';
    this.filing.set(true);
  }
  closeFile(): void {
    this.filing.set(false);
  }

  async submitFile(): Promise<void> {
    const claimId = this.claimIdValue.trim();
    if (!claimId) return;
    this.busy.set('file');
    try {
      await firstValueFrom(
        this.http.post(
          '/api/work/disputes',
          { claimId, reason: this.reasonValue, notes: this.notesValue.trim() || undefined },
          { withCredentials: true },
        ),
      );
      this.toast.success('Dispute filed — operator responds within 48h');
      this.closeFile();
      await this.refresh();
    } catch (err) {
      const status = (err as { status?: number }).status;
      if (status === 409) {
        this.toast.error('Already filed', undefined, 'A dispute on that claim already exists.');
      } else {
        this.toast.error('Could not file dispute', undefined, (err as Error).message);
      }
    } finally {
      this.busy.set(null);
    }
  }

  askWithdraw(id: string): void {
    this.withdrawing.set(id);
  }
  cancelWithdraw(): void {
    this.withdrawing.set(null);
  }

  async confirmWithdraw(): Promise<void> {
    const id = this.withdrawing();
    if (!id) return;
    this.busy.set(id);
    try {
      await firstValueFrom(
        this.http.post(`/api/work/disputes/${id}/withdraw`, {}, { withCredentials: true }),
      );
      this.toast.success('Dispute withdrawn');
      this.cancelWithdraw();
      await this.refresh();
    } catch (err) {
      this.toast.error('Could not withdraw', undefined, (err as Error).message);
    } finally {
      this.busy.set(null);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'disputes-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
