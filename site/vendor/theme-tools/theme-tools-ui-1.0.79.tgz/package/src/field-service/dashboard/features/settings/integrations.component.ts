import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SettingsIntegrationsComponent — a preview of the connectors marketplace that
 * launches the canonical Integrations cockpit (`/integrations`).
 *
 * Connecting/disconnecting + live status + webhooks all live on the richer
 * admin IntegrationsComponent backed by /api/admin/integrations/*. This sub-tab
 * used to navigate to per-provider /api/integrations/<id>/start endpoints that
 * don't exist (404 on click) — it's now a routerLink launcher to the real
 * surface, so the two integrations views are reconciled to one backend.
 */
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { HlmCardImports, HlmButton } from '../../shared/ui-spartan';

interface IntegrationPreview {
  readonly id: string;
  readonly name: string;
  readonly description: string;
  readonly kind: 'oauth' | 'api-key';
}

const CATALOG: readonly IntegrationPreview[] = [
  { id: 'slack', name: 'Slack', description: 'Pipe gigs + payments into a channel.', kind: 'oauth' },
  { id: 'gmail', name: 'Gmail', description: 'Send invoices and receipts from your Gmail.', kind: 'oauth' },
  { id: 'calendar', name: 'Google Calendar', description: 'Sync gigs to your calendar.', kind: 'oauth' },
  { id: 'drive', name: 'Google Drive', description: 'Auto-archive signed COIs and BOLs.', kind: 'oauth' },
  { id: 'sentry', name: 'Sentry', description: 'Mirror errors to your own Sentry org.', kind: 'api-key' },
  { id: 'cloudflare', name: 'Cloudflare', description: 'Provision custom domains automatically.', kind: 'api-key' },
  { id: 'context7', name: 'Context7', description: 'AI-assist docs for your own SDK.', kind: 'api-key' },
];

@Component({
  selector: 'app-settings-integrations',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="mb-4 flex items-center justify-between gap-3">
      <p class="text-sm text-muted-foreground">
        Connect Slack, Gmail, Stripe, Sentry and more — manage every connection, status, and webhook
        on the Integrations cockpit.
      </p>
      <a hlmBtn routerLink="/integrations" size="sm">Open Integrations →</a>
    </div>
    <div class="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
      @for (i of catalog; track i.id) {
        <a hlmCard routerLink="/integrations" class="block transition hover:border-primary/60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring">
          <div hlmCardHeader><h3 hlmCardTitle>{{ i.name }}</h3></div>
          <div hlmCardContent>
            <p class="mb-3 text-sm text-muted-foreground">{{ i.description }}</p>
            <span class="text-xs font-medium text-primary">
              {{ i.kind === 'oauth' ? 'Connect via OAuth →' : 'Add API key →' }}
            </span>
          </div>
        </a>
      }
    </div>
  `,
})
export class SettingsIntegrationsComponent {
  readonly catalog = CATALOG;
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'integrations-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
