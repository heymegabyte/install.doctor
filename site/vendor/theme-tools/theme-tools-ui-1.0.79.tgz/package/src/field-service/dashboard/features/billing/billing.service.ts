import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * BillingService — HTTP client + signal cache for every billing surface.
 *
 * Wraps the Worker's `/api/billing/*` endpoints. All requests carry
 * cookies (the Worker reads `bcl_cust_sid`). Stripe is the source of truth for invoices + payment methods; the
 * Worker proxies plus caches. No subscription plans — hourly-labor business.
 */
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';

/**
 * Brick Labor is an HOURLY LABOR business, not a SaaS — there are no
 * subscription plan tiers. Customers pay $50/hr per crew member (1-hour
 * minimum), either pay-as-you-go per job or on a recurring hourly contract
 * (daily / weekly / biweekly / monthly) that earns a standing discount.
 * (See `src/shared/recurring.ts` for the canonical cadence catalog.)
 */
export type RecurringContract = 'pay_as_you_go' | 'daily' | 'weekly' | 'biweekly' | 'monthly';

export interface ContractInfo {
  readonly id: RecurringContract;
  readonly label: string;
  readonly discountPct: number;
}

// Discounts MUST match the canonical catalog in `src/shared/recurring.ts`
// (`RECURRING_PLANS`): daily 12% · weekly 8% · bi-weekly 5% · monthly 3%.
// `scripts/validate-recurring-discounts.mjs` parses BOTH this array and the
// canonical source and fails the build on any drift — a customer must never
// see a discount here that contradicts what the booking flow charges.
export const CONTRACTS: readonly ContractInfo[] = [
  { id: 'pay_as_you_go', label: 'Pay as you go', discountPct: 0 },
  { id: 'daily', label: 'Daily contract', discountPct: 12 },
  { id: 'weekly', label: 'Weekly contract', discountPct: 8 },
  { id: 'biweekly', label: 'Biweekly contract', discountPct: 5 },
  { id: 'monthly', label: 'Monthly contract', discountPct: 3 },
];

export interface BillingOverview {
  /** Standing recurring cadence; `pay_as_you_go` = no contract. */
  readonly contract: RecurringContract;
  /** Effective labor rate per crew member, in cents (default $50/hr). */
  readonly hourlyRatePerPersonCents: number;
  readonly nextInvoiceCents: number;
  readonly nextInvoiceDate: string;
  readonly paymentMethodLast4: string | null;
  readonly paymentMethodBrand: string | null;
  readonly addOnsCents: number;
  readonly usageCents: number;
}


export interface Invoice {
  readonly id: string;
  readonly date: string;
  readonly amountCents: number;
  readonly status: 'paid' | 'open' | 'void' | 'uncollectible';
  readonly pdfUrl: string | null;
  readonly hostedUrl: string | null;
}

export interface PaymentMethod {
  readonly id: string;
  readonly kind: 'card' | 'ach';
  readonly brand: string;
  readonly last4: string;
  readonly expMonth: number | null;
  readonly expYear: number | null;
  readonly isDefault: boolean;
}

export interface Receipt {
  readonly id: string;
  readonly jobId: string;
  readonly date: string;
  readonly amountCents: number;
  readonly customerName: string;
}

interface OkEnvelope<T> {
  readonly ok: true;
  readonly data?: T;
}

interface ErrEnvelope {
  readonly ok: false;
  readonly error: string;
  readonly code?: string;
}

@Injectable({ providedIn: 'root' })
export class BillingService {
  private readonly http = inject(HttpClient);

  readonly overview = signal<BillingOverview | null>(null);
  readonly invoices = signal<readonly Invoice[]>([]);
  readonly paymentMethods = signal<readonly PaymentMethod[]>([]);
  readonly receipts = signal<readonly Receipt[]>([]);
  readonly loading = signal<boolean>(false);
  readonly error = signal<string | null>(null);

  /** Recurring hourly-contract cadences + their standing discounts. */
  readonly contracts: readonly ContractInfo[] = CONTRACTS;

  /** Lookup helper for a contract's label + discount. */
  contractInfo(id: RecurringContract): ContractInfo {
    return (
      CONTRACTS.find((c) => c.id === id) ?? {
        id: 'pay_as_you_go',
        label: 'Pay as you go',
        discountPct: 0,
      }
    );
  }

  async loadOverview(): Promise<void> {
    this.loading.set(true);
    this.error.set(null); // clear any stale error from a prior tab (shared signal) before this fetch
    try {
      const r = await firstValueFrom(
        this.http.get<OkEnvelope<BillingOverview> | ErrEnvelope>('/api/billing/overview'),
      );
      if (r.ok && r.data) this.overview.set(r.data);
      else if (!r.ok) this.error.set(r.error);
    } catch (e) {
      this.error.set(this.extract(e));
    } finally {
      this.loading.set(false);
    }
  }

  async loadInvoices(): Promise<void> {
    this.loading.set(true);
    this.error.set(null); // clear any stale error from a prior tab (shared signal) before this fetch
    try {
      const r = await firstValueFrom(
        this.http.get<{ ok: true; invoices: Invoice[] } | ErrEnvelope>('/api/billing/invoices'),
      );
      if (r.ok) this.invoices.set(r.invoices);
      else this.error.set(r.error);
    } catch (e) {
      this.error.set(this.extract(e));
    } finally {
      this.loading.set(false);
    }
  }

  async loadPaymentMethods(): Promise<void> {
    this.loading.set(true);
    this.error.set(null); // clear any stale error from a prior tab (shared signal) before this fetch
    try {
      const r = await firstValueFrom(
        this.http.get<{ ok: true; methods: PaymentMethod[] } | ErrEnvelope>(
          '/api/billing/payment-methods',
        ),
      );
      if (r.ok) this.paymentMethods.set(r.methods);
      else this.error.set(r.error);
    } catch (e) {
      this.error.set(this.extract(e));
    } finally {
      this.loading.set(false);
    }
  }

  async loadReceipts(): Promise<void> {
    this.loading.set(true);
    this.error.set(null); // clear any stale error from a prior tab (shared signal) before this fetch
    try {
      const r = await firstValueFrom(
        this.http.get<{ ok: true; receipts: Receipt[] } | ErrEnvelope>('/api/billing/receipts'),
      );
      if (r.ok) this.receipts.set(r.receipts);
      else this.error.set(r.error);
    } catch (e) {
      this.error.set(this.extract(e));
    } finally {
      this.loading.set(false);
    }
  }

  /** Returns a Stripe Customer Portal session URL — caller opens in a new tab. */
  async openPortal(returnPath = '/billing'): Promise<string> {
    const r = await firstValueFrom(
      this.http.get<{ ok: true; url: string } | ErrEnvelope>(
        `/api/billing/portal?return=${encodeURIComponent(returnPath)}`,
      ),
    );
    if (!r.ok) throw new Error(r.error);
    return r.url;
  }

  async createSetupIntent(): Promise<{ clientSecret: string }> {
    const r = await firstValueFrom(
      this.http.post<{ ok: true; clientSecret: string } | ErrEnvelope>(
        '/api/billing/setup-intent',
        {},
      ),
    );
    if (!r.ok) throw new Error(r.error);
    return { clientSecret: r.clientSecret };
  }

  async removePaymentMethod(id: string): Promise<void> {
    const r = await firstValueFrom(
      this.http.delete<{ ok: true } | ErrEnvelope>(
        `/api/billing/payment-methods/${encodeURIComponent(id)}`,
      ),
    );
    if (!r.ok) throw new Error(r.error);
    this.paymentMethods.update((arr) => arr.filter((m) => m.id !== id));
  }

  private extract(e: unknown): string {
    if (e instanceof HttpErrorResponse) {
      const body = e.error as ErrEnvelope | null;
      return body?.error ?? `HTTP ${e.status}`;
    }
    return e instanceof Error ? e.message : 'Unknown error';
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'billing-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
