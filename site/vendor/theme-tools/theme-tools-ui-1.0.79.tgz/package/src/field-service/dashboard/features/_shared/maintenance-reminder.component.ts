import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * MaintenanceReminderComponent — SCAN-46 maintenance-reminder enrollment visibility
 * + opt-out (`<bcl-maintenance-reminder>`).
 *
 * The customer-facing CONSENT surface for the SCAN-27 predictive-maintenance
 * Workflow. SCAN-27 enrolls a past customer, on gig completion (recurring-friendly
 * service), into a durable Workflow that N months later texts them to book the
 * seasonal follow-up. This card tells the signed-in customer they're enrolled and
 * lets them opt out with one toggle. The opt-out is NOT cosmetic: it flips
 * `bookings.marketing_sms_opt_in=0` server-side, the SAME column the Workflow's
 * wake-time check reads — so an opted-out customer's reminder bails (TCPA/consent).
 *
 * Self-gating (mirrors ContractUpsellComponent / ReceivedRatingComponent): fetches
 * GET /api/maintenance-enrollment exactly once, and ONLY when a signed-in visitor
 * AND the `maintenance_reminder` server flag is live (the public flag map, incl. the
 * E2E-override-cookie seam). While the flag is dark the endpoint 404s and this card
 * renders NOTHING — no console error, hidden for everyone. Renders only when the
 * customer actually has an enrollable booking (enrolled OR opted-out), never an
 * empty "you have no reminders" shell.
 *
 * Brand accent = ORANGE (bcl-accent), never cyan (per the project's brand rule).
 * Standalone, signals, OnPush, zoneless-safe.
 */
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '../../core/auth.service';
import { FeatureFlagService } from '../../core/feature-flag.service';
import { HlmSwitch } from '../../shared/ui-spartan';

/** The server flag gating GET /api/maintenance-enrollment (404 when dark). Reused from SCAN-27. */
const MAINTENANCE_REMINDER_FLAG = 'maintenance_reminder';

/**
 * Response of GET /api/maintenance-enrollment. Mirrors the canonical
 * `ENROLLMENT_STATUS_SCHEMA` in `src/shared/maintenance-enrollment.ts` — the
 * dashboard build can't import `src/shared`, so this interface is kept in parity
 * by the Jest spec (`maintenance-reminder.spec.ts`), matching the same
 * mirror-and-lock discipline used by recurring-plans-card / notifications.
 */
interface EnrollmentStatus {
  readonly ok: boolean;
  readonly enrolled?: boolean;
  readonly optedOut?: boolean;
  readonly service?: string | null;
  readonly months?: number | null;
}

/** Response of the opt-out / opt-in mutations (mirrors ENROLLMENT_MUTATION_SCHEMA). */
interface EnrollmentMutation {
  readonly ok: boolean;
  readonly optedOut?: boolean;
  readonly updated?: number;
}

/** Local view state derived from the enrollment endpoint. */
interface Loaded {
  readonly service: string | null;
  readonly months: number | null;
  readonly optedOut: boolean;
}

/** Pure: humanize a service slug ("gutter-clean" → "gutter clean") for display copy. */
export function humanizeService(service: string | null): string {
  if (!service) return 'seasonal service';
  return service.replace(/-/g, ' ');
}

@Component({
  selector: 'bcl-maintenance-reminder',
  standalone: true,
  imports: [HlmSwitch],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <aside
        data-testid="maintenance-reminder-card"
        class="relative overflow-hidden rounded-2xl border border-bcl-accent/30 bg-gradient-to-br from-bcl-accent/12 to-bcl-accent/[0.04] p-5 sm:p-6"
        [attr.aria-label]="'Seasonal maintenance reminders'"
      >
        <span
          aria-hidden="true"
          class="pointer-events-none absolute -right-8 -top-8 size-32 rounded-full bg-bcl-accent/15 blur-2xl"
        ></span>
        <div class="relative z-10 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div class="min-w-0">
            <p class="bcl-eyebrow mb-2 text-bcl-accent">Seasonal reminders</p>
            <h3 class="font-display text-lg font-extrabold text-bcl-ink sm:text-xl">
              @if (optedOut()) {
                Maintenance reminders are off
              } @else {
                We'll remind you about your {{ serviceLabel() }}
              }
            </h3>
            <p class="mt-1 max-w-xl text-sm text-bcl-ink-muted">
              @if (optedOut()) {
                You won't get a text about booking your next
                {{ serviceLabel() }}. Turn it back on anytime.
              } @else {
                About {{ monthsLabel() }} after your {{ serviceLabel() }}, we'll
                send one text to check if you'd like to book it again. One message,
                no spam — turn it off anytime.
              }
            </p>
          </div>
          <label
            class="flex shrink-0 items-center gap-3 rounded-xl border border-bcl-border bg-bcl-bg/40 px-4 py-3"
          >
            <span class="text-sm font-medium text-bcl-ink">
              <span
                class="inline-block min-w-[7ch] text-center"
                [attr.data-testid]="'maintenance-reminder-state'"
                >{{ optedOut() ? 'Off' : 'On' }}</span
              >
            </span>
            <hlm-switch
              data-testid="maintenance-reminder-toggle"
              [checked]="!optedOut()"
              [disabled]="saving()"
              [ariaLabel]="'Seasonal maintenance reminders — ' + (optedOut() ? 'off' : 'on')"
              (changed)="onToggle($event)"
            />
          </label>
        </div>
        @if (error(); as e) {
          <p class="relative z-10 mt-3 text-sm text-destructive" role="alert">{{ e }}</p>
        }
      </aside>
    }
  `,
})
export class MaintenanceReminderComponent {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);
  private readonly flags = inject(FeatureFlagService);
  private readonly flagOn = this.flags.isOn(MAINTENANCE_REMINDER_FLAG);
  private fetched = false;

  /** Enrollment payload, or null while unloaded / not enrollable / dark. */
  private readonly loaded = signal<Loaded | null>(null);
  protected readonly saving = signal<boolean>(false);
  protected readonly error = signal<string | null>(null);

  /** Render only when signed in, flag live, and the customer has an enrollable booking. */
  protected readonly visible = computed(
    () => this.auth.authenticated() && this.flagOn() && this.loaded() !== null,
  );
  protected readonly optedOut = computed(() => this.loaded()?.optedOut ?? false);
  protected readonly serviceLabel = computed(() => humanizeService(this.loaded()?.service ?? null));
  protected readonly monthsLabel = computed(() => {
    const m = this.loaded()?.months ?? null;
    return m ? `${m} months` : 'a few months';
  });

  constructor() {
    // Fetch exactly once, only when signed in AND the flag is live. While dark the
    // flag isn't in the public map → we never probe the 404 endpoint → no console
    // error. Self-activates the moment the flag is promoted.
    effect(() => {
      if (this.auth.authenticated() && this.flagOn() && !this.fetched) {
        this.fetched = true;
        void this.refresh();
      }
    });
  }

  private async refresh(): Promise<void> {
    try {
      const resp = await firstValueFrom(
        this.http.get<EnrollmentStatus>('/api/maintenance-enrollment', {
          withCredentials: true,
        }),
      );
      // Only surface the card when the customer actually has an enrollable booking
      // (enrolled OR explicitly opted-out). A customer with no recurring-friendly
      // history has service=null → render nothing (no empty shell).
      if (resp?.ok && typeof resp.service === 'string') {
        this.loaded.set({
          service: resp.service,
          months: resp.months ?? null,
          optedOut: resp.optedOut ?? false,
        });
      } else {
        this.loaded.set(null);
      }
    } catch {
      // 404 (dark), 401, or network — render nothing, never a broken card.
      this.loaded.set(null);
    }
  }

  /** Toggle handler — switch ON means opted-in (marketing_sms_opt_in=1); OFF means opt-out. */
  async onToggle(checked: boolean): Promise<void> {
    const cur = this.loaded();
    if (!cur || this.saving()) return;
    const path = checked ? '/api/maintenance-enrollment/opt-in' : '/api/maintenance-enrollment/opt-out';
    // Optimistic flip, reconciled by the server response.
    this.saving.set(true);
    this.error.set(null);
    this.loaded.set({ ...cur, optedOut: !checked });
    try {
      const resp = await firstValueFrom(
        this.http.post<EnrollmentMutation>(path, {}, { withCredentials: true }),
      );
      if (resp?.ok) {
        this.loaded.set({ ...cur, optedOut: resp.optedOut ?? !checked });
      } else {
        // Revert on a non-ok body.
        this.loaded.set(cur);
        this.error.set('Could not save. Try again.');
      }
    } catch {
      // Revert on network/error — the toggle never lies about the stored state.
      this.loaded.set(cur);
      this.error.set('Connection issue. Try again.');
    } finally {
      this.saving.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'maintenance-reminder-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
