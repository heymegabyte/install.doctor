import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * TeamDirectoryComponent — member table + pending-invites table.
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, inject } from '@angular/core';
import { Router } from '@angular/router';
import { type ColumnDef } from '@tanstack/angular-table';
import { HlmButton, HlmSkeleton, SmartTableComponent, ToastService } from '../../shared/ui-spartan';
import { BclRoleBadgeComponent } from '../_shared/role-badge.component';
import { TeamService } from './team.service';

interface MemberRow extends Record<string, unknown> {
  readonly id: string;
  readonly name: string;
  readonly email: string;
  readonly role: string;
  readonly status: string;
  readonly lastActive: string;
}

@Component({
  selector: 'app-team-directory',
  standalone: true,
  imports: [HlmButton, HlmSkeleton, SmartTableComponent, BclRoleBadgeComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (svc.loading() && svc.members().length === 0) {
      <div class="space-y-2" aria-label="Loading team directory">
        <div hlmSkeleton class="h-10 w-full"></div>
        <div hlmSkeleton class="h-10 w-full"></div>
        <div hlmSkeleton class="h-10 w-full"></div>
      </div>
    } @else {
      <app-smart-table
        [data]="memberRows()"
        [columns]="memberCols"
        [filterable]="true"
        filterPlaceholder="Filter members…"
        emptyText="No members yet."
        (rowActivate)="open($event)"
      />
      @if (svc.invites().length > 0) {
        <div class="mt-6">
          <h2 class="mb-2 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
            Pending invites
          </h2>
          <ul class="divide-y divide-border rounded-xl border border-border bg-card">
            @for (i of svc.invites(); track i.id) {
              <li class="flex items-center justify-between px-4 py-3 text-sm">
                <div class="min-w-0">
                  <p class="truncate text-foreground">{{ i.email }}</p>
                  <p class="text-xs text-muted-foreground">
                    <bcl-role-badge [role]="i.role" /> · invited {{ rel(i.invitedAt) }}
                  </p>
                </div>
                <div class="flex shrink-0 gap-1">
                  <button hlmBtn variant="ghost" size="sm" (click)="resend(i.id)">Resend</button>
                  <button hlmBtn variant="ghost" size="sm" (click)="revoke(i.id)">Revoke</button>
                </div>
              </li>
            }
          </ul>
        </div>
      }
      @if (svc.error(); as e) {
        <p class="mt-3 text-sm text-destructive" role="alert">{{ e }}</p>
      }
    }
  `,
})
export class TeamDirectoryComponent implements OnInit {
  readonly svc = inject(TeamService);
  private readonly router = inject(Router);
  private readonly toast = inject(ToastService);

  readonly memberCols: ColumnDef<MemberRow>[] = [
    { accessorKey: 'name', header: 'Name' },
    { accessorKey: 'email', header: 'Email' },
    { accessorKey: 'role', header: 'Role' },
    { accessorKey: 'status', header: 'Status' },
    { accessorKey: 'lastActive', header: 'Last active' },
  ];

  readonly memberRows = computed<MemberRow[]>(() =>
    this.svc.members().map((m) => ({
      id: m.id,
      name: m.displayName || '—',
      email: m.email,
      role: m.role,
      status: m.status,
      lastActive: m.lastActiveAt ? this.rel(m.lastActiveAt) : 'never',
    })),
  );

  ngOnInit(): void {
    if (this.svc.members().length === 0) void this.svc.loadAll();
  }

  open(r: MemberRow): void {
    void this.router.navigate(['/team', r.id]);
  }

  async resend(id: string): Promise<void> {
    try {
      await this.svc.resendInvite(id);
      this.toast.success('Invite resent · just now');
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Failed';
      this.svc.error.set(msg);
      this.toast.error("Couldn't resend invite", undefined, msg);
    }
  }

  async revoke(id: string): Promise<void> {
    try {
      await this.svc.revokeInvite(id);
      this.toast.success('Invite revoked');
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Failed';
      this.svc.error.set(msg);
      this.toast.error("Couldn't revoke invite", undefined, msg);
    }
  }

  rel(iso: string): string {
    const ms = Date.now() - Date.parse(iso);
    const m = Math.floor(ms / 60_000);
    if (m < 1) return 'just now';
    if (m < 60) return `${m}m ago`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h}h ago`;
    const d = Math.floor(h / 24);
    return `${d}d ago`;
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'directory-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
