import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminComplianceComponent — compliance audit-trail viewer on the admin console.
 * Live surface = Angular /dashboard/admin.
 *
 * Unblocked 2026-06-03: `/api/admin/compliance` migrated from OWNER_INVOICE_KEY
 * Bearer-only to the shared `ownerOrSuperAdmin` gate.
 *   GET /api/admin/compliance/audit-trail → { ok, items:[{id,kind,severity,ts,actor,payload}], nextCursor }
 * Read-only (the append endpoint is system/operator-driven). Pure helpers
 * severityTone/formatTs unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmCardImports } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export interface ComplianceItem {
  readonly id: string;
  readonly kind: string;
  readonly severity: string;
  readonly ts: string;
  readonly actor: string | null;
}

/** Pure: tone band for a severity string. */
export function severityTone(severity: string): 'danger' | 'warn' | 'info' {
  const s = (severity ?? '').toLowerCase();
  if (s === 'critical' || s === 'high' || s === 'error') return 'danger';
  if (s === 'warn' || s === 'warning' || s === 'medium') return 'warn';
  return 'info';
}

/** Pure: short local date-time, tolerant of junk. */
export function formatTs(ts: string): string {
  const t = Date.parse(ts);
  if (Number.isNaN(t)) return ts;
  return new Date(t).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}

interface AuditResponse {
  readonly ok: boolean;
  readonly items?: readonly ComplianceItem[];
}

@Component({
  selector: 'app-admin-compliance',
  standalone: true,
  imports: [...HlmCardImports, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard bclReveal data-testid="admin-compliance">
      <div hlmCardHeader>
        <h3 hlmCardTitle>Compliance audit trail</h3>
        <p hlmCardDescription>Tamper-evident log of compliance-relevant events.</p>
      </div>
      <div hlmCardContent>
        @if (loading()) {
          <p class="text-sm text-bcl-ink-muted">Loading audit trail…</p>
        } @else if (error()) {
          <p class="text-sm text-bcl-warn" role="status">{{ error() }}</p>
        } @else if (items().length === 0) {
          <p class="text-sm text-bcl-ink-muted">No compliance events recorded.</p>
        } @else {
          <ul class="grid gap-2">
            @for (it of items(); track it.id) {
              <li class="flex items-center justify-between gap-2 rounded-md border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm">
                <span class="flex items-center gap-2 min-w-0">
                  <span
                    class="shrink-0 rounded-full px-2 py-0.5 text-[10px] uppercase tracking-wider ring-1"
                    [class.text-destructive]="tone(it.severity) === 'danger'"
                    [class.ring-destructive\/40]="tone(it.severity) === 'danger'"
                    [class.text-bcl-warn]="tone(it.severity) === 'warn'"
                    [class.ring-bcl-warn\/40]="tone(it.severity) === 'warn'"
                    [class.text-bcl-ink-muted]="tone(it.severity) === 'info'"
                    [class.ring-bcl-border]="tone(it.severity) === 'info'"
                  >{{ it.severity || 'info' }}</span>
                  <span class="truncate text-bcl-ink">{{ it.kind }}</span>
                  @if (it.actor) { <span class="truncate text-xs text-bcl-ink-muted">· {{ it.actor }}</span> }
                </span>
                <span class="shrink-0 font-mono text-xs tabular-nums text-bcl-ink-muted">{{ when(it.ts) }}</span>
              </li>
            }
          </ul>
        }
      </div>
    </div>
  `,
})
export class AdminComplianceComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly items = signal<readonly ComplianceItem[]>([]);
  readonly loading = signal(true);
  readonly error = signal<string>('');

  readonly tone = severityTone;
  readonly when = formatTs;

  ngOnInit(): void {
    void this.load();
  }

  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set('');
    try {
      const r = await firstValueFrom(
        this.http.get<AuditResponse>('/api/admin/compliance/audit-trail?limit=50', { withCredentials: true }),
      );
      this.items.set(r?.ok ? (r.items ?? []) : []);
    } catch {
      this.error.set('Sign in as an operator to view the compliance audit trail.');
    } finally {
      this.loading.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'compliance-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
