import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * DayTabComponent — one day card for a multi-day quote (domain UI, used by
 * quote-detail). Relocated from the deprecated shared/ui into features/_shared
 * during the Spartan rebuild (Wave 3d) so the old shared/ can be deleted in
 * Wave 12. Styled on the cockpit semantic tokens (HLM theme bridge), modern
 * output() signals. Selection state is owned by the parent.
 */
import { ChangeDetectionStrategy, Component, computed, input, output } from '@angular/core';

export interface DayPlan {
  readonly date: string; // YYYY-MM-DD
  readonly startTime: string; // HH:MM
  readonly endTime: string; // HH:MM
}

function fmtDow(iso: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return '';
  const d = new Date(`${iso}T12:00:00Z`);
  return d.toLocaleDateString(undefined, { weekday: 'short', timeZone: 'UTC' });
}

function fmtDate(iso: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return iso;
  const d = new Date(`${iso}T12:00:00Z`);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', timeZone: 'UTC' });
}

@Component({
  selector: 'bcl-day-tab',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <article
      class="relative rounded-xl bg-card p-4 ring-1 transition-colors"
      [class.ring-primary]="active()"
      [class.ring-border]="!active()"
      [attr.data-testid]="'day-tab-' + index()"
    >
      <button
        type="button"
        role="tab"
        [attr.aria-selected]="active() ? 'true' : 'false'"
        [attr.aria-label]="'Day ' + (index() + 1) + ', ' + dateLabel() + ', ' + plan().startTime + ' to ' + plan().endTime"
        class="min-h-[44px] w-full rounded-md text-left transition-all duration-[333ms] focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        (click)="select.emit(index())"
      >
        <p class="font-mono text-xs uppercase tracking-wide text-muted-foreground">
          Day {{ index() + 1 }} · {{ dow() }}
        </p>
        <p class="mt-0.5 text-base font-semibold text-foreground">{{ dateLabel() }}</p>
        <p class="mt-2 font-mono text-sm tabular-nums text-foreground">
          {{ plan().startTime }} <span class="text-muted-foreground">–</span> {{ plan().endTime }}
        </p>
      </button>

      <div class="mt-3 flex items-end justify-between gap-2">
        <p class="text-[10px] uppercase tracking-wider text-muted-foreground/80">Start and end time</p>
        <button
          type="button"
          (click)="edit.emit(index())"
          data-testid="day-time-edit"
          aria-label="Edit start and end time for this day"
          class="inline-flex min-h-[44px] items-center rounded px-2 py-1 text-xs font-medium text-primary hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        >
          Edit time
        </button>
      </div>
    </article>
  `,
})
export class DayTabComponent {
  readonly plan = input.required<DayPlan>();
  readonly index = input.required<number>();
  readonly active = input<boolean>(false);

  readonly select = output<number>();
  readonly edit = output<number>();

  readonly dow = computed(() => fmtDow(this.plan().date));
  readonly dateLabel = computed(() => fmtDate(this.plan().date));
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'day-tab-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
