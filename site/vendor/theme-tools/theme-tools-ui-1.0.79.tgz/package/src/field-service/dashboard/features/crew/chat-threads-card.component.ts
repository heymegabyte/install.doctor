import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CrewChatThreadsCardComponent — "your customer conversations" card on the crew
 * surface. Angular port of the FULL worker-chat view (read AND reply). Live
 * surface = Angular /dashboard, crew audience.
 *
 * Contracts (worker-cookie gated → 401 anon):
 *   GET  /api/work/chat/threads          → { threads:[{ id, gig_id, customer_phone,
 *       last_msg_at, created_at, unread_count, last_body }] }
 *   GET  /api/work/chat/:gigId           → { threadId, gigId, customerPhone,
 *       messages:[{ id, thread_id, sender, body, sent_at, read_at }] } (marks read)
 *   POST /api/work/chat/:gigId/message   → { ok, message:{…sender:'worker'…} } (rate-limited)
 *
 * Inbox lists every thread with unread badges; tapping a thread opens an inline
 * conversation panel (message bubbles, relative times) + a composer so crew can
 * reply to a customer right from the dashboard — Enter sends, Shift+Enter newlines,
 * optimistic append, read-marking. Full 4-state, bclReveal, dark cockpit. Pure
 * helpers unit-tested.
 */
import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnInit,
  computed,
  effect,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmSkeleton } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export interface ChatThread {
  readonly id: string;
  readonly gig_id: string;
  readonly customer_phone: string | null;
  readonly last_msg_at: string | null;
  readonly created_at: string;
  readonly unread_count: number;
  readonly last_body: string | null;
}

export interface ChatMessage {
  readonly id: string;
  readonly thread_id: string;
  readonly sender: 'worker' | 'customer';
  readonly body: string;
  readonly sent_at: string;
  readonly read_at: string | null;
}

interface ThreadsResponse {
  readonly threads?: readonly ChatThread[];
}

interface ThreadResponse {
  readonly threadId: string;
  readonly gigId: string;
  readonly customerPhone: string | null;
  readonly messages?: readonly ChatMessage[];
}

interface SendResponse {
  readonly ok?: boolean;
  readonly message?: ChatMessage;
}

/** Mirrors the worker zod bound. */
const MAX_MESSAGE_LEN = 1000;

/** Pure: mask a customer phone to its last 4 digits. Unit-tested. */
export function maskCustomer(phone: string | null): string {
  const digits = (phone || '').replace(/\D/g, '');
  if (!digits) return 'Customer';
  return digits.length >= 4 ? `Customer •••• ${digits.slice(-4)}` : 'Customer';
}

/** Pure: the last-message preview, tolerant of null/blank. Unit-tested. */
export function threadPreview(t: Pick<ChatThread, 'last_body'>): string {
  const body = (t.last_body || '').trim();
  return body || 'No messages yet';
}

/** Pure: total unread across all threads (drives the header badge). Unit-tested. */
export function totalUnread(threads: readonly ChatThread[]): number {
  return threads.reduce((sum, t) => sum + (t.unread_count || 0), 0);
}

/** Pure: short local time for a thread, blank when absent/junk. Unit-tested. */
export function formatThreadTime(iso: string | null): string {
  if (!iso) return '';
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return '';
  return new Date(t).toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  });
}

/** Pure: trim + bound a composer draft to the worker contract. `null` = unsendable. Unit-tested. */
export function sanitizeMessageBody(raw: string): string | null {
  const body = (raw || '').trim();
  if (body.length < 1 || body.length > MAX_MESSAGE_LEN) return null;
  return body;
}

/** Pure: may the composer submit right now? Unit-tested. */
export function canSend(raw: string, sending: boolean): boolean {
  return !sending && sanitizeMessageBody(raw) !== null;
}

/** Pure: did this keypress mean "send" (Enter without Shift)? Unit-tested. */
export function isSendKey(e: { key: string; shiftKey: boolean }): boolean {
  return e.key === 'Enter' && !e.shiftKey;
}

/** Pure: bubble alignment — true when the crew member authored it. Unit-tested. */
export function isOwnMessage(m: Pick<ChatMessage, 'sender'>): boolean {
  return m.sender === 'worker';
}

/** Pure: append a message, reconciling a confirmed id over its optimistic twin. Unit-tested. */
export function appendMessage(
  msgs: readonly ChatMessage[],
  next: ChatMessage,
): readonly ChatMessage[] {
  if (msgs.some((m) => m.id === next.id)) {
    return msgs.map((m) => (m.id === next.id ? next : m));
  }
  return [...msgs, next];
}

/** Pure: short clock time for a message bubble; blank for junk. Unit-tested. */
export function formatMsgTime(iso: string | null): string {
  if (!iso) return '';
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return '';
  return new Date(t).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
}

/** Pure: zero the unread count for one opened thread (backend marks read on open). Unit-tested. */
export function markThreadRead(
  threads: readonly ChatThread[],
  gigId: string,
): readonly ChatThread[] {
  return threads.map((t) => (t.gig_id === gigId || t.id === gigId ? { ...t, unread_count: 0 } : t));
}

@Component({
  selector: 'app-crew-chat-threads-card',
  standalone: true,
  imports: [HlmSkeleton, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section
      bclReveal
      data-testid="crew-chat-threads-card"
      class="rounded-xl border border-bcl-border bg-bcl-bg-elev/40 p-5"
      aria-labelledby="crew-chat-title"
    >
      <header class="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <p class="font-mono text-xs uppercase tracking-wide text-bcl-accent">Messages</p>
          <h3 id="crew-chat-title" class="text-lg font-semibold text-bcl-ink">Customer conversations</h3>
        </div>
        @if (unread() > 0) {
          <span
            class="rounded-full bg-bcl-accent/15 px-2.5 py-0.5 text-xs font-semibold text-bcl-accent ring-1 ring-bcl-accent/30"
            [attr.aria-label]="unread() + ' unread messages'"
            >{{ unread() }} unread</span
          >
        }
      </header>

      @if (error(); as e) {
        <div
          class="mb-3 flex items-center justify-between gap-3 rounded-lg border border-destructive/40 bg-destructive/5 px-3 py-2"
          role="alert"
        >
          <p class="text-sm text-bcl-ink">{{ e }}</p>
          <button
            type="button"
            class="rounded-md px-2 py-1 text-xs font-medium text-bcl-accent hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            (click)="refresh()"
          >
            Try again
          </button>
        </div>
      }

      @if (loading() && threads().length === 0) {
        <div class="space-y-2" aria-label="Loading conversations">
          <div hlmSkeleton class="h-12 w-full"></div>
          <div hlmSkeleton class="h-12 w-full"></div>
        </div>
      } @else if (threads().length === 0 && !error()) {
        <div
          class="rounded-lg border border-dashed border-bcl-border p-6 text-center text-sm text-bcl-ink-muted"
          data-testid="chat-threads-empty"
        >
          No conversations yet. Messages from customers on your gigs will appear here.
        </div>
      } @else {
        <ul class="space-y-1.5">
          @for (t of threads(); track t.id) {
            <li class="overflow-hidden rounded-md border border-bcl-border bg-bcl-bg/40">
              <button
                type="button"
                class="flex w-full items-center gap-3 px-3 py-2 text-left transition-[background-color,transform] duration-[0.333s] hover:bg-bcl-bg-elev/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                [attr.data-unread]="t.unread_count > 0 ? 'true' : 'false'"
                [attr.data-testid]="'chat-thread-' + t.gig_id"
                [attr.aria-expanded]="openGigId() === t.gig_id"
                [attr.aria-controls]="'chat-panel-' + t.gig_id"
                (click)="toggleThread(t)"
              >
                <span class="shrink-0 text-sm font-medium text-bcl-ink">{{ customer(t.customer_phone) }}</span>
                <span class="flex-1 truncate text-sm text-bcl-ink-muted">{{ preview(t) }}</span>
                @if (t.unread_count > 0) {
                  <span
                    class="shrink-0 rounded-full bg-bcl-accent px-1.5 py-0.5 text-[10px] font-bold tabular-nums text-black"
                    >{{ t.unread_count }}</span
                  >
                }
                <span class="shrink-0 font-mono text-xs tabular-nums text-bcl-ink-muted">{{
                  when(t.last_msg_at || t.created_at)
                }}</span>
                <svg
                  class="h-4 w-4 shrink-0 text-bcl-ink-muted transition-transform duration-[0.333s]"
                  [class.rotate-180]="openGigId() === t.gig_id"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                  aria-hidden="true"
                >
                  <path
                    fill-rule="evenodd"
                    d="M5.23 7.21a.75.75 0 011.06.02L10 11.17l3.71-3.94a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z"
                    clip-rule="evenodd"
                  />
                </svg>
              </button>

              @if (openGigId() === t.gig_id) {
                <div
                  bclReveal
                  [id]="'chat-panel-' + t.gig_id"
                  class="border-t border-bcl-border bg-bcl-bg/60 p-3"
                  data-testid="chat-thread-panel"
                >
                  @if (threadLoading()) {
                    <div class="space-y-2" aria-label="Loading conversation">
                      <div hlmSkeleton class="h-8 w-3/4"></div>
                      <div hlmSkeleton class="ml-auto h-8 w-2/3"></div>
                    </div>
                  } @else {
                    @if (threadError(); as te) {
                      <p class="mb-2 text-sm text-destructive" role="alert">{{ te }}</p>
                    }
                    <ul
                      class="mb-3 max-h-64 space-y-2 overflow-y-auto"
                      role="log"
                      aria-label="Conversation with customer"
                    >
                      @for (m of messages(); track m.id) {
                        <li class="flex" [class.justify-end]="own(m)">
                          <div
                            class="max-w-[80%] rounded-2xl px-3 py-2 text-sm"
                            [class]="
                              own(m)
                                ? 'bg-bcl-accent/15 text-bcl-ink ring-1 ring-bcl-accent/25'
                                : 'bg-bcl-bg-elev/70 text-bcl-ink ring-1 ring-bcl-border'
                            "
                          >
                            <p class="whitespace-pre-wrap break-words">{{ m.body }}</p>
                            <p class="mt-1 text-right font-mono text-[10px] tabular-nums text-bcl-ink-muted">
                              {{ msgTime(m.sent_at) }}
                            </p>
                          </div>
                        </li>
                      } @empty {
                        <li class="py-3 text-center text-sm text-bcl-ink-muted">
                          No messages yet. Say hello to your customer.
                        </li>
                      }
                    </ul>

                    <form class="flex items-end gap-2" (submit)="onSubmit($event, t.gig_id)">
                      <label class="sr-only" [attr.for]="'chat-composer-' + t.gig_id"
                        >Reply to customer</label
                      >
                      <textarea
                        #composer
                        [id]="'chat-composer-' + t.gig_id"
                        data-testid="chat-composer"
                        rows="1"
                        [value]="draft()"
                        (input)="onDraft($event)"
                        (keydown)="onComposerKeydown($event, t.gig_id)"
                        [attr.maxlength]="MAX_MESSAGE_LEN"
                        placeholder="Type a reply…  (Enter to send)"
                        class="min-h-[40px] flex-1 resize-none rounded-lg border border-bcl-border bg-bcl-bg px-3 py-2 text-sm text-bcl-ink placeholder:text-bcl-ink-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                      ></textarea>
                      <button
                        type="submit"
                        data-testid="chat-send"
                        [disabled]="!sendable()"
                        class="min-h-[40px] shrink-0 rounded-lg bg-bcl-accent px-4 py-2 text-sm font-semibold text-black transition-[opacity,transform] duration-[0.333s] enabled:hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                      >
                        {{ sending() ? 'Sending…' : 'Send' }}
                      </button>
                    </form>
                  }
                </div>
              }
            </li>
          }
        </ul>
      }
    </section>
  `,
})
export class CrewChatThreadsCardComponent implements OnInit {
  private readonly http = inject(HttpClient);
  protected readonly MAX_MESSAGE_LEN = MAX_MESSAGE_LEN;

  readonly loading = signal(false);
  readonly threads = signal<readonly ChatThread[]>([]);
  readonly error = signal<string | null>(null);
  readonly unread = computed(() => totalUnread(this.threads()));

  // Per-thread conversation view state.
  readonly openGigId = signal<string | null>(null);
  readonly messages = signal<readonly ChatMessage[]>([]);
  readonly threadLoading = signal(false);
  readonly threadError = signal<string | null>(null);
  readonly draft = signal('');
  readonly sending = signal(false);
  readonly sendable = computed(() => canSend(this.draft(), this.sending()));

  private readonly composer = viewChild<ElementRef<HTMLTextAreaElement>>('composer');

  constructor() {
    // Move focus into the composer the moment a thread opens (keyboard-first, zero extra clicks).
    effect(() => {
      if (this.openGigId() && !this.threadLoading()) {
        this.composer()?.nativeElement.focus();
      }
    });
  }

  ngOnInit(): void {
    void this.refresh();
  }

  customer(phone: string | null): string {
    return maskCustomer(phone);
  }
  preview(t: ChatThread): string {
    return threadPreview(t);
  }
  when(iso: string | null): string {
    return formatThreadTime(iso);
  }
  own(m: ChatMessage): boolean {
    return isOwnMessage(m);
  }
  msgTime(iso: string): string {
    return formatMsgTime(iso);
  }

  async refresh(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    try {
      const r = await firstValueFrom(
        this.http.get<ThreadsResponse>('/api/work/chat/threads', { withCredentials: true }),
      );
      this.threads.set(r?.threads ?? []);
    } catch (err) {
      this.error.set(`Couldn't load conversations: ${(err as Error).message}`);
      this.threads.set([]);
    } finally {
      this.loading.set(false);
    }
  }

  toggleThread(t: ChatThread): void {
    if (this.openGigId() === t.gig_id) {
      this.openGigId.set(null);
      return;
    }
    void this.openThread(t);
  }

  async openThread(t: ChatThread): Promise<void> {
    this.openGigId.set(t.gig_id);
    this.messages.set([]);
    this.draft.set('');
    this.threadError.set(null);
    this.threadLoading.set(true);
    try {
      const r = await firstValueFrom(
        this.http.get<ThreadResponse>(`/api/work/chat/${encodeURIComponent(t.gig_id)}`, {
          withCredentials: true,
        }),
      );
      this.messages.set(r?.messages ?? []);
      // Backend marks customer messages read on this GET — mirror it locally so the badge clears.
      this.threads.set(markThreadRead(this.threads(), t.gig_id));
    } catch (err) {
      this.threadError.set(`Couldn't open this conversation: ${(err as Error).message}`);
    } finally {
      this.threadLoading.set(false);
    }
  }

  onDraft(e: Event): void {
    this.draft.set((e.target as HTMLTextAreaElement).value);
  }

  onComposerKeydown(e: KeyboardEvent, gigId: string): void {
    if (isSendKey(e)) {
      e.preventDefault();
      void this.send(gigId);
    }
  }

  onSubmit(e: Event, gigId: string): void {
    e.preventDefault();
    void this.send(gigId);
  }

  async send(gigId: string): Promise<void> {
    const body = sanitizeMessageBody(this.draft());
    if (!body || this.sending()) return;
    this.sending.set(true);
    this.threadError.set(null);
    try {
      const r = await firstValueFrom(
        this.http.post<SendResponse>(
          `/api/work/chat/${encodeURIComponent(gigId)}/message`,
          { body },
          { withCredentials: true },
        ),
      );
      if (r?.message) this.messages.set(appendMessage(this.messages(), r.message));
      this.draft.set('');
      this.composer()?.nativeElement.focus();
    } catch (err) {
      this.threadError.set(`Couldn't send — try again: ${(err as Error).message}`);
    } finally {
      this.sending.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'chat-threads-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
