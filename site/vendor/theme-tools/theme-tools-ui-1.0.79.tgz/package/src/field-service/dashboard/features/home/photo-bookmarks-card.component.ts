import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * PhotoBookmarksCardComponent — the customer's pinned crew-uploaded job photos.
 *
 * Closes the last customer dashboard-parity gap (the React PhotoBookmarksGrid).
 * Fetches GET /api/customer/bookmarks (now returns signed, customer-viewable
 * photo URLs + ownership-checked server-side) and renders a thumbnail grid;
 * each photo can be un-pinned (DELETE /api/customer/photos/:photoId/bookmark).
 * Hidden entirely when the customer has pinned nothing (keeps the home tidy).
 */
import { ChangeDetectionStrategy, Component, type OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HlmCardImports } from '../../shared/ui-spartan';
import { AuthService } from '../../core/auth.service';

interface Bookmark {
  readonly id: string;
  readonly photoId: string;
  readonly bookmarkedAt: string;
  readonly kind?: string;
  readonly url: string;
}

@Component({
  selector: 'app-photo-bookmarks-card',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [...HlmCardImports],
  template: `
    @if (bookmarks().length > 0) {
      <div hlmCard class="p-4" data-testid="photo-bookmarks-card">
        <div class="mb-3 flex items-baseline justify-between">
          <h2 class="text-sm font-semibold text-bcl-ink">Pinned photos</h2>
          <span class="font-mono text-xs text-bcl-ink-muted">{{ bookmarks().length }}</span>
        </div>
        <div class="grid grid-cols-3 gap-2 sm:grid-cols-4">
          @for (b of bookmarks(); track b.id) {
            <figure class="group relative aspect-square overflow-hidden rounded-lg ring-1 ring-bcl-border">
              <img
                [src]="b.url"
                [alt]="(b.kind === 'end' ? 'After' : 'Before') + ' photo'"
                loading="lazy"
                decoding="async"
                class="h-full w-full object-cover"
              />
              <button
                type="button"
                class="absolute right-1 top-1 rounded-full bg-black/60 px-1.5 py-0.5 text-[11px] text-white opacity-0 transition-opacity group-hover:opacity-100 focus-visible:opacity-100"
                [disabled]="removing() === b.photoId"
                (click)="remove(b.photoId)"
                aria-label="Unpin photo"
              >
                {{ removing() === b.photoId ? '…' : '✕' }}
              </button>
            </figure>
          }
        </div>
      </div>
    }
  `,
})
export class PhotoBookmarksCardComponent implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);
  readonly bookmarks = signal<readonly Bookmark[]>([]);
  readonly removing = signal<string | null>(null);

  ngOnInit(): void {
    void this.refresh();
  }

  private async refresh(): Promise<void> {
    // The home index (/dashboard) renders for guests too; skip the authed
    // /api/customer/bookmarks fetch when signed out (no wasted 401, card hides).
    if (!this.auth.authenticated()) {
      this.bookmarks.set([]);
      return;
    }
    const r = await firstValueFrom(
      this.http
        .get<{ ok?: boolean; bookmarks?: Bookmark[] }>('/api/customer/bookmarks', { withCredentials: true })
        .pipe(catchError(() => of({ ok: false } as { ok?: boolean; bookmarks?: Bookmark[] }))),
    );
    if (r.ok && Array.isArray(r.bookmarks)) this.bookmarks.set(r.bookmarks);
  }

  async remove(photoId: string): Promise<void> {
    this.removing.set(photoId);
    await firstValueFrom(
      this.http
        .delete(`/api/customer/photos/${encodeURIComponent(photoId)}/bookmark`, { withCredentials: true })
        .pipe(catchError(() => of(null))),
    );
    this.removing.set(null);
    this.bookmarks.update((bs) => bs.filter((b) => b.photoId !== photoId));
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'photo-bookmarks-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
