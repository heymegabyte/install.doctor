import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * WalletComponent — GP-09 /dashboard/wallet (flag: wallet_balance_menu).
 *
 * Role-aware wallet page:
 *  - CREW  → balance breakdown (available + this-week + lifetime), a Cash out
 *            action (Stripe Connect instant payout via CrewEarningsService →
 *            POST /api/crew/payout-instant; idempotent server-side per crew+day+
 *            amount), the instant-fee preview, and eligibility hints.
 *  - CUSTOMER → store-credit + lifetime-spend breakdown and an Add money
 *            (card-on-file top-up) affordance. Brick Labor is hourly
 *            pay-as-you-go, so there is no prepaid balance to add TO — "Add
 *            money" saves a card on file for one-tap booking; Cash out is hidden.
 *
 * Loading / empty (flag dark) / error states via the shared StateBlock. Balance
 * is live from WalletService (never hardcoded). strictTemplates-safe: the ready
 * branch reads off `crew()` / `cust()` computeds that are only truthy once the
 * matching role resolves.
 */
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
  HlmCardImports,
  HlmButton,
  HlmInput,
  StateBlockComponent,
  type SurfaceState,
} from '../../shared/ui-spartan';
import {
  WalletService,
  formatUsd,
  type CrewWallet,
  type CustomerWallet,
  type Wallet,
} from '../../core/wallet.service';
import { CrewEarningsService } from '../../core/crew-earnings.service';

@Component({
  selector: 'app-wallet',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [...HlmCardImports, HlmButton, HlmInput, StateBlockComponent, FormsModule],
  template: `
    <header class="mb-6">
      <h1 class="text-2xl font-bold text-foreground">Wallet</h1>
      <p class="text-sm text-muted-foreground">
        Your balance, earnings, and money in one place.
      </p>
    </header>

    <app-state-block
      [state]="state()"
      [errorDetail]="errorDetail()"
      emptyTitle="Wallet unavailable"
      emptyHint="This feature isn't turned on for your account yet."
      (retry)="reload()"
    >
      <!-- CREW wallet -->
      @if (crew(); as w) {
        <div class="grid gap-4 md:grid-cols-3">
          <div hlmCard class="md:col-span-1 border-l-2 border-bcl-accent">
            <div hlmCardHeader><h3 hlmCardTitle>Available to cash out</h3></div>
            <div hlmCardContent>
              <p class="text-3xl font-bold tabular-nums text-foreground" data-testid="wallet-available">
                {{ money(w.availableCents) }}
              </p>
              <p class="mt-1 text-xs text-muted-foreground">
                {{ w.availableJobs }} completed {{ w.availableJobs === 1 ? 'gig' : 'gigs' }} · instant
                fee {{ money(w.instantFeeCents) }}
              </p>
            </div>
          </div>
          <div hlmCard>
            <div hlmCardHeader><h3 hlmCardTitle>This week</h3></div>
            <div hlmCardContent>
              <p class="text-2xl font-bold tabular-nums text-foreground">
                {{ money(w.weekGrossCents + w.weekTipsCents) }}
              </p>
              <p class="mt-1 text-xs text-muted-foreground">
                {{ money(w.weekTipsCents) }} tips · {{ w.weekGigs }} gigs
              </p>
            </div>
          </div>
          <div hlmCard>
            <div hlmCardHeader><h3 hlmCardTitle>Lifetime</h3></div>
            <div hlmCardContent>
              <p class="text-2xl font-bold tabular-nums text-foreground">{{ money(w.lifetimeCents) }}</p>
              <p class="mt-1 text-xs text-muted-foreground">
                {{ money(w.postedCents) }} already paid out
              </p>
            </div>
          </div>
        </div>

        <div hlmCard class="mt-4">
          <div hlmCardHeader><h3 hlmCardTitle>Cash out</h3></div>
          <div hlmCardContent>
            @if (payoutOk()) {
              <div
                class="rounded-lg bg-bcl-success/10 px-4 py-3 text-sm text-foreground ring-1 ring-bcl-success/40"
                role="status"
                data-testid="wallet-cashout-ok"
              >
                Cash-out requested — {{ money(lastAmountCents()) }} on its way.
                RTP arrives in seconds, ACH next business day.
              </div>
            } @else {
              <div class="space-y-4">
                <div class="max-w-xs">
                  <label for="cashout" class="mb-1 block text-sm font-medium text-foreground">
                    Amount (USD)
                  </label>
                  <input
                    hlmInput
                    id="cashout"
                    type="number"
                    min="10"
                    step="0.01"
                    [ngModel]="amountDollars()"
                    (ngModelChange)="setAmount($event)"
                    class="w-full tabular-nums"
                    data-testid="wallet-cashout-amount"
                    placeholder="50.00"
                    [attr.aria-invalid]="cashoutInvalid(w) ? 'true' : null"
                    [attr.aria-describedby]="cashoutDescribedBy(w)"
                  />
                  <p id="cashout-hint" class="mt-1 text-xs text-muted-foreground">
                    Min {{ money(w.minCashoutCents) }}. Brick Labor absorbs the fee under $100.
                  </p>
                  @if (cashoutConstraint(w); as msg) {
                    <p
                      id="cashout-constraint"
                      class="mt-1 text-xs font-medium text-destructive"
                      role="status"
                      aria-live="polite"
                      data-testid="wallet-cashout-constraint"
                    >
                      {{ msg }}
                    </p>
                  }
                </div>
                @if (payoutError(); as e) {
                  <div
                    class="rounded-lg bg-destructive/10 px-4 py-3 text-sm text-foreground ring-1 ring-destructive/40"
                    role="alert"
                  >
                    {{ cashoutErrorCopy(e) }}
                  </div>
                }
                @if (!w.cashoutReady) {
                  <p class="text-xs text-muted-foreground">
                    Connect your bank + complete 10 gigs to cash out instantly. You're at
                    {{ w.eligibleGigs }}/10.
                  </p>
                }
                <button
                  hlmBtn
                  type="button"
                  class="min-w-[16ch]"
                  data-testid="wallet-cashout-submit"
                  [disabled]="!canCashout(w) || submitting()"
                  (click)="cashOut(w)"
                >
                  @if (submitting()) {
                    <span class="inline-block min-w-[13ch] text-center">Requesting…</span>
                  } @else {
                    <span class="inline-block min-w-[13ch] text-center">Cash out {{ money(amountCents()) }}</span>
                  }
                </button>
              </div>
            }
          </div>
        </div>
      }

      <!-- CUSTOMER wallet -->
      @if (cust(); as w) {
        <div class="grid gap-4 md:grid-cols-3">
          <div hlmCard class="md:col-span-1 border-l-2 border-bcl-accent">
            <div hlmCardHeader><h3 hlmCardTitle>Store credit</h3></div>
            <div hlmCardContent>
              <p class="text-3xl font-bold tabular-nums text-foreground" data-testid="wallet-credit">
                {{ money(w.creditCents) }}
              </p>
              <p class="mt-1 text-xs text-muted-foreground">
                Referral credit — applied automatically at checkout.
              </p>
            </div>
          </div>
          <div hlmCard>
            <div hlmCardHeader><h3 hlmCardTitle>Lifetime spent</h3></div>
            <div hlmCardContent>
              <p class="text-2xl font-bold tabular-nums text-foreground">
                {{ money(w.lifetimeSpentCents) }}
              </p>
              <p class="mt-1 text-xs text-muted-foreground">
                {{ w.bookingsCount }} paid {{ w.bookingsCount === 1 ? 'job' : 'jobs' }}
              </p>
            </div>
          </div>
          <div hlmCard>
            <div hlmCardHeader><h3 hlmCardTitle>Last payment</h3></div>
            <div hlmCardContent>
              <p class="text-2xl font-bold tabular-nums text-foreground">
                {{ w.lastPaymentCents > 0 ? money(w.lastPaymentCents) : '—' }}
              </p>
              <p class="mt-1 text-xs text-muted-foreground">
                {{ w.lastPaymentAt ? day(w.lastPaymentAt) : 'No payments yet' }}
              </p>
            </div>
          </div>
        </div>

        <div hlmCard class="mt-4">
          <div hlmCardHeader><h3 hlmCardTitle>Add money</h3></div>
          <div hlmCardContent>
            <p class="mb-3 max-w-prose text-sm text-muted-foreground">
              Brick Labor is pay-as-you-go — you're billed by the hour, so there's no prepaid balance
              to top up. Save a card on file for one-tap booking and to auto-apply your store credit.
            </p>
            <a hlmBtn href="/me#billing" data-testid="wallet-add-money" class="inline-flex">
              {{ w.hasCardOnFile ? 'Manage card on file' : 'Add a card on file' }}
            </a>
          </div>
        </div>
      }
    </app-state-block>
  `,
})
export class WalletComponent {
  private readonly svc = inject(WalletService);
  private readonly crewEarnings = inject(CrewEarningsService);

  protected readonly state = signal<SurfaceState>('loading');
  protected readonly errorDetail = signal('');
  private readonly wallet = signal<Wallet | null>(null);

  protected readonly crew = computed<CrewWallet | null>(() => {
    const w = this.wallet();
    return w && w.role === 'crew' ? w : null;
  });
  protected readonly cust = computed<CustomerWallet | null>(() => {
    const w = this.wallet();
    return w && w.role === 'customer' ? w : null;
  });

  // Cash-out (crew) state. A signal (not a plain property) so the template stays
  // reactive under zoneless CD — the derived aria-invalid / constraint-reason /
  // button-disabled all recompute the instant the amount changes.
  protected readonly amountDollars = signal(50);
  protected readonly submitting = signal(false);
  protected readonly payoutOk = signal(false);
  protected readonly payoutError = signal<string | null>(null);
  protected readonly lastAmountCents = signal(0);

  constructor() {
    this.reload();
  }

  protected money(cents: number | null | undefined): string {
    return formatUsd(cents);
  }

  /** ISO/SQL date-time → YYYY-MM-DD (avoids a SlicePipe import). */
  protected day(iso: string | null): string {
    return (iso ?? '').slice(0, 10);
  }

  /** ngModel → signal bridge: coerce the raw input value to a finite number of dollars. */
  protected setAmount(v: unknown): void {
    const n = Number(v);
    this.amountDollars.set(Number.isFinite(n) ? n : 0);
  }

  protected amountCents(): number {
    return Math.round((Number(this.amountDollars()) || 0) * 100);
  }

  protected canCashout(w: CrewWallet): boolean {
    const cents = this.amountCents();
    return w.cashoutReady && cents >= w.minCashoutCents && cents <= w.availableCents;
  }

  /**
   * True when a POSITIVE amount is out of the valid cash-out range (below the
   * minimum or above the available balance). A zero/empty field is *incomplete*,
   * not invalid — so we never flip aria-invalid on an untouched input (WCAG 3.3.1
   * is about identifying real errors, not scolding a blank field).
   */
  protected cashoutInvalid(w: CrewWallet): boolean {
    const cents = this.amountCents();
    return cents > 0 && (cents < w.minCashoutCents || cents > w.availableCents);
  }

  /**
   * The specific, actionable reason the amount is rejected — announced via a polite
   * live region so a screen-reader user hears WHY the Cash out button is disabled,
   * instead of a silently-greyed control. Empty string when valid/incomplete.
   */
  protected cashoutConstraint(w: CrewWallet): string {
    const cents = this.amountCents();
    if (cents <= 0) return '';
    if (cents < w.minCashoutCents) return `Minimum cash-out is ${this.money(w.minCashoutCents)}.`;
    if (cents > w.availableCents) return `That's more than your ${this.money(w.availableCents)} available.`;
    return '';
  }

  /** Links the always-on min/fee hint, plus the constraint reason when invalid. */
  protected cashoutDescribedBy(w: CrewWallet): string {
    return this.cashoutInvalid(w) ? 'cashout-hint cashout-constraint' : 'cashout-hint';
  }

  protected cashoutErrorCopy(code: string): string {
    switch (code) {
      case 'eligibility_failed':
        return 'You need at least 10 completed gigs to cash out instantly.';
      case 'stripe_account_required':
        return 'Connect your bank account first to cash out.';
      case 'rate_limited':
        return 'Too many requests — wait a moment and try again.';
      default:
        return 'Cash-out failed. Try again, or call (855) 82LABOR.';
    }
  }

  protected reload(): void {
    this.state.set('loading');
    this.svc.summary$().subscribe((r) => {
      if (r.ok && r.wallet) {
        this.wallet.set(r.wallet);
        this.state.set('ready');
      } else if (r.error === 'unavailable') {
        this.state.set('empty');
      } else {
        this.errorDetail.set(
          r.error === 'unauthorized' ? 'Sign in to view your wallet.' : '',
        );
        this.state.set('error');
      }
    });
  }

  protected cashOut(w: CrewWallet): void {
    if (!this.canCashout(w) || this.submitting()) return;
    const cents = this.amountCents();
    this.submitting.set(true);
    this.payoutError.set(null);
    // Reuse the existing, idempotent instant-payout endpoint (Stripe Connect).
    this.crewEarnings.requestPayout$('rtp', cents).subscribe((res) => {
      this.submitting.set(false);
      if (res.ok) {
        this.lastAmountCents.set(cents);
        this.payoutOk.set(true);
      } else {
        this.payoutError.set(res.error ?? 'payout_failed');
      }
    });
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'wallet-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
