import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * DisputeMediationComponent — surfaces the AI-drafted de-escalation reply recorded on
 * a disputed close-out, embedded in each dispute card on the admin console.
 *
 * SCAN-25 DRAFTS + RECORDS a warm, accountable de-escalation reply (+ severity +
 * suggested concession) on `booking_close_out` the instant a customer disputes a
 * completed job during GP-06's 1h satisfaction window. SCAN-51 is the DISPLAY half:
 * this panel reads that recorded draft (read-only) so the operator can read it and
 * copy it — it drafts, it never auto-sends.
 *
 * Feeds from `GET /api/admin/close-out/:bookingId/mediation` (super_admin cookie
 * session). FLAG-DARK: the endpoint 404s while `dispute_ai_mediator` is off, so this
 * panel SELF-HIDES (mediation stays null) whenever the flag is dark, the booking was
 * never disputed, or the fetch is unauthorized — mirroring `app-dispute-evidence`.
 * Brand ORANGE (bcl-accent), dark cockpit, one-tap copy affordance. Read-only.
 */
import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  input,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

/** The recorded mediation the admin endpoint returns (null when none/dark). */
export interface RecordedMediation {
  readonly message: string;
  readonly severity: number | null;
  readonly concession: string;
  readonly concessionLabel: string;
  readonly aiUsed: boolean;
  readonly at: string;
  readonly disputeState: string | null;
}

interface MediationResponse {
  readonly ok: boolean;
  readonly bookingId?: string;
  readonly mediation?: RecordedMediation | null;
}

/**
 * Severity → chip classes (higher = more severe). Pure, unit-tested.
 *
 * @param severity - 0-100 model-estimated severity, or null.
 * @returns Tailwind ring/bg/text classes for the severity chip.
 * @example severityChipClass(80) // → destructive classes
 */
export function severityChipClass(severity: number | null): string {
  const s = severity ?? 0;
  if (s >= 70) return 'bg-destructive/10 text-destructive ring-destructive/30';
  if (s >= 40) return 'bg-bcl-warn/10 text-bcl-warn ring-bcl-warn/30';
  return 'bg-bcl-bg-elev text-bcl-ink-muted ring-bcl-border';
}

/**
 * Short "AI-drafted" vs "fallback" provenance label. Pure, unit-tested.
 *
 * @param aiUsed - true when the live model produced the draft, false for the deterministic floor.
 * @returns 'AI-drafted' or 'Auto-drafted (fallback)'.
 * @example mediationSourceLabel(false) // → 'Auto-drafted (fallback)'
 */
export function mediationSourceLabel(aiUsed: boolean): string {
  return aiUsed ? 'AI-drafted' : 'Auto-drafted (fallback)';
}

@Component({
  selector: 'app-dispute-mediation',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (mediation(); as m) {
      <section
        class="mt-3 rounded-lg border border-bcl-accent/30 bg-bcl-accent/5 p-3"
        data-testid="dispute-mediation"
      >
        <!-- Orange top-accent hairline -->
        <div
          class="-mx-3 -mt-3 mb-3 h-0.5 rounded-t-lg bg-gradient-to-r from-bcl-accent/70 via-bcl-accent to-bcl-accent/40"
          aria-hidden="true"
        ></div>

        <header class="mb-2 flex flex-wrap items-center justify-between gap-2">
          <div>
            <p class="font-mono text-[10px] uppercase tracking-wider text-bcl-accent">
              AI dispute mediation
            </p>
            <p class="mt-0.5 text-xs text-muted-foreground">
              A suggested reply — read, edit, and send it yourself. Never auto-sent.
            </p>
          </div>
          <div class="flex flex-wrap items-center gap-1.5">
            <span
              class="rounded-full px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider ring-1"
              [class]="sevChip()"
              [attr.title]="'Estimated severity ' + (m.severity ?? '—') + ' / 100'"
              data-testid="dispute-mediation-severity"
              >Severity {{ m.severity ?? '—' }}</span
            >
            <span
              class="rounded-full bg-bcl-bg-elev px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground ring-1 ring-bcl-border"
              data-testid="dispute-mediation-source"
              >{{ sourceLabel() }}</span
            >
          </div>
        </header>

        <!-- The drafted reply -->
        <blockquote
          class="whitespace-pre-line rounded-md border border-border bg-bcl-bg/60 px-3 py-2 text-sm text-foreground"
          data-testid="dispute-mediation-message"
        >
          {{ m.message }}
        </blockquote>

        <!-- Suggested concession -->
        <p class="mt-2 flex items-start gap-2 text-xs text-muted-foreground">
          <span class="font-mono text-[10px] uppercase tracking-wider text-bcl-accent"
            >Suggested fix</span
          >
          <span data-testid="dispute-mediation-concession">{{ m.concessionLabel }}</span>
        </p>

        <!-- One-tap copy -->
        <div class="mt-3 flex items-center gap-2">
          <button
            type="button"
            (click)="copy(m.message)"
            class="inline-flex items-center gap-1.5 rounded-md border border-bcl-accent/40 bg-bcl-accent/10 px-3 py-1.5 font-mono text-[10px] uppercase tracking-wider text-bcl-accent transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-bcl-accent/20 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent motion-reduce:transition-none"
            data-testid="dispute-mediation-copy"
          >
            <!-- reserve widest label so the button never resizes on copy -->
            <span class="inline-block min-w-[9ch] text-center">{{
              copied() ? 'Copied!' : 'Copy reply'
            }}</span>
          </button>
        </div>
      </section>
    }
  `,
})
export class DisputeMediationComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly bookingId = input.required<string>();

  readonly mediation = signal<RecordedMediation | null>(null);
  readonly copied = signal(false);

  protected readonly sevChip = computed(() => severityChipClass(this.mediation()?.severity ?? null));
  protected readonly sourceLabel = computed(() =>
    mediationSourceLabel(this.mediation()?.aiUsed ?? false),
  );

  async ngOnInit(): Promise<void> {
    const id = this.bookingId();
    if (!id) return;
    try {
      const res = await firstValueFrom(
        this.http.get<MediationResponse>(
          `/api/admin/close-out/${encodeURIComponent(id)}/mediation`,
          { withCredentials: true },
        ),
      );
      // 200 with a recorded mediation → show it; null (never disputed) or dark 404 → hide.
      if (res?.ok && res.mediation && res.mediation.message.trim().length > 0) {
        this.mediation.set(res.mediation);
      }
    } catch {
      // 404 (flag dark) / 401 (unauthorized) / not-found → self-hide (stays null).
    }
  }

  async copy(text: string): Promise<void> {
    try {
      await navigator.clipboard?.writeText(text);
      this.copied.set(true);
      setTimeout(() => this.copied.set(false), 2000);
    } catch {
      // clipboard unavailable — the text is visible for manual copy anyway.
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'dispute-mediation-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
