import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CrewReferComponent — crew-refers-crew bonus surface (the labor-supply funnel).
 *
 * The LIVE crew surface is Angular `/dashboard/refer` (UNIFIED_DASHBOARD_CUTOVER
 * 308-redirects `/work/refer` here). Before this slice that route rendered ONLY
 * the customer neighbor-referral view, so a signed-in crew member never saw
 * their own `$100`-after-`5-gigs` Stripe Connect bonus program — the backend
 * (`/api/work/refer`) was mounted with no Angular frontend (a mounted-backend-
 * no-frontend gap, not "blocked"). `ReferSwitchComponent` now picks this view
 * for the crew persona; the React `CrewReferralWidget` stays the rollback.
 *
 * Contract (worker-cookie `bcl_work_sid` gated → 401 anon):
 *  - GET  /api/work/refer        → { ok, referrals[], totals }
 *  - POST /api/work/refer/mint   → { ok, referral } (idempotent — returns the
 *    open pending slot's code if one exists)
 *
 * Self-gates: `/dashboard/refer` has no role guard, so the shell renders for a
 * guest → the authed GET would 401 + log a red console error. Skip the fetch
 * when signed out; show a crew sign-in affordance instead. The bonus + threshold
 * render through the canonical `crew-refer.economics` mirror (parity-locked),
 * never hardcoded literals.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, finalize, of } from 'rxjs';
import { AuthService } from '../../core/auth.service';
import { StateBlockComponent } from '../../shared/ui-spartan';
import {
  CREW_REFERRAL_QUALIFYING_GIGS,
  formatCrewBonus,
  crewStatusChip,
  crewStatusLabel,
  crewReferralProgressPct,
  type CrewReferralStatus,
} from '@theme.tools/billing/field-service/crew-refer-economics';

interface CrewReferralRow {
  readonly id: string;
  readonly code: string;
  readonly referred_worker_id: string | null;
  readonly referredFirstName: string | null;
  readonly qualifying_gigs_completed: number;
  readonly qualifying_threshold: number;
  readonly payout_cents: number;
  readonly status: CrewReferralStatus | string;
  readonly created_at: string;
}

interface CrewReferralTotals {
  readonly pending: number;
  readonly signedUp: number;
  readonly qualified: number;
  readonly paid: number;
  readonly totalPaidCents: number;
}

interface CrewReferListResponse {
  readonly ok: boolean;
  readonly referrals?: readonly CrewReferralRow[];
  readonly totals?: CrewReferralTotals;
}

interface CrewReferMintResponse {
  readonly ok: boolean;
  readonly referral?: CrewReferralRow;
  readonly error?: string;
}

@Component({
  selector: 'app-crew-refer',
  standalone: true,
  imports: [RouterLink, StateBlockComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bcl-rise mb-6 rounded-2xl border border-bcl-border bcl-grain p-6">
      <p class="bcl-eyebrow mb-2">Crew referrals</p>
      <h1 class="font-display text-3xl font-extrabold tracking-tight text-bcl-ink">
        Earn {{ bonus }} for every crew member you bring on
      </h1>
      <p class="mt-2 max-w-2xl text-sm text-bcl-ink-muted">
        Share your code. When someone you refer joins Brick Labor and finishes
        their first {{ qualifyingGigs }} gigs, you earn a {{ bonus }} bonus on
        your next Stripe payout.
      </p>
    </header>

    @if (needsAuth()) {
      <div
        class="rounded-2xl border border-dashed border-bcl-border p-10 text-center"
        data-testid="crew-refer-signin"
      >
        <p class="text-2xl" aria-hidden="true">🤝</p>
        <p class="mt-2 text-base font-semibold text-bcl-ink">Sign in to get your crew code</p>
        <p class="mx-auto mt-1 max-w-md text-sm text-bcl-ink-muted">
          Log in as crew to mint your referral code and track every {{ bonus }} bonus.
        </p>
        <a
          [routerLink]="['/login']"
          [queryParams]="{ as: 'crew', next: '/refer' }"
          class="mt-4 inline-flex items-center justify-center rounded-md bg-bcl-accent px-4 py-2 text-sm font-extrabold text-bcl-bg focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        >
          Sign in →
        </a>
      </div>
    } @else if (loading()) {
      <p class="text-sm text-bcl-ink-muted" data-testid="crew-refer-loading">Loading…</p>
    } @else if (loadError(); as err) {
      <app-state-block
        [state]="'error'"
        errorTitle="Couldn't load your crew referrals"
        [errorDetail]="err"
        (retry)="reload()"
      />
    } @else {
      <section class="bcl-glass bcl-fade-in p-6" data-testid="crew-refer-panel">
        @if (activeCode(); as code) {
          <p class="bcl-eyebrow mb-1">Your crew code</p>
          <p class="font-mono text-xl text-bcl-accent break-all">{{ code }}</p>
          <p class="mt-1 font-mono text-xs text-bcl-ink-muted break-all">{{ shareUrl(code) }}</p>
          <div class="mt-4 flex flex-wrap gap-2">
            <button
              type="button"
              (click)="copy(code)"
              class="rounded-md bg-bcl-accent px-4 py-2 text-sm font-extrabold text-bcl-bg focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            >
              {{ copied() ? 'Copied ✓' : 'Copy link' }}
            </button>
            <a
              [href]="smsHref(code)"
              class="rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-4 py-2 text-sm font-bold text-bcl-ink"
            >
              Share via SMS
            </a>
            <a
              [href]="mailHref(code)"
              class="rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-4 py-2 text-sm font-bold text-bcl-ink"
            >
              Share via email
            </a>
          </div>
        } @else {
          <p class="bcl-eyebrow mb-1">Get started</p>
          <h2 class="font-display text-xl font-extrabold text-bcl-ink">
            Generate your referral code
          </h2>
          <p class="mt-1 text-sm text-bcl-ink-muted">
            One tap mints a unique code you can share with crew you'd vouch for.
          </p>
          <button
            type="button"
            (click)="mint()"
            [disabled]="busy()"
            class="mt-4 inline-flex items-center justify-center rounded-md bg-bcl-accent px-4 py-2 text-sm font-extrabold text-bcl-bg disabled:opacity-60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            data-testid="crew-refer-mint"
          >
            {{ busy() ? 'Creating…' : 'Generate my code →' }}
          </button>
        }
        @if (error()) {
          <p class="mt-3 text-sm text-amber-300">{{ error() }}</p>
        }
      </section>

      @if (totals(); as t) {
        <section class="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4" data-testid="crew-refer-totals">
          <div class="rounded-xl border border-bcl-border bg-bcl-bg-elev/40 p-3">
            <span class="block text-xs text-bcl-ink-muted">Invited</span>
            <span class="bcl-tabular text-lg font-bold text-bcl-ink">{{ t.signedUp }}</span>
          </div>
          <div class="rounded-xl border border-bcl-border bg-bcl-bg-elev/40 p-3">
            <span class="block text-xs text-bcl-ink-muted">Bonuses earned</span>
            <span class="bcl-tabular text-lg font-bold text-bcl-ink">{{ t.qualified }}</span>
          </div>
          <div class="rounded-xl border border-bcl-border bg-bcl-bg-elev/40 p-3">
            <span class="block text-xs text-bcl-ink-muted">Paid</span>
            <span class="bcl-tabular text-lg font-bold text-bcl-ink">{{ t.paid }}</span>
          </div>
          <div class="rounded-xl border border-bcl-border bg-bcl-bg-elev/40 p-3">
            <span class="block text-xs text-bcl-ink-muted">Total earned</span>
            <span class="bcl-tabular text-lg font-bold text-bcl-success">{{
              formatBonus(t.totalPaidCents)
            }}</span>
          </div>
        </section>
      }

      @if (referees().length > 0) {
        <section class="mt-4 space-y-2" data-testid="crew-refer-referees">
          <p class="bcl-eyebrow">Your referrals</p>
          @for (r of referees(); track r.id) {
            <div
              class="flex items-center justify-between rounded-xl border border-bcl-border bg-bcl-bg-elev/40 p-3"
            >
              <div>
                <span class="text-sm font-semibold text-bcl-ink">{{
                  r.referredFirstName ?? 'Crew member'
                }}</span>
                <span
                  class="ml-2 inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset"
                  [class]="statusChip(r.status)"
                  >{{ statusLabel(r.status) }}</span
                >
              </div>
              <span class="bcl-tabular text-xs text-bcl-ink-muted">
                {{ r.qualifying_gigs_completed }} / {{ r.qualifying_threshold }} gigs
                · {{ progressPct(r) }}%
              </span>
            </div>
          }
        </section>
      }
    }

    <span class="sr-only" role="status" aria-live="polite">{{ copied() ? 'Crew code copied to clipboard' : '' }}</span>
  `,
})
export class CrewReferComponent {
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);
  private readonly auth = inject(AuthService);

  protected readonly bonus = formatCrewBonus();
  protected readonly qualifyingGigs = CREW_REFERRAL_QUALIFYING_GIGS;

  readonly loading = signal(true);
  readonly busy = signal(false);
  readonly copied = signal(false);
  readonly error = signal<string | null>(null);
  /** Initial-load failure (distinct from `error`, which is the mint-POST error). */
  readonly loadError = signal<string | null>(null);
  readonly rows = signal<readonly CrewReferralRow[]>([]);
  readonly totals = signal<CrewReferralTotals | null>(null);
  /** Set after a mint when the list had no open code yet. */
  readonly mintedCode = signal<string | null>(null);

  /** The shareable code = the open `pending` slot's code, else a freshly minted one. */
  readonly activeCode = computed<string | null>(() => {
    const pending = this.rows().find((r) => r.status === 'pending');
    return pending?.code ?? this.mintedCode();
  });

  /** Referees are every row that has actually been linked to a new crew member. */
  readonly referees = computed(() => this.rows().filter((r) => r.referred_worker_id !== null));

  protected readonly needsAuth = computed(() => !this.auth.authenticated());

  constructor() {
    if (this.needsAuth()) {
      this.loading.set(false);
      return;
    }
    this.reload();
  }

  /**
   * (Re)fetch the crew referral list. A FAILED load now surfaces a distinct
   * error + retry (via <app-state-block>) instead of blanking rows+totals and
   * falling through to the "Generate your referral code" mint panel — that
   * get-started state is reserved for a crew member who genuinely has no code,
   * never a fetch failure (the lying-empty this fixes; twin of fire-107).
   */
  reload(): void {
    this.loading.set(true);
    this.loadError.set(null);
    this.http
      .get<CrewReferListResponse>('/api/work/refer', { withCredentials: true })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((err: { status?: number }) => {
          this.loadError.set(
            err?.status
              ? `We couldn't load your crew referrals (HTTP ${err.status}). Try again.`
              : "We couldn't load your crew referrals. Try again.",
          );
          return of<CrewReferListResponse>({ ok: false });
        }),
        finalize(() => this.loading.set(false)),
      )
      .subscribe((r) => {
        if (this.loadError()) return;
        this.rows.set(r.referrals ?? []);
        this.totals.set(r.totals ?? null);
      });
  }

  shareUrl(code: string): string {
    return `https://bricklabor.com/careers?ref=${encodeURIComponent(code)}`;
  }

  smsHref(code: string): string {
    const body = `Come work with me at Brick Labor — use my crew code ${code}: ${this.shareUrl(code)}`;
    return `sms:?body=${encodeURIComponent(body)}`;
  }

  mailHref(code: string): string {
    const body = `Come work with me at Brick Labor — use my crew code ${code}: ${this.shareUrl(code)}`;
    return `mailto:?subject=${encodeURIComponent('Join the Brick Labor crew')}&body=${encodeURIComponent(body)}`;
  }

  formatBonus(cents: number): string {
    return formatCrewBonus(cents);
  }

  statusLabel(status: string): string {
    return crewStatusLabel(status);
  }

  statusChip(status: string): string {
    return crewStatusChip(status);
  }

  progressPct(r: CrewReferralRow): number {
    return crewReferralProgressPct(r.qualifying_gigs_completed, r.qualifying_threshold);
  }

  async copy(code: string): Promise<void> {
    try {
      await navigator.clipboard.writeText(this.shareUrl(code));
      this.copied.set(true);
      setTimeout(() => this.copied.set(false), 2000);
    } catch {
      /* clipboard unavailable — ignore */
    }
  }

  mint(): void {
    if (this.busy()) return;
    this.busy.set(true);
    this.error.set(null);
    this.http
      .post<CrewReferMintResponse>('/api/work/refer/mint', {}, { withCredentials: true })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((err: { status?: number; error?: { error?: string } }) =>
          of<CrewReferMintResponse>({ ok: false, error: err.error?.error ?? `HTTP ${err.status}` }),
        ),
        finalize(() => this.busy.set(false)),
      )
      .subscribe((r) => {
        if (r.ok && r.referral) {
          this.mintedCode.set(r.referral.code);
          // Reflect the new pending row in the list so activeCode stays stable.
          this.rows.update((prev) => [r.referral as CrewReferralRow, ...prev]);
        } else {
          this.error.set(
            r.error === 'unauthorized'
              ? 'Sign in as crew to generate a code.'
              : `Couldn't create your code (${r.error ?? 'unknown'}). Try again.`,
          );
        }
      });
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'crew-refer-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
