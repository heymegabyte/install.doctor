import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * HomeComponent — persona-aware dashboard landing.
 *
 * Renders:
 *   1. Persona welcome panel keyed off RoleService.viewAs()
 *   2. Onboarding checklist (shipped in W26-E)
 *   3. "Today" KPI strip — counts differ by persona
 *   4. Quick-actions tile with persona-specific CTAs
 *   5. Activity feed (last 10 events from /api/dashboard/feed, polled 60s)
 *
 * Feed polling lives in the component itself rather than a service so the
 * effect tears down when this route unmounts. No setInterval leak.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  OnDestroy,
  OnInit,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Subscription, timer } from 'rxjs';
import { switchMap, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { AuthService } from '../../core/auth.service';
import { RoleService } from '../../core/role.service';
import { HlmCardImports, HlmBadge, HlmSkeleton, type BadgeVariant } from '../../shared/ui-spartan';
import { OnboardingChecklistComponent } from './onboarding-checklist.component';
import { CarbonImpactCardComponent } from './carbon-impact-card.component';
import { LoyaltyCardComponent } from './loyalty-card.component';
import { CommLogCardComponent } from './comm-log-card.component';
import { RecurringPlansCardComponent } from './recurring-plans-card.component';
import { PhotoBookmarksCardComponent } from './photo-bookmarks-card.component';
import { ContractUpsellComponent } from '../_shared/contract-upsell.component';
import { MaintenanceReminderComponent } from '../_shared/maintenance-reminder.component';
import { ReceivedRatingComponent } from '../_shared/received-rating.component';
import { BclKpiBentoComponent, type KpiBentoItem } from '../_shared/kpi-bento.component';
import { fadeUpItem, listStagger, routeFade, reducedMotion } from '../../shared/animations';
import { CANONICAL_SERVICES, HOURLY_RATE_USD } from '../quotes/quote-detail.component';

interface FeedEvent {
  readonly id: string;
  readonly kind: 'booking' | 'subscription' | 'gig' | 'sms' | 'inbox' | 'audit' | 'system';
  readonly title: string;
  readonly subtitle: string;
  readonly at: string;
  readonly ago?: string;
  readonly href?: string;
  readonly severity: 'info' | 'success' | 'warn' | 'error';
}

interface FeedResponse {
  readonly ok: boolean;
  readonly events: readonly FeedEvent[];
  readonly generatedAt: string;
}

interface KpiTile {
  readonly label: string;
  readonly value: number;
  readonly prefix?: string;
  readonly suffix?: string;
  readonly decimals?: number;
  readonly hint: string;
}

const HERO_PHRASES = {
  customer: [
    'Your crew is one tap away.',
    'Booked. Done. Easy.',
    'Brick City moves you.',
    'A great day to get it done.',
    'Move smarter, not harder.',
    'You bring the boxes. We bring the muscle.',
    "Quotes ready. Jobs queued. Let's go.",
  ],
  crew: [
    'Light it up — gigs are live.',
    'Stay online, stack the bag.',
    'Surge is moving. So should you.',
    "Today's your day, captain.",
    'Crew of one, energy of ten.',
    'Tips climbing. Keep the streak.',
    'Hit the road, hit the goal.',
  ],
  super_admin: [
    'Pulse strong. Ops humming.',
    'Drivers up. Surge balanced.',
    'Eyes on. Hands on.',
    "Today's revenue waits for no one.",
    'Live ops looking sharp.',
    'Every job, every crew, every dollar.',
    'You are mission control.',
  ],
} as const;

function dailyPhrase(persona: 'customer' | 'crew' | 'super_admin'): string {
  const pool = HERO_PHRASES[persona];
  const today = new Date();
  const seed = today.getUTCFullYear() * 1000 + today.getUTCMonth() * 32 + today.getUTCDate();
  return pool[seed % pool.length] ?? pool[0] ?? '';
}

const FEED_POLL_MS = 60_000;

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    ...HlmCardImports,
    HlmBadge,
    HlmSkeleton,
    OnboardingChecklistComponent,
    CarbonImpactCardComponent,
    LoyaltyCardComponent,
    CommLogCardComponent,
    RecurringPlansCardComponent,
    PhotoBookmarksCardComponent,
    ReceivedRatingComponent,
    ContractUpsellComponent,
    MaintenanceReminderComponent,
    RouterLink,
    BclKpiBentoComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [listStagger, fadeUpItem, routeFade],
  template: `
    <!-- Cinematic hero — gradient text, eyebrow rule, dot-grid texture -->
    <header
      class="bcl-rise relative mb-8 overflow-hidden rounded-2xl border border-bcl-border bg-gradient-to-br from-bcl-bg-elev/60 to-bcl-bg/30 px-6 py-8 sm:px-10 sm:py-12"
    >
      <span aria-hidden="true" class="bcl-grain absolute inset-0 opacity-50"></span>
      <div class="relative z-10">
        <p class="bcl-eyebrow mb-3">{{ persona() }}</p>
        <h1
          class="font-display text-3xl font-extrabold tracking-tight text-bcl-ink sm:text-4xl lg:text-5xl"
          style="font-size: var(--bcl-text-3xl);"
        >
          {{ greeting() }}
        </h1>
        <p class="mt-2 max-w-2xl text-sm text-bcl-ink-muted">{{ welcomeBlurb() }}</p>
        <p class="bcl-text-gradient mt-4 max-w-3xl font-display text-lg font-extrabold">
          {{ dailyHero() }}
        </p>
        <!-- GP-07: your received reputation (crew: from customers, customer: from crews).
             Self-gated on the mutual_ratings flag — renders nothing while dark. -->
        <div class="mt-4">
          <bcl-received-rating />
        </div>
      </div>
      <span
        aria-hidden="true"
        class="pointer-events-none absolute -right-12 -top-12 size-48 rounded-full bg-bcl-accent/8 blur-2xl"
      ></span>
      <span
        aria-hidden="true"
        class="pointer-events-none absolute -left-10 -bottom-12 size-40 rounded-full bg-bcl-violet/8 blur-2xl"
      ></span>
    </header>

    <app-onboarding-checklist />
    <!-- SCAN-24: contract-conversion upsell for a repeat one-time booker (self-gated
         on the contract_conversion_upsell flag + eligibility — dark = renders nothing). -->
    <bcl-contract-upsell />
    <!-- SCAN-46: maintenance-reminder enrollment visibility + opt-out (self-gated on
         the maintenance_reminder flag + an enrollable booking — dark = renders nothing).
         The opt-out flips bookings.marketing_sms_opt_in=0, honored by the SCAN-27 Workflow. -->
    <bcl-maintenance-reminder />
    <app-loyalty-card />
    <app-recurring-plans-card />
    <app-carbon-impact-card />
    <app-comm-log-card />
    <app-photo-bookmarks-card />

    <!-- Today KPI bento -->
    <section aria-labelledby="today-kpis" class="mb-8" data-testid="today-kpis">
      <header class="mb-3 flex items-baseline justify-between">
        <h2
          id="today-kpis"
          class="font-display text-lg font-extrabold text-bcl-ink"
        >
          <span class="bcl-eyebrow mr-2">Today</span>
          <span class="font-mono text-xs font-normal text-bcl-ink-muted">{{ now() }}</span>
        </h2>
        @if (loading()) {
          <span class="text-xs text-bcl-ink-muted">Refreshing…</span>
        } @else if (lastRefreshed()) {
          <span class="text-xs text-bcl-ink-muted">Updated {{ lastRefreshedAgo() }}</span>
        }
      </header>
      <bcl-kpi-bento [items]="bentoItems()" [loading]="loading()" />
    </section>

    @if (loadError(); as err) {
      <div
        class="mb-6 flex items-center justify-between gap-3 rounded-xl border border-destructive/40 bg-destructive/5 px-4 py-3"
        role="alert"
      >
        <p class="text-sm text-foreground">Couldn't load your dashboard — {{ err }}</p>
        <button
          type="button"
          (click)="refreshOnce()"
          class="rounded-md border border-border px-3 py-1 text-xs text-muted-foreground hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        >
          Try again
        </button>
      </div>
    }

    <!-- Quick actions + activity feed bento — staggered fade-up entrance -->
    <div
      class="grid gap-4 lg:grid-cols-3"
      [@listStagger]="2"
      [@.disabled]="reducedMotion()"
    >
      <div hlmCard [@fadeUpItem]>
        <div hlmCardHeader>
          <h3 hlmCardTitle>Quick actions</h3>
          <p hlmCardDescription>Jump straight in.</p>
        </div>
        <div hlmCardContent>
          <ul class="space-y-2">
            @for (a of quickActions(); track a.href) {
              <li>
                <a
                  [routerLink]="a.href"
                  class="flex min-h-[44px] items-center justify-between rounded-lg bg-accent/40 px-3 py-2 text-sm text-foreground transition-colors hover:bg-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                >
                  <span>{{ a.label }}</span>
                  <span aria-hidden="true" class="text-primary">→</span>
                </a>
              </li>
            }
          </ul>
        </div>
      </div>

      <div hlmCard class="lg:col-span-2" [@fadeUpItem]>
        <div hlmCardHeader>
          <h3 hlmCardTitle>Recent activity</h3>
          <p hlmCardDescription>Live feed from /api/dashboard/feed.</p>
        </div>
        <div hlmCardContent>
          @if (loading() && events().length === 0) {
            <div class="space-y-2">
              <div hlmSkeleton class="h-4 w-full"></div>
              <div hlmSkeleton class="h-4 w-full"></div>
              <div hlmSkeleton class="h-4 w-full"></div>
            </div>
          } @else if (events().length === 0) {
            <p class="text-sm text-muted-foreground">No activity yet — your events will appear here.</p>
          } @else {
            <ul class="divide-y divide-border">
              @for (e of events(); track e.id) {
                <li class="flex items-start gap-3 py-2.5">
                  <span hlmBadge [variant]="badgeVariant(e.severity)">{{ e.kind }}</span>
                  <div class="min-w-0 flex-1">
                    @if (e.href) {
                      @if (isInternalHref(e.href)) {
                        <a
                          [routerLink]="internalPath(e.href)"
                          [queryParams]="internalQueryParams(e.href)"
                          class="rounded text-sm font-medium text-foreground hover:text-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                        >
                          {{ e.title }}
                        </a>
                      } @else {
                        <a
                          [href]="e.href"
                          target="_blank"
                          rel="noopener noreferrer"
                          class="rounded text-sm font-medium text-foreground hover:text-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                        >
                          {{ e.title }}
                        </a>
                      }
                    } @else {
                      <p class="text-sm font-medium text-foreground">{{ e.title }}</p>
                    }
                    <p class="truncate text-xs text-muted-foreground">{{ e.subtitle }}</p>
                  </div>
                  <span class="whitespace-nowrap text-xs text-muted-foreground">{{ e.ago }}</span>
                </li>
              }
            </ul>
          }
        </div>
      </div>
    </div>

    @if (isCustomerView()) {
      <section
        hlmCard
        class="mt-6"
        aria-labelledby="home-service-catalog-title"
        data-testid="home-service-catalog"
      >
        <div hlmCardHeader>
          <h3 id="home-service-catalog-title" hlmCardTitle>9-service instant presets</h3>
          <p hlmCardDescription>
            Launch a prefilled quote with recommended crew &amp; hours at $60/hr/person.
          </p>
        </div>
        <div hlmCardContent>
          <div class="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            @for (svc of serviceCatalog; track svc.slug) {
              <a
                [routerLink]="['/quotes', 'new']"
                [queryParams]="{ service: svc.slug, crew: svc.crew, hours: svc.hours }"
                [attr.data-testid]="'home-service-' + svc.slug"
                class="flex min-h-[44px] items-center justify-between gap-2 rounded-lg border border-border bg-accent/20 px-3 py-2 text-sm text-foreground transition-colors duration-[333ms] hover:border-primary hover:bg-accent/50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              >
                <span class="truncate font-medium">{{ svc.label }}</span>
                <span class="shrink-0 font-mono text-xs text-primary">
                  {{ svc.crew }}c · {{ svc.hours }}h · {{ '$' + (svc.crew * svc.hours * hourlyRate) }}
                </span>
              </a>
            }
          </div>
        </div>
      </section>
    }
  `,
})
export class HomeComponent implements OnInit, OnDestroy {
  private readonly auth = inject(AuthService);
  private readonly role = inject(RoleService);
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);

  /** Bound to [@.disabled] on animated containers — skips all triggers for reduced-motion users. */
  protected readonly reducedMotion = reducedMotion;

  readonly serviceCatalog = CANONICAL_SERVICES;
  readonly hourlyRate = HOURLY_RATE_USD;
  readonly isCustomerView = computed(() => {
    const r = this.role.viewAs();
    return r !== 'crew' && r !== 'super_admin';
  });

  private feedSub: Subscription | null = null;

  readonly events = signal<readonly FeedEvent[]>([]);
  readonly loading = signal<boolean>(true);
  readonly lastRefreshed = signal<number | null>(null);
  readonly loadError = signal<string | null>(null);

  readonly dailyHero = computed(() => {
    const r = this.role.viewAs();
    const persona: 'customer' | 'crew' | 'super_admin' =
      r === 'crew' ? 'crew' : r === 'super_admin' ? 'super_admin' : 'customer';
    return dailyPhrase(persona);
  });

  readonly persona = computed(() => {
    const r = this.role.viewAs();
    return r === 'crew' ? 'Crew view' : r === 'super_admin' ? 'Admin view' : 'Customer view';
  });

  readonly greeting = computed(() => `Welcome, ${this.auth.displayName()}`);

  readonly welcomeBlurb = computed(() => {
    const r = this.role.viewAs();
    if (r === 'crew') return "Today's gigs, earnings, and availability — all in one place.";
    if (r === 'super_admin') return 'Operational pulse across the platform.';
    return 'Your bookings, quotes, and account at a glance.';
  });

  readonly kpis = computed<readonly KpiTile[]>(() => {
    const r = this.role.viewAs();
    const evs = this.events();
    if (r === 'crew') {
      const todayGigs = evs.filter((e) => e.kind === 'gig').length;
      const earnings = evs
        .filter((e) => e.kind === 'gig')
        .reduce((sum, e) => sum + extractDollars(e.subtitle), 0);
      return [
        { label: "Today's earnings", value: earnings, prefix: '$', hint: 'From completed gigs' },
        { label: "Today's gigs", value: todayGigs, hint: 'Assigned to you' },
        { label: 'Active streak', value: 1, suffix: 'd', hint: 'Days online this week' },
      ];
    }
    if (r === 'super_admin') {
      const activeRides = evs.filter(
        (e) => e.kind === 'booking' && !/canceled|completed/i.test(e.subtitle),
      ).length;
      const recentSubs = evs.filter((e) => e.kind === 'subscription').length;
      return [
        { label: 'Active rides', value: activeRides, hint: 'In-flight bookings' },
        { label: 'Online crew', value: 0, hint: 'Available now' },
        { label: 'Subscriptions today', value: recentSubs, hint: 'Recurring revenue' },
      ];
    }
    const upcoming = evs.filter(
      (e) => e.kind === 'booking' && !/canceled|completed/i.test(e.subtitle),
    ).length;
    const completedCount = evs.filter((e) => /completed/i.test(e.subtitle)).length;
    return [
      { label: 'Upcoming bookings', value: upcoming, hint: 'Confirmed + pending' },
      { label: 'Completed', value: completedCount, hint: 'In your recent activity' },
      { label: 'Saved quotes', value: 0, hint: 'Open quotes' },
    ];
  });

  /**
   * KPI bento items — a presentation-shaped projection over `kpis()`.
   * Adds a synthetic sparkline + baseline trend for visual richness; the
   * underlying numbers are still the live event-derived values so the
   * dashboard stays correct.
   */
  readonly bentoItems = computed<ReadonlyArray<KpiBentoItem>>(() => {
    const list = this.kpis();
    const tones: ReadonlyArray<'accent' | 'success' | 'warn'> = ['accent', 'success', 'warn'];
    // Build a synthetic 7-pt sparkline from the current value, decaying back so
    // the line slopes up toward "today" — purely visual cue, no real time
    // series is wired yet. Replace with a real trend feed when /api/dashboard
    // exposes one.
    function spark(value: number): readonly number[] {
      if (!Number.isFinite(value) || value <= 0) return [1, 1, 2, 1, 2, 3, 3];
      const peak = Math.max(2, Math.round(value));
      return [
        Math.max(1, peak - 5),
        Math.max(1, peak - 3),
        Math.max(1, peak - 4),
        Math.max(1, peak - 2),
        Math.max(1, peak - 2),
        Math.max(1, peak - 1),
        peak,
      ];
    }
    return list.map((k, i) => ({
      key: k.label,
      label: k.label,
      value: k.value,
      prefix: k.prefix,
      suffix: k.suffix,
      decimals: k.decimals,
      hint: k.hint,
      baseline: k.value > 0 ? Math.max(1, Math.round(k.value * 0.85)) : undefined,
      spark: spark(k.value),
      tone: tones[i % tones.length],
      span: i === 0 ? ('wide' as const) : ('normal' as const),
    }));
  });

  /** Pretty "Wed · May 28 · 4:32pm" label for the Today header. */
  readonly now = computed(() => {
    const d = new Date();
    return d.toLocaleString(undefined, {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });
  });

  readonly quickActions = computed<readonly { label: string; href: string }[]>(() => {
    const r = this.role.viewAs();
    if (r === 'crew') {
      return [
        { label: "Today's gigs", href: '/jobs' },
        // Crew payouts are Stripe-Connect earnings (/crew/earnings), NOT the
        // SaaS /billing portal — that was a misroute.
        { label: 'Payouts', href: '/crew/earnings' },
        { label: 'Profile + availability', href: '/settings' },
      ];
    }
    if (r === 'super_admin') {
      return [
        { label: 'Operations dashboard', href: '/admin' },
        { label: 'Crew roster', href: '/crew' },
        { label: 'Sites', href: '/sites' },
        { label: 'Billing', href: '/billing' },
      ];
    }
    return [
      { label: 'Book the crew', href: '/quotes/new' },
      { label: 'My bookings', href: '/bookings' },
      { label: 'My quotes', href: '/quotes' },
      { label: 'Account settings', href: '/settings' },
    ];
  });

  readonly lastRefreshedAgo = computed(() => {
    const t = this.lastRefreshed();
    if (!t) return '';
    const ms = Date.now() - t;
    const s = Math.floor(ms / 1000);
    if (s < 60) return `${s}s ago`;
    const m = Math.floor(s / 60);
    return `${m}m ago`;
  });

  constructor() {
    // Refresh feed whenever persona changes.
    effect(() => {
      this.role.viewAs();
      // Don't fire on first render — ngOnInit handles initial load.
      if (this.feedSub) {
        void this.refreshOnce();
      }
    });
  }

  ngOnInit(): void {
    this.feedSub = timer(0, FEED_POLL_MS)
      .pipe(
        switchMap(() => {
          // Self-gate: the home index (/) renders for guests too. Skip the
          // session-scoped /api/dashboard/feed poll when signed out — no wasted
          // network call every 60s, and a future feed-401 can never surface as a
          // console error on the public landing (defense-in-depth, matches every
          // home card's `authenticated()` guard). Re-evaluated each tick, so the
          // poll resumes the moment whoami hydrates after sign-in.
          if (!this.auth.authenticated()) {
            this.loadError.set(null);
            return of<FeedResponse>({ ok: true, events: [], generatedAt: '' });
          }
          return this.http.get<FeedResponse>('/api/dashboard/feed', { withCredentials: true }).pipe(
            catchError((err: { message?: string }) => {
              this.loadError.set(err?.message ?? 'Network error');
              return of<FeedResponse>({ ok: false, events: [], generatedAt: '' });
            }),
          );
        }),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((resp) => {
        if (resp.ok) this.loadError.set(null);
        this.events.set((resp?.events ?? []).slice(0, 10));
        this.loading.set(false);
        this.lastRefreshed.set(Date.now());
      });
  }

  ngOnDestroy(): void {
    this.feedSub?.unsubscribe();
  }

  async refreshOnce(): Promise<void> {
    // Same self-gate as the poll: a persona-change effect must not fire an authed
    // feed fetch for a signed-out visitor on the public home index.
    if (!this.auth.authenticated()) {
      this.events.set([]);
      this.loadError.set(null);
      this.loading.set(false);
      return;
    }
    this.loading.set(true);
    try {
      const resp = await new Promise<FeedResponse>((resolve) => {
        this.http.get<FeedResponse>('/api/dashboard/feed', { withCredentials: true }).subscribe({
          next: (r) => resolve(r),
          error: () => resolve({ ok: false, events: [], generatedAt: '' }),
        });
      });
      this.events.set((resp?.events ?? []).slice(0, 10));
      this.lastRefreshed.set(Date.now());
    } finally {
      this.loading.set(false);
    }
  }

  isInternalHref(href: string): boolean {
    return href.startsWith('/') && !href.startsWith('//');
  }

  internalPath(href: string): string {
    const qIdx = href.indexOf('?');
    return qIdx >= 0 ? href.slice(0, qIdx) : href;
  }

  internalQueryParams(href: string): Record<string, string> | null {
    const qIdx = href.indexOf('?');
    if (qIdx < 0) return null;
    const params = new URLSearchParams(href.slice(qIdx + 1));
    const out: Record<string, string> = {};
    params.forEach((value, key) => {
      out[key] = value;
    });
    return Object.keys(out).length > 0 ? out : null;
  }

  badgeVariant(sev: FeedEvent['severity']): BadgeVariant {
    switch (sev) {
      case 'success':
        return 'success';
      case 'warn':
        return 'warning';
      case 'error':
        return 'destructive';
      case 'info':
        return 'default';
      default:
        return 'secondary';
    }
  }
}

/** Pull a `$NNN` amount out of an audit-feed subtitle. */
function extractDollars(s: string): number {
  const m = /\$(\d+(?:\.\d+)?)/.exec(s);
  return m ? Math.round(Number(m[1])) : 0;
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'home-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
