import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * CrewTax1099CardComponent — the crew member's own 1099-NEC standing. Live
 * surface = Angular /dashboard, crew audience.
 *
 * Consumes the worker-facing endpoint (session-gated, reads existing tables —
 * no migration):
 *   GET /api/work/payouts/connect/1099 → {
 *     ok, currentYear:{ taxYear, grossCents, transferCount, meetsThreshold },
 *     priorYear:{ taxYear, grossCents, meetsThreshold, form|null }, thresholdCents }
 *
 * Shows prior-year (filing) standing + a current-year progress bar toward the
 * $600 IRS reporting threshold. The actual 1099 PDF is downloaded from the
 * Stripe Express dashboard (Payouts card) — this surface tells the worker WHERE
 * they stand. Full 4-state, bclReveal, rolling YTD counter. Pure helpers tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmSkeleton } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { BclRollingCounterComponent } from '../_shared/rolling-counter.component';

export interface Form1099Status {
  readonly status: string;
  readonly box1Cents: number;
  readonly hasPdf: boolean;
  readonly submittedAt: string | null;
  readonly acceptedAt: string | null;
}

export interface Tax1099Response {
  readonly ok: boolean;
  readonly currentYear: { taxYear: number; grossCents: number; transferCount: number; meetsThreshold: boolean };
  readonly priorYear: { taxYear: number; grossCents: number; meetsThreshold: boolean; form: Form1099Status | null };
  readonly thresholdCents: number;
}

/** Pure: cents → "$N,NNN.NN". Unit-tested. */
export function formatUsd(cents: number): string {
  return `$${((cents || 0) / 100).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

/** Pure: percent (0..100) of the threshold reached. Unit-tested. */
export function thresholdPct(grossCents: number, thresholdCents: number): number {
  if (!thresholdCents || thresholdCents <= 0) return 0;
  return Math.max(0, Math.min(100, Math.round(((grossCents || 0) / thresholdCents) * 100)));
}

/**
 * Pure: the prior-year filing standing label. Unit-tested.
 * Uses the filed form's status when present, else derives from the threshold.
 */
export function taxStandingLabel(priorYear: Tax1099Response['priorYear']): string {
  const f = priorYear.form;
  if (f) {
    switch (f.status) {
      case 'accepted':
        return 'Filed & accepted by the IRS';
      case 'submitted':
      case 'queued':
        return 'Filed — pending IRS acceptance';
      case 'rejected':
      case 'error':
        return 'Filing issue — contact ops';
      default:
        return 'Being prepared';
    }
  }
  return priorYear.meetsThreshold
    ? 'Eligible — your 1099 is being prepared'
    : `Under $600 — no 1099 required for ${priorYear.taxYear}`;
}

@Component({
  selector: 'app-crew-tax-1099-card',
  standalone: true,
  imports: [HlmSkeleton, BclRevealDirective, BclRollingCounterComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section
      bclReveal
      data-testid="crew-tax-1099-card"
      class="rounded-xl border border-bcl-border bg-bcl-bg-elev/40 p-5"
      aria-labelledby="crew-tax-title"
    >
      <header class="mb-3">
        <p class="font-mono text-xs uppercase tracking-wide text-bcl-accent">Taxes</p>
        <h3 id="crew-tax-title" class="text-lg font-semibold text-bcl-ink">Your 1099-NEC</h3>
      </header>

      @if (error(); as e) {
        <div class="flex items-center justify-between gap-3 rounded-lg border border-destructive/40 bg-destructive/5 px-3 py-2" role="alert">
          <p class="text-sm text-bcl-ink">{{ e }}</p>
          <button
            type="button"
            class="rounded-md px-2 py-1 text-xs font-medium text-bcl-accent hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            (click)="refresh()"
          >
            Try again
          </button>
        </div>
      } @else if (loading() && !data()) {
        <div class="space-y-2" aria-label="Loading 1099 standing">
          <div hlmSkeleton class="h-12 w-full"></div>
          <div hlmSkeleton class="h-10 w-full"></div>
        </div>
      } @else if (data(); as d) {
        <!-- Prior tax year (the filing year). -->
        <div class="mb-4 rounded-lg border border-bcl-border bg-bcl-bg/40 p-3">
          <div class="flex flex-wrap items-center gap-2">
            <span class="text-sm font-semibold text-bcl-ink">{{ d.priorYear.taxYear }} tax year</span>
            <span class="bcl-tabular ml-auto text-sm text-bcl-ink">{{ usd(d.priorYear.grossCents) }}</span>
          </div>
          <p class="mt-1 text-xs" [class]="standingTone(d)">{{ standing(d.priorYear) }}</p>
        </div>

        <!-- Current year progress toward the $600 reporting threshold. -->
        <div>
          <div class="mb-1 flex items-center justify-between text-xs text-bcl-ink-muted">
            <span>{{ d.currentYear.taxYear }} so far</span>
            <span class="bcl-tabular text-bcl-ink">
              <bcl-rolling-counter [value]="ytdDollars(d)" prefix="$" /> / {{ usd(d.thresholdCents) }}
            </span>
          </div>
          <div
            class="h-2 w-full overflow-hidden rounded-full bg-bcl-bg"
            role="progressbar"
            [attr.aria-valuenow]="pct(d)"
            aria-valuemin="0"
            aria-valuemax="100"
            [attr.aria-label]="'Earnings toward the $600 1099 threshold: ' + pct(d) + '%'"
          >
            <div
              class="h-full rounded-full transition-[width] duration-700"
              [class]="d.currentYear.meetsThreshold ? 'bg-bcl-success' : 'bg-bcl-accent'"
              [style.width.%]="pct(d)"
            ></div>
          </div>
          <p class="mt-2 text-xs text-bcl-ink-muted">
            Download the official PDF from the Stripe dashboard on your Payouts card.
          </p>
        </div>
      }
    </section>
  `,
})
export class CrewTax1099CardComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly loading = signal(false);
  readonly data = signal<Tax1099Response | null>(null);
  readonly error = signal<string | null>(null);

  ngOnInit(): void {
    void this.refresh();
  }

  usd(cents: number): string {
    return formatUsd(cents);
  }
  ytdDollars(d: Tax1099Response): number {
    return Math.round(d.currentYear.grossCents / 100);
  }
  pct(d: Tax1099Response): number {
    return thresholdPct(d.currentYear.grossCents, d.thresholdCents);
  }
  standing(priorYear: Tax1099Response['priorYear']): string {
    return taxStandingLabel(priorYear);
  }
  standingTone(d: Tax1099Response): string {
    const f = d.priorYear.form;
    if (f?.status === 'accepted') return 'text-bcl-success';
    if (f?.status === 'rejected' || f?.status === 'error') return 'text-destructive';
    return 'text-bcl-ink-muted';
  }

  async refresh(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    try {
      const r = await firstValueFrom(
        this.http.get<Tax1099Response>('/api/work/payouts/connect/1099', { withCredentials: true }),
      );
      this.data.set(r?.ok ? r : null);
    } catch (err) {
      this.error.set(`Couldn't load your 1099 standing: ${(err as Error).message}`);
      this.data.set(null);
    } finally {
      this.loading.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'tax-1099-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
