import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * hlm-button — Spartan helm button. Vendored (copy-in-source, we own it) per
 * the Phase-0 decision to use @spartan-ng/brain directly + vendor helm, avoiding
 * the @spartan-ng/cli ↔ Nx-22 peer risk. Composes BrnButton (a11y/disabled
 * behaviour) + cva variants themed by the HLM CSS vars in styles.css.
 *
 * Usage: <button hlmBtn variant="default|secondary|destructive|outline|ghost|link"
 *                 size="default|sm|lg|icon">…</button>
 */
import { Directive, computed, input } from '@angular/core';
import { BrnButton } from '@spartan-ng/brain/button';
import { cva, type VariantProps } from 'class-variance-authority';
import { HLM_BUTTON_CVA_BASE, HLM_BUTTON_CVA_VARIANTS } from '@theme-tools/ui/spartan-helm-variants';
import { cn } from '../utils/cn';

export const buttonVariants = cva(HLM_BUTTON_CVA_BASE, {
  variants: HLM_BUTTON_CVA_VARIANTS,
  defaultVariants: { variant: 'default', size: 'default' },
});

export type ButtonVariant = VariantProps<typeof buttonVariants>['variant'];
export type ButtonSize = VariantProps<typeof buttonVariants>['size'];

@Directive({
  selector: 'button[hlmBtn], a[hlmBtn]',
  standalone: true,
  hostDirectives: [{ directive: BrnButton, inputs: ['disabled'] }],
  host: { '[class]': '_computedClass()' },
})
export class HlmButton {
  readonly variant = input<ButtonVariant>('default');
  readonly size = input<ButtonSize>('default');
  /** Pass-through consumer classes (merged last, so they win). */
  readonly userClass = input<string>('', { alias: 'class' });

  protected readonly _computedClass = computed(() =>
    cn(buttonVariants({ variant: this.variant(), size: this.size() }), this.userClass()),
  );
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'hlm-button',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
