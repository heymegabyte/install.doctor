import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * RideChatComponent — in-app chat between customer + crew + admin observer.
 *
 * Connects to `wss://<host>/api/ride/chat?rideId=<id>`. Renders the last
 * 50 messages (backlog frame replays them on connect). New `msg` frames
 * append in real time. Send box submits on Enter; Shift+Enter inserts a
 * newline. Photo upload posts to `/api/ride/arrival-photo` then echoes a
 * synthetic chat line.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  ElementRef,
  effect,
  inject,
  input,
  signal,
  viewChild,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { WsService } from '../../core/ws.service';

interface ChatMessage {
  readonly id: string;
  readonly senderType: 'customer' | 'crew' | 'admin';
  readonly senderId: string;
  readonly body: string;
  readonly sentAt: number;
}

interface BacklogFrame {
  type: 'backlog';
  messages: ReadonlyArray<{
    id: string;
    sender_type: ChatMessage['senderType'];
    sender_id: string;
    body: string;
    sent_at: number;
  }>;
}
interface MsgFrame extends ChatMessage {
  type: 'msg';
}
type AnyFrame = BacklogFrame | MsgFrame;

@Component({
  selector: 'bcl-ride-chat',
  standalone: true,
  imports: [FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section
      class="flex h-full flex-col rounded-xl bg-bcl-bg-elev ring-1 ring-bcl-border"
      aria-label="Ride chat"
    >
      <header class="border-b border-bcl-border px-4 py-3">
        <h3 class="text-sm font-semibold text-bcl-ink">Trip chat</h3>
        <p class="text-xs text-bcl-ink-muted">
          {{ connected() ? 'Live' : 'Reconnecting…' }} ·
          {{ messages().length }} message(s)
        </p>
      </header>

      <ol
        #scroll
        role="log"
        aria-live="polite"
        aria-label="Chat messages"
        class="flex-1 space-y-2 overflow-y-auto px-4 py-3"
      >
        @for (m of messages(); track m.id) {
          <li
            class="flex flex-col"
            [class.items-end]="m.senderType === me()"
            [class.items-start]="m.senderType !== me()"
          >
            <div
              class="max-w-[80%] rounded-2xl px-3 py-2 text-sm"
              [class.bg-bcl-accent]="m.senderType === me()"
              [class.text-bcl-bg]="m.senderType === me()"
              [class.bg-white\/5]="m.senderType !== me()"
              [class.text-bcl-ink]="m.senderType !== me()"
            >{{ m.body }}</div>
            <span class="mt-0.5 text-[10px] uppercase tracking-wider text-bcl-ink-muted">
              {{ m.senderType }} · {{ formatTime(m.sentAt) }}
            </span>
          </li>
        }
      </ol>

      <form
        class="flex items-end gap-2 border-t border-bcl-border px-3 py-3"
        (submit)="onSubmit($event)"
      >
        <label class="sr-only" for="bcl-chat-input">Type a message</label>
        <textarea
          id="bcl-chat-input"
          data-testid="chat-input"
          name="message"
          rows="1"
          aria-label="Type a message"
          [(ngModel)]="draft"
          (keydown.enter)="onEnterKey($event)"
          class="min-h-[44px] flex-1 resize-none rounded-lg bg-bcl-bg px-3 py-2 text-sm text-bcl-ink ring-1 ring-bcl-border focus:outline-none focus:ring-bcl-accent"
          placeholder="Message your crew…"
        ></textarea>
        <label
          class="inline-flex min-h-[44px] min-w-[44px] cursor-pointer items-center justify-center rounded-lg bg-bcl-bg-elev ring-1 ring-bcl-border hover:bg-white/5"
          aria-label="Attach arrival photo"
        >
          <input
            #photo
            type="file"
            accept="image/*"
            capture="environment"
            class="sr-only"
            (change)="onPhoto($event)"
          />
          <span aria-hidden="true">📷</span>
        </label>
        <button
          type="submit"
          [disabled]="!draft.trim()"
          class="min-h-[44px] rounded-lg bg-bcl-accent px-4 text-sm font-semibold text-bcl-bg disabled:opacity-50"
        >Send</button>
      </form>
    </section>
  `,
})
export class RideChatComponent {
  private readonly ws = inject(WsService);
  private readonly destroyRef = inject(DestroyRef);

  readonly rideId = input.required<string>();
  readonly me = input<'customer' | 'crew' | 'admin'>('customer');
  readonly senderId = input<string>('anon');

  readonly messages = signal<ChatMessage[]>([]);
  readonly connected = signal<boolean>(false);
  readonly scroll = viewChild<ElementRef<HTMLOListElement>>('scroll');
  draft = '';

  private handle: ReturnType<WsService['connect']> | null = null;

  constructor() {
    // Track connection state in a top-level effect so we don't nest effects.
    effect(() => this.connected.set(this.handle?.isOpen() ?? false));

    effect((onCleanup) => {
      const id = this.rideId();
      if (!id) return;
      const proto = globalThis.location?.protocol === 'https:' ? 'wss' : 'ws';
      const host = globalThis.location?.host ?? '';
      const url = `${proto}://${host}/api/ride/chat?rideId=${encodeURIComponent(id)}`;
      this.handle = this.ws.connect(url);
      this.handle.stream$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((ev) => {
        let frame: AnyFrame | null = null;
        try {
          frame = JSON.parse(ev.data) as AnyFrame;
        } catch {
          return;
        }
        if (frame.type === 'backlog') {
          const norm = frame.messages.slice(-50).map((m) => ({
            id: m.id,
            senderType: m.sender_type,
            senderId: m.sender_id,
            body: m.body,
            sentAt: m.sent_at,
          }));
          this.messages.set(norm);
        } else if (frame.type === 'msg') {
          this.messages.update((arr) => {
            if (arr.some((m) => m.id === frame!.id)) return arr;
            return [...arr, frame as ChatMessage].slice(-50);
          });
        }
        queueMicrotask(() => this.scrollToBottom());
      });
      onCleanup(() => this.handle?.close());
    });
  }

  onEnterKey(ev: Event): void {
    const ke = ev as KeyboardEvent;
    if (ke.shiftKey) return;
    ev.preventDefault();
    this.send();
  }

  onSubmit(ev: Event): void {
    ev.preventDefault();
    this.send();
  }

  send(): void {
    const body = this.draft.trim();
    if (!body) return;
    const msg: ChatMessage & { type: 'msg' } = {
      type: 'msg',
      id: cryptoRandomId(),
      senderType: this.me(),
      senderId: this.senderId(),
      body,
      sentAt: Date.now(),
    };
    // Optimistic local append so the test (and the user) sees it immediately.
    this.messages.update((arr) => [...arr, msg]);
    this.handle?.send(msg);
    this.draft = '';
    queueMicrotask(() => this.scrollToBottom());
  }

  async onPhoto(ev: Event): Promise<void> {
    const input = ev.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append('rideId', this.rideId());
    form.append('photo', file, file.name);
    try {
      await fetch('/api/ride/arrival-photo', {
        method: 'POST',
        body: form,
        credentials: 'include',
      });
      this.draft = '📷 Arrival photo uploaded';
      this.send();
    } catch {
      // best-effort; chat shows the failure via offline indicator
    }
    input.value = '';
  }

  formatTime(ts: number): string {
    const d = new Date(ts);
    return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  private scrollToBottom(): void {
    const el = this.scroll()?.nativeElement;
    if (el) el.scrollTop = el.scrollHeight;
  }
}

function pad(n: number): string {
  return n < 10 ? `0${n}` : `${n}`;
}

function cryptoRandomId(): string {
  try {
    if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
      return crypto.randomUUID();
    }
  } catch {
    /* noop */
  }
  return `m_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'ride-chat-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
