import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * RateReviewComponent — 5-star rating + tag chips + freeform comment.
 *
 * Posts to /api/ratings/submit. Tags are pre-curated short adjectives the
 * customer can multi-select; comment is optional but encouraged for low stars.
 */
import { ChangeDetectionStrategy, Component, computed, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { focusRadioAtIndex, nextRadioIndex, rovingTabIndex } from '@theme.tools/i18n-a11y/field-service/radio-keynav';

const TAGS = [
  'On time',
  'Friendly',
  'Careful with items',
  'Communicated well',
  'Professional',
  'Above & beyond',
  'Late',
  'Needs improvement',
] as const;

@Component({
  selector: 'bcl-rate-review',
  standalone: true,
  imports: [FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section
      class="rounded-xl bg-bcl-bg-elev p-5 ring-1 ring-bcl-border"
      aria-label="Rate this trip"
    >
      <h3 class="text-base font-semibold text-bcl-ink">Rate your crew</h3>
      <p class="mt-1 text-sm text-bcl-ink-muted">
        Help us match you with the right folks next time.
      </p>

      <div
        class="mt-4 flex items-center gap-2"
        role="radiogroup"
        aria-label="Stars"
        (keydown)="onStarKey($event)"
      >
        @for (n of stars; track n; let i = $index) {
          <button
            type="button"
            role="radio"
            [attr.aria-checked]="rating() === n"
            [attr.aria-label]="n + ' stars'"
            [attr.tabindex]="rove(i)"
            (click)="rating.set(n)"
            class="min-h-[44px] min-w-[44px] rounded-lg text-2xl transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            [class.text-bcl-accent]="rating() >= n"
            [class.text-bcl-ink-muted]="rating() < n"
          >
            ★
          </button>
        }
      </div>

      <fieldset class="mt-4">
        <legend class="text-xs uppercase tracking-wider text-bcl-ink-muted">Tags</legend>
        <div class="mt-2 flex flex-wrap gap-2">
          @for (t of tags; track t) {
            <label
              class="cursor-pointer rounded-full px-3 py-1 text-xs ring-1 transition-colors"
              [class.bg-bcl-accent]="tagSet().has(t)"
              [class.text-bcl-bg]="tagSet().has(t)"
              [class.ring-bcl-accent]="tagSet().has(t)"
              [class.bg-bcl-bg]="!tagSet().has(t)"
              [class.text-bcl-ink-muted]="!tagSet().has(t)"
              [class.ring-bcl-border]="!tagSet().has(t)"
            >
              <input
                type="checkbox"
                class="sr-only"
                [checked]="tagSet().has(t)"
                (change)="toggleTag(t)"
              />
              {{ t }}
            </label>
          }
        </div>
      </fieldset>

      <label class="mt-4 block">
        <span class="text-xs uppercase tracking-wider text-bcl-ink-muted">Comment</span>
        <textarea
          [(ngModel)]="comment"
          rows="3"
          maxlength="500"
          class="mt-1 w-full rounded-lg bg-bcl-bg px-3 py-2 text-sm text-bcl-ink ring-1 ring-bcl-border focus:outline-none focus:ring-bcl-accent"
          placeholder="Anything you want the crew to know?"
        ></textarea>
      </label>

      <button
        type="button"
        (click)="submit()"
        [disabled]="pending() || rating() === 0"
        class="mt-4 min-h-[44px] w-full rounded-lg bg-bcl-accent px-4 text-sm font-semibold text-bcl-bg disabled:opacity-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
      >
        Submit
      </button>

      @if (errorMsg(); as err) {
        <p class="mt-3 text-sm text-destructive" role="alert" data-testid="rate-review-error">
          {{ err }}
        </p>
      }
    </section>
  `,
})
export class RateReviewComponent {
  readonly rideId = input.required<string>();
  readonly submitted = output<{
    rideId: string;
    rating: number;
    tags: string[];
    comment: string;
  }>();

  readonly stars = [1, 2, 3, 4, 5] as const;
  readonly tags = TAGS;

  readonly rating = signal<0 | 1 | 2 | 3 | 4 | 5>(0);
  readonly selectedTags = signal<readonly string[]>([]);
  readonly pending = signal<boolean>(false);
  readonly errorMsg = signal<string | null>(null);
  comment = '';

  readonly tagSet = computed(() => new Set(this.selectedTags()));

  /** Index of the tab stop: the selected star, or the first star when unrated. */
  private readonly activeStarIndex = computed(() => {
    const r = this.rating();
    return r === 0 ? 0 : r - 1;
  });

  /** Roving tabindex for the star at `i`: 0 for the active star, else -1. */
  rove(i: number): 0 | -1 {
    return rovingTabIndex(i, this.activeStarIndex());
  }

  /** ARIA radio-group arrow/Home/End navigation across the 5 stars. */
  onStarKey(event: KeyboardEvent): void {
    const next = nextRadioIndex(this.activeStarIndex(), this.stars.length, event.key);
    if (next === null) return;
    event.preventDefault();
    const star = this.stars[next];
    if (star === undefined) return;
    this.rating.set(star);
    focusRadioAtIndex(event.currentTarget as HTMLElement, next);
  }

  toggleTag(t: string): void {
    const set = new Set(this.selectedTags());
    if (set.has(t)) set.delete(t);
    else set.add(t);
    this.selectedTags.set([...set]);
  }

  async submit(): Promise<void> {
    if (this.pending() || this.rating() === 0) return;
    this.pending.set(true);
    const payload = {
      rideId: this.rideId(),
      rating: this.rating(),
      tags: [...this.selectedTags()],
      comment: this.comment.trim(),
    };
    try {
      const res = await fetch('/api/ratings/submit', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      // fetch does NOT throw on HTTP errors — gate on res.ok so a 4xx/5xx is
      // never reported to the parent as a successful rating (the false-success
      // bug: the panel would close as "rated" when the server actually rejected).
      // Mirror the proven app-rate-customer error contract.
      if (res.ok) {
        this.submitted.emit(payload);
        return;
      }
      if (res.status === 401) {
        this.errorMsg.set('Please sign in again to rate your crew.');
        return;
      }
      this.errorMsg.set('Couldn’t submit your rating — please try again.');
    } catch {
      this.errorMsg.set('Network hiccup — please try again.');
    } finally {
      this.pending.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'rate-review-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
