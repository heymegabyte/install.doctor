import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CrewAssignmentsService — loads assigned-crew identity (worker ids per booking)
 * for a date range from GET /api/admin/crew-assignments?from=&to=, so the
 * calendar can detect PER-CREW conflicts (the same worker double-booked) and
 * (next) draw crew swimlanes.
 *
 * The endpoint is flag-gated (calendar_crew_resource_view), so a 404/error
 * degrades to an empty map — conflict detection then falls back to its
 * time-overlap warning. Shared (providedIn root). `load(from, to)` is called per
 * visible range (sync-on-open) and de-dupes identical re-queries. Exposes a
 * `byBooking` signal: Map<bookingId, workerIds[]>.
 */
import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, of } from 'rxjs';

interface CrewAssignment {
  readonly bookingId: string;
  readonly workerIds: readonly string[];
}

export interface CrewMember {
  readonly id: string;
  readonly name: string;
}

@Injectable({ providedIn: 'root' })
export class CrewAssignmentsService {
  private readonly http = inject(HttpClient);
  /** booking id → assigned worker ids for the last-loaded range (empty when off). */
  readonly byBooking = signal<ReadonlyMap<string, readonly string[]>>(new Map());
  /** Active-crew roster — the lanes/filter chips (empty when off). */
  readonly roster = signal<readonly CrewMember[]>([]);
  private lastKey = '';

  load(from: string, to: string): void {
    const key = `${from}|${to}`;
    if (key === this.lastKey) return; // de-dupe identical range re-queries
    this.lastKey = key;
    type CrewResponse = {
      ok: boolean;
      assignments?: readonly CrewAssignment[];
      crew?: readonly CrewMember[];
    };
    this.http
      .get<CrewResponse>(`/api/admin/crew-assignments?from=${from}&to=${to}`, {
        withCredentials: true,
      })
      .pipe(catchError(() => of({ ok: false } as CrewResponse)))
      .subscribe((r) => {
        const map = new Map<string, readonly string[]>();
        if (r.ok) for (const a of r.assignments ?? []) map.set(a.bookingId, a.workerIds);
        this.byBooking.set(map);
        this.roster.set(r.ok ? (r.crew ?? []) : []);
      });
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'crew-assignments-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
