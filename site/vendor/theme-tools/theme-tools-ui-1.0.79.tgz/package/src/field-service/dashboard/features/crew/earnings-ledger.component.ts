import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * CrewEarningsLedgerComponent — the crew member's per-gig pay-transparency
 * ledger. Live surface = Angular /dashboard, crew audience. Resurrected per
 * roadmap decision #1 (migration 0144); gated by `crew_earnings_dashboard`.
 *
 * Reads the flag-gated worker endpoint (session-gated, reads gig_claims — no
 * new table): GET /api/earnings/ledger?year=YYYY → { ok, year, entries[], summary }.
 * Each entry itemizes base wage + tip + total for one COMPLETED gig. The annual
 * summary mirrors the sum of the rows. A CSV export (1099-NEC-friendly) downloads
 * from /api/earnings/ledger-export. Surge is intentionally NOT shown — it is a
 * customer-side pricing factor that does not flow to flat-wage crew.
 *
 * Full 4-state (error / loading / empty / data), bclReveal entrance, rolling
 * total counter, year switcher. Pure helpers shared with the worker via shape.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { HlmSkeleton } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { BclRollingCounterComponent } from '../_shared/rolling-counter.component';
import { CrewEarningsService, type LedgerResult } from '../../core/crew-earnings.service';

/** Pure: cents → "$N,NNN.NN". */
export function ledgerUsd(cents: number): string {
  return `$${((cents || 0) / 100).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

/** Pure: a short, human gig reference from the opaque gig id. */
export function shortGigRef(gigId: string): string {
  return gigId ? `#${gigId.slice(-6).toUpperCase()}` : '#------';
}

/** Pure: the selectable tax years — current year back through `count-1` prior. */
export function ledgerYears(currentYear: number, count = 4): number[] {
  return Array.from({ length: count }, (_, i) => currentYear - i);
}

@Component({
  selector: 'app-crew-earnings-ledger',
  standalone: true,
  imports: [HlmSkeleton, BclRevealDirective, BclRollingCounterComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section bclReveal data-testid="crew-earnings-ledger" class="space-y-5" aria-labelledby="crew-ledger-title">
      <header class="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p class="font-mono text-xs uppercase tracking-wide text-bcl-accent">Earnings</p>
          <h1 id="crew-ledger-title" class="text-2xl font-bold text-bcl-ink">Your pay ledger</h1>
          <p class="text-sm text-bcl-ink-muted">Every completed job, itemized — base + tips. Built for your 1099.</p>
        </div>
        <!-- Year switcher — each year is a styled pill, never a bare select. -->
        <div class="flex flex-wrap gap-1.5" role="group" aria-label="Tax year">
          @for (y of years; track y) {
            <button
              type="button"
              [attr.aria-pressed]="y === year()"
              (click)="selectYear(y)"
              class="rounded-full border px-3 py-1 text-sm font-medium transition-all duration-[0.333s] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
              [class]="
                y === year()
                  ? 'border-bcl-accent bg-bcl-accent/15 text-bcl-ink'
                  : 'border-bcl-border bg-bcl-bg-elev/40 text-bcl-ink-muted hover:-translate-y-0.5 hover:text-bcl-ink'
              "
            >
              {{ y }}
            </button>
          }
        </div>
      </header>

      @if (error(); as e) {
        <div class="flex items-center justify-between gap-3 rounded-lg border border-destructive/40 bg-destructive/5 px-3 py-2" role="alert">
          <p class="text-sm text-bcl-ink">{{ e }}</p>
          <button
            type="button"
            class="rounded-md px-2 py-1 text-xs font-medium text-bcl-accent transition-all duration-[0.333s] hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            (click)="refresh()"
          >
            Try again
          </button>
        </div>
      } @else if (loading() && !data()) {
        <div class="space-y-2" aria-label="Loading your earnings">
          <div hlmSkeleton class="h-20 w-full"></div>
          <div hlmSkeleton class="h-12 w-full"></div>
          <div hlmSkeleton class="h-12 w-full"></div>
        </div>
      } @else if (data(); as d) {
        <!-- Annual summary -->
        <div class="grid gap-3 sm:grid-cols-3">
          <div class="rounded-xl border border-bcl-border bg-bcl-bg-elev/40 p-4">
            <p class="text-xs uppercase tracking-wide text-bcl-ink-muted">{{ d.year }} total</p>
            <p class="bcl-tabular mt-1 text-2xl font-bold text-bcl-ink">
              <bcl-rolling-counter [value]="dollars(d.summary!.totalCents)" prefix="$" />
            </p>
          </div>
          <div class="rounded-xl border border-bcl-border bg-bcl-bg-elev/40 p-4">
            <p class="text-xs uppercase tracking-wide text-bcl-ink-muted">Base wages</p>
            <p class="bcl-tabular mt-1 text-2xl font-semibold text-bcl-ink">{{ usd(d.summary!.grossCents) }}</p>
          </div>
          <div class="rounded-xl border border-bcl-border bg-bcl-bg-elev/40 p-4">
            <p class="text-xs uppercase tracking-wide text-bcl-ink-muted">Tips</p>
            <p class="bcl-tabular mt-1 text-2xl font-semibold text-bcl-success">{{ usd(d.summary!.tipsCents) }}</p>
          </div>
        </div>

        <div class="flex items-center justify-between gap-3">
          <p class="text-sm text-bcl-ink-muted">
            {{ d.summary!.gigsCount }} completed {{ d.summary!.gigsCount === 1 ? 'job' : 'jobs' }}
          </p>
          @if (d.summary!.gigsCount > 0) {
            <a
              [href]="exportHref()"
              data-testid="crew-ledger-export"
              class="inline-flex items-center gap-1.5 rounded-lg border border-bcl-border bg-bcl-bg-elev/40 px-3 py-1.5 text-sm font-medium text-bcl-ink transition-all duration-[0.333s] hover:-translate-y-0.5 hover:border-bcl-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            >
              Export CSV
            </a>
          }
        </div>

        @if (d.summary!.gigsCount === 0) {
          <!-- Empty state — actionable, not a dead end. -->
          <div class="rounded-xl border border-dashed border-bcl-border bg-bcl-bg/40 p-8 text-center">
            <p class="text-sm font-medium text-bcl-ink">No completed jobs in {{ d.year }} yet</p>
            <p class="mt-1 text-sm text-bcl-ink-muted">
              Go online and claim a gig — your pay lands here the moment you check out.
            </p>
          </div>
        } @else {
          <!-- Per-gig ledger -->
          <ul class="space-y-2" aria-label="Per-job earnings">
            @for (e of d.entries; track e.gigId) {
              <li
                class="flex flex-wrap items-center gap-x-4 gap-y-1 rounded-lg border border-bcl-border bg-bcl-bg-elev/40 px-4 py-3 transition-all duration-[0.333s] hover:-translate-y-0.5 hover:border-bcl-accent/60"
              >
                <span class="bcl-tabular text-sm font-medium text-bcl-ink">{{ e.date || '—' }}</span>
                <span class="rounded-full border border-bcl-border px-2 py-0.5 font-mono text-xs text-bcl-ink-muted">
                  {{ ref(e.gigId) }}
                </span>
                <span class="ml-auto bcl-tabular text-sm text-bcl-ink-muted">base {{ usd(e.baseCents) }}</span>
                @if (e.tipCents > 0) {
                  <span class="bcl-tabular text-sm text-bcl-success">tip {{ usd(e.tipCents) }}</span>
                }
                <span class="bcl-tabular w-20 text-right text-sm font-semibold text-bcl-ink">{{ usd(e.totalCents) }}</span>
              </li>
            }
          </ul>
        }
      }
    </section>
  `,
})
export class CrewEarningsLedgerComponent implements OnInit {
  private readonly svc = inject(CrewEarningsService);

  readonly year = signal(new Date().getUTCFullYear());
  readonly years = ledgerYears(new Date().getUTCFullYear());
  readonly loading = signal(false);
  readonly data = signal<LedgerResult | null>(null);
  readonly error = signal<string | null>(null);

  ngOnInit(): void {
    void this.refresh();
  }

  usd(cents: number): string {
    return ledgerUsd(cents);
  }
  dollars(cents: number): number {
    return Math.round((cents || 0) / 100);
  }
  ref(gigId: string): string {
    return shortGigRef(gigId);
  }
  exportHref(): string {
    return `/api/earnings/ledger-export?year=${this.year()}`;
  }

  selectYear(y: number): void {
    if (y === this.year()) return;
    this.year.set(y);
    void this.refresh();
  }

  async refresh(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    try {
      const r = await firstValueFrom(this.svc.ledger$(this.year()));
      if (r?.ok) {
        this.data.set(r);
      } else {
        this.data.set(null);
        this.error.set(
          r?.error === 'unavailable'
            ? 'The earnings ledger is not available yet.'
            : "Couldn't load your earnings. Pull to retry.",
        );
      }
    } catch (err) {
      this.data.set(null);
      this.error.set(`Couldn't load your earnings: ${(err as Error).message}`);
    } finally {
      this.loading.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'earnings-ledger-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
