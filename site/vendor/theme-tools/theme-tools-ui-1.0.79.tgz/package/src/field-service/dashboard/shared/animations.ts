import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * Shared Angular animation triggers for the Brick Labor dashboard.
 *
 * Convention: the dashboard uses the Web Animations API via `BclRevealDirective`
 * ([bclReveal]) for individual element entrance (opacity 0→1, translateY 8px→0,
 * 480ms, cubic-bezier(0.16,1,0.3,1)). This file extends that system with three
 * Angular `@angular/animations` triggers for card grids, list rows, and route
 * transitions:
 *
 * - `fadeUpItem`   — single element fade-up; pair with `*ngFor` items or host elements
 * - `listStagger`  — container-level stagger that animates children at 60ms intervals
 * - `routeFade`    — subtle opacity transition for route content panels
 *
 * ## Reduced-motion
 * `reducedMotion()` reads `window.matchMedia('(prefers-reduced-motion: reduce)')`.
 * Bind it to `[@.disabled]="reducedMotion()"` on animated host elements so Angular
 * skips all triggers when the user prefers reduced motion. Content is always
 * visible immediately (no opacity:0 starting state that relies on JS to flip).
 *
 * ## Usage
 * ```ts
 * import { fadeUpItem, listStagger, routeFade, reducedMotion } from '../../shared/animations';
 *
 * @Component({
 *   animations: [fadeUpItem, listStagger, routeFade],
 *   template: `<div [@listStagger]="items().length" [@.disabled]="reducedMotion()">
 *     @for (item of items(); track item.id) {
 *       <div [@fadeUpItem]>{{ item.name }}</div>
 *     }
 *   </div>`,
 * })
 * ```
 */
import {
  trigger,
  transition,
  animate,
  style,
  query,
  stagger,
  animateChild,
} from '@angular/animations';

/** Easing matches `BclRevealDirective`'s cubic-bezier(0.16,1,0.3,1). */
const BCL_EASE = 'cubic-bezier(0.16, 1, 0.3, 1)';

/**
 * Single-element fade-up trigger.
 * Place on the animated element itself (e.g. each card in an `@for` loop).
 * GPU-only: opacity + translateY — no layout changes, no CLS.
 *
 * @example
 * `<div [@fadeUpItem]>…</div>` inside a container with `[@listStagger]`
 */
export const fadeUpItem = trigger('fadeUpItem', [
  transition(':enter', [
    style({ opacity: 0, transform: 'translateY(16px)' }),
    animate(`300ms ${BCL_EASE}`, style({ opacity: 1, transform: 'translateY(0)' })),
  ]),
  transition(':leave', [
    animate(`150ms ease-in`, style({ opacity: 0, transform: 'translateY(8px)' })),
  ]),
]);

/**
 * Container-level stagger trigger.
 * Place on the parent element; add `[@fadeUpItem]` on each child.
 * Bind `[@listStagger]` to a changing value (e.g. `items().length`) so Angular
 * re-runs the stagger when data arrives.
 *
 * Stagger interval: 60ms — matches the 70ms `revealStep` default from
 * `BclRevealDirective`, rounded to a clean value for `@angular/animations`.
 *
 * @example
 * `<ul [@listStagger]="items().length"><li [@fadeUpItem] *ngFor="…">…</li></ul>`
 */
export const listStagger = trigger('listStagger', [
  transition('* => *', [
    query(':enter', [stagger(60, [animateChild()])], { optional: true }),
  ]),
]);

/**
 * Route content fade trigger — subtle 200ms opacity transition.
 * Apply to the top-level content container of route components for a smooth
 * enter when the route loads. No vertical movement (keeps CLS = 0).
 *
 * @example
 * `<div [@routeFade]>…route content…</div>`
 */
export const routeFade = trigger('routeFade', [
  transition(':enter', [
    style({ opacity: 0 }),
    animate('200ms ease-out', style({ opacity: 1 })),
  ]),
]);

/**
 * Returns `true` when the user has requested reduced motion.
 * SSR/test-safe: returns `false` when `matchMedia` is unavailable.
 *
 * Use as `[@.disabled]="reducedMotion()"` on Angular-animated host elements
 * to disable all `@angular/animations` triggers for reduced-motion users.
 * The CSS layer (`@layer fx`) in `styles.css` independently zeroes all
 * `@keyframes` animations via `@media (prefers-reduced-motion: reduce)`.
 *
 * @example
 * ```ts
 * protected readonly reducedMotion = reducedMotion;
 * ```
 * ```html
 * <div [@listStagger]="items.length" [@.disabled]="reducedMotion()">
 * ```
 */
export function reducedMotion(): boolean {
  if (typeof globalThis === 'undefined' || typeof globalThis.matchMedia !== 'function') {
    return false;
  }
  return globalThis.matchMedia('(prefers-reduced-motion: reduce)').matches;
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'animations',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
