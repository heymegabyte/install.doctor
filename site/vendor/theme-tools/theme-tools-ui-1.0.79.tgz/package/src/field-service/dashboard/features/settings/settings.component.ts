import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SettingsComponent — sidebar + outlet shell.
 *
 * The left rail is the only navigation; each link routes to a child
 * component. On small screens it collapses to a horizontal scroll bar.
 */
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { HlmButton } from '../../shared/ui-spartan';
import { AuthService } from '../../core/auth.service';
import { routeFade, reducedMotion } from '../../shared/animations';

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, HlmButton],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header class="mb-4">
      <h1 class="text-2xl font-bold text-foreground">Settings</h1>
      <p class="text-sm text-muted-foreground">
        Profile, workspace, security, notifications, integrations, API.
      </p>
    </header>

    @if (needsAuth()) {
      <!--
        /dashboard/settings has no role guard, so this shell renders for guests.
        Mounting the outlet instantiates every child (profile, workspace,
        security, notifications, api-webhooks, address-book, data-rights), each
        of which fires an authed /api/* fetch on init that the worker 401s → a
        red console error / 4xx on a guest. Gate the whole shell at the parent —
        one sign-in affordance, zero authed requests — which closes the entire
        settings guest-leak class at once instead of patching each child. (Same
        precedent as billing.component.ts.)
      -->
      <div
        class="rounded-xl border border-dashed border-border p-10 text-center"
        data-testid="settings-signin"
      >
        <p class="text-2xl" aria-hidden="true">⚙️</p>
        <p class="mt-2 text-base font-semibold text-foreground">Sign in to manage your settings</p>
        <p class="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
          Log in to update your profile, security, notifications, integrations, and data rights.
        </p>
        <a hlmBtn class="mt-4" [routerLink]="['/login']" [queryParams]="{ as: 'customer', next: '/settings' }">
          Sign in →
        </a>
      </div>
    } @else {
      <div class="grid gap-6 md:grid-cols-[200px_minmax(0,1fr)]">
        <nav
          class="flex flex-col gap-1 overflow-x-auto md:flex-col md:overflow-visible"
          aria-label="Settings sections"
        >
          @for (s of sections; track s.path) {
            <a
              [routerLink]="['.', s.path]"
              routerLinkActive="bg-accent text-accent-foreground ring-1 ring-border"
              class="whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            >
              {{ s.label }}
            </a>
          }
        </nav>
        <main>
          <router-outlet />
        </main>
      </div>
    }
  `,
})
export class SettingsComponent {
  protected readonly reducedMotion = reducedMotion;
  private readonly auth = inject(AuthService);
  protected readonly needsAuth = computed(() => !this.auth.authenticated());

  readonly sections = [
    { path: 'profile', label: 'Profile' },
    { path: 'security', label: 'Security' },
    { path: 'notifications', label: 'Notifications' },
    { path: 'appearance', label: 'Appearance' },
    { path: 'api-webhooks', label: 'API & webhooks' },
    { path: 'integrations', label: 'Integrations' },
    { path: 'data-rights', label: 'Data rights' },
    { path: 'address-book', label: 'Addresses' },
    { path: 'danger-zone', label: 'Danger zone' },
  ] as const;
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'settings-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
