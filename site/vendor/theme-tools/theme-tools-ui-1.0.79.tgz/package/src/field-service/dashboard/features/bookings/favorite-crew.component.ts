import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * FavoriteCrewComponent — tap-to-favorite the crew on a booking. Angular port of
 * the React `customer/FavoriteCrewPicker`. Live surface = Angular /dashboard.
 *
 * Reads GET /api/loyalty/favorites (the customer's favorited crew ids), renders a
 * heart per crew member, toggles via POST/DELETE /api/loyalty/favorites
 * { crewUserId } (idempotent server-side). Optimistic; reverts on failure.
 * Self-gates: hides when the booking has no crew roster yet.
 */
import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  input,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmCardImports } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export interface CrewMemberLite {
  readonly workerId: string;
  readonly firstName: string;
  readonly lastInitial: string;
}

interface FavoritesResponse {
  readonly favorites?: readonly string[];
}

/** Pure: display name for a crew member. */
export function crewName(m: CrewMemberLite): string {
  return `${m.firstName} ${m.lastInitial}.`.trim();
}

@Component({
  selector: 'app-favorite-crew',
  standalone: true,
  imports: [...HlmCardImports, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <div hlmCard bclReveal class="mt-4" data-testid="favorite-crew">
        <div hlmCardHeader>
          <h3 hlmCardTitle>Favorite your crew</h3>
          <p hlmCardDescription>Next time, we'll try to dispatch the same team.</p>
        </div>
        <div hlmCardContent>
          <ul class="grid grid-cols-2 gap-2 sm:grid-cols-3">
            @for (m of crew(); track m.workerId) {
              <li>
                <button
                  type="button"
                  (click)="toggle(m.workerId)"
                  [attr.aria-pressed]="isFav(m.workerId)"
                  [attr.aria-label]="(isFav(m.workerId) ? 'Unfavorite ' : 'Favorite ') + name(m)"
                  [disabled]="pending().has(m.workerId)"
                  class="flex w-full items-center gap-2 rounded-lg border border-bcl-border bg-bcl-bg-elev/40 p-2 text-left text-sm hover:border-bcl-accent disabled:opacity-60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                >
                  <span
                    aria-hidden="true"
                    [class.text-rose-400]="isFav(m.workerId)"
                    [class.text-bcl-ink-muted]="!isFav(m.workerId)"
                    >{{ isFav(m.workerId) ? '♥' : '♡' }}</span
                  >
                  <span class="flex-1 truncate text-bcl-ink">{{ name(m) }}</span>
                </button>
              </li>
            }
          </ul>
          @if (error()) {
            <p class="mt-2 text-xs text-destructive" role="alert">{{ error() }}</p>
          }
        </div>
      </div>
    }
  `,
})
export class FavoriteCrewComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly crew = input.required<readonly CrewMemberLite[]>();

  readonly favorites = signal<ReadonlySet<string>>(new Set());
  readonly pending = signal<ReadonlySet<string>>(new Set());
  readonly error = signal<string>('');
  readonly visible = computed(() => this.crew().length > 0);

  ngOnInit(): void {
    void this.load();
  }

  async load(): Promise<void> {
    try {
      const r = await firstValueFrom(
        this.http.get<FavoritesResponse>('/api/loyalty/favorites', { withCredentials: true }),
      );
      this.favorites.set(new Set(r?.favorites ?? []));
    } catch {
      this.favorites.set(new Set());
    }
  }

  isFav(workerId: string): boolean {
    return this.favorites().has(workerId);
  }

  name(m: CrewMemberLite): string {
    return crewName(m);
  }

  async toggle(workerId: string): Promise<void> {
    if (this.pending().has(workerId)) return;
    const wasFav = this.isFav(workerId);
    const next = new Set(this.favorites());
    if (wasFav) next.delete(workerId);
    else next.add(workerId);
    this.favorites.set(next); // optimistic
    this.pending.set(new Set(this.pending()).add(workerId));
    this.error.set('');
    try {
      const res = await fetch('/api/loyalty/favorites', {
        method: wasFav ? 'DELETE' : 'POST',
        credentials: 'include',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ crewUserId: workerId }),
      });
      if (!res.ok) {
        const revert = new Set(this.favorites());
        if (wasFav) revert.add(workerId);
        else revert.delete(workerId);
        this.favorites.set(revert);
        this.error.set('Could not update favorite. Try again.');
      }
    } catch {
      const revert = new Set(this.favorites());
      if (wasFav) revert.add(workerId);
      else revert.delete(workerId);
      this.favorites.set(revert);
      this.error.set('Network error. Try again.');
    } finally {
      const p = new Set(this.pending());
      p.delete(workerId);
      this.pending.set(p);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'favorite-crew-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
