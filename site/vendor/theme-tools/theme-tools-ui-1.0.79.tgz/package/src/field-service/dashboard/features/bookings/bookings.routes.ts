import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { Route } from '@angular/router';

export const BOOKINGS_ROUTES: Route[] = [
  {
    path: '',
    pathMatch: 'full',
    loadComponent: () => import('./bookings.component').then((m) => m.BookingsComponent),
  },
  {
    path: ':id',
    loadComponent: () => import('./booking-detail.component').then((m) => m.BookingDetailComponent),
  },
];
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'bookings-routes',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
