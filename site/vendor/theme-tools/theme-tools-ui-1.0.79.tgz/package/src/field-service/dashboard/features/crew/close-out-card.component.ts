import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CrewCloseOutCardComponent — the crew's job close-out surface (item 13 c-ui).
 *
 * This closes the last wiring gap in the completion-package loop. The shared
 * engine (`src/shared/completion-package.ts`) already feeds three surfaces:
 *   • the customer proof view (`app-completion-proof`)        — READS the verdict
 *   • the operator dispute-evidence panel (`app-dispute-evidence`) — READS it
 *   • the crew close-out                                       — WRITES it (THIS)
 * The write backend (`PATCH /api/jobs/:bookingId/completion-package`,
 * worker-cookie gated, merge semantics, 409 when locked) was mounted with NO
 * crew frontend — a mounted-backend-no-frontend gap, not "blocked". This card is
 * the crew port that drives it.
 *
 * Flow: GET /api/work/gigs → active claims carry `booking_id`; pick the job →
 * GET /api/jobs/:bookingId/completion-package → render the editable close-out
 * checklist + (on $500+ jobs) a walkthrough-video URL field → each change
 * PATCHes the proof bundle and re-reads the recomputed assessment so the crew
 * sees the same progress the customer + operator will. Photo rows are read-only
 * here (crew uploads photos in the field elsewhere); this card persists the
 * checklist confirmations + the video reference.
 *
 * Persistence only: it records the close-out, it does NOT change the completion
 * GATE or move money (wiring the gate to require the checklist is slice 13(c),
 * payment-tier, gated). Self-gates: no active job / 401 / 404 → hide (no console
 * error). Locked job → read-only with a "locked" badge. Live surface = Angular
 * /dashboard, crew audience. Dark-cockpit Spartan styling.
 */
import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmCardImports, HlmInput } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

/** One crew gig invite as returned by `GET /api/work/gigs` (`invites[]`). */
export interface CrewGigInvite {
  readonly id: string;
  readonly booking_id: string;
  readonly status: string;
  readonly service_address?: string | null;
  readonly start_at?: string | null;
}

/** A job the crew can close out — a booking they are actively assigned to. */
export interface CloseOutJob {
  readonly bookingId: string;
  readonly label: string;
}

/** An editable close-out checklist item (mirrors the worker engine shape). */
export interface CloseOutChecklistItem {
  readonly id: string;
  readonly label: string;
  readonly required: boolean;
}

/** One requirement row of the recomputed assessment. */
export interface CloseOutRequirement {
  readonly id: string;
  readonly label: string;
  readonly satisfied: boolean;
}

/** The completion-package verdict the read/write endpoints recompute. */
export interface CloseOutAssessment {
  readonly complete: boolean;
  readonly videoRequired: boolean;
  readonly requirements: readonly CloseOutRequirement[];
  readonly satisfiedCount: number;
  readonly requiredCount: number;
  readonly progress: number;
}

interface CrewGigsResponse {
  readonly invites?: readonly CrewGigInvite[];
}

interface CompletionPackageResponse {
  readonly ok: boolean;
  readonly bookingId?: string;
  readonly completionLockedAt?: string | null;
  readonly checklist?: readonly CloseOutChecklistItem[];
  readonly checkedItemIds?: readonly string[];
  readonly walkthroughVideoUrl?: string | null;
  readonly assessment?: CloseOutAssessment;
}

/** Claim statuses where the crew is committed and can document the job. */
const ACTIVE_CLAIM_STATUSES: ReadonlySet<string> = new Set([
  'accepted',
  'confirmed',
  'checked_in',
]);

/** Requirement ids that are photo rows — read-only here (uploaded in the field). */
const PHOTO_REQUIREMENT_IDS: ReadonlySet<string> = new Set(['photos_before', 'photos_after']);

/**
 * Derive the closeable jobs from a crew gigs response: active claims only, one
 * row per booking (deduped), each with a human label.
 *
 * @param invites - The `invites[]` array from `GET /api/work/gigs`.
 * @returns Active jobs the crew can document, in input order, deduped by booking.
 * @example
 * activeCloseOutJobs([{ id: 'g1', booking_id: 'b1', status: 'checked_in', service_address: '12 Oak St' }])
 * // → [{ bookingId: 'b1', label: '12 Oak St' }]
 */
export function activeCloseOutJobs(invites: readonly CrewGigInvite[] | undefined): CloseOutJob[] {
  const seen = new Set<string>();
  const out: CloseOutJob[] = [];
  for (const g of invites ?? []) {
    if (!g?.booking_id) continue;
    if (!ACTIVE_CLAIM_STATUSES.has(g.status)) continue;
    if (seen.has(g.booking_id)) continue;
    seen.add(g.booking_id);
    out.push({ bookingId: g.booking_id, label: closeOutJobLabel(g) });
  }
  return out;
}

/**
 * Human label for a gig in the close-out picker: address, else start time, else id.
 *
 * @param g - The gig invite.
 * @returns A short label, never empty.
 * @example closeOutJobLabel({ id: 'g', booking_id: 'b', status: 'checked_in', service_address: '5 Elm Ave' }) // → '5 Elm Ave'
 */
export function closeOutJobLabel(g: CrewGigInvite): string {
  const addr = g.service_address?.trim();
  if (addr) return addr;
  const start = g.start_at?.trim();
  if (start) return start;
  return `Job ${g.booking_id}`;
}

/**
 * Immutably toggle a checklist id in/out of the checked set.
 *
 * @param ids - The currently-checked ids.
 * @param id - The id to flip.
 * @returns A new array with `id` added if absent, removed if present.
 * @example toggleChecklistId(['a'], 'b') // → ['a', 'b']
 * @example toggleChecklistId(['a', 'b'], 'a') // → ['b']
 */
export function toggleChecklistId(ids: readonly string[], id: string): string[] {
  return ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id];
}

/**
 * Whole-percent close-out progress, clamped to [0, 100].
 *
 * @param a - The recomputed assessment.
 * @returns The satisfaction percentage rounded to an integer in [0, 100].
 * @example closeOutProgressPct({ progress: 3 / 6 } as CloseOutAssessment) // → 50
 */
export function closeOutProgressPct(a: Pick<CloseOutAssessment, 'progress'>): number {
  const pct = Math.round((a.progress ?? 0) * 100);
  return Math.min(100, Math.max(0, pct));
}

/**
 * Crew-facing headline summarizing the close-out state.
 *
 * @param a - The recomputed assessment.
 * @returns A done line when complete, else an "N of M documented" count.
 * @example closeOutHeadline({ complete: false, satisfiedCount: 3, requiredCount: 6 } as CloseOutAssessment)
 * // → '3 of 6 documented'
 */
export function closeOutHeadline(
  a: Pick<CloseOutAssessment, 'complete' | 'satisfiedCount' | 'requiredCount'>,
): string {
  if (a.complete) return 'Job fully documented';
  return `${a.satisfiedCount} of ${a.requiredCount} documented`;
}

/**
 * The read-only photo requirement rows (uploaded in the field, not edited here).
 *
 * @param a - The recomputed assessment.
 * @returns The before/after photo rows in canonical order.
 * @example photoRequirements({ requirements: [{ id: 'photos_before', label: 'x', satisfied: true }] } as CloseOutAssessment)
 * // → [{ id: 'photos_before', label: 'x', satisfied: true }]
 */
export function photoRequirements(a: CloseOutAssessment): CloseOutRequirement[] {
  return a.requirements.filter((r) => PHOTO_REQUIREMENT_IDS.has(r.id));
}

@Component({
  selector: 'app-crew-close-out-card',
  standalone: true,
  imports: [...HlmCardImports, HlmInput, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <div hlmCard bclReveal data-testid="crew-close-out-card">
        <div hlmCardHeader class="flex flex-row items-start justify-between gap-3">
          <div>
            <h3 hlmCardTitle>Job close-out</h3>
            <p hlmCardDescription>
              Document the finished work — this is what the customer and dispatch see.
            </p>
          </div>
          @if (assessment(); as a) {
            @if (a.complete) {
              <span
                class="rounded-full border border-bcl-success/40 bg-bcl-success/10 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-bcl-success"
                data-testid="crew-close-out-complete"
                >✓ Documented</span
              >
            } @else {
              <span
                class="rounded-full border border-bcl-accent/30 bg-bcl-accent/10 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-bcl-accent"
                >{{ pct() }}%</span
              >
            }
          }
        </div>

        <div hlmCardContent>
          <!-- Job picker (only when the crew is on more than one active job) -->
          @if (jobs().length > 1) {
            <ul
              role="list"
              aria-label="Choose a job to close out"
              class="mb-4 flex flex-wrap gap-2"
            >
              @for (j of jobs(); track j.bookingId) {
                <li>
                  <button
                    type="button"
                    [attr.aria-pressed]="selectedBookingId() === j.bookingId"
                    (click)="selectJob(j.bookingId)"
                    class="rounded-full border px-3 py-1 text-sm font-medium transition-all duration-[333ms] hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring motion-reduce:transition-none"
                    [class.bg-primary]="selectedBookingId() === j.bookingId"
                    [class.text-primary-foreground]="selectedBookingId() === j.bookingId"
                    [class.border-transparent]="selectedBookingId() === j.bookingId"
                    [class.border-border]="selectedBookingId() !== j.bookingId"
                    [class.text-foreground]="selectedBookingId() !== j.bookingId"
                    [class.hover:bg-muted]="selectedBookingId() !== j.bookingId"
                  >
                    {{ j.label }}
                  </button>
                </li>
              }
            </ul>
          }

          @if (assessment(); as a) {
            <!-- Progress -->
            <p class="mb-2 text-xs text-muted-foreground" data-testid="crew-close-out-headline">
              {{ headline() }}
            </p>
            <div
              class="mb-4 h-1.5 w-full overflow-hidden rounded-full bg-white/10"
              role="progressbar"
              [attr.aria-valuenow]="pct()"
              aria-valuemin="0"
              aria-valuemax="100"
              [attr.aria-label]="'Close-out ' + pct() + ' percent done'"
            >
              <div
                class="h-full rounded-full bg-bcl-accent transition-[width] duration-[333ms] ease-out motion-reduce:transition-none"
                [style.width.%]="pct()"
              ></div>
            </div>

            @if (locked()) {
              <p
                class="mb-3 rounded-md border border-bcl-warn/40 bg-bcl-warn/10 px-3 py-2 text-xs text-bcl-warn"
                data-testid="crew-close-out-locked"
              >
                This job is locked — its close-out record is final and can't be changed.
              </p>
            }

            <!-- Photos (read-only — uploaded in the field) -->
            <ul role="list" class="mb-4 space-y-1.5" aria-label="Photo requirements">
              @for (r of photos(); track r.id) {
                <li class="flex items-center gap-2 text-sm">
                  <span
                    class="flex size-4 flex-none items-center justify-center rounded-full font-mono text-[10px] leading-none"
                    [class]="r.satisfied
                      ? 'bg-bcl-success/20 text-bcl-success'
                      : 'bg-white/10 text-muted-foreground'"
                    aria-hidden="true"
                    >{{ r.satisfied ? '✓' : '·' }}</span
                  >
                  <span [class]="r.satisfied ? 'text-foreground' : 'text-muted-foreground'">{{
                    r.label
                  }}</span>
                </li>
              }
            </ul>

            <!-- Editable close-out checklist -->
            <fieldset class="space-y-2" [disabled]="locked() || saving()">
              <legend class="mb-1 text-xs font-medium text-muted-foreground">Close-out checklist</legend>
              @for (item of checklist(); track item.id) {
                <label
                  class="flex cursor-pointer items-start gap-2.5 rounded-md p-1.5 text-sm transition-colors duration-[333ms] hover:bg-white/5 motion-reduce:transition-none"
                  [attr.data-testid]="'crew-close-out-item-' + item.id"
                >
                  <input
                    type="checkbox"
                    class="mt-0.5 size-4 flex-none rounded border-border accent-bcl-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    [checked]="isChecked(item.id)"
                    [disabled]="locked() || saving()"
                    (change)="onToggle(item.id)"
                  />
                  <span class="text-foreground">
                    {{ item.label }}
                    @if (!item.required) {
                      <span class="ml-1 text-[10px] uppercase tracking-wider text-muted-foreground"
                        >optional</span
                      >
                    }
                  </span>
                </label>
              }
            </fieldset>

            <!-- Walkthrough video URL (required on $500+ jobs) -->
            @if (a.videoRequired) {
              <div class="mt-4">
                <label
                  class="mb-1 block text-xs font-medium text-muted-foreground"
                  for="crew-close-out-video"
                  >Walkthrough video link</label
                >
                <input
                  hlmInput
                  id="crew-close-out-video"
                  type="url"
                  inputmode="url"
                  placeholder="https://… (required on larger jobs)"
                  class="w-full"
                  [value]="videoUrl()"
                  [disabled]="locked() || saving()"
                  (change)="onVideoChange($event)"
                  data-testid="crew-close-out-video"
                />
                <p class="mt-1 text-[11px] text-muted-foreground">
                  Paste a link to your walkthrough recording (cloud drive, Photos share, etc.).
                </p>
              </div>
            }

            @if (saveError()) {
              <p class="mt-3 text-xs text-destructive" data-testid="crew-close-out-error">
                {{ saveError() }}
              </p>
            }
          } @else {
            <p class="text-sm text-muted-foreground">Loading your job…</p>
          }
        </div>
      </div>
    }
  `,
})
export class CrewCloseOutCardComponent implements OnInit {
  private readonly http = inject(HttpClient);

  protected readonly visible = signal(false);
  protected readonly jobs = signal<readonly CloseOutJob[]>([]);
  protected readonly selectedBookingId = signal<string | null>(null);
  protected readonly checklist = signal<readonly CloseOutChecklistItem[]>([]);
  protected readonly checkedIds = signal<readonly string[]>([]);
  protected readonly videoUrl = signal<string>('');
  protected readonly assessment = signal<CloseOutAssessment | null>(null);
  protected readonly locked = signal(false);
  protected readonly saving = signal(false);
  protected readonly saveError = signal<string | null>(null);

  protected readonly pct = computed(() => {
    const a = this.assessment();
    return a ? closeOutProgressPct(a) : 0;
  });
  protected readonly headline = computed(() => {
    const a = this.assessment();
    return a ? closeOutHeadline(a) : '';
  });
  protected readonly photos = computed(() => {
    const a = this.assessment();
    return a ? photoRequirements(a) : [];
  });

  protected isChecked(id: string): boolean {
    return this.checkedIds().includes(id);
  }

  async ngOnInit(): Promise<void> {
    try {
      const res = await firstValueFrom(
        this.http.get<CrewGigsResponse>('/api/work/gigs', { withCredentials: true }),
      );
      const jobs = activeCloseOutJobs(res?.invites);
      const first = jobs[0];
      if (!first) return; // no active job → stay hidden
      this.jobs.set(jobs);
      this.visible.set(true);
      await this.selectJob(first.bookingId);
    } catch {
      // Guest / 401 / network → self-hide (visible stays false).
    }
  }

  protected async selectJob(bookingId: string): Promise<void> {
    this.selectedBookingId.set(bookingId);
    this.assessment.set(null);
    this.saveError.set(null);
    try {
      const res = await firstValueFrom(
        this.http.get<CompletionPackageResponse>(
          `/api/jobs/${encodeURIComponent(bookingId)}/completion-package`,
          { withCredentials: true },
        ),
      );
      this.applyResponse(res);
    } catch {
      // Package not readable for this job → leave the card on a loading note.
      this.saveError.set('Could not load this job right now.');
    }
  }

  protected async onToggle(id: string): Promise<void> {
    if (this.locked() || this.saving()) return;
    const next = toggleChecklistId(this.checkedIds(), id);
    this.checkedIds.set(next); // optimistic
    await this.patch({ checkedItemIds: next });
  }

  protected async onVideoChange(ev: Event): Promise<void> {
    if (this.locked() || this.saving()) return;
    const value = (ev.target as HTMLInputElement).value.trim();
    this.videoUrl.set(value);
    await this.patch({ walkthroughVideoUrl: value || null });
  }

  private async patch(body: {
    checkedItemIds?: readonly string[];
    walkthroughVideoUrl?: string | null;
  }): Promise<void> {
    const bookingId = this.selectedBookingId();
    if (!bookingId) return;
    this.saving.set(true);
    this.saveError.set(null);
    try {
      const res = await firstValueFrom(
        this.http.patch<CompletionPackageResponse>(
          `/api/jobs/${encodeURIComponent(bookingId)}/completion-package`,
          body,
          { withCredentials: true },
        ),
      );
      this.applyResponse(res);
    } catch (err: unknown) {
      // 409 → the job got locked while editing; otherwise a generic save error.
      const status = (err as { status?: number })?.status;
      if (status === 409) {
        this.locked.set(true);
        this.saveError.set('This job was locked — your record is now final.');
      } else {
        this.saveError.set('Could not save — check your connection and try again.');
      }
      // Re-read truth so the UI reflects the server, not the failed optimistic edit.
      await this.selectJob(bookingId);
    } finally {
      this.saving.set(false);
    }
  }

  private applyResponse(res: CompletionPackageResponse | null): void {
    if (!res?.ok) return;
    if (res.checklist) this.checklist.set(res.checklist);
    this.checkedIds.set(res.checkedItemIds ?? []);
    this.videoUrl.set(res.walkthroughVideoUrl ?? '');
    this.locked.set(Boolean(res.completionLockedAt));
    if (res.assessment) this.assessment.set(res.assessment);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'close-out-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
