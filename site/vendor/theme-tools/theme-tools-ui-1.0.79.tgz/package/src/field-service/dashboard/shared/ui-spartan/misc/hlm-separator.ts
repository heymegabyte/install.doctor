import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * hlm-separator — themed divider (vendored helm). Horizontal by default;
 * [vertical]=true for inline dividers. Themed by the HLM border var.
 */
import { Directive, computed, input } from '@angular/core';
import { cn } from '../utils/cn';

@Directive({
  selector: '[hlmSeparator]',
  standalone: true,
  host: { '[class]': '_c()', role: 'separator', '[attr.aria-orientation]': 'orientation()' },
})
export class HlmSeparator {
  readonly vertical = input<boolean>(false);
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly orientation = computed(() => (this.vertical() ? 'vertical' : 'horizontal'));
  protected readonly _c = computed(() =>
    cn('shrink-0 bg-border', this.vertical() ? 'h-full w-px' : 'h-px w-full', this.userClass()),
  );
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'hlm-separator',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
