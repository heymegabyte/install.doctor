import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * QuoteDetailComponent — unified prefilled editable quote form.
 *
 * Two modes off `dayCount`:
 *   - 1 day  → single time-picker, no per-day tabs
 *   - 2+ day → <bcl-day-tab> grid with per-day start/end time edit button.
 *
 * The "Start and end time" label renders bottom-right of each day card
 * (handled inside <bcl-day-tab>).
 *
 * Submit posts to /api/booking-payments/intent then triggers the Square
 * SDK or Stripe Payment Element. The button disables on first click +
 * shows a loading state so duplicate clicks can never fire a second intent.
 *
 * Supports `?from=<ride_id>` to prefill from a past booking (reorder).
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import {
  AbstractControl,
  FormBuilder,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { combineLatest, distinctUntilChanged, firstValueFrom, map } from 'rxjs';
import { z } from 'zod';
import {
  HlmCardImports,
  HlmButton,
  HlmInput,
  HlmFormField,
  HlmSkeleton,
  HlmSpinner,
} from '../../shared/ui-spartan';
import { routeFade, reducedMotion } from '../../shared/animations';
import { DayTabComponent, type DayPlan } from '../_shared/day-tab.component';
import { RovingTablistDirective } from '../_shared/roving-tablist.directive';
import { AuthService } from '../../core/auth.service';

export type CanonicalServiceSlug =
  | 'power-washing'
  | 'lawn-care'
  | 'hauling'
  | 'light-repairs'
  | 'moving-labor'
  | 'furniture-removal'
  | 'apartment-cleanout'
  | 'paint-scraping'
  | 'loading-unloading';

export interface CanonicalServicePreset {
  readonly slug: CanonicalServiceSlug;
  readonly label: string;
  readonly crew: number;
  readonly hours: number;
  readonly scopeHint: string;
}

export const HOURLY_RATE_USD = 60;

export const CANONICAL_SERVICES: readonly CanonicalServicePreset[] = [
  {
    slug: 'power-washing',
    label: 'Power Washing',
    crew: 2,
    hours: 3,
    scopeHint: 'Driveways, siding, patios, walkways, and brick facades.',
  },
  {
    slug: 'lawn-care',
    label: 'Lawn Care',
    crew: 2,
    hours: 2,
    scopeHint: 'Mowing, edging, trimming, leaf blowing, and yard tidy-up.',
  },
  {
    slug: 'hauling',
    label: 'Hauling & Junk Removal',
    crew: 2,
    hours: 3,
    scopeHint: 'Curbside, basement, garage, or estate haul-away and disposal prep.',
  },
  {
    slug: 'light-repairs',
    label: 'Light Repairs',
    crew: 1,
    hours: 2,
    scopeHint: 'Drywall patching, hardware swap, fixture mounting, and handyman fixes.',
  },
  {
    slug: 'moving-labor',
    label: 'Moving Labor',
    crew: 3,
    hours: 4,
    scopeHint: 'Full-muscle apartment or house move, stairs, wrapping, and room placement.',
  },
  {
    slug: 'furniture-removal',
    label: 'Furniture Removal',
    crew: 2,
    hours: 2,
    scopeHint: 'Couches, mattresses, dressers, and bulky item breakdown and carry-out.',
  },
  {
    slug: 'apartment-cleanout',
    label: 'Apartment Cleanout',
    crew: 3,
    hours: 4,
    scopeHint: 'Move-out or turnover clear-out, bagging, sorting, and broom-sweep finish.',
  },
  {
    slug: 'paint-scraping',
    label: 'Paint Scraping',
    crew: 2,
    hours: 4,
    scopeHint: 'Exterior and interior scraping, sanding, drop-cloth prep, and surface priming.',
  },
  {
    slug: 'loading-unloading',
    label: 'Loading & Unloading',
    crew: 2,
    hours: 3,
    scopeHint: 'Rental truck, PODS, or container tight-pack loading and unloading.',
  },
];

export function findServicePreset(
  slug: string | null | undefined,
): CanonicalServicePreset | undefined {
  if (!slug) return undefined;
  const normalized = slug.trim().toLowerCase();
  return CANONICAL_SERVICES.find((s) => s.slug === normalized);
}

const QuoteSchema = z.object({
  service: z.string().min(1),
  address: z.string().min(3),
  city: z.string().min(1),
  zip: z.string().min(3),
  crew: z.number().int().min(1).max(8),
  startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  dayCount: z.number().int().min(1).max(14),
  notes: z.string().max(2000).optional(),
  perDay: z
    .array(
      z.object({
        date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
        startTime: z.string().regex(/^\d{2}:\d{2}$/),
        endTime: z.string().regex(/^\d{2}:\d{2}$/),
      }),
    )
    .min(1)
    .max(14),
});

type QuotePayload = z.infer<typeof QuoteSchema>;

interface QuoteDetailResponse {
  readonly ok: boolean;
  readonly quote?: {
    readonly id: string;
    readonly service: string;
    readonly address: string;
    readonly city: string;
    readonly zip: string;
    readonly crew: number;
    readonly preferredDate: string;
    readonly preferredTime: string;
    readonly hours: number;
    readonly dayCount?: number;
    readonly notes?: string;
    readonly perDay?: readonly DayPlan[];
    readonly totalCents: number;
  };
}

interface QuoteForm {
  service: FormControl<string | null>;
  address: FormControl<string | null>;
  city: FormControl<string | null>;
  zip: FormControl<string | null>;
  crew: FormControl<number | null>;
  startDate: FormControl<string | null>;
  dayCount: FormControl<number | null>;
  startTime: FormControl<string | null>;
  endTime: FormControl<string | null>;
  notes: FormControl<string | null>;
}

@Component({
  selector: 'app-quote-detail',
  standalone: true,
  imports: [
    ...HlmCardImports,
    HlmButton,
    HlmInput,
    HlmFormField,
    HlmSkeleton,
    HlmSpinner,
    DayTabComponent,
    RovingTablistDirective,
    ReactiveFormsModule,
    RouterLink,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <a
      routerLink="/quotes"
      class="mb-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
    >
      <span aria-hidden="true">←</span> All quotes
    </a>

    @if (loading()) {
      <div class="space-y-3">
        <div hlmSkeleton class="h-12 w-64"></div>
        <div hlmSkeleton class="h-56 w-full"></div>
      </div>
    } @else {
      <header class="mb-6">
        <h1 class="text-2xl font-bold text-foreground">{{ isNew() ? 'New quote' : 'Edit quote' }}</h1>
        <p class="mt-1 text-sm text-muted-foreground">
          Prefilled and ready — tweak anything below and book in one tap.
        </p>
      </header>

      <form [formGroup]="form" (ngSubmit)="onSubmit()" class="space-y-4">
        <div hlmCard>
          <div hlmCardHeader>
            <h3 hlmCardTitle>Job details</h3>
            <p hlmCardDescription>
              Pick one of our 9 canonical services for instant crew &amp; hour presets, or customize below.
            </p>
          </div>
          <div hlmCardContent class="space-y-4">
            <div data-testid="service-presets" role="group" aria-label="Canonical service presets">
              <p class="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                9-service scope presets
              </p>
              <div class="flex flex-wrap gap-2">
                @for (preset of canonicalServices; track preset.slug) {
                  <button
                    type="button"
                    (click)="selectServicePreset(preset)"
                    [attr.data-testid]="'service-pill-' + preset.slug"
                    [attr.aria-pressed]="serviceSig() === preset.slug"
                    class="inline-flex min-h-[38px] items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors duration-[333ms] focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                    [class.border-primary]="serviceSig() === preset.slug"
                    [class.bg-primary/15]="serviceSig() === preset.slug"
                    [class.text-primary]="serviceSig() === preset.slug"
                    [class.border-border]="serviceSig() !== preset.slug"
                    [class.bg-card]="serviceSig() !== preset.slug"
                    [class.text-foreground]="serviceSig() !== preset.slug"
                  >
                    <span>{{ preset.label }}</span>
                    <span class="font-mono text-[11px] text-muted-foreground">
                      {{ preset.crew }}c · {{ preset.hours }}h
                    </span>
                  </button>
                }
              </div>
              @if (activePreset(); as active) {
                <p class="mt-2 text-xs text-muted-foreground" data-testid="service-scope-hint">
                  <span class="font-semibold text-foreground">{{ active.label }}:</span>
                  {{ active.scopeHint }} (recommended {{ active.crew }} crew · {{ active.hours }} hrs)
                </p>
              }
            </div>

            <div class="grid gap-4 md:grid-cols-2">
              <app-form-field label="Service" [error]="serviceErr()">
                <input hlmInput [formControl]="form.controls.service" [error]="!!serviceErr()" [attr.aria-invalid]="serviceErr() ? 'true' : null" (blur)="markBlurred()" placeholder="e.g. moving-help" />
              </app-form-field>
              <app-form-field label="Crew size">
                <input hlmInput type="number" inputmode="numeric" [formControl]="crewStr" placeholder="2" />
              </app-form-field>
              <app-form-field label="Address" [error]="addressErr()">
                <input hlmInput [formControl]="form.controls.address" [error]="!!addressErr()" [attr.aria-invalid]="addressErr() ? 'true' : null" (blur)="markBlurred()" autocomplete="street-address" placeholder="123 Main St" />
              </app-form-field>
              <div class="grid grid-cols-2 gap-3">
                <app-form-field label="City" [error]="cityErr()">
                  <input hlmInput [formControl]="form.controls.city" [error]="!!cityErr()" [attr.aria-invalid]="cityErr() ? 'true' : null" (blur)="markBlurred()" autocomplete="address-level2" />
                </app-form-field>
                <app-form-field label="Zip" [error]="zipErr()">
                  <input hlmInput [formControl]="form.controls.zip" [error]="!!zipErr()" [attr.aria-invalid]="zipErr() ? 'true' : null" (blur)="markBlurred()" autocomplete="postal-code" inputmode="numeric" />
                </app-form-field>
              </div>
            </div>
          </div>
        </div>

        <div hlmCard>
          <div hlmCardHeader><h3 hlmCardTitle>Dates and times</h3></div>
          <div hlmCardContent>
            <div class="flex flex-wrap items-end gap-3">
              <label class="flex flex-col text-sm">
                <span class="mb-1 text-muted-foreground">Start date</span>
                <input
                  hlmInput
                  type="date"
                  formControlName="startDate"
                  data-testid="quote-date-picker"
                  aria-label="Start date"
                />
              </label>
              <label class="flex flex-col text-sm">
                <span class="mb-1 text-muted-foreground">Days</span>
                <input
                  hlmInput
                  type="number"
                  formControlName="dayCount"
                  name="days"
                  min="1"
                  max="14"
                  data-testid="day-count"
                  aria-label="Number of days"
                  class="w-24"
                />
              </label>
            </div>

            @if (isSingleDay()) {
              <div class="mt-4 flex flex-wrap items-end gap-3">
                <label class="flex flex-col text-sm">
                  <span class="mb-1 text-muted-foreground">Start time</span>
                  <input hlmInput type="time" formControlName="startTime" data-testid="single-time-picker" aria-label="Start time" />
                </label>
                <label class="flex flex-col text-sm">
                  <span class="mb-1 text-muted-foreground">End time</span>
                  <input hlmInput type="time" formControlName="endTime" aria-label="End time" />
                </label>
              </div>
            } @else {
              <div
                role="tablist"
                bclRovingTablist
                aria-label="Per-day schedule"
                data-testid="per-day-tabs"
                class="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3"
              >
                @for (d of perDay(); track $index; let i = $index) {
                  <bcl-day-tab
                    [plan]="d"
                    [index]="i"
                    [active]="activeDayIndex() === i"
                    (select)="setActiveDay($event)"
                    (edit)="onEditDayTime(i)"
                  />
                }
              </div>

              @if (editingDay() !== null) {
                <div
                  class="mt-4 rounded-xl bg-card p-4 ring-1 ring-primary"
                  role="region"
                  [attr.aria-label]="'Edit start and end time for day ' + (editingDay()! + 1)"
                >
                  <p class="mb-2 text-sm font-semibold text-foreground">
                    Editing Day {{ editingDay()! + 1 }}
                  </p>
                  <div class="flex flex-wrap items-end gap-3">
                    <label class="flex flex-col text-sm">
                      <span class="mb-1 text-muted-foreground">Start time</span>
                      <input hlmInput type="time" [value]="editingDayPlan()?.startTime ?? '09:00'" (change)="onPerDayTimeChange($event, 'start')" />
                    </label>
                    <label class="flex flex-col text-sm">
                      <span class="mb-1 text-muted-foreground">End time</span>
                      <input hlmInput type="time" [value]="editingDayPlan()?.endTime ?? '13:00'" (change)="onPerDayTimeChange($event, 'end')" />
                    </label>
                    <button hlmBtn variant="secondary" type="button" (click)="closeEditor()">Done</button>
                  </div>
                </div>
              }
            }
          </div>
        </div>

        <div hlmCard>
          <div hlmCardHeader>
            <h3 hlmCardTitle>Notes</h3>
            <p hlmCardDescription>Anything our crew should know?</p>
          </div>
          <div hlmCardContent>
            <textarea
              formControlName="notes"
              rows="3"
              class="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
              placeholder="Parking restrictions, stairs, fragile items…"
            ></textarea>
          </div>
        </div>

        <div
          hlmCard
          data-testid="quote-price-preview"
          class="border-primary/30 bg-primary/5"
        >
          <div hlmCardContent class="flex flex-wrap items-center justify-between gap-4 py-4">
            <div>
              <p class="font-mono text-xs uppercase tracking-wider text-primary">
                Estimated price preview
              </p>
              <p class="mt-1 text-sm text-foreground">
                {{ crewSig() }} crew × {{ hoursPerDay() }} hr/day × {{ dayCountSig() }}
                {{ dayCountSig() === 1 ? 'day' : 'days' }} × $60/hr
              </p>
              <p class="mt-0.5 text-xs text-muted-foreground" data-testid="quote-deposit-breakdown">
                20% deposit now, 80% after completion ({{ '$' + depositNowDollars() }} now · {{ '$' + balanceAfterDollars() }} after completion)
              </p>
            </div>
            <div class="text-right">
              <p class="font-mono text-2xl font-bold tabular-nums text-primary" data-testid="quote-estimated-total">
                {{ '$' + estimatedTotalDollars() }}
              </p>
              <p class="text-xs text-muted-foreground">
                Deposit due today: {{ '$' + depositNowDollars() }}
              </p>
            </div>
          </div>
        </div>

        @if (submitError()) {
          <p class="text-sm text-destructive" role="alert">{{ submitError() }}</p>
        }

        <div class="flex items-center justify-between gap-3">
          <p class="text-xs text-muted-foreground">
            By booking you agree to the
            <!-- /terms is a marketing page (not an Angular route) → href, not
                 routerLink, which would dead-end on the SPA wildcard. -->
            <a href="/terms" class="text-primary hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring">terms</a>.
          </p>
          <span data-testid="pay-button">
            <button hlmBtn size="lg" type="submit" [disabled]="submitting() || !form.valid">
              @if (submitting()) { <app-spinner [size]="18" /> Processing… } @else { {{ payLabel() }} }
            </button>
          </span>
        </div>
      </form>
    }
  `,
})
export class QuoteDetailComponent implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly fb = inject(FormBuilder);
  private readonly destroyRef = inject(DestroyRef);
  private readonly auth = inject(AuthService);
  protected readonly reducedMotion = reducedMotion;

  readonly canonicalServices = CANONICAL_SERVICES;
  readonly hourlyRate = HOURLY_RATE_USD;

  readonly id = signal<string>('');
  readonly loading = signal<boolean>(true);
  readonly submitting = signal<boolean>(false);
  readonly submitError = signal<string | null>(null);
  readonly perDay = signal<readonly DayPlan[]>([]);
  readonly activeDayIndex = signal<number>(0);
  readonly editingDay = signal<number | null>(null);
  /** Signal mirrors of the form controls so OnPush + computeds react. */
  readonly dayCountSig = signal<number>(1);
  readonly serviceSig = signal<string>('moving-help');
  readonly crewSig = signal<number>(2);
  readonly startTimeSig = signal<string>('09:00');
  readonly endTimeSig = signal<string>('13:00');

  readonly form: FormGroup<QuoteForm> = this.fb.group({
    service: this.fb.control<string | null>('moving-help', Validators.required),
    address: this.fb.control<string | null>('', Validators.required),
    city: this.fb.control<string | null>('', Validators.required),
    zip: this.fb.control<string | null>('', Validators.required),
    crew: this.fb.control<number | null>(2, [Validators.required, Validators.min(1)]),
    startDate: this.fb.control<string | null>(todayIso(), Validators.required),
    dayCount: this.fb.control<number | null>(1, [
      Validators.required,
      Validators.min(1),
      Validators.max(14),
    ]),
    startTime: this.fb.control<string | null>('09:00', Validators.required),
    endTime: this.fb.control<string | null>('13:00', Validators.required),
    notes: this.fb.control<string | null>(''),
  });

  /** Mirror the numeric crew field into a string-flavored control for InputComponent. */
  readonly crewStr: FormControl<string | null> = this.fb.control<string | null>('2');

  readonly isNew = computed(() => this.id() === 'new' || this.id() === '');
  readonly isSingleDay = computed(() => this.dayCountSig() <= 1);
  readonly activePreset = computed<CanonicalServicePreset | null>(
    () => findServicePreset(this.serviceSig()) ?? null,
  );
  readonly hoursPerDay = computed<number>(() =>
    computeHoursBetween(this.startTimeSig(), this.endTimeSig()),
  );
  readonly estimatedTotalDollars = computed<number>(() =>
    Math.round(this.crewSig() * this.hoursPerDay() * this.dayCountSig() * HOURLY_RATE_USD),
  );
  readonly depositNowDollars = computed<number>(() =>
    Math.round(this.estimatedTotalDollars() * 0.2),
  );
  readonly balanceAfterDollars = computed<number>(
    () => this.estimatedTotalDollars() - this.depositNowDollars(),
  );

  readonly editingDayPlan = computed<DayPlan | null>(() => {
    const i = this.editingDay();
    if (i === null) return null;
    return this.perDay()[i] ?? null;
  });

  readonly payLabel = computed(() => {
    return this.isNew() ? 'Book the crew now' : 'Pay and confirm';
  });

  /** Form validity as a signal so the per-field error computeds re-run on every status change. */
  private readonly formStatus = toSignal(this.form.statusChanges, { initialValue: this.form.status });
  /**
   * Bumped on each field blur. The pay button is disabled while the form is invalid, so a
   * submit can never fire on an invalid form — field errors are instead surfaced on BLUR
   * (the standard reactive-forms `touched` pattern): leave a required field empty and its
   * specific error appears, guiding the user to fill it (which re-enables the button).
   */
  readonly blurTick = signal(0);
  protected markBlurred(): void {
    this.blurTick.update((n) => n + 1);
  }

  /** A specific error for `control`, shown once it is touched + invalid, cleared as it is fixed. */
  private fieldErr(control: AbstractControl, msg: string): string {
    this.blurTick(); // recompute when any field is blurred (touched)
    this.formStatus(); // recompute when any control's validity changes (error clears on fix)
    return control.touched && control.invalid ? msg : '';
  }
  readonly serviceErr = computed(() => this.fieldErr(this.form.controls.service, 'Choose a service'));
  // Crew is intentionally NOT wired: the input binds the `crewStr` mirror (blur touches crewStr,
  // not form.controls.crew), and the crewStr→crew sync rejects non-positive values — so crew can
  // never be driven invalid through its own input. A per-field error there would be dead wiring.
  readonly addressErr = computed(() => this.fieldErr(this.form.controls.address, 'Enter the street address'));
  readonly cityErr = computed(() => this.fieldErr(this.form.controls.city, 'Enter the city'));
  readonly zipErr = computed(() => this.fieldErr(this.form.controls.zip, 'Enter the ZIP code'));

  ngOnInit(): void {
    // Guest reaching /dashboard/quotes/* (the `requireRole('customer')` guard
    // passes because `RoleService.viewAs` defaults to 'customer' when whoami is
    // empty) can't build or save a quote and would only fire an authed fetch
    // that 401s (console error). Send them to sign-in instead.
    if (!this.auth.authenticated()) {
      void this.router.navigate(['/login'], {
        queryParams: { as: 'customer', next: this.router.url },
      });
      return;
    }

    // Sync crewStr ↔ crew (numeric). valueChanges never completes → tie every
    // subscription to the component lifetime so they don't leak on re-entry.
    this.crewStr.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((v) => {
      const n = Number(v);
      if (Number.isFinite(n) && n >= 1) {
        this.form.controls.crew.setValue(n);
        this.crewSig.set(n);
      }
    });

    this.form.controls.service.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((v) => this.serviceSig.set(v ?? ''));
    this.form.controls.crew.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((v) => {
        const n = Number(v);
        if (Number.isFinite(n) && n >= 1) this.crewSig.set(n);
      });

    // Recompute perDay whenever startDate / dayCount / startTime / endTime change.
    this.form.controls.startDate.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => this.rebuildPerDay());
    this.form.controls.dayCount.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((v) => {
        const n = Math.max(1, Math.min(14, Number(v) || 1));
        this.dayCountSig.set(n);
        this.rebuildPerDay();
      });
    this.form.controls.startTime.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((v) => {
        this.startTimeSig.set(v ?? '09:00');
        this.rebuildPerDay();
      });
    this.form.controls.endTime.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((v) => {
        this.endTimeSig.set(v ?? '13:00');
        this.rebuildPerDay();
      });

    combineLatest([this.route.paramMap, this.route.queryParamMap])
      .pipe(
        map(([params, query]) => ({
          id: params.get('id') ?? 'new',
          from: query.get('from'),
          service: query.get('service'),
          crew: query.get('crew'),
          hours: query.get('hours'),
        })),
        distinctUntilChanged(
          (left, right) =>
            left.id === right.id &&
            left.from === right.from &&
            left.service === right.service &&
            left.crew === right.crew &&
            left.hours === right.hours,
        ),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe(({ id, from, service, crew, hours }) => {
        this.id.set(id);
        if (this.isNew() && from) {
          void this.prefillFromBooking(from);
        } else if (this.isNew()) {
          this.applyQueryPrefill(service, crew, hours);
          this.rebuildPerDay();
          this.loading.set(false);
        } else {
          void this.load(id);
        }
      });
  }

  selectServicePreset(preset: CanonicalServicePreset): void {
    const st = this.form.controls.startTime.value ?? '09:00';
    const et = addHours(st, preset.hours);
    this.form.controls.service.setValue(preset.slug);
    this.form.controls.crew.setValue(preset.crew);
    this.crewStr.setValue(String(preset.crew));
    this.form.controls.endTime.setValue(et);
    this.serviceSig.set(preset.slug);
    this.crewSig.set(preset.crew);
    this.endTimeSig.set(et);
    this.rebuildPerDay();
  }

  applyQueryPrefill(
    service: string | null,
    crewParam: string | null,
    hoursParam: string | null,
  ): void {
    if (!service && !crewParam && !hoursParam) return;
    const preset = findServicePreset(service);
    if (service && service.trim().length > 0) {
      const resolvedService = preset ? preset.slug : service.trim();
      this.form.controls.service.setValue(resolvedService);
      this.serviceSig.set(resolvedService);
    }
    const parsedCrew = crewParam !== null ? Number(crewParam) : Number.NaN;
    const resolvedCrew =
      Number.isFinite(parsedCrew) && parsedCrew >= 1 && parsedCrew <= 8
        ? Math.round(parsedCrew)
        : preset?.crew;
    if (resolvedCrew !== undefined) {
      this.form.controls.crew.setValue(resolvedCrew);
      this.crewStr.setValue(String(resolvedCrew));
      this.crewSig.set(resolvedCrew);
    }
    const parsedHours = hoursParam !== null ? Number(hoursParam) : Number.NaN;
    const resolvedHours =
      Number.isFinite(parsedHours) && parsedHours >= 1 && parsedHours <= 12
        ? Math.round(parsedHours)
        : preset?.hours;
    if (resolvedHours !== undefined) {
      const st = this.form.controls.startTime.value ?? '09:00';
      const et = addHours(st, resolvedHours);
      this.form.controls.endTime.setValue(et);
      this.endTimeSig.set(et);
    }
  }

  async load(id: string): Promise<void> {
    this.loading.set(true);
    try {
      const resp = await firstValueFrom(
        this.http.get<QuoteDetailResponse>(`/api/customer/quotes/${id}`, {
          withCredentials: true,
        }),
      );
      const q = resp?.quote;
      if (q) {
        const st = normalizeTime(q.preferredTime);
        const et = addHours(st, q.hours || 4);
        this.form.patchValue({
          service: q.service,
          address: q.address,
          city: q.city,
          zip: q.zip,
          crew: q.crew,
          startDate: q.preferredDate,
          dayCount: q.dayCount ?? 1,
          startTime: st,
          endTime: et,
          notes: q.notes ?? '',
        });
        this.crewStr.setValue(String(q.crew));
        this.serviceSig.set(q.service);
        this.crewSig.set(q.crew);
        this.dayCountSig.set(q.dayCount ?? 1);
        this.startTimeSig.set(st);
        this.endTimeSig.set(et);
        if (q.perDay && q.perDay.length > 0) {
          this.perDay.set(q.perDay.slice());
        } else {
          this.rebuildPerDay();
        }
      } else {
        this.rebuildPerDay();
      }
    } catch {
      this.rebuildPerDay();
    } finally {
      this.loading.set(false);
    }
  }

  async prefillFromBooking(bookingId: string): Promise<void> {
    this.loading.set(true);
    try {
      const resp = await firstValueFrom(
        this.http.get<{ ok: boolean; booking?: QuoteDetailResponse['quote'] }>(
          `/api/customer/jobs/${bookingId}`,
          { withCredentials: true },
        ),
      );
      const b = resp?.booking;
      if (b) {
        const st = normalizeTime(b.preferredTime);
        const et = addHours(st, b.hours || 4);
        this.form.patchValue({
          service: b.service,
          address: b.address,
          city: b.city,
          zip: b.zip,
          crew: b.crew,
          startDate: todayIso(),
          dayCount: 1,
          startTime: st,
          endTime: et,
        });
        this.crewStr.setValue(String(b.crew));
        this.serviceSig.set(b.service);
        this.crewSig.set(b.crew);
        this.dayCountSig.set(1);
        this.startTimeSig.set(st);
        this.endTimeSig.set(et);
      }
    } catch {
      // ignore — empty form
    } finally {
      this.rebuildPerDay();
      this.loading.set(false);
    }
  }

  rebuildPerDay(): void {
    const start = this.form.controls.startDate.value ?? todayIso();
    const count = Math.max(1, Math.min(14, Number(this.form.controls.dayCount.value) || 1));
    const st = this.form.controls.startTime.value ?? '09:00';
    const et = this.form.controls.endTime.value ?? '13:00';
    this.dayCountSig.set(count);
    this.startTimeSig.set(st);
    this.endTimeSig.set(et);
    const next: DayPlan[] = [];
    for (let i = 0; i < count; i++) {
      next.push({ date: addDays(start, i), startTime: st, endTime: et });
    }
    this.perDay.set(next);
    if (this.activeDayIndex() >= count) this.activeDayIndex.set(0);
  }

  setActiveDay(i: number): void {
    this.activeDayIndex.set(i);
  }

  onEditDayTime(i: number): void {
    this.activeDayIndex.set(i);
    this.editingDay.set(i);
  }

  closeEditor(): void {
    this.editingDay.set(null);
  }

  onPerDayTimeChange(ev: Event, which: 'start' | 'end'): void {
    const idx = this.editingDay();
    if (idx === null) return;
    const v = (ev.target as HTMLInputElement).value;
    const updated = this.perDay().map((d, i) =>
      i !== idx ? d : which === 'start' ? { ...d, startTime: v } : { ...d, endTime: v },
    );
    this.perDay.set(updated);
  }

  async onSubmit(): Promise<void> {
    if (this.submitting()) return; // hard-block re-entry
    this.submitting.set(true);
    this.submitError.set(null);

    try {
      const payload: QuotePayload = {
        service: this.form.controls.service.value ?? '',
        address: this.form.controls.address.value ?? '',
        city: this.form.controls.city.value ?? '',
        zip: this.form.controls.zip.value ?? '',
        crew: Number(this.form.controls.crew.value ?? 2),
        startDate: this.form.controls.startDate.value ?? todayIso(),
        dayCount: Number(this.form.controls.dayCount.value ?? 1),
        notes: this.form.controls.notes.value ?? '',
        perDay: this.perDay().map((d) => ({ ...d })),
      };
      const parsed = QuoteSchema.safeParse(payload);
      if (!parsed.success) {
        this.submitError.set('Please fill in every required field.');
        this.submitting.set(false);
        return;
      }

      const id = this.id();
      const resp = await firstValueFrom(
        this.http.post<{
          ok: boolean;
          clientSecret?: string;
          publishableKey?: string;
          paymentLinkUrl?: string;
          bookingId?: string;
          error?: string;
        }>(
          `/api/booking-payments/intent`,
          {
            quoteId: id === 'new' ? null : id,
            payload: parsed.data,
            mode: 'partial',
          },
          { withCredentials: true },
        ),
      );

      if (!resp?.ok) {
        this.submitError.set(resp?.error ?? 'Could not start payment.');
        this.submitting.set(false);
        return;
      }

      if (resp.paymentLinkUrl) {
        globalThis.location?.assign(resp.paymentLinkUrl);
        return;
      }
      if (resp.bookingId) {
        await this.router.navigate(['/bookings', resp.bookingId]);
        return;
      }
      // Fallback: hand off to the React /book flow with prefilled params.
      const qs = new URLSearchParams({
        service: parsed.data.service,
        crew: String(parsed.data.crew),
        address: parsed.data.address,
      });
      globalThis.location?.assign(`/book?${qs.toString()}`);
    } catch (e: unknown) {
      this.submitError.set(
        (e as { error?: { error?: string } })?.error?.error ?? 'Network error — please retry.',
      );
      this.submitting.set(false);
    }
  }
}

function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

function addDays(iso: string, n: number): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return iso;
  const d = new Date(`${iso}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

function normalizeTime(t: string): string {
  if (!t) return '09:00';
  const m = /^(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$/i.exec(t.trim());
  if (!m) return '09:00';
  let h = Number(m[1]);
  const mm = m[2] ? Number(m[2]) : 0;
  const period = m[3]?.toLowerCase();
  if (period === 'pm' && h < 12) h += 12;
  if (period === 'am' && h === 12) h = 0;
  return `${String(h).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
}

function addHours(time: string, hours: number): string {
  const parts = time.split(':').map(Number);
  const h = parts[0] ?? 9;
  const m = parts[1] ?? 0;
  if (!Number.isFinite(h) || !Number.isFinite(m)) return '13:00';
  const total = h * 60 + m + hours * 60;
  const nh = Math.floor((total / 60) % 24);
  const nm = total % 60;
  return `${String(nh).padStart(2, '0')}:${String(nm).padStart(2, '0')}`;
}

function computeHoursBetween(startTime: string, endTime: string): number {
  const sp = startTime.split(':').map(Number);
  const ep = endTime.split(':').map(Number);
  const sh = sp[0] ?? 9;
  const sm = sp[1] ?? 0;
  const eh = ep[0] ?? 13;
  const em = ep[1] ?? 0;
  if (
    !Number.isFinite(sh) ||
    !Number.isFinite(sm) ||
    !Number.isFinite(eh) ||
    !Number.isFinite(em)
  ) {
    return 4;
  }
  const diffMinutes = eh * 60 + em - (sh * 60 + sm);
  if (diffMinutes <= 0) return 4;
  return Math.max(1, Math.round((diffMinutes / 60) * 10) / 10);
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'quote-detail-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
