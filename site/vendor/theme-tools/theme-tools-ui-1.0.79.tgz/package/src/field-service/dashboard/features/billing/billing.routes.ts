import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { Route } from '@angular/router';

/**
 * Billing surfaces — overview (hourly rate + contract), usage, invoices,
 * payment methods, receipts. No SaaS plan picker (hourly-labor business). Per-tab lazy-load so each page boots fast.
 */
export const BILLING_ROUTES: Route[] = [
  {
    path: '',
    loadComponent: () => import('./billing.component').then((m) => m.BillingComponent),
    children: [
      {
        path: '',
        pathMatch: 'full',
        loadComponent: () => import('./overview.component').then((m) => m.BillingOverviewComponent),
      },
      {
        // SaaS "usage/credits" meter REMOVED (fire-48) — Brick Labor is hourly labor, not SaaS
        // (no credits / per-site metering / burn). Redirect stale bookmarks to the billing overview.
        path: 'usage',
        redirectTo: '',
        pathMatch: 'full',
      },
      {
        path: 'invoices',
        loadComponent: () => import('./invoices.component').then((m) => m.BillingInvoicesComponent),
      },
      {
        path: 'payment-methods',
        loadComponent: () =>
          import('./payment-methods.component').then((m) => m.BillingPaymentMethodsComponent),
      },
      {
        path: 'receipts',
        loadComponent: () => import('./receipts.component').then((m) => m.BillingReceiptsComponent),
      },
    ],
  },
];
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'billing-routes',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
