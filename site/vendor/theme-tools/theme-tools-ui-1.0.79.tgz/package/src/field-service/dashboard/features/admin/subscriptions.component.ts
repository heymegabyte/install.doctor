import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminSubscriptionsComponent — recurring-revenue (MRR / churn / counts) on the
 * admin console. Live surface = Angular /dashboard/admin.
 *
 * Unblocked 2026-06-03: `/api/admin/subscriptions` migrated from OWNER_INVOICE_KEY
 * Bearer-only to the shared `ownerOrSuperAdmin` gate.
 *   GET /api/admin/subscriptions/stats → { ok, stats:{ activeCount, mrrCents, pendingCount,
 *        pausedCount, canceledLast30dCount, churnRate30d (already a %), lifetimeBilledCents } }
 * READ-ONLY: the winback-batch / no-show-sweep workflow triggers are operator actions.
 * Pure helpers dollars/formatChurn unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmCardImports } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { BclRollingCounterComponent } from '../_shared/rolling-counter.component';

export interface SubscriptionStats {
  readonly activeCount: number;
  readonly mrrCents: number;
  readonly pendingCount: number;
  readonly pausedCount: number;
  readonly canceledLast30dCount: number;
  readonly churnRate30d: number;
  readonly lifetimeBilledCents: number;
}

/** Pure: cents → $ with thousands separators, no decimals for large sums. */
export function dollars(cents: number): string {
  if (!Number.isFinite(cents)) return '$0';
  return `$${Math.round(cents / 100).toLocaleString('en-US')}`;
}

/** Pure: churn is already a percentage from the API — clamp + one decimal. */
export function formatChurn(pct: number): string {
  if (!Number.isFinite(pct)) return '0.0%';
  return `${Math.max(0, pct).toFixed(1)}%`;
}

interface StatsResponse {
  readonly ok: boolean;
  readonly stats?: SubscriptionStats;
}

const ZERO: SubscriptionStats = {
  activeCount: 0,
  mrrCents: 0,
  pendingCount: 0,
  pausedCount: 0,
  canceledLast30dCount: 0,
  churnRate30d: 0,
  lifetimeBilledCents: 0,
};

@Component({
  selector: 'app-admin-subscriptions',
  standalone: true,
  imports: [...HlmCardImports, BclRollingCounterComponent, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard bclReveal data-testid="admin-subscriptions">
      <div hlmCardHeader>
        <h3 hlmCardTitle>Subscriptions</h3>
        <p hlmCardDescription>Recurring revenue, active plans, and 30-day churn.</p>
      </div>
      <div hlmCardContent>
        @if (loading()) {
          <p class="text-sm text-bcl-ink-muted">Loading subscription stats…</p>
        } @else if (error()) {
          <p class="text-sm text-bcl-warn" role="status">{{ error() }}</p>
        } @else {
          <div class="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <div class="rounded-md border border-bcl-border bg-bcl-bg-elev p-3">
              <p class="font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">MRR</p>
              <p class="mt-1 font-mono text-lg tabular-nums text-bcl-accent">
                <bcl-rolling-counter [value]="s().mrrCents / 100" prefix="$" />
              </p>
            </div>
            <div class="rounded-md border border-bcl-border bg-bcl-bg-elev p-3">
              <p class="font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">Active</p>
              <p class="mt-1 font-mono text-lg tabular-nums text-bcl-ink">
                <bcl-rolling-counter [value]="s().activeCount" />
              </p>
            </div>
            <div class="rounded-md border border-bcl-border bg-bcl-bg-elev p-3">
              <p class="font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">Churn 30d</p>
              <p
                class="mt-1 font-mono text-lg tabular-nums"
                [class.text-bcl-success]="s().churnRate30d < 5"
                [class.text-bcl-warn]="s().churnRate30d >= 5 && s().churnRate30d < 12"
                [class.text-destructive]="s().churnRate30d >= 12"
              ><bcl-rolling-counter [value]="s().churnRate30d" [decimals]="1" suffix="%" /></p>
            </div>
            <div class="rounded-md border border-bcl-border bg-bcl-bg p-3">
              <p class="font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">Pending</p>
              <p class="mt-1 font-mono tabular-nums text-bcl-ink">
                <bcl-rolling-counter [value]="s().pendingCount" />
              </p>
            </div>
            <div class="rounded-md border border-bcl-border bg-bcl-bg p-3">
              <p class="font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">Paused</p>
              <p class="mt-1 font-mono tabular-nums text-bcl-ink">
                <bcl-rolling-counter [value]="s().pausedCount" />
              </p>
            </div>
            <div class="rounded-md border border-bcl-border bg-bcl-bg p-3">
              <p class="font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">Lifetime billed</p>
              <p class="mt-1 font-mono tabular-nums text-bcl-ink">
                <bcl-rolling-counter [value]="s().lifetimeBilledCents / 100" prefix="$" />
              </p>
            </div>
          </div>
          @if (s().canceledLast30dCount > 0) {
            <p class="mt-3 text-xs text-bcl-ink-muted">{{ s().canceledLast30dCount }} canceled in the last 30 days.</p>
          }
        }
      </div>
    </div>
  `,
})
export class AdminSubscriptionsComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly s = signal<SubscriptionStats>(ZERO);
  readonly loading = signal(true);
  readonly error = signal<string>('');

  readonly money = dollars;
  readonly churn = formatChurn;

  ngOnInit(): void {
    void this.load();
  }

  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set('');
    try {
      const r = await firstValueFrom(
        this.http.get<StatsResponse>('/api/admin/subscriptions/stats', { withCredentials: true }),
      );
      if (!r?.ok || !r.stats) throw new Error('not_ok');
      this.s.set(r.stats);
    } catch {
      this.error.set('Sign in as an operator to view subscription stats.');
    } finally {
      this.loading.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'subscriptions-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
