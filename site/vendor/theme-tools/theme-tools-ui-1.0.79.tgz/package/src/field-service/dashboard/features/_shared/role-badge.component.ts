import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * BclRoleBadge — small role/tier pill (member directory + admin lists). Relocated
 * shared/ui → features/_shared during the Spartan rebuild; cockpit-palette tones.
 */
import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';

export type BclRole = 'owner' | 'admin' | 'member' | 'viewer' | 'customer' | 'crew' | 'super_admin';

@Component({
  selector: 'bcl-role-badge',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<span
    class="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ring-1"
    [class]="cls()"
    >{{ label() }}</span
  >`,
})
export class BclRoleBadgeComponent {
  readonly role = input.required<BclRole>();

  readonly label = computed<string>(() => {
    const r = this.role();
    if (r === 'super_admin') return 'Super Admin';
    return r.charAt(0).toUpperCase() + r.slice(1);
  });

  cls(): string {
    const tones: Record<BclRole, string> = {
      owner: 'bg-violet-500/15 text-violet-300 ring-violet-400/30',
      admin: 'bg-primary/15 text-primary ring-primary/30',
      member: 'bg-muted text-muted-foreground ring-border',
      viewer: 'bg-muted text-muted-foreground ring-border',
      customer: 'bg-emerald-500/15 text-emerald-300 ring-emerald-400/30',
      crew: 'bg-blue-500/15 text-blue-300 ring-blue-400/30',
      super_admin: 'bg-destructive/15 text-destructive ring-destructive/30',
    };
    return tones[this.role()];
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'role-badge-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
