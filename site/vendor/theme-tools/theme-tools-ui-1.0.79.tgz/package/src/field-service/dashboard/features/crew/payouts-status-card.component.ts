import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CrewPayoutsStatusCardComponent — Stripe Connect Express crew payout onboarding on the
 * crew surface (BACKLOG item 7). Live surface = Angular /dashboard, crew audience.
 *
 * GET  /api/work/payouts/connect/status (worker-cookie gated) → { ok, state, account, fees, ytd }.
 * POST /api/work/payouts/connect/start  → { ok, url } — Stripe-hosted Express ONBOARDING link
 *   (KYC, account verification). This is NOT a money movement, so wiring the redirect is
 *   agent-tier; the real ACTIONS that move money (transfer / instant cash-out) stay gated.
 *   503 stripe_not_configured (no STRIPE_SECRET_KEY) + 401 anon both degrade gracefully here.
 *
 * The card SURFACES: onboarding state badge · what verification Stripe still needs
 * (dueRequirements) · a Start/Continue/Finish CTA that redirects to the hosted flow ·
 * instant-payout eligibility + fees once active · YTD earnings. Pure helpers
 * (stateLabel / stateTone / payoutsReady / onboardingCta / dueRequirements /
 * instantFeeLabel / formatUsdCents / startErrorMessage / humanizeRequirement) are
 * unit-tested in payouts-status-card.component.spec.ts. Self-gates 401 → hide.
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { HlmCardImports, HlmButton, StateBlockComponent } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { FeatureFlagService } from '../../core/feature-flag.service';

export type ConnectState = 'not_started' | 'in_progress' | 'needs_action' | 'restricted' | 'active';

export interface ConnectFees {
  readonly instantPct: number;
  readonly instantMinCents: number;
  readonly instantCapCents: number;
  readonly standardPct: number;
  readonly standardFlatCents: number;
}

export interface ConnectYtd {
  readonly grossCents: number;
  readonly feesCents: number;
  readonly transferCount: number;
  readonly taxYear?: number;
}

export interface ConnectAccount {
  readonly payoutsEnabled: boolean;
  readonly requirementsCurrentlyDue?: readonly string[];
  readonly requirementsPastDue?: readonly string[];
}

export interface ConnectStatus {
  readonly ok: boolean;
  readonly state: ConnectState;
  readonly account: ConnectAccount | null;
  readonly fees?: ConnectFees;
  readonly ytd?: ConnectYtd;
}

const STATE_LABEL: Readonly<Record<ConnectState, string>> = {
  not_started: 'Not started',
  in_progress: 'In progress',
  needs_action: 'Needs your attention',
  restricted: 'Restricted',
  active: 'Active',
};

const CTA_LABEL: Readonly<Record<ConnectState, string>> = {
  not_started: 'Start payout setup',
  in_progress: 'Continue setup',
  needs_action: 'Finish verification',
  restricted: 'Resolve account hold',
  active: 'Manage payout account',
};

/** Pure: human label for a connect state. */
export function stateLabel(state: ConnectState): string {
  return STATE_LABEL[state] ?? 'Unknown';
}

/** Pure: tone band — active=high, needs_action/restricted=warn, else neutral. */
export function stateTone(state: ConnectState): 'high' | 'warn' | 'neutral' {
  if (state === 'active') return 'high';
  if (state === 'needs_action' || state === 'restricted') return 'warn';
  return 'neutral';
}

/** Pure: payouts are usable only when active AND payoutsEnabled. */
export function payoutsReady(s: Pick<ConnectStatus, 'state' | 'account'>): boolean {
  return s.state === 'active' && !!s.account?.payoutsEnabled;
}

/** Pure: the call-to-action label for the onboarding button by state. */
export function onboardingCta(state: ConnectState): string {
  return CTA_LABEL[state] ?? 'Set up payouts';
}

/** Pure: cents → en-US currency string ($1,234.56). */
export function formatUsdCents(cents: number): string {
  return ((cents || 0) / 100).toLocaleString('en-US', { style: 'currency', currency: 'USD' });
}

/** Pure: human label for an instant-payout fee schedule. Drops the "min" clause
 * when the schedule has no floor (`instantMinCents === 0`), so the live 1.5% /
 * no-floor / $1.50-cap schedule reads "1.5% (max $1.50)" rather than the
 * awkward "min $0.00". */
export function instantFeeLabel(
  fees: Pick<ConnectFees, 'instantPct' | 'instantMinCents' | 'instantCapCents'>,
): string {
  const max = `max ${formatUsdCents(fees.instantCapCents)}`;
  const clause =
    fees.instantMinCents > 0 ? `min ${formatUsdCents(fees.instantMinCents)}, ${max}` : max;
  return `${fees.instantPct}% (${clause})`;
}

/**
 * Pure: the instant-payout fee in cents for a given cash-out amount, using the
 * SAME schedule the card displays (`pct` floored at `min`, capped at `max`).
 * Keeps the card's "you receive" net internally consistent with the fee label.
 */
export function instantPayoutFeeFromSchedule(
  amountCents: number,
  fees: Pick<ConnectFees, 'instantPct' | 'instantMinCents' | 'instantCapCents'>,
): number {
  if (amountCents <= 0) return 0;
  const pctFee = Math.ceil((amountCents * fees.instantPct) / 100);
  return Math.min(Math.max(pctFee, fees.instantMinCents), fees.instantCapCents);
}

/** Pure: net cents a crew member receives after the instant-payout fee (never negative). */
export function instantPayoutNetCents(
  amountCents: number,
  fees: Pick<ConnectFees, 'instantPct' | 'instantMinCents' | 'instantCapCents'>,
): number {
  return Math.max(0, amountCents - instantPayoutFeeFromSchedule(amountCents, fees));
}

/**
 * Pure: whether to surface an actionable instant cash-out CTA. True only when
 * payouts are active AND the `instant_payout_rtp` flag is on AND a real
 * available balance exists — so the "Instant cash-out available" copy is never
 * a dead promise (the request route is flag-gated; without the flag there is no
 * working destination).
 */
export function instantCashOutEligible(
  ready: boolean,
  instantOn: boolean,
  payable: Pick<CrewPayable, 'availableCents'> | null,
): boolean {
  return ready && instantOn && !!payable && payable.availableCents > 0;
}

/** Pure: turn a dotted Stripe requirement field into a readable label. */
export function humanizeRequirement(field: string): string {
  const leaf = field.split('.').pop() ?? field;
  return leaf
    .replace(/_/g, ' ')
    .trim()
    .replace(/\b\w/g, (m) => m.toUpperCase());
}

/** Pure: dedup + humanize the outstanding requirements (past-due first), capped at `max`. */
export function dueRequirements(
  account: Pick<ConnectAccount, 'requirementsCurrentlyDue' | 'requirementsPastDue'> | null,
  max = 4,
): string[] {
  if (!account) return [];
  const seen = new Set<string>();
  const out: string[] = [];
  for (const f of [...(account.requirementsPastDue ?? []), ...(account.requirementsCurrentlyDue ?? [])]) {
    const h = humanizeRequirement(f);
    if (h && !seen.has(h)) {
      seen.add(h);
      out.push(h);
    }
    if (out.length >= max) break;
  }
  return out;
}

/** One reason's frozen total in the crew payout-balance breakdown. */
export interface CrewPayableHold {
  readonly reason: string;
  readonly jobs: number;
  readonly cents: number;
  readonly label: string;
}

/** Available-now vs on-hold breakdown of unposted earnings (GET /api/work/payouts). */
export interface CrewPayable {
  readonly availableCents: number;
  readonly availableJobs: number;
  readonly windowOpenCents: number;
  readonly windowOpenJobs: number;
  readonly frozenCents: number;
  readonly frozenJobs: number;
  readonly holds: readonly CrewPayableHold[];
}

/** Pure: any unposted earnings at all (available, waiting, or frozen). */
export function payableHasBalance(p: CrewPayable | null): boolean {
  if (!p) return false;
  return p.availableJobs > 0 || p.windowOpenJobs > 0 || p.frozenJobs > 0;
}

/** Pure: any earnings on hold (benign 24h window OR a frozen problem). */
export function payableOnHold(p: CrewPayable | null): boolean {
  if (!p) return false;
  return p.windowOpenJobs > 0 || p.frozenJobs > 0;
}

/** Pure: "1 job" / "N jobs". */
export function jobsLabel(n: number): string {
  return `${n} job${n === 1 ? '' : 's'}`;
}

/** Pure: map a /connect/start error code to a crew-facing message. */
export function startErrorMessage(code: string | undefined): string {
  switch (code) {
    case 'stripe_not_configured':
      return 'Payouts aren’t switched on yet — check back shortly.';
    case 'email_required':
      return 'Add your email to your profile first, then set up payouts.';
    case 'rate_limited':
      return 'Too many attempts. Try again in a few minutes.';
    case 'unauthorized':
      return 'Please sign in again to set up payouts.';
    default:
      return 'Couldn’t start payout setup. Please try again.';
  }
}

/** The three outcomes of loading the crew payout status. */
export type StatusFetchOutcome = 'render' | 'hide' | 'error';

/**
 * Pure: classify a `/connect/status` fetch result into what the card should DO.
 *
 * SCAN-04: `refresh()` used to collapse every non-render case into "hide", so a
 * reachable-but-failed load (a 5xx, or a thrown network error) silently vanished
 * the card — a signed-in crew member with real earnings saw a blank space. This
 * splits the outcomes so a real failure surfaces a retry-able error panel instead:
 *
 *   - **hide**  — 401 (anon, no crew session): nothing to show, correctly hidden.
 *   - **error** — reachable but failed: a network throw (`threw`), any other
 *     non-ok HTTP status (5xx / 403 / 404), or an `{ ok:false }` payload. The card
 *     was successfully requested by a signed-in crew, so a failure is real and gets
 *     a visible, retry-able error — never a silent blank.
 *   - **render** — `res.ok` AND `body.ok === true`: show the card.
 *
 * @param res  the fetch outcome: `{ ok, status }` from `fetch`, or `null` when the
 *             request threw before a response (network error) — pass `{ threw:true }`.
 * @param body the parsed JSON body (`{ ok }`) or `null` when unparseable.
 */
export function classifyStatusFetch(
  res: { readonly ok: boolean; readonly status: number } | { readonly threw: true } | null,
  body: { readonly ok?: boolean } | null,
): StatusFetchOutcome {
  // Network-level failure (fetch threw): reachable intent, failed — surface it.
  if (res === null || 'threw' in res) return 'error';
  // 401 = no crew session → genuinely nothing to show for this viewer.
  if (res.status === 401) return 'hide';
  // Any other non-ok HTTP status = a real server/transport failure → error.
  if (!res.ok) return 'error';
  // ok HTTP but the app-level envelope says not-ok → treat as a real failure.
  if (!body?.ok) return 'error';
  return 'render';
}

@Component({
  selector: 'app-crew-payouts-status-card',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, BclRevealDirective, RouterLink, StateBlockComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <div hlmCard bclReveal data-testid="crew-payouts-status-card">
        <div hlmCardHeader class="flex flex-row items-center justify-between gap-3">
          <div>
            <h3 hlmCardTitle>Payouts</h3>
            <p hlmCardDescription>Stripe Connect — how you get paid for completed gigs.</p>
          </div>
          <span
            class="shrink-0 rounded-full px-3 py-1 text-xs ring-1"
            [class.text-bcl-success]="tone() === 'high'"
            [class.ring-bcl-success\\/40]="tone() === 'high'"
            [class.text-bcl-warn]="tone() === 'warn'"
            [class.ring-bcl-warn\\/40]="tone() === 'warn'"
            [class.text-bcl-ink-muted]="tone() === 'neutral'"
            [class.ring-bcl-border]="tone() === 'neutral'"
            data-testid="payouts-state-badge"
            >{{ label() }}</span
          >
        </div>
        <div hlmCardContent>
          @if (ready()) {
            <p class="text-sm text-bcl-success" role="status">
              ✓ Payouts are enabled — earnings transfer automatically after each gig.
            </p>
            @if (instantEligible() && fees(); as f) {
              <!-- Eligible: real available balance + flag on → actionable cash-out CTA
                   (never a dead "available" promise without a working destination). -->
              <a
                hlmBtn
                size="sm"
                routerLink="/crew/payout"
                class="mt-3 inline-flex"
                data-testid="instant-cashout-cta"
                [attr.aria-label]="
                  'Cash out ' +
                  usd(instantNet(payable()!.availableCents, f)) +
                  ' now via instant payout'
                "
              >
                Cash out {{ usd(instantNet(payable()!.availableCents, f)) }} now
              </a>
              <p class="mt-2 text-xs text-bcl-ink-muted" data-testid="instant-fee">
                Instant — you receive
                {{ usd(instantNet(payable()!.availableCents, f)) }} of
                {{ usd(payable()!.availableCents) }} after the
                {{ instantFee(f) }} fee. Arrives in minutes.
              </p>
            } @else if (fees(); as f) {
              <!-- Active but no actionable instant payout (flag off or zero balance):
                   state the automatic-transfer fact, no instant-cash-out promise. -->
              <p class="mt-2 text-xs text-bcl-ink-muted" data-testid="instant-fee-info">
                Standard transfers land automatically · instant cash-out fee
                {{ instantFee(f) }} when available.
              </p>
            }
          } @else {
            <p class="mb-3 text-sm text-bcl-ink-muted">
              Finish Stripe onboarding to unlock automatic payouts + instant cash-out.
            </p>
            @if (dueReqs().length) {
              <div class="mb-3" data-testid="due-requirements">
                <p class="text-xs font-medium text-bcl-warn">Stripe still needs:</p>
                <ul class="mt-1 flex flex-wrap gap-2" aria-label="Outstanding verification items">
                  @for (req of dueReqs(); track req) {
                    <li
                      class="rounded-full bg-bcl-warn/10 px-3 py-1 text-xs text-bcl-warn ring-1 ring-bcl-warn/30"
                    >
                      {{ req }}
                    </li>
                  }
                </ul>
              </div>
            }
            <button
              hlmBtn
              type="button"
              [disabled]="pending()"
              (click)="startOnboarding()"
              data-testid="payouts-start-btn"
            >
              {{ pending() ? 'Opening Stripe…' : cta() }}
            </button>
            @if (error()) {
              <p class="mt-2 text-sm text-bcl-warn" role="alert" data-testid="payouts-start-error">
                {{ error() }}
              </p>
            }
          }
          @if (ytd(); as y) {
            @if (y.grossCents > 0) {
              <p class="mt-3 text-xs text-bcl-ink-muted" data-testid="payouts-ytd">
                {{ usd(y.grossCents) }} earned this year · {{ y.transferCount }} payout{{
                  y.transferCount === 1 ? '' : 's'
                }}
              </p>
            }
          }
          @if (payableHasBalance(payable())) {
            @if (payable(); as p) {
              <div class="mt-4 border-t border-bcl-border pt-3" data-testid="payout-balance">
                <p class="text-xs font-medium uppercase tracking-wide text-bcl-ink-muted">
                  Payout balance
                </p>
                <p class="mt-1 text-sm text-bcl-success" data-testid="payout-available">
                  {{ usd(p.availableCents) }} available now · {{ jobs(p.availableJobs) }}
                </p>
                @if (p.windowOpenJobs > 0) {
                  <p class="mt-1 text-xs text-bcl-ink-muted" data-testid="payout-window-open">
                    {{ usd(p.windowOpenCents) }} awaiting customer confirmation ·
                    {{ jobs(p.windowOpenJobs) }}
                  </p>
                }
                @if (p.frozenJobs > 0) {
                  <div class="mt-2" data-testid="payout-holds">
                    <p class="text-xs font-medium text-bcl-warn">
                      {{ usd(p.frozenCents) }} on hold
                    </p>
                    <ul class="mt-1 flex flex-wrap gap-2" aria-label="Earnings on hold">
                      @for (h of p.holds; track h.reason) {
                        <li
                          class="rounded-full bg-bcl-warn/10 px-3 py-1 text-xs text-bcl-warn ring-1 ring-bcl-warn/30"
                        >
                          {{ h.label }} · {{ usd(h.cents) }} ({{ jobs(h.jobs) }})
                        </li>
                      }
                    </ul>
                  </div>
                }
              </div>
            }
          }
        </div>
      </div>
    } @else if (loadError()) {
      <!-- SCAN-04: a reachable-but-failed status fetch surfaces a retry-able panel
           instead of a silent blank card (crew money surface — never lying-empty).
           Reuses the design-system StateBlock error state (extend-don't-duplicate). -->
      <div data-testid="payouts-status-error">
        <app-state-block
          state="error"
          errorTitle="Payouts"
          [errorDetail]="loadError()"
          (retry)="retry()"
        />
      </div>
    }
  `,
})
export class CrewPayoutsStatusCardComponent implements OnInit {
  readonly visible = signal(false);
  readonly state = signal<ConnectState>('not_started');
  readonly ready = signal(false);
  readonly label = signal('Not started');
  readonly cta = signal('Start payout setup');
  readonly tone = signal<'high' | 'warn' | 'neutral'>('neutral');
  readonly dueReqs = signal<string[]>([]);
  readonly fees = signal<ConnectFees | null>(null);
  readonly ytd = signal<ConnectYtd | null>(null);
  readonly payable = signal<CrewPayable | null>(null);
  readonly pending = signal(false);
  readonly error = signal('');
  /** True while the initial `/connect/status` fetch is in flight. */
  readonly loading = signal(true);
  /**
   * Non-empty when the status fetch was reachable-but-failed (5xx / network error /
   * `{ok:false}`). Drives the SCAN-04 error+retry panel; empty on 401-anon (hide) or
   * a successful render.
   */
  readonly loadError = signal('');

  /** `instant_payout_rtp` flag — gates the actionable cash-out CTA + its route. */
  private readonly flags = inject(FeatureFlagService);
  readonly instantOn = this.flags.isOn('instant_payout_rtp');

  /** True only when active + flag-on + a real available balance → show the CTA. */
  readonly instantEligible = computed(() =>
    instantCashOutEligible(this.ready(), this.instantOn(), this.payable()),
  );

  /** Template adapters around the pure helpers. */
  readonly instantFee = instantFeeLabel;
  readonly instantNet = instantPayoutNetCents;
  readonly usd = formatUsdCents;
  readonly jobs = jobsLabel;
  readonly payableHasBalance = payableHasBalance;

  ngOnInit(): void {
    void this.refresh();
  }

  async refresh(): Promise<void> {
    this.loading.set(true);
    let res: Response | null = null;
    let s: ConnectStatus | null = null;
    try {
      res = await fetch('/api/work/payouts/connect/status', { credentials: 'include' });
      s = (await res.json().catch(() => null)) as ConnectStatus | null;
    } catch {
      res = null; // network-level failure (fetch threw)
    }

    // SCAN-04: split "hide" (401 anon) from "error" (reachable-but-failed) so a real
    // failure surfaces a retry-able panel instead of silently vanishing the card.
    const outcome = classifyStatusFetch(res === null ? { threw: true } : res, s);
    this.loading.set(false);

    if (outcome === 'hide') {
      this.loadError.set('');
      this.visible.set(false);
      return;
    }
    if (outcome === 'error') {
      this.visible.set(false);
      this.loadError.set(
        'Couldn’t load your payout status — check your connection and try again.',
      );
      return;
    }

    // outcome === 'render': s is guaranteed non-null + ok here.
    const status = s as ConnectStatus;
    this.loadError.set('');
    this.state.set(status.state);
    this.label.set(stateLabel(status.state));
    this.tone.set(stateTone(status.state));
    this.cta.set(onboardingCta(status.state));
    this.ready.set(payoutsReady(status));
    this.dueReqs.set(dueRequirements(status.account));
    this.fees.set(status.fees ?? null);
    this.ytd.set(status.ytd ?? null);
    this.visible.set(true);
    void this.loadPayable();
  }

  /** Re-run the status fetch after a reachable-but-failed load (SCAN-04 error panel). */
  retry(): void {
    void this.refresh();
  }

  /**
   * Load the available-now vs on-hold breakdown of unposted earnings. Separate,
   * best-effort fetch — a failure leaves `payable` null and the section simply
   * hides; the onboarding card is never blocked on it.
   */
  async loadPayable(): Promise<void> {
    try {
      const res = await fetch('/api/work/payouts', { credentials: 'include' });
      if (!res.ok) return;
      const body = (await res.json().catch(() => null)) as { payable?: CrewPayable } | null;
      if (body?.payable) this.payable.set(body.payable);
    } catch {
      /* leave payable null — the section just hides */
    }
  }

  /**
   * Kick off (or resume) the Stripe-hosted Express onboarding flow. POSTs /connect/start,
   * then redirects the crew to the returned account-link URL. KYC only — no money moves.
   */
  async startOnboarding(): Promise<void> {
    if (this.pending()) return;
    this.pending.set(true);
    this.error.set('');
    try {
      const res = await fetch('/api/work/payouts/connect/start', {
        method: 'POST',
        credentials: 'include',
        headers: { 'content-type': 'application/json' },
        body: '{}',
      });
      const body = (await res.json().catch(() => null)) as
        | { ok?: boolean; url?: string; code?: string }
        | null;
      if (res.ok && body?.ok && body.url) {
        window.location.href = body.url; // navigate to Stripe's hosted flow
        return;
      }
      this.error.set(startErrorMessage(body?.code));
    } catch {
      this.error.set(startErrorMessage(undefined));
    } finally {
      this.pending.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'payouts-status-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
