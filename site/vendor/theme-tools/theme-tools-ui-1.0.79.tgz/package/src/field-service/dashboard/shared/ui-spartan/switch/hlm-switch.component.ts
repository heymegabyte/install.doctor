import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * HlmSwitch — accessible toggle switch (ARIA role="switch"), the Spartan
 * design-system replacement for the deprecated bcl-toggle. Same API
 * (checked model + label + ariaLabel + disabled + changed) so consumers migrate
 * by swapping the import + selector. Keyboard: Space AND Enter toggle. Themed on
 * the cockpit tokens (primary track when on, input track when off).
 *
 * Usage:
 *   <hlm-switch [checked]="on()" (changed)="save($event)" label="Enabled" />
 */
import { ChangeDetectionStrategy, Component, input, model, output } from '@angular/core';

@Component({
  selector: 'hlm-switch',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <label class="inline-flex cursor-pointer items-center gap-3">
      <button
        type="button"
        role="switch"
        [attr.aria-checked]="checked()"
        [attr.aria-label]="ariaLabel() || label() || null"
        [disabled]="disabled()"
        (click)="toggle()"
        (keydown.space)="onKey($event)"
        (keydown.enter)="onKey($event)"
        class="relative h-6 w-11 shrink-0 rounded-full ring-1 ring-border transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring disabled:cursor-not-allowed disabled:opacity-50"
        [class.bg-primary]="checked()"
        [class.bg-input]="!checked()"
        data-testid="hlm-switch"
      >
        <span
          class="absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform"
          [style.transform]="checked() ? 'translateX(20px)' : 'translateX(0)'"
          aria-hidden="true"
        ></span>
      </button>
      @if (label()) {
        <span class="text-sm text-foreground">{{ label() }}</span>
      }
    </label>
  `,
})
export class HlmSwitch {
  readonly checked = model<boolean>(false);
  readonly label = input<string>('');
  readonly ariaLabel = input<string | null>(null);
  readonly disabled = input<boolean>(false);
  readonly changed = output<boolean>();

  toggle(): void {
    if (this.disabled()) return;
    const next = !this.checked();
    this.checked.set(next);
    this.changed.emit(next);
  }

  onKey(e: Event): void {
    e.preventDefault(); // stop Space-scroll / Enter-submit
    this.toggle();
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'hlm-switch-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
