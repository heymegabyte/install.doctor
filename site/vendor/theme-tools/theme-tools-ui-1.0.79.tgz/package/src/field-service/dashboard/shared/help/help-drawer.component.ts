import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * HelpDrawer — floating "?" launcher in the bottom-right of every dashboard
 * surface. Opens a CDK overlay slide-over with:
 *   - Searchable docs index (/api/docs/index)
 *   - Context-aware suggestions based on the current route
 *   - "Contact support" form → POST /api/contact
 *   - Live status indicator (green/yellow/red) from /api/status
 *
 * Listens for a `bcl:help-drawer:open` custom event so other top-nav
 * components (account menu) can trigger it without a direct service.
 */
import {
  ChangeDetectionStrategy,
  Component,
  type ElementRef,
  HostListener,
  OnDestroy,
  OnInit,
  computed,
  effect,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { OverlayModule } from '@angular/cdk/overlay';
import { A11yModule } from '@angular/cdk/a11y';
import { HttpClient } from '@angular/common/http';
import { NavigationEnd, Router } from '@angular/router';
import { Subscription, filter, firstValueFrom } from 'rxjs';

interface DocEntry {
  readonly title: string;
  readonly slug: string;
  readonly summary?: string;
  readonly tags?: readonly string[];
}

interface StatusSnap {
  readonly state: 'operational' | 'degraded' | 'down';
  readonly message?: string;
}

const STATUS_LABEL: Record<StatusSnap['state'], string> = {
  operational: 'All systems normal',
  degraded: 'Partial degradation',
  down: 'Major outage',
};
const STATUS_COLOR: Record<StatusSnap['state'], string> = {
  operational: 'bg-bcl-success',
  degraded: 'bg-bcl-warn',
  down: 'bg-bcl-danger',
};

@Component({
  selector: 'app-help-drawer',
  standalone: true,
  imports: [OverlayModule, A11yModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <button
      type="button"
      cdkOverlayOrigin
      #trigger="cdkOverlayOrigin"
      #triggerBtn
      (click)="toggleOpen()"
      class="fixed bottom-4 right-4 z-40 inline-flex items-center justify-center rounded-full size-12 bg-bcl-accent text-bcl-bg font-bold shadow-xl ring-2 ring-bcl-bg hover:scale-105 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent transition-transform"
      [attr.aria-expanded]="open()"
      aria-label="Open help drawer"
    >
      <span class="text-2xl leading-none" aria-hidden="true">?</span>
    </button>

    <ng-template
      cdkConnectedOverlay
      [cdkConnectedOverlayOrigin]="trigger"
      [cdkConnectedOverlayOpen]="open()"
      [cdkConnectedOverlayHasBackdrop]="true"
      [cdkConnectedOverlayBackdropClass]="['bg-black/50', 'backdrop-blur-sm']"
      [cdkConnectedOverlayPositions]="[
        {
          originX: 'end',
          originY: 'bottom',
          overlayX: 'end',
          overlayY: 'bottom',
          offsetX: -16,
          offsetY: -72,
        },
      ]"
      (backdropClick)="open.set(false)"
      (overlayKeydown)="onOverlayKeydown($event)"
    >
      <aside
        role="dialog"
        aria-modal="true"
        aria-labelledby="help-drawer-title"
        cdkTrapFocus
        [cdkTrapFocusAutoCapture]="true"
        class="w-[420px] max-w-[92vw] max-h-[80vh] overflow-hidden rounded-xl bg-bcl-bg-elev ring-1 ring-bcl-border shadow-2xl flex flex-col"
      >
        <header class="flex items-center justify-between border-b border-bcl-border px-4 py-3">
          <h2 id="help-drawer-title" class="text-sm font-semibold text-bcl-ink">Help &amp; support</h2>
          <button
            type="button"
            (click)="open.set(false)"
            class="text-bcl-ink-muted hover:text-bcl-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
            aria-label="Close help drawer"
          >
            ✕
          </button>
        </header>

        <div class="border-b border-bcl-border px-4 py-2 flex items-center gap-2">
          <span
            aria-hidden="true"
            class="inline-block size-2.5 rounded-full"
            [class]="statusColor()"
          ></span>
          <span class="text-xs text-bcl-ink-muted">
            {{ statusLabel() }}
          </span>
          <a
            href="https://bricklabor.com/status"
            target="_blank"
            rel="noopener noreferrer"
            class="ml-auto text-xs text-bcl-accent hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
          >
            Status page →
          </a>
        </div>

        <div class="border-b border-bcl-border px-4 py-3">
          <label class="block">
            <span class="sr-only">Search documentation</span>
            <input
              type="text"
              [value]="query()"
              (input)="onQuery($event)"
              placeholder="Search docs…"
              class="w-full rounded-md bg-bcl-bg/40 px-3 py-2 text-sm text-bcl-ink placeholder:text-bcl-ink-muted outline-none ring-1 ring-bcl-border focus:ring-bcl-accent"
              aria-label="Search documentation"
            />
          </label>
        </div>

        <div class="flex-1 overflow-y-auto px-4 py-3 space-y-4">
          @if (contextual().length > 0 && !query()) {
            <section>
              <h3 class="font-mono text-[10px] uppercase tracking-wide text-bcl-accent mb-2">
                For this page
              </h3>
              <ul class="space-y-1">
                @for (d of contextual(); track d.slug) {
                  <li>
                    <a
                      [href]="docLink(d.slug)"
                      target="_blank"
                      rel="noopener noreferrer"
                      class="block rounded-md px-2 py-1.5 text-sm text-bcl-ink hover:bg-white/5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
                    >
                      {{ d.title }}
                      @if (d.summary) {
                        <span class="block text-xs text-bcl-ink-muted">{{ d.summary }}</span>
                      }
                    </a>
                  </li>
                }
              </ul>
            </section>
          }

          <section>
            <h3 class="font-mono text-[10px] uppercase tracking-wide text-bcl-ink-muted mb-2">
              {{ query() ? 'Search results' : 'All docs' }}
            </h3>
            @if (filtered().length === 0) {
              <p class="text-sm text-bcl-ink-muted">No matching docs.</p>
            } @else {
              <ul class="space-y-1">
                @for (d of filtered(); track d.slug) {
                  <li>
                    <a
                      [href]="docLink(d.slug)"
                      target="_blank"
                      rel="noopener noreferrer"
                      class="block rounded-md px-2 py-1.5 text-sm text-bcl-ink hover:bg-white/5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
                    >
                      {{ d.title }}
                      @if (d.summary) {
                        <span class="block text-xs text-bcl-ink-muted">{{ d.summary }}</span>
                      }
                    </a>
                  </li>
                }
              </ul>
            }
          </section>

          <section class="border-t border-bcl-border pt-3">
            <h3 class="font-mono text-[10px] uppercase tracking-wide text-bcl-ink-muted mb-2">
              Contact support
            </h3>
            <form (submit)="contact($event)" class="space-y-2">
              <textarea
                name="message"
                rows="3"
                required
                placeholder="What's on your mind?"
                class="w-full rounded-md bg-bcl-bg/40 px-3 py-2 text-sm text-bcl-ink placeholder:text-bcl-ink-muted outline-none ring-1 ring-bcl-border focus:ring-bcl-accent"
              ></textarea>
              <!-- Removed a dead "Recent changes → /dashboard/changelog" link
                   (no changelog page exists; the /api/ai/changelog data has no
                   renderer yet). Right-align the Send button until a real
                   changelog page lands. -->
              <div class="flex items-center justify-end gap-3">
                <button
                  type="submit"
                  [disabled]="sending()"
                  class="rounded-md bg-bcl-accent px-3 py-1.5 text-xs font-semibold text-bcl-bg hover:opacity-90 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent disabled:opacity-50"
                >
                  {{ sending() ? 'Sending…' : 'Send' }}
                </button>
              </div>
              @if (sentNote()) {
                <p class="text-xs text-bcl-success" role="status">{{ sentNote() }}</p>
              }
              @if (sendErr()) {
                <p class="text-xs text-destructive" role="alert">{{ sendErr() }}</p>
              }
            </form>
          </section>
        </div>
      </aside>
    </ng-template>
  `,
})
export class HelpDrawerComponent implements OnInit, OnDestroy {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);

  /** The "?" launcher — focus returns here when the modal drawer closes. */
  private readonly triggerBtn = viewChild<ElementRef<HTMLButtonElement>>('triggerBtn');

  readonly open = signal<boolean>(false);
  readonly query = signal<string>('');
  readonly docs = signal<readonly DocEntry[]>([]);
  readonly currentRoute = signal<string>('/');
  readonly status = signal<StatusSnap>({ state: 'operational' });
  readonly sending = signal<boolean>(false);
  /** Success note — polite, green (role="status"). */
  readonly sentNote = signal<string | null>(null);
  /** Failure note — assertive, destructive (role="alert"); never masquerades as success-green. */
  readonly sendErr = signal<string | null>(null);

  readonly statusLabel = computed(() => this.status().message || STATUS_LABEL[this.status().state]);
  readonly statusColor = computed(() => STATUS_COLOR[this.status().state]);

  readonly filtered = computed<readonly DocEntry[]>(() => {
    const q = this.query().trim().toLowerCase();
    if (!q) return this.docs();
    return this.docs().filter((d) => {
      const hay = `${d.title} ${d.summary ?? ''} ${(d.tags ?? []).join(' ')}`.toLowerCase();
      return hay.includes(q);
    });
  });

  readonly contextual = computed<readonly DocEntry[]>(() => {
    const path = this.currentRoute();
    const segment = path.split('/').filter(Boolean)[0] ?? 'home';
    return this.docs()
      .filter((d) => (d.tags ?? []).includes(segment) || d.slug.includes(segment))
      .slice(0, 4);
  });

  private routerSub?: Subscription;

  /** Remember the element focused before open so it can be restored on close. */
  private previouslyFocused: HTMLElement | null = null;

  constructor() {
    // Honor the modal contract: capture the pre-open focus target when the
    // drawer opens (cdkTrapFocusAutoCapture moves focus INTO the drawer), and
    // restore it when the drawer closes so a keyboard user isn't stranded. The
    // trigger button is the canonical restore target, but fall back to whatever
    // held focus (e.g. the account-menu item that fired the external-open event).
    effect(() => {
      if (this.open()) {
        this.previouslyFocused =
          typeof document !== 'undefined'
            ? (document.activeElement as HTMLElement | null)
            : null;
      } else {
        const restore = this.triggerBtn()?.nativeElement ?? this.previouslyFocused;
        restore?.focus?.();
        this.previouslyFocused = null;
      }
    });
  }

  @HostListener('window:bcl:help-drawer:open')
  onExternalOpen(): void {
    this.open.set(true);
  }

  /**
   * Escape dismisses the modal drawer (WCAG 2.1.2 / APG modal-dialog keyboard
   * expectation). cdkConnectedOverlay does NOT close on Escape by default, so
   * this is wired explicitly via (overlayKeydown); focus is restored to the
   * trigger by the constructor effect when `open` flips false.
   */
  onOverlayKeydown(event: KeyboardEvent): void {
    if (event.key === 'Escape' && this.open()) {
      event.preventDefault();
      this.open.set(false);
    }
  }

  ngOnInit(): void {
    void this.loadDocs();
    void this.loadStatus();
    this.currentRoute.set(this.router.url);
    this.routerSub = this.router.events
      .pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd))
      .subscribe((e) => this.currentRoute.set(e.urlAfterRedirects));
  }

  ngOnDestroy(): void {
    this.routerSub?.unsubscribe();
  }

  toggleOpen(): void {
    this.open.update((v) => !v);
  }

  onQuery(event: Event): void {
    const target = event.target as HTMLInputElement | null;
    this.query.set(target?.value ?? '');
  }

  docLink(slug: string): string {
    return slug.startsWith('http')
      ? slug
      : `https://bricklabor.com/docs/${encodeURIComponent(slug)}`;
  }

  async contact(event: Event): Promise<void> {
    event.preventDefault();
    const form = event.target as HTMLFormElement;
    const data = new FormData(form);
    const message = String(data.get('message') ?? '').trim();
    if (!message) return;
    this.sending.set(true);
    this.sentNote.set(null);
    this.sendErr.set(null);
    try {
      await firstValueFrom(
        this.http.post(
          '/api/contact',
          { source: 'help-drawer', route: this.currentRoute(), message },
          { withCredentials: true },
        ),
      );
      form.reset();
      this.sentNote.set("Thanks — we'll get back to you shortly.");
    } catch {
      // Assertive failure (role="alert"), pointing at the CANONICAL support address —
      // never the success-green polite note (which read as "sent" on a real failure).
      this.sendErr.set('Could not send right now. Try email hey@bricklabor.com.');
    } finally {
      this.sending.set(false);
    }
  }

  private async loadDocs(): Promise<void> {
    try {
      const resp = await firstValueFrom(
        this.http.get<{ ok: boolean; entries: DocEntry[] }>('/api/docs/index', {
          withCredentials: true,
        }),
      );
      if (resp?.entries) this.docs.set(resp.entries);
    } catch {
      // Fallback to a minimal hard-coded list so the drawer is still useful.
      this.docs.set([
        { title: 'Booking flow', slug: 'booking', tags: ['bookings', 'home'] },
        { title: 'Pricing & surge', slug: 'pricing', tags: ['billing'] },
        { title: 'Crew dashboard', slug: 'crew', tags: ['crew', 'jobs'] },
        { title: 'Operator playbook', slug: 'ops', tags: ['admin', 'logs'] },
      ]);
    }
  }

  private async loadStatus(): Promise<void> {
    try {
      const resp = await firstValueFrom(
        this.http.get<{ ok: boolean; status: StatusSnap }>('/api/status', {
          withCredentials: true,
        }),
      );
      if (resp?.status) this.status.set(resp.status);
    } catch {
      // Default state stays "operational" — silent on failure.
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'help-drawer-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
