import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * hlm-card — Spartan helm card family (vendored). The cockpit's elevated
 * surface primitive: card / header / title / description / content / footer.
 * Themed by the HLM `card`/`border` vars (mapped to --bcl-bg-elev).
 */
import { Directive, computed, input } from '@angular/core';
import {
  HLM_CARD_BASE_CLASS,
  HLM_CARD_CONTENT_CLASS,
  HLM_CARD_DESCRIPTION_CLASS,
  HLM_CARD_FOOTER_CLASS,
  HLM_CARD_HEADER_CLASS,
  HLM_CARD_TITLE_CLASS,
} from '@theme-tools/ui/spartan-helm-variants';
import { cn } from '../utils/cn';

@Directive({
  selector: '[hlmCard]',
  standalone: true,
  host: { '[class]': '_computedClass()' },
})
export class HlmCard {
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly _computedClass = computed(() =>
    cn(HLM_CARD_BASE_CLASS, this.userClass()),
  );
}

@Directive({
  selector: '[hlmCardHeader]',
  standalone: true,
  host: { '[class]': '_computedClass()' },
})
export class HlmCardHeader {
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly _computedClass = computed(() => cn(HLM_CARD_HEADER_CLASS, this.userClass()));
}

@Directive({
  selector: '[hlmCardTitle]',
  standalone: true,
  host: { '[class]': '_computedClass()' },
})
export class HlmCardTitle {
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly _computedClass = computed(() =>
    cn(HLM_CARD_TITLE_CLASS, this.userClass()),
  );
}

@Directive({
  selector: '[hlmCardDescription]',
  standalone: true,
  host: { '[class]': '_computedClass()' },
})
export class HlmCardDescription {
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly _computedClass = computed(() =>
    cn(HLM_CARD_DESCRIPTION_CLASS, this.userClass()),
  );
}

@Directive({
  selector: '[hlmCardContent]',
  standalone: true,
  host: { '[class]': '_computedClass()' },
})
export class HlmCardContent {
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly _computedClass = computed(() => cn(HLM_CARD_CONTENT_CLASS, this.userClass()));
}

@Directive({
  selector: '[hlmCardFooter]',
  standalone: true,
  host: { '[class]': '_computedClass()' },
})
export class HlmCardFooter {
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly _computedClass = computed(() =>
    cn(HLM_CARD_FOOTER_CLASS, this.userClass()),
  );
}

export const HlmCardImports = [
  HlmCard,
  HlmCardHeader,
  HlmCardTitle,
  HlmCardDescription,
  HlmCardContent,
  HlmCardFooter,
] as const;
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'hlm-card',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
