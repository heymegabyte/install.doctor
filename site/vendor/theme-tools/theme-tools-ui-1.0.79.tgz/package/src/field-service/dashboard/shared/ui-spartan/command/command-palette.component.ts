import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CommandPaletteComponent — Cmd+K / Ctrl+K command palette (per the always.md
 * Cmd+K mandate: opens AND immediately focuses the input, caret ready; Esc
 * closes and restores focus to the trigger via HlmDialog). Built on HlmDialog +
 * HlmInput. Generic: the shell supplies `commands`; selecting one emits `run`.
 * Keyboard: ↑/↓ move, Home/End jump to first/last, Enter runs the highlighted
 * command, type to filter.
 *
 * Accessibility — this is the WAI-ARIA **combobox + listbox** pattern, NOT a
 * `role="menu"` (so it deliberately does NOT use {@link RovingMenuDirective}):
 * the input keeps DOM focus while a visually-highlighted `role="option"` is the
 * "active" item. That pattern REQUIRES `aria-activedescendant` on the input
 * pointing at the active option's stable `id`, or a screen-reader user arrowing
 * the list hears nothing as the highlight moves. axe-core does NOT catch a
 * missing active-descendant link (it's an interaction-state gap, not a static
 * attribute one) — it is locked by the colocated behavior spec instead. The
 * active option is also scrolled into view so it never falls off the bottom of
 * the scrollable list under keyboard navigation.
 *
 * The shell wires `commands` to routes + the /api/dashboard search index.
 */
import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  computed,
  effect,
  input,
  output,
  signal,
  viewChild,
} from '@angular/core';
import { HlmDialog } from '../dialog/hlm-dialog.component';
import { HlmInput } from '../input/hlm-input';

export interface PaletteCommand {
  readonly id: string;
  readonly label: string;
  readonly hint?: string;
  readonly group?: string;
}

/** Pure case-insensitive subsequence-ish filter over label+hint+group. Tested. */
export function filterCommands(commands: PaletteCommand[], query: string): PaletteCommand[] {
  const q = query.trim().toLowerCase();
  if (!q) return commands;
  return commands.filter((c) =>
    `${c.label} ${c.hint ?? ''} ${c.group ?? ''}`.toLowerCase().includes(q),
  );
}

/**
 * Stable DOM id for the option at `index` in the rendered list — the target of
 * the input's `aria-activedescendant`. Index-keyed (not command-id-keyed) so a
 * duplicate command id can never collide, and the value is deterministic. Pure.
 */
export function optionId(index: number): string {
  return `command-option-${index}`;
}

@Component({
  selector: 'app-command-palette',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [HlmDialog, HlmInput],
  template: `
    <app-dialog [open]="open()" (openChange)="setOpen($event)" ariaLabel="Command palette">
      <div class="flex flex-col gap-3">
        <input
          #queryInput
          hlmInput
          type="text"
          placeholder="Search commands…"
          [value]="query()"
          (input)="onQuery($event)"
          (keydown)="onKey($event)"
          data-testid="command-input"
          role="combobox"
          aria-label="Search the dashboard"
          aria-expanded="true"
          aria-controls="command-list"
          [attr.aria-activedescendant]="activeOptionId()"
        />
        <ul
          #list
          id="command-list"
          role="listbox"
          aria-label="Commands"
          class="max-h-80 overflow-y-auto"
          data-testid="command-list"
        >
          @for (grp of groups(); track grp.name) {
            <li role="group" [attr.aria-label]="grp.name">
              <div
                class="px-3 pt-3 pb-1 font-mono text-[10px] uppercase tracking-wide text-muted-foreground"
                aria-hidden="true"
              >
                {{ grp.name }}
              </div>
              <ul role="presentation" class="contents">
                @for (item of grp.items; track item.cmd.id) {
                  <li
                    [id]="optionId(item.index)"
                    role="option"
                    [attr.aria-selected]="item.index === active()"
                    [class]="rowClass(item.index === active())"
                    (click)="choose(item.cmd)"
                    (mouseenter)="active.set(item.index)"
                  >
                    <span class="text-foreground">{{ item.cmd.label }}</span>
                    @if (item.cmd.hint) {
                      <span class="ml-auto text-xs text-muted-foreground">{{ item.cmd.hint }}</span>
                    }
                  </li>
                }
              </ul>
            </li>
          } @empty {
            <li class="px-3 py-6 text-center text-sm text-muted-foreground">No matching commands.</li>
          }
        </ul>
      </div>
    </app-dialog>
  `,
})
export class CommandPaletteComponent {
  readonly commands = input<PaletteCommand[]>([]);
  readonly run = output<PaletteCommand>();

  protected readonly open = signal(false);
  protected readonly query = signal('');
  protected readonly active = signal(0);
  protected readonly filtered = computed(() => filterCommands(this.commands(), this.query()));

  /**
   * The filtered commands grouped into CONSECUTIVE runs by their `group` (the nav
   * section), each item carrying its FLAT index into {@link filtered}. The flat
   * index is what the aria-activedescendant / active-highlight / arrow-key contract
   * keys on, so grouping is a pure render concern layered over the untouched flat
   * list — a group never reorders options or breaks keyboard nav. `group`-less
   * commands fall into a trailing "Other" run.
   */
  protected readonly groups = computed<
    ReadonlyArray<{ name: string; items: ReadonlyArray<{ cmd: PaletteCommand; index: number }> }>
  >(() => {
    const out: { name: string; items: { cmd: PaletteCommand; index: number }[] }[] = [];
    this.filtered().forEach((cmd, index) => {
      const name = cmd.group ?? 'Other';
      const tail = out[out.length - 1];
      if (tail && tail.name === name) tail.items.push({ cmd, index });
      else out.push({ name, items: [{ cmd, index }] });
    });
    return out;
  });

  /** Template handle to the pure id helper so each `<li>` gets a stable id. */
  protected readonly optionId = optionId;

  /**
   * The `aria-activedescendant` value for the input: the active option's id, or
   * `null` when the list is empty (no option to point at — the attribute must be
   * absent, not stale). Drives SR announcement of the highlighted command.
   */
  readonly activeOptionId = computed<string | null>(() =>
    this.filtered().length ? optionId(this.active()) : null,
  );

  private readonly queryInput = viewChild<ElementRef<HTMLInputElement>>('queryInput');
  private readonly list = viewChild<ElementRef<HTMLUListElement>>('list');

  constructor() {
    // Per always.md: when the palette opens, focus the input immediately (caret
    // ready, zero extra clicks). requestAnimationFrame after the @if mounts it.
    effect(() => {
      if (this.open()) {
        const raf = typeof requestAnimationFrame !== 'undefined' ? requestAnimationFrame : setTimeout;
        raf(() => this.queryInput()?.nativeElement.focus({ preventScroll: true }));
      }
    });

    // Keep the active option in view: arrowing past the visible window of the
    // scrollable list must scroll the highlight back on-screen, not lose it.
    effect(() => {
      const idx = this.active();
      if (!this.open() || !this.filtered().length) return;
      const ul = this.list()?.nativeElement;
      const el = ul?.querySelector<HTMLElement>(`#${optionId(idx)}`);
      el?.scrollIntoView?.({ block: 'nearest' });
    });
  }

  /** Global Cmd/Ctrl+K toggle — the shell binds this to a host keydown. */
  onGlobalHotkey(ev: KeyboardEvent): void {
    if ((ev.metaKey || ev.ctrlKey) && ev.key.toLowerCase() === 'k') {
      ev.preventDefault();
      this.toggle();
    }
  }

  /** Open/close the palette directly (e.g. a top-bar Cmd+K button). */
  toggle(): void {
    this.open.update((v) => !v);
    this.query.set('');
    this.active.set(0);
  }

  protected setOpen(v: boolean): void {
    this.open.set(v);
  }
  onQuery(ev: Event): void {
    this.query.set((ev.target as HTMLInputElement).value);
    this.active.set(0);
  }
  onKey(ev: KeyboardEvent): void {
    const list = this.filtered();
    const last = Math.max(0, list.length - 1);
    if (ev.key === 'ArrowDown') {
      ev.preventDefault();
      this.active.update((i) => Math.min(i + 1, last));
    } else if (ev.key === 'ArrowUp') {
      ev.preventDefault();
      this.active.update((i) => Math.max(i - 1, 0));
    } else if (ev.key === 'Home') {
      ev.preventDefault();
      this.active.set(0);
    } else if (ev.key === 'End') {
      ev.preventDefault();
      this.active.set(last);
    } else if (ev.key === 'Enter') {
      ev.preventDefault();
      const cmd = list[this.active()];
      if (cmd) this.choose(cmd);
    }
  }
  protected choose(cmd: PaletteCommand): void {
    this.run.emit(cmd);
    this.open.set(false);
  }
  protected rowClass(isActive: boolean): string {
    return `flex cursor-pointer items-center gap-2 rounded-md px-3 py-2 text-sm ${
      isActive ? 'bg-accent text-accent-foreground' : 'text-foreground'
    }`;
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'command-palette-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
