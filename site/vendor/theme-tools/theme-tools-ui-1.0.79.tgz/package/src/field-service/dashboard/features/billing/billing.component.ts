import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * BillingComponent — tab shell for the billing surface.
 *
 * Renders the section header + nav tabs and a <router-outlet> for each
 * child route. Mounts the billing tabs documented in `[[payments-routing]]`:
 * Stripe Billing owns recurring (≥2-of: seat/entitlements/usage/payouts)
 * while Square remains the rail for accepting customer money.
 */
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { HlmButton } from '../../shared/ui-spartan';
import { AuthService } from '../../core/auth.service';
import { RovingTablistDirective } from '../_shared/roving-tablist.directive';

@Component({
  selector: 'app-billing',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, HlmButton, RovingTablistDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="mb-4">
      <h1 class="text-2xl font-bold text-foreground">Billing</h1>
      <p class="text-sm text-muted-foreground">
        Your hourly rate &amp; contract, invoices, payment methods, and per-job receipts.
      </p>
    </header>

    @if (needsAuth()) {
      <!--
        /dashboard/billing has no role guard, so the shell renders for guests.
        Mounting the tab outlet would fire five authed /api/billing/* fetches
        the worker 401s. Show a sign-in affordance instead — no authed request.
      -->
      <div class="rounded-xl border border-dashed border-border p-10 text-center" data-testid="billing-signin">
        <p class="text-2xl" aria-hidden="true">🧾</p>
        <p class="mt-2 text-base font-semibold text-foreground">Sign in to see your billing</p>
        <p class="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
          Log in to view your hourly rate, contract, invoices, payment methods, and per-job receipts.
        </p>
        <a hlmBtn class="mt-4" [routerLink]="['/login']" [queryParams]="{ as: 'customer', next: '/billing' }">
          Sign in →
        </a>
      </div>
    } @else {
      <nav
        class="mb-6 flex flex-wrap gap-1 border-b border-border"
        role="tablist"
        bclRovingTablist
        aria-label="Billing sections"
      >
        @for (tab of tabs; track tab.path) {
          <a
            #billTab="routerLinkActive"
            [routerLink]="tab.path === '' ? ['.'] : ['.', tab.path]"
            [routerLinkActiveOptions]="{ exact: tab.path === '' }"
            routerLinkActive="border-primary text-foreground"
            class="-mb-px border-b-2 border-transparent px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            role="tab"
            [attr.aria-selected]="billTab.isActive"
          >
            {{ tab.label }}
          </a>
        }
      </nav>
      <router-outlet />
    }
  `,
})
export class BillingComponent {
  private readonly auth = inject(AuthService);
  protected readonly needsAuth = computed(() => !this.auth.authenticated());

  // No "Plan" tab — Brick Labor bills hourly + via recurring hourly contracts,
  // not SaaS subscription plans. Recurring contracts live on /recurring.
  readonly tabs = [
    { path: '', label: 'Overview' },
    { path: 'invoices', label: 'Invoices' },
    { path: 'payment-methods', label: 'Payment methods' },
    { path: 'receipts', label: 'Receipts' },
  ] as const;
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'billing-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
