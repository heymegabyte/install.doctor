import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * PastBookingsComponent — GP-08 unified "Past" history
 * (flag: past_bookings_unified, dark by default).
 *
 * ONE reverse-chronological list that interweaves the caller's past
 * customer-bookings AND the gigs they worked as crew. Each row is identical in
 * layout; the ONLY differentiator is a role badge — "as Crew" (brand orange) or
 * "as Customer" (neutral) — so a dual-role person (customer + crew) sees a
 * single, simple history that serves both personas at once. Tapping a row opens
 * the relevant detail: customer → /bookings/:id, crew → /jobs/:id.
 *
 * Self-scoped: the service fetches the customer branch only when signed in and
 * the crew branch only when the active persona is crew (or a super-admin viewing
 * crew), so no endpoint is fired that would 401, and one user's list can never
 * contain another's rows. 4-state via <app-state-block>; strictTemplates-safe
 * (every template read is guarded / off a pure helper). RxJS-first: the fetch
 * stream is bridged to a signal at the boundary, never inside the service.
 */
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { of, startWith, switchMap } from 'rxjs';
import { HlmBadge, StateBlockComponent, type SurfaceState } from '../../shared/ui-spartan';
import { fadeUpItem, listStagger, routeFade, reducedMotion } from '../../shared/animations';
import { statusBadge } from '@theme.tools/crm/field-service/status-badge';
import { ReceivedRatingComponent } from '../_shared/received-rating.component';
import { AuthService } from '../../core/auth.service';
import { RoleService } from '../../core/role.service';
import {
  PastBookingsService,
  pastDate,
  pastDetailLink,
  pastMoney,
  type PastBookingRow,
  type PastBookingsResult,
} from '../../core/past-bookings.service';

interface ViewState {
  readonly state: SurfaceState;
  readonly items: readonly PastBookingRow[];
  readonly error: string;
}

@Component({
  selector: 'app-past-bookings',
  standalone: true,
  imports: [HlmBadge, StateBlockComponent, RouterLink, ReceivedRatingComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [listStagger, fadeUpItem, routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header class="mb-6">
      <div class="flex flex-wrap items-center justify-between gap-3">
        <h1 class="text-2xl font-bold text-foreground">Past</h1>
        <!-- GP-07: your received reputation across these jobs. Self-gated on the
             mutual_ratings flag — renders nothing while dark. -->
        <bcl-received-rating />
      </div>
      <p class="mt-1 text-sm text-muted-foreground">
        Every wrapped-up job — the ones you booked and the ones you worked — in one place.
      </p>
    </header>

    <app-state-block
      [state]="view().state"
      [errorDetail]="view().error"
      errorTitle="Couldn't load your history"
      emptyTitle="No past jobs yet"
      emptyHint="Once a job wraps up, it lands here — badged by whether you booked it or worked it."
      (retry)="reload()"
    >
      <ul class="space-y-2" [@listStagger]="view().items.length" [@.disabled]="reducedMotion()">
        @for (b of view().items; track b.role + ':' + b.id) {
          <li [@fadeUpItem]>
            <a
              [routerLink]="detailLink(b)"
              class="block min-h-[44px] rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              [attr.data-testid]="'past-row-' + b.role + '-' + b.id"
            >
              <div class="flex items-start justify-between gap-3">
                <div class="min-w-0 flex-1">
                  <div class="mb-1 flex flex-wrap items-center gap-2">
                    <!-- The ONE differentiator: role badge. Crew = brand orange, customer = neutral. -->
                    @if (b.role === 'crew') {
                      <span
                        class="inline-flex min-h-[24px] items-center rounded-full bg-bcl-accent/15 px-2.5 py-0.5 text-xs font-semibold text-bcl-accent ring-1 ring-bcl-accent/30"
                        data-testid="role-badge-crew"
                      >
                        as Crew
                      </span>
                    } @else {
                      <span
                        class="inline-flex min-h-[24px] items-center rounded-full bg-muted px-2.5 py-0.5 text-xs font-semibold text-muted-foreground ring-1 ring-border"
                        data-testid="role-badge-customer"
                      >
                        as Customer
                      </span>
                    }
                    <span hlmBadge [variant]="badge(b.status).variant">{{
                      badge(b.status).label
                    }}</span>
                  </div>
                  <p class="truncate text-sm font-medium text-foreground">{{ b.service }}</p>
                  <p class="mt-1 truncate text-xs text-muted-foreground">
                    {{ dateOf(b.whenMs) }} · {{ b.subtitle }}
                  </p>
                </div>
                <div class="flex flex-col items-end gap-1">
                  <p class="font-mono text-base tabular-nums text-primary">
                    {{ money(b.amountCents) }}
                  </p>
                  <p class="text-[11px] uppercase tracking-wide text-muted-foreground">
                    {{ b.amountLabel }}
                  </p>
                </div>
              </div>
            </a>
          </li>
        }
      </ul>
    </app-state-block>
  `,
})
export class PastBookingsComponent {
  private readonly svc = inject(PastBookingsService);
  private readonly auth = inject(AuthService);
  private readonly roleSvc = inject(RoleService);

  /** Bound to host [@.disabled] — skips the route fade for reduced-motion users. */
  protected readonly reducedMotion = reducedMotion;

  protected readonly badge = statusBadge;
  protected readonly money = pastMoney;
  protected readonly dateOf = pastDate;
  protected readonly detailLink = pastDetailLink;

  /** Manual reload nonce — bump to re-fire the stream after an error retry. */
  private readonly reloadTick = signal(0);

  /**
   * Which branches this persona can have. Customer branch when authenticated;
   * crew branch when the active view-as is crew (a super-admin viewing crew
   * still has no worker cookie, so the crew fetch simply degrades to empty —
   * harmless). Gating here keeps us from firing an endpoint that would 401.
   */
  private readonly includeCustomer = computed(() => this.auth.authenticated());
  private readonly includeCrew = computed(() => this.roleSvc.viewAs() === 'crew');

  private readonly source$ = toObservable(
    computed(() => ({
      customer: this.includeCustomer(),
      crew: this.includeCrew(),
      tick: this.reloadTick(),
    })),
  );

  protected readonly view = toSignal(
    this.source$.pipe(
      switchMap(({ customer, crew }) => {
        // Signed out AND not crew → nothing to fetch; show the empty launchpad.
        if (!customer && !crew) {
          return of<ViewState>({ state: 'empty', items: [], error: '' });
        }
        return this.svc.history$(customer, crew).pipe(
          switchMap((r: PastBookingsResult) =>
            of<ViewState>(
              r.ok
                ? {
                    state: r.items.length ? 'ready' : 'empty',
                    items: r.items,
                    error: '',
                  }
                : {
                    state: 'error',
                    items: [],
                    error: r.error === 'unauthorized' ? 'Sign in to see your history.' : '',
                  },
            ),
          ),
          startWith<ViewState>({ state: 'loading', items: [], error: '' }),
        );
      }),
    ),
    { initialValue: { state: 'loading', items: [], error: '' } as ViewState },
  );

  protected reload(): void {
    this.reloadTick.update((n) => n + 1);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'past-bookings-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
