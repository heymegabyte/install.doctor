import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * TipDialogComponent — modal with 15 / 20 / 25 % presets + custom amount.
 *
 * Posts to /api/tips/add with `{ rideId, amountCents }`. Closes on success.
 *
 * A real ARIA APG modal dialog: CDK `cdkTrapFocus` + `cdkTrapFocusAutoCapture`
 * moves focus INTO the panel on open, traps Tab/Shift+Tab inside, and restores
 * focus to the trigger on close; Esc closes; body scroll locks while it covers
 * the viewport. axe-core is blind to every one of those interaction gaps, so the
 * behavior spec is the only guard. This is the live-dashboard counterpart of the
 * React `use-dialog-a11y` kit (extend-the-platform-primitive, not a parallel one).
 */
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  input,
  output,
  signal,
} from '@angular/core';
import { A11yModule } from '@angular/cdk/a11y';
import { FormsModule } from '@angular/forms';
import { focusRadioAtIndex, nextRadioIndex, rovingTabIndex } from '@theme.tools/i18n-a11y/field-service/radio-keynav';

@Component({
  selector: 'bcl-tip-dialog',
  standalone: true,
  imports: [FormsModule, A11yModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (open()) {
      <div
        class="fixed inset-0 z-50 flex items-end justify-center bg-bcl-bg/80 backdrop-blur-sm sm:items-center"
        role="dialog"
        aria-modal="true"
        aria-labelledby="tip-title"
        (click)="onScrim($event)"
        (keydown.escape)="closed.emit()"
      >
        <div
          cdkTrapFocus
          [cdkTrapFocusAutoCapture]="true"
          class="w-full max-w-md rounded-t-3xl bg-bcl-bg-elev p-6 ring-1 ring-bcl-border sm:rounded-2xl"
          style="padding-bottom: max(1.5rem, env(safe-area-inset-bottom));"
        >
          <h2 id="tip-title" class="text-lg font-semibold text-bcl-ink">Leave a tip</h2>
          <p class="mt-1 text-sm text-bcl-ink-muted">
            Subtotal {{ formatMoney(subtotalCents()) }} · 100% goes to your crew.
          </p>

          <div
            class="mt-5 grid grid-cols-3 gap-3"
            role="radiogroup"
            aria-label="Tip percentage"
            (keydown)="onPresetKey($event)"
          >
            @for (p of presets; track p; let i = $index) {
              <button
                type="button"
                role="radio"
                [attr.aria-checked]="!custom() && percent() === p"
                [attr.tabindex]="rove(i)"
                (click)="setPercent(p)"
                class="min-h-[44px] rounded-lg px-4 text-sm font-semibold ring-1 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                [class.bg-bcl-accent]="!custom() && percent() === p"
                [class.text-bcl-bg]="!custom() && percent() === p"
                [class.ring-bcl-accent]="!custom() && percent() === p"
                [class.bg-bcl-bg]="custom() || percent() !== p"
                [class.text-bcl-ink]="custom() || percent() !== p"
                [class.ring-bcl-border]="custom() || percent() !== p"
              >
                <span class="block text-base">{{ p }}%</span>
                <span class="block text-xs opacity-70">{{ formatMoney(computeCents(p)) }}</span>
              </button>
            }
          </div>

          <label class="mt-4 block">
            <span class="text-xs uppercase tracking-wider text-bcl-ink-muted">Custom</span>
            <input
              type="number"
              inputmode="decimal"
              min="0"
              step="0.50"
              [(ngModel)]="customDollars"
              (focus)="custom.set(true)"
              class="mt-1 min-h-[44px] w-full rounded-lg bg-bcl-bg px-3 text-base text-bcl-ink ring-1 ring-bcl-border focus:outline-none focus:ring-bcl-accent"
              aria-label="Custom tip amount in dollars"
              placeholder="0.00"
            />
          </label>

          @if (error(); as e) {
            <p class="mt-4 rounded-lg bg-bcl-bg px-3 py-2 text-sm text-bcl-ink ring-1 ring-bcl-border" role="alert">
              {{ e }}
            </p>
          }

          <div class="mt-6 flex gap-3">
            <button
              type="button"
              (click)="closed.emit()"
              [disabled]="pending()"
              class="min-h-[44px] flex-1 rounded-lg bg-bcl-bg-elev px-4 text-sm font-semibold text-bcl-ink ring-1 ring-bcl-border disabled:opacity-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            >
              Cancel
            </button>
            <button
              type="button"
              (click)="submit()"
              [disabled]="pending() || tipCents() <= 0"
              class="min-h-[44px] flex-1 rounded-lg bg-bcl-accent px-4 text-sm font-semibold text-bcl-bg disabled:opacity-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            >
              Send {{ formatMoney(tipCents()) }}
            </button>
          </div>
        </div>
      </div>
    }
  `,
})
export class TipDialogComponent {
  readonly open = input.required<boolean>();
  readonly rideId = input.required<string>();
  readonly subtotalCents = input<number>(0);

  readonly closed = output<void>();
  readonly tipped = output<{ rideId: string; amountCents: number }>();

  constructor() {
    // Lock body scroll while the full-screen tip dialog covers the viewport;
    // restore it when it closes. Mirrors the React `useBodyScrollLock` kit.
    effect(() => {
      if (typeof document === 'undefined') return;
      document.body.style.overflow = this.open() ? 'hidden' : '';
    });
  }

  readonly presets = [15, 20, 25] as const;
  readonly percent = signal<15 | 20 | 25>(20);
  readonly custom = signal<boolean>(false);
  readonly pending = signal<boolean>(false);
  readonly error = signal<string | null>(null);
  customDollars: number | null = null;

  readonly tipCents = computed(() => {
    if (this.custom() && this.customDollars !== null) {
      return Math.max(0, Math.round(this.customDollars * 100));
    }
    return this.computeCents(this.percent());
  });

  setPercent(p: 15 | 20 | 25): void {
    this.percent.set(p);
    this.custom.set(false);
  }

  /**
   * Index of the selected preset — the single tab stop for the radiogroup. Stays
   * a valid index even in custom mode (the last preset remains tracked), so the
   * group always has exactly one keyboard entry point per the ARIA pattern.
   */
  readonly activeIndex = computed(() => this.presets.indexOf(this.percent()));

  /** Roving tabindex for the preset at `i`: 0 for the active preset, else -1. */
  rove(i: number): 0 | -1 {
    return rovingTabIndex(i, this.activeIndex());
  }

  /**
   * ARIA radio-group arrow/Home/End navigation across the tip presets. axe-core
   * cannot see this interaction-pattern gap, so it's locked by a behavior spec;
   * arrowing also clears custom mode (setPercent) so selection + focus stay in sync.
   */
  onPresetKey(event: KeyboardEvent): void {
    const next = nextRadioIndex(this.activeIndex(), this.presets.length, event.key);
    if (next === null) return;
    event.preventDefault();
    const preset = this.presets[next];
    if (preset === undefined) return;
    this.setPercent(preset);
    focusRadioAtIndex(event.currentTarget as HTMLElement, next);
  }

  computeCents(percent: number): number {
    return Math.round(this.subtotalCents() * (percent / 100));
  }

  formatMoney(cents: number): string {
    return `$${(cents / 100).toFixed(2)}`;
  }

  onScrim(ev: MouseEvent): void {
    if (ev.target === ev.currentTarget) this.closed.emit();
  }

  async submit(): Promise<void> {
    if (this.pending()) return;
    const amountCents = this.tipCents();
    if (amountCents <= 0) return;
    this.pending.set(true);
    this.error.set(null);
    try {
      // fetch() does NOT throw on 4xx/5xx — must inspect res.ok, or a failed
      // tip would emit a FALSE success (dialog closes, nothing charged).
      const res = await fetch('/api/tips/add', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rideId: this.rideId(), amountCents }),
      });
      if (!res.ok) {
        // /api/tips/add settles the tip through the crew payout ledger. A 404 /
        // 409 only happens on an old client or a trip with no settleable crew —
        // degrade honestly instead of pretending the tip went through.
        this.error.set(
          res.status === 404 || res.status === 409
            ? 'Online tipping isn’t available for this trip — please mention your crew in your review and we’ll make sure they’re recognized.'
            : 'Couldn’t process that tip. Please try again.',
        );
        return;
      }
      this.tipped.emit({ rideId: this.rideId(), amountCents });
      this.closed.emit();
    } catch {
      this.error.set('Connection issue. Please try again.');
    } finally {
      this.pending.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'tip-dialog-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
