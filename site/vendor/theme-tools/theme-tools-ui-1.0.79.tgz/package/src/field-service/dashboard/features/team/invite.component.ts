import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * TeamInviteComponent — typed Reactive Form to send an invite. Server
 * errors surface inline via the form-field error slot.
 */
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import {
  HlmCardImports,
  HlmButton,
  HlmInput,
  HlmFormField,
  HlmSpinner,
} from '../../shared/ui-spartan';
import { TeamService } from './team.service';
import type { BclRole } from '../_shared/role-badge.component';

interface InviteFormShape {
  readonly email: FormControl<string>;
  readonly role: FormControl<BclRole>;
}

@Component({
  selector: 'app-team-invite',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, HlmInput, HlmFormField, HlmSpinner, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard>
      <div hlmCardHeader>
        <h3 hlmCardTitle>Invite a member</h3>
        <p hlmCardDescription>They'll receive an email with a one-time link.</p>
      </div>
      <div hlmCardContent>
        <form [formGroup]="form" (ngSubmit)="submit()" class="grid gap-4 md:max-w-md">
          <app-form-field label="Email">
            <input
              hlmInput
              id="invite-email"
              type="email"
              autocomplete="off"
              formControlName="email"
              placeholder="teammate@example.com"
            />
          </app-form-field>
          <app-form-field label="Role">
            <select
              hlmInput
              id="invite-role"
              formControlName="role"
              class="h-10 w-full"
            >
              <option value="owner">Owner</option>
              <option value="admin">Admin</option>
              <option value="member">Member</option>
              <option value="viewer">Viewer</option>
              <option value="customer">Customer</option>
              <option value="crew">Crew</option>
              <option value="super_admin">Super Admin</option>
            </select>
          </app-form-field>
          @if (submitError(); as e) {
            <p class="text-sm text-destructive" role="alert">{{ e }}</p>
          }
          <div class="flex gap-2">
            <button hlmBtn type="submit" [disabled]="form.invalid || submitting()">
              @if (submitting()) { <app-spinner [size]="16" /> Sending… } @else { Send invite }
            </button>
          </div>
        </form>
      </div>
    </div>
  `,
})
export class TeamInviteComponent {
  private readonly svc = inject(TeamService);
  private readonly router = inject(Router);

  readonly submitting = signal<boolean>(false);
  readonly submitError = signal<string | null>(null);

  readonly form = new FormGroup<InviteFormShape>({
    email: new FormControl<string>('', {
      nonNullable: true,
      validators: [Validators.required, Validators.email],
    }),
    role: new FormControl<BclRole>('member', {
      nonNullable: true,
      validators: [Validators.required],
    }),
  });

  async submit(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitting.set(true);
    this.submitError.set(null);
    const { email, role } = this.form.getRawValue();
    try {
      await this.svc.invite(email, role);
      void this.router.navigate(['/team']);
    } catch (e) {
      this.submitError.set(e instanceof Error ? e.message : 'Invite failed');
    } finally {
      this.submitting.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'invite-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
