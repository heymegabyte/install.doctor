import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SqlCopilotComponent — AI NL→SQL assistant at /admin/sql-copilot.
 *
 * Surfaces /api/super-admin/sql-copilot: describe a question in English → AI drafts
 * a SAFE SELECT (UNSAFE blocked server-side) → review → run (confirm-hash gated,
 * LIMIT 200) → results table. Complements the raw /admin/sql for operators who'd
 * rather ask than write SQL. Auth migrated bearer-only → ownerOrSuperAdmin 2026-06-07.
 */
import { ChangeDetectionStrategy, Component, type OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HlmCardImports } from '../../shared/ui-spartan';

interface DraftResponse {
  readonly ok: boolean;
  readonly sql?: string;
  readonly explanation?: string;
  readonly estimatedRowCount?: number | null;
  readonly warnings?: readonly string[];
  readonly confirmHash?: string;
  readonly error?: string;
}

interface RunResponse {
  readonly ok: boolean;
  readonly columns?: readonly string[];
  readonly rows?: readonly (readonly unknown[])[];
  readonly rowCount?: number;
  readonly truncated?: boolean;
  readonly error?: string;
}

interface SavedQuery {
  readonly id: string;
  readonly name: string;
  readonly sql: string;
  readonly chart_type?: string;
}
interface TableInfo {
  readonly name: string;
  readonly rowCount: number;
  readonly columns: readonly string[];
}
interface HistoryEntry {
  readonly id: string;
  readonly executedAt: string;
  readonly sql: string;
  readonly rowCount: number;
  readonly executionMs: number;
}

/** SHA-256 of `s`, first 12 hex chars — matches the worker's confirm-hash. */
async function sha256Hex12(s: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
  return [...new Uint8Array(buf)]
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
    .slice(0, 12);
}

@Component({
  selector: 'app-admin-sql-copilot',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [...HlmCardImports, FormsModule],
  template: `
    <header class="mb-4">
      <h1 class="text-2xl font-bold text-foreground">SQL copilot</h1>
      <p class="text-sm text-muted-foreground">
        Ask in plain English → AI drafts a safe read-only SELECT → review → run.
      </p>
    </header>

    <div hlmCard class="mb-4 p-4">
      <label class="block text-xs text-muted-foreground" for="q">Question</label>
      <textarea
        id="q"
        rows="2"
        class="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground"
        placeholder="e.g. top 10 cities by completed jobs in the last 30 days"
        [(ngModel)]="query"
      ></textarea>
      <div class="mt-2 flex justify-end">
        <button
          type="button"
          class="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
          [disabled]="drafting() || query().trim().length < 3"
          (click)="draft()"
        >
          {{ drafting() ? 'Drafting…' : 'Draft SQL' }}
        </button>
      </div>
    </div>

    @if (saved().length > 0) {
      <div hlmCard class="mb-4 flex flex-wrap items-center gap-2 p-3">
        <span class="text-xs text-muted-foreground">Saved queries:</span>
        @for (q of saved(); track q.id) {
          <button
            type="button"
            class="rounded-full border border-border px-3 py-1 text-xs text-foreground hover:border-primary hover:text-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            (click)="loadSaved(q)"
          >
            {{ q.name }}
          </button>
        }
      </div>
    }

    <div class="mb-4 flex gap-2">
      <button
        type="button"
        class="rounded-md border border-border px-3 py-1.5 text-xs text-muted-foreground hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        (click)="toggleSchema()"
      >
        {{ schemaOpen() ? 'Hide tables' : 'Browse tables' }}
      </button>
      <button
        type="button"
        class="rounded-md border border-border px-3 py-1.5 text-xs text-muted-foreground hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        (click)="toggleHistory()"
      >
        {{ historyOpen() ? 'Hide recent' : 'Recent runs' }}
      </button>
    </div>

    @if (schemaOpen()) {
      <div hlmCard class="mb-4 max-h-72 overflow-y-auto p-3">
        @if (schemaLoading()) {
          <p class="text-xs text-muted-foreground">Loading tables…</p>
        } @else if (schemaError(); as err) {
          <div class="flex items-center justify-between gap-3" role="alert">
            <p class="text-xs text-destructive">Couldn't load the schema — {{ err }}</p>
            <button
              type="button"
              (click)="loadSchema()"
              class="rounded-md border border-border px-3 py-1 text-xs text-muted-foreground hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            >
              Try again
            </button>
          </div>
        } @else {
          <div class="grid gap-2 sm:grid-cols-2">
            @for (t of tables(); track t.name) {
              <div class="rounded-md border border-border/50 p-2">
                <div class="flex items-baseline justify-between gap-2">
                  <span class="font-mono text-xs font-semibold text-foreground">{{ t.name }}</span>
                  <span class="font-mono text-[11px] text-muted-foreground tabular-nums">{{ t.rowCount }} rows</span>
                </div>
                <ul aria-label="Columns" class="mt-1.5 flex flex-wrap gap-1">
                  @for (col of t.columns; track col) {
                    <li class="rounded-full bg-bcl-bg-elev px-2 py-0.5 font-mono text-[10px] text-bcl-ink-muted ring-1 ring-bcl-border/60 transition-colors duration-[333ms] hover:text-bcl-ink">{{ col }}</li>
                  }
                </ul>
              </div>
            }
          </div>
        }
      </div>
    }

    @if (historyOpen()) {
      <div hlmCard class="mb-4 max-h-72 overflow-y-auto p-0">
        @if (historyLoading()) {
          <p class="p-3 text-xs text-muted-foreground">Loading recent runs…</p>
        } @else if (historyError(); as err) {
          <div class="flex items-center justify-between gap-3 p-3" role="alert">
            <p class="text-xs text-destructive">Couldn't load recent runs — {{ err }}</p>
            <button
              type="button"
              (click)="refreshHistory()"
              class="rounded-md border border-border px-3 py-1 text-xs text-muted-foreground hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            >
              Try again
            </button>
          </div>
        } @else if (history().length === 0) {
          <p class="p-3 text-xs text-muted-foreground">No recent runs.</p>
        } @else {
          @for (h of history(); track h.id) {
            <button
              type="button"
              class="block w-full border-b border-border/40 p-2.5 text-left hover:bg-primary/5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              (click)="loadHistory(h)"
            >
              <div class="truncate font-mono text-xs text-foreground">{{ h.sql }}</div>
              <div class="mt-0.5 text-[11px] text-muted-foreground">{{ h.rowCount }} rows · {{ h.executionMs }}ms</div>
            </button>
          }
        }
      </div>
    }

    @if (error(); as e) {
      <div hlmCard class="mb-4 p-4"><p class="text-sm text-destructive">{{ e }}</p></div>
    }

    @if (sql(); as s) {
      <div hlmCard class="mb-4 p-4">
        @if (explanation()) { <p class="mb-2 text-sm text-muted-foreground">{{ explanation() }}</p> }
        <pre class="overflow-x-auto rounded-md bg-background p-3 font-mono text-xs text-foreground ring-1 ring-border">{{ s }}</pre>
        @if (warnings().length > 0) {
          <div class="mt-2 flex flex-wrap gap-1.5">
            @for (w of warnings(); track w) {
              <span class="rounded-full bg-bcl-warn/10 px-2 py-0.5 text-xs text-bcl-warn ring-1 ring-bcl-warn/30 transition-colors duration-[333ms]">{{ w }}</span>
            }
          </div>
        }
        <div class="mt-3 flex justify-end gap-2">
          <button
            type="button"
            class="rounded-md border border-border px-4 py-2 text-sm text-muted-foreground hover:bg-muted/40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring disabled:opacity-50"
            [disabled]="saving()"
            (click)="save()"
          >
            {{ saving() ? 'Saving…' : 'Save query' }}
          </button>
          <button
            type="button"
            class="rounded-md border border-border px-4 py-2 text-sm text-primary hover:bg-primary/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring disabled:opacity-50"
            [disabled]="running()"
            (click)="run()"
          >
            {{ running() ? 'Running…' : 'Run (read-only, LIMIT 200)' }}
          </button>
        </div>
      </div>
    }

    @if (columns().length > 0) {
      <div hlmCard class="overflow-x-auto p-0">
        <table class="w-full text-left text-sm">
          <thead class="border-b border-border bg-background">
            <tr>
              @for (c of columns(); track c) { <th class="px-3 py-2 font-mono text-xs text-muted-foreground">{{ c }}</th> }
            </tr>
          </thead>
          <tbody>
            @for (row of rows(); track $index) {
              <tr class="border-b border-border/50">
                @for (cell of row; track $index) { <td class="px-3 py-1.5 font-mono text-xs text-foreground">{{ fmt(cell) }}</td> }
              </tr>
            }
          </tbody>
        </table>
        <div class="flex items-center justify-between gap-3 px-3 py-2">
          <p class="text-xs text-muted-foreground">
            {{ rowCount() }} row{{ rowCount() === 1 ? '' : 's' }}{{ truncated() ? ' (truncated at 200)' : '' }}
          </p>
          <button
            type="button"
            (click)="copyCsv()"
            data-testid="sql-copy-csv"
            class="shrink-0 rounded-md border border-border px-2.5 py-1 text-xs text-muted-foreground transition-colors hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
          >
            {{ copied() ? 'Copied ✓' : 'Copy CSV' }}
          </button>
        </div>
        <span class="sr-only" role="status" aria-live="polite">{{
          copied() ? 'Copied ' + rows().length + ' rows as CSV' : ''
        }}</span>
      </div>
    }
  `,
})
export class SqlCopilotComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly saved = signal<readonly SavedQuery[]>([]);
  readonly saving = signal<boolean>(false);
  readonly tables = signal<readonly TableInfo[]>([]);
  readonly history = signal<readonly HistoryEntry[]>([]);
  readonly schemaOpen = signal<boolean>(false);
  readonly schemaLoading = signal<boolean>(false);
  readonly schemaError = signal<string | null>(null);
  readonly historyOpen = signal<boolean>(false);
  readonly historyLoading = signal<boolean>(false);
  readonly historyError = signal<string | null>(null);
  readonly query = signal<string>('');
  readonly sql = signal<string | null>(null);
  readonly explanation = signal<string>('');
  readonly warnings = signal<readonly string[]>([]);
  readonly confirmHash = signal<string>('');
  readonly columns = signal<readonly string[]>([]);
  readonly rows = signal<readonly (readonly unknown[])[]>([]);
  readonly rowCount = signal<number>(0);
  readonly truncated = signal<boolean>(false);
  readonly drafting = signal<boolean>(false);
  readonly running = signal<boolean>(false);
  readonly error = signal<string | null>(null);

  fmt(v: unknown): string {
    return v == null ? '∅' : String(v);
  }

  /** Copied-✓ affordance for the CSV export (auto-resets; announced via a polite live region). */
  readonly copied = signal<boolean>(false);
  private copiedTimer: ReturnType<typeof setTimeout> | undefined;

  /** Export the current result set as RFC4180 CSV to the clipboard (operators couldn't get the
   * data out except by hand-selecting mono-table cells). Flips a copied-✓ label on success. */
  async copyCsv(): Promise<void> {
    try {
      await navigator.clipboard.writeText(resultsToCsv(this.columns(), this.rows()));
      this.copied.set(true);
      if (this.copiedTimer) clearTimeout(this.copiedTimer);
      this.copiedTimer = setTimeout(() => this.copied.set(false), 2500);
    } catch {
      /* clipboard blocked (insecure ctx / permissions) — leave the button idle, no false ✓ */
    }
  }

  ngOnInit(): void {
    void this.refreshSaved();
  }

  private async refreshSaved(): Promise<void> {
    const r = await firstValueFrom(
      this.http
        .get<{ ok?: boolean; queries?: SavedQuery[] }>('/api/admin/widgets/saved-queries', {
          withCredentials: true,
        })
        .pipe(catchError(() => of({ ok: false } as { ok?: boolean; queries?: SavedQuery[] }))),
    );
    if (r.ok && Array.isArray(r.queries)) this.saved.set(r.queries);
  }

  async toggleSchema(): Promise<void> {
    const open = !this.schemaOpen();
    this.schemaOpen.set(open);
    if (open && this.tables().length === 0) await this.loadSchema();
  }

  /**
   * Fetch the Browse-tables schema. Separate method so the error state can retry — the drawer used to
   * show "Loading tables…" FOREVER on a fetch failure (tables stayed [] with no error/loading signal).
   */
  async loadSchema(): Promise<void> {
    this.schemaLoading.set(true);
    this.schemaError.set(null);
    const r = await firstValueFrom(
      this.http
        .get<{ ok?: boolean; tables?: TableInfo[]; error?: string }>(
          '/api/super-admin/sql-copilot/schema/tables',
          { withCredentials: true },
        )
        .pipe(
          catchError((e: { error?: { error?: string } }) =>
            of({ ok: false, error: e?.error?.error } as {
              ok?: boolean;
              tables?: TableInfo[];
              error?: string;
            }),
          ),
        ),
    );
    this.schemaLoading.set(false);
    if (r.ok && Array.isArray(r.tables)) this.tables.set(r.tables);
    else this.schemaError.set(r.error ?? 'Could not load the schema. Try again.');
  }

  async toggleHistory(): Promise<void> {
    const open = !this.historyOpen();
    this.historyOpen.set(open);
    if (open) await this.refreshHistory();
  }

  /**
   * Fetch the recent-runs list. Separate method so the error state can retry — the drawer used to show
   * "No recent runs." on BOTH a genuinely-empty history AND a fetch failure (history stayed [] with no
   * error signal), masking a failed load as "nothing yet". (`loadHistory(h)` loads a single entry.)
   */
  async refreshHistory(): Promise<void> {
    this.historyLoading.set(true);
    this.historyError.set(null);
    const r = await firstValueFrom(
      this.http
        .get<{ ok?: boolean; history?: HistoryEntry[]; error?: string }>(
          '/api/super-admin/sql-copilot/history',
          { withCredentials: true },
        )
        .pipe(
          catchError((e: { error?: { error?: string } }) =>
            of({ ok: false, error: e?.error?.error } as {
              ok?: boolean;
              history?: HistoryEntry[];
              error?: string;
            }),
          ),
        ),
    );
    this.historyLoading.set(false);
    if (r.ok && Array.isArray(r.history)) this.history.set(r.history);
    else this.historyError.set(r.error ?? 'Could not load recent runs. Try again.');
  }

  /** Save the drafted SQL for reuse (name via prompt). */
  async save(): Promise<void> {
    const sql = this.sql();
    if (!sql) return;
    const name = (globalThis.prompt('Name this query:') || '').trim();
    if (!name) return;
    this.saving.set(true);
    this.error.set(null);
    const r = await firstValueFrom(
      this.http
        .post<{ ok?: boolean; error?: string }>(
          '/api/admin/widgets/saved-queries/save',
          { name, sql, chart_type: 'table' },
          { withCredentials: true },
        )
        .pipe(catchError((e) => of({ ok: false, error: e?.error?.error ?? 'Save failed' }))),
    );
    this.saving.set(false);
    if (r.ok === false) {
      this.error.set(r.error ?? 'Save failed');
      return;
    }
    await this.refreshSaved();
  }

  /**
   * Load a saved query's SQL into the editor, ready to Run. The run endpoint is
   * confirm-hash gated (SHA-256 of the normalized SQL, first 12 hex) — we compute
   * the same hash client-side so a loaded query runs without re-drafting.
   */
  async loadSaved(q: SavedQuery): Promise<void> {
    const norm = q.sql.trim().replace(/;\s*$/, '');
    this.sql.set(norm);
    this.confirmHash.set(await sha256Hex12(norm));
    this.explanation.set(`Saved query: ${q.name}`);
    this.warnings.set([]);
    this.columns.set([]);
    this.error.set(null);
  }

  /** Load a recent run's SQL into the editor, ready to re-run. */
  async loadHistory(h: HistoryEntry): Promise<void> {
    await this.loadSaved({ id: h.id, name: 'recent run', sql: h.sql });
  }

  async draft(): Promise<void> {
    this.drafting.set(true);
    this.error.set(null);
    this.sql.set(null);
    this.columns.set([]);
    const r = await firstValueFrom(
      this.http
        .post<DraftResponse>('/api/super-admin/sql-copilot/draft', { query: this.query().trim() })
        .pipe(catchError(() => of({ ok: false, error: 'Draft failed' } as DraftResponse))),
    );
    this.drafting.set(false);
    if (r.ok && r.sql) {
      this.sql.set(r.sql);
      this.explanation.set(r.explanation ?? '');
      this.warnings.set(r.warnings ?? []);
      this.confirmHash.set(r.confirmHash ?? '');
    } else {
      this.error.set(r.error ?? 'Draft failed');
    }
  }

  async run(): Promise<void> {
    const sql = this.sql();
    if (!sql) return;
    this.running.set(true);
    this.error.set(null);
    const r = await firstValueFrom(
      this.http
        .post<RunResponse>('/api/super-admin/sql-copilot/run', { sql, confirmHash: this.confirmHash() })
        .pipe(catchError(() => of({ ok: false, error: 'Run failed' } as RunResponse))),
    );
    this.running.set(false);
    if (r.ok) {
      this.columns.set(r.columns ?? []);
      this.rows.set(r.rows ?? []);
      this.rowCount.set(r.rowCount ?? 0);
      this.truncated.set(r.truncated ?? false);
    } else {
      this.error.set(r.error ?? 'Run failed');
    }
  }
}

/** A single CSV cell (RFC4180): null/undefined → empty, objects → JSON, then quote if it
 * contains a comma / quote / newline (doubling internal quotes). Data-faithful — NOT the
 * display `fmt()` (which shows '∅' for null). */
export function csvCell(v: unknown): string {
  if (v === null || v === undefined) return '';
  const s = typeof v === 'object' ? JSON.stringify(v) : String(v);
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** Serialize a result set (header + rows) to RFC4180 CSV with CRLF line breaks. Header-only
 * when there are no rows. Pure + exported so the operator export is unit-tested. */
export function resultsToCsv(
  columns: readonly string[],
  rows: readonly (readonly unknown[])[],
): string {
  const head = columns.map(csvCell).join(',');
  if (rows.length === 0) return head;
  const body = rows.map((r) => r.map(csvCell).join(',')).join('\r\n');
  return `${head}\r\n${body}`;
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'sql-copilot-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
