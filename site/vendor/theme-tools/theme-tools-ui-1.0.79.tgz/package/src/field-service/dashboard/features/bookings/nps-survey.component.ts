import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
/**
 * NpsSurveyComponent — per-booking NPS capture (0–10 + comment) on the live
 * Angular /dashboard booking detail. Angular port of React `customer/NpsSurvey`.
 *
 * POST /api/nps-survey/submit { bookingId, score, comment? } → { ok, aiFollowupDraft? }.
 * Detractor (≤6) responses may carry an AI follow-up draft → surfaced for edit-and-send.
 * Rendered by booking-detail only for completed/review_requested bookings.
 *
 * Pure helpers categoryFor/isValidScore are unit-tested in nps-survey.component.spec.ts.
 */
import { ChangeDetectionStrategy, Component, computed, inject, input, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmCardImports, HlmButton } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { focusRadioAtIndex, nextRadioIndex, rovingTabIndex } from '@theme.tools/i18n-a11y/field-service/radio-keynav';

export type NpsCategory = 'detractor' | 'passive' | 'promoter';

interface SubmitResponse {
  readonly ok: boolean;
  readonly aiFollowupDraft?: string;
  readonly error?: string;
}

/** Pure: NPS-standard bucket for a 0–10 score. */
export function categoryFor(score: number): NpsCategory {
  if (score <= 6) return 'detractor';
  if (score <= 8) return 'passive';
  return 'promoter';
}

/** Pure: a valid NPS score is an integer 0–10. */
export function isValidScore(score: number | null): boolean {
  return score !== null && Number.isInteger(score) && score >= 0 && score <= 10;
}

@Component({
  selector: 'app-nps-survey',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard bclReveal data-testid="nps-survey">
      @if (done()) {
        <div hlmCardContent>
          <p class="font-mono text-[10px] uppercase tracking-widest text-bcl-accent">Thank you</p>
          <p class="mt-2 text-sm text-bcl-ink" aria-live="polite">
            Your feedback helps us pay the crews who earn it. We'll follow up if anything needs it.
          </p>
        </div>
      } @else {
        <div hlmCardHeader>
          <h3 hlmCardTitle>Rate your experience</h3>
          <p hlmCardDescription>How likely are you to recommend Brick Labor to a neighbor?</p>
        </div>
        <div hlmCardContent>
          <div
            role="radiogroup"
            aria-label="Score from 0 to 10"
            class="flex flex-wrap gap-1.5"
            (keydown)="onScoreKey($event)"
          >
            @for (n of scores; track n; let i = $index) {
              <button
                type="button"
                role="radio"
                [attr.aria-checked]="score() === n"
                [attr.tabindex]="rove(i)"
                (click)="score.set(n)"
                class="h-10 w-10 rounded-md border text-sm font-semibold transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                [class.border-bcl-danger]="score() === n && cat(n) === 'detractor'"
                [class.bg-bcl-danger\/15]="score() === n && cat(n) === 'detractor'"
                [class.text-bcl-danger]="score() === n && cat(n) === 'detractor'"
                [class.border-bcl-warn]="score() === n && cat(n) === 'passive'"
                [class.bg-bcl-warn\/15]="score() === n && cat(n) === 'passive'"
                [class.text-bcl-warn]="score() === n && cat(n) === 'passive'"
                [class.border-bcl-success]="score() === n && cat(n) === 'promoter'"
                [class.bg-bcl-success\/15]="score() === n && cat(n) === 'promoter'"
                [class.text-bcl-success]="score() === n && cat(n) === 'promoter'"
                [class.border-bcl-border]="score() !== n"
                [class.bg-bcl-bg]="score() !== n"
                [class.text-bcl-ink-muted]="score() !== n"
              >{{ n }}</button>
            }
          </div>
          <div class="mt-2 flex justify-between font-mono text-[9px] uppercase tracking-widest text-bcl-ink-muted">
            <span>Not likely</span><span>Very likely</span>
          </div>

          <label class="mt-4 block">
            <span class="font-mono text-[10px] uppercase tracking-widest text-bcl-ink-muted">Optional comment</span>
            <textarea
              [value]="comment()"
              (input)="comment.set($any($event.target).value)"
              rows="3"
              maxlength="500"
              placeholder="What went well, or what would have made it a 10?"
              class="mt-1 w-full rounded-md border border-bcl-border bg-bcl-bg px-3 py-2 text-sm text-bcl-ink placeholder:text-bcl-ink-muted focus:border-bcl-accent focus:outline-none"
            ></textarea>
          </label>

          @if (followup()) {
            <div class="mt-3 rounded-md border border-bcl-warn/40 bg-bcl-warn/5 p-3" aria-live="polite">
              <p class="font-mono text-[10px] uppercase tracking-widest text-bcl-warn">Suggested follow-up</p>
              <p class="mt-1 text-xs text-bcl-ink">We drafted a note to support so you don't have to retype. Edit above, then send.</p>
              <button hlmBtn class="mt-2" (click)="sendFollowup()">Send to support →</button>
            </div>
          }
          @if (error()) {
            <p role="alert" class="mt-3 text-xs text-destructive">{{ error() }}</p>
          }
          @if (!followup()) {
            <button hlmBtn class="mt-4" [disabled]="busy() || !valid()" (click)="submit()">
              {{ busy() ? 'Sending…' : 'Submit' }}
            </button>
          }
        </div>
      }
    </div>
  `,
})
export class NpsSurveyComponent {
  private readonly http = inject(HttpClient);

  readonly bookingId = input.required<string>();

  readonly scores = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  readonly cat = categoryFor;

  readonly score = signal<number | null>(null);
  readonly comment = signal('');
  readonly busy = signal(false);
  readonly error = signal('');
  readonly done = signal(false);
  readonly followup = signal<string | null>(null);

  /** Index of the tab stop: the chosen score, or 0 when nothing is picked yet. */
  private readonly activeIndex = computed(() => {
    const s = this.score();
    return s === null ? 0 : s;
  });

  /** Roving tabindex for the score at `i`: 0 for the active score, else -1. */
  rove(i: number): 0 | -1 {
    return rovingTabIndex(i, this.activeIndex());
  }

  /** ARIA radio-group arrow/Home/End navigation across the 0–10 scores. */
  onScoreKey(event: KeyboardEvent): void {
    const next = nextRadioIndex(this.activeIndex(), this.scores.length, event.key);
    if (next === null) return;
    event.preventDefault();
    const picked = this.scores[next];
    if (picked === undefined) return;
    this.score.set(picked);
    focusRadioAtIndex(event.currentTarget as HTMLElement, next);
  }

  valid(): boolean {
    return isValidScore(this.score());
  }

  async submit(): Promise<void> {
    const s = this.score();
    if (!isValidScore(s)) {
      this.error.set('Pick a number from 0 to 10.');
      return;
    }
    this.busy.set(true);
    this.error.set('');
    try {
      const r = await firstValueFrom(
        this.http.post<SubmitResponse>(
          '/api/nps-survey/submit',
          { bookingId: this.bookingId(), score: s, comment: this.comment().trim() || undefined },
          { withCredentials: true },
        ),
      );
      if (!r?.ok) {
        this.error.set(r?.error ?? 'Submit failed — try again.');
        return;
      }
      if (r.aiFollowupDraft && categoryFor(s as number) === 'detractor') {
        this.followup.set(r.aiFollowupDraft);
        if (!this.comment()) this.comment.set(r.aiFollowupDraft);
      } else {
        this.done.set(true);
      }
    } catch {
      this.error.set('Network error — try again.');
    } finally {
      this.busy.set(false);
    }
  }

  sendFollowup(): void {
    this.done.set(true);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'nps-survey-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
