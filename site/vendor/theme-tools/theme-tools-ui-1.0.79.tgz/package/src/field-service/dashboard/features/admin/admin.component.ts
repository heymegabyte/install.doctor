import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminComponent — live-ops dashboard, rebuilt on Spartan (Wave 5b-ii).
 *
 * Polls /api/admin/live-ops/metrics every 15s (active rides, online crew, surge,
 * KPIs) + /api/admin/live-ops/cancellations (hand-rolled SVG bar chart — no chart
 * lib). Rides render on the Spartan SmartTable (global filter + row-click → the
 * ride-supervisor HlmDialog). KPI tiles use the relocated rolling-counter; status
 * via HlmBadge + statusBadge; toasts via the ui-spartan ToastService.
 *
 * Router tabs link to /admin/flags + /admin/tenants (admin.routes.ts).
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  OnDestroy,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { DatePipe, DecimalPipe } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { type ColumnDef } from '@tanstack/angular-table';
import {
  HlmButton,
  HlmBadge,
  HlmDialog,
  HlmSkeleton,
  SmartTableComponent,
  ToastService,
  ConfirmDialog,
} from '../../shared/ui-spartan';
import { statusBadge } from '@theme.tools/crm/field-service/status-badge';
import { BclRollingCounterComponent } from '../_shared/rolling-counter.component';
import { RovingTablistDirective } from '../_shared/roving-tablist.directive';
import { routeFade, reducedMotion } from '../../shared/animations';

interface RideRow extends Record<string, unknown> {
  readonly ride_id: string;
  readonly state: string;
  readonly crew_name: string;
  readonly pickup: string;
  readonly customer_phone: string;
  readonly started_at: string;
}

interface MetricsResp {
  readonly ok: boolean;
  readonly metrics?: {
    readonly activeRides: number;
    readonly onlineCrew: number;
    readonly pendingOffers: number;
    readonly completedToday: number;
    readonly grossTodayCents: number;
    readonly surgeMultiplier: number;
    readonly rides: readonly RideRow[];
    readonly surgeHeatmap: readonly { readonly city: string; readonly multiplier: number }[];
  };
}

interface CancellationRow {
  readonly reason: string;
  readonly count: number;
}

interface CancellationsResp {
  readonly ok: boolean;
  readonly cancellations?: readonly CancellationRow[];
}

const POLL_MS = 15_000;

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [
    DatePipe,
    DecimalPipe,
    RouterLink,
    RouterLinkActive,
    HlmButton,
    HlmBadge,
    HlmDialog,
    HlmSkeleton,
    SmartTableComponent,
    BclRollingCounterComponent,
    RovingTablistDirective,
    ConfirmDialog,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header class="mb-4 flex items-start justify-between gap-3">
      <div>
        <h1 class="text-2xl font-bold text-foreground">Live ops</h1>
        <p class="text-sm text-muted-foreground">
          Active rides, online crew, surge, today's KPIs. Refreshes every 15 seconds.
        </p>
      </div>
      <button hlmBtn variant="secondary" (click)="refresh()">Refresh now</button>
    </header>

    <nav
      role="tablist"
      bclRovingTablist
      aria-label="Admin sub-sections"
      class="mb-4 flex flex-wrap items-center gap-x-4 gap-y-2 border-b border-border pb-2"
    >
      @for (grp of tabGroups; track grp.group) {
        <div class="flex items-center gap-1.5">
          <span
            class="select-none font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted/70"
            aria-hidden="true"
            >{{ grp.group }}</span
          >
          @for (t of grp.items; track t.route) {
            <a
              #adminTab="routerLinkActive"
              role="tab"
              [routerLink]="t.route"
              routerLinkActive="bg-bcl-accent/15 text-bcl-accent ring-1 ring-bcl-accent/40"
              [routerLinkActiveOptions]="{ exact: true }"
              [attr.aria-selected]="adminTab.isActive"
              class="rounded-full px-3 py-1 text-sm text-muted-foreground transition hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent focus-visible:ring-offset-1 focus-visible:ring-offset-bcl-bg"
            >
              {{ t.label }}
            </a>
          }
        </div>
      }
    </nav>

    @if (loadError(); as err) {
      <div
        class="mt-4 flex items-center justify-between gap-3 rounded-xl border border-destructive/40 bg-destructive/5 px-4 py-3"
        role="alert"
      >
        <p class="text-sm text-foreground">Live-ops metrics offline — {{ err }}</p>
        <button hlmBtn variant="outline" size="sm" (click)="refresh()">Try again</button>
      </div>
    }

    <section
      class="my-6 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6"
      aria-label="Live KPIs"
    >
      @for (k of kpis(); track k.label) {
        <div class="rounded-xl border border-border bg-card p-4">
          <p class="font-mono text-[11px] uppercase tracking-wider text-bcl-accent">
            {{ k.label }}
          </p>
          <p class="bcl-tabular mt-1 text-2xl font-bold text-foreground">
            <bcl-rolling-counter
              [value]="k.value"
              [decimals]="k.decimals"
              [prefix]="k.prefix"
              [suffix]="k.suffix"
            />
          </p>
        </div>
      }
    </section>

    <div class="grid grid-cols-1 gap-6 xl:grid-cols-3">
      <section class="xl:col-span-2" aria-labelledby="rides-h">
        <header class="mb-3 flex items-center justify-between">
          <h2 id="rides-h" class="text-lg font-semibold text-foreground">Active rides</h2>
          <span class="text-xs text-muted-foreground">Click a row to open ride supervisor</span>
        </header>
        @if (initialLoading()) {
          <div class="space-y-2" aria-label="Loading active rides">
            <div hlmSkeleton class="h-10 w-full"></div>
            <div hlmSkeleton class="h-10 w-full"></div>
            <div hlmSkeleton class="h-10 w-full"></div>
          </div>
        } @else if (rides().length === 0) {
          <div
            class="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground"
          >
            No active rides — crew + customers idle right now.
          </div>
        } @else {
          <app-smart-table
            [data]="ridesArray()"
            [columns]="rideCols"
            [filterable]="true"
            filterPlaceholder="Filter by crew, pickup, phone…"
            (rowActivate)="openRide($event)"
          />
        }
      </section>

      <section aria-labelledby="cx-h">
        <header class="mb-3">
          <h2 id="cx-h" class="text-lg font-semibold text-foreground">Cancellations today</h2>
        </header>
        @if (initialLoading()) {
          <div hlmSkeleton class="h-32 w-full"></div>
        } @else if (cancellations().length === 0) {
          <div
            class="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground"
          >
            No cancellations — clean day so far.
          </div>
        } @else {
          <svg
            [attr.viewBox]="'0 0 400 ' + (cancellations().length * 28 + 8)"
            class="w-full"
            role="img"
            [attr.aria-label]="'Cancellation taxonomy: ' + cxTotalLabel()"
          >
            @for (row of cancellations(); track row.reason; let i = $index) {
              <g [attr.transform]="'translate(0,' + (i * 28 + 4) + ')'">
                <text
                  x="0"
                  y="14"
                  class="fill-muted-foreground"
                  font-size="11"
                  font-family="ui-sans-serif"
                >
                  {{ row.reason }}
                </text>
                <rect
                  x="140"
                  y="4"
                  height="14"
                  rx="2"
                  [attr.width]="barWidth(row.count)"
                  class="fill-primary"
                />
                <text
                  [attr.x]="146 + barWidth(row.count)"
                  y="14"
                  class="fill-foreground"
                  font-size="11"
                  font-family="ui-sans-serif"
                >
                  {{ row.count }}
                </text>
              </g>
            }
          </svg>
        }
      </section>
    </div>

    <section class="mt-8" aria-labelledby="surge-h">
      <header class="mb-3">
        <h2 id="surge-h" class="text-lg font-semibold text-foreground">Surge heatmap</h2>
      </header>
      @if (initialLoading()) {
        <div hlmSkeleton class="h-24 w-full"></div>
      } @else if ((metrics()?.surgeHeatmap?.length ?? 0) === 0) {
        <div
          class="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground"
        >
          No surge data — multipliers populate as bookings roll in.
        </div>
      } @else {
        <ul class="grid grid-cols-2 gap-2 sm:grid-cols-4">
          @for (row of metrics()?.surgeHeatmap ?? []; track row.city) {
            <li
              class="flex items-center justify-between rounded-lg border border-border bg-card px-3 py-2"
              [style.background]="surgeTint(row.multiplier)"
            >
              <span class="text-sm text-foreground">{{ row.city }}</span>
              <span class="text-sm font-semibold text-foreground"
                >{{ row.multiplier | number: '1.2-2' }}×</span
              >
            </li>
          }
        </ul>
      }
    </section>

    <app-dialog
      [open]="rideOpen() !== null"
      (openChange)="onDialogOpenChange($event)"
      ariaLabel="Ride supervisor"
    >
      @if (rideOpen(); as r) {
        <h2 class="mb-4 text-lg font-semibold text-foreground">Ride supervisor</h2>
        <dl class="mb-4 grid grid-cols-2 gap-y-2 text-sm sm:grid-cols-3">
          <dt class="text-muted-foreground">Ride ID</dt>
          <dd class="col-span-2 font-mono text-foreground">{{ r.ride_id }}</dd>
          <dt class="text-muted-foreground">State</dt>
          <dd class="col-span-2">
            <span hlmBadge [variant]="badge(r.state).variant">{{ badge(r.state).label }}</span>
          </dd>
          <dt class="text-muted-foreground">Crew</dt>
          <dd class="col-span-2 text-foreground">{{ r.crew_name }}</dd>
          <dt class="text-muted-foreground">Pickup</dt>
          <dd class="col-span-2 text-foreground">{{ r.pickup }}</dd>
          <dt class="text-muted-foreground">Customer</dt>
          <dd class="col-span-2 text-foreground">{{ r.customer_phone }}</dd>
          <dt class="text-muted-foreground">Started</dt>
          <dd class="col-span-2 text-foreground">{{ r.started_at | date: 'short' }}</dd>
        </dl>
        <div class="flex flex-wrap justify-end gap-2">
          <button hlmBtn variant="ghost" (click)="closeRide()">Close</button>
          <button hlmBtn variant="secondary" (click)="requestRideAction(r, 'override')">
            Override dispatch
          </button>
          <button hlmBtn variant="secondary" (click)="requestRideAction(r, 'forceComplete')">
            Force complete
          </button>
          <button hlmBtn variant="destructive" (click)="requestRideAction(r, 'refund')">Refund</button>
        </div>
      }
    </app-dialog>

    <app-confirm-dialog
      [open]="pendingRideAction() !== null"
      [title]="rideActionTitle()"
      [description]="rideActionDesc()"
      [confirmLabel]="rideActionConfirmLabel()"
      [verifySlug]="rideActionSlug()"
      (confirmed)="confirmRideAction()"
      (cancelled)="pendingRideAction.set(null)"
    />
  `,
})
export class AdminComponent implements OnInit, OnDestroy {
  /** Bound to host [@.disabled] — skips the route-entrance fade for reduced-motion users. */
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);
  private readonly toast = inject(ToastService);

  protected readonly badge = statusBadge;

  readonly metrics = signal<MetricsResp['metrics'] | null>(null);
  readonly cancellations = signal<readonly CancellationRow[]>([]);
  readonly rideOpen = signal<RideRow | null>(null);
  /** A ride destructive action (refund/override/force-complete) awaiting the operator's confirm. */
  readonly pendingRideAction = signal<{
    r: RideRow;
    kind: 'refund' | 'override' | 'forceComplete';
  } | null>(null);
  readonly rideActionTitle = computed(() => {
    const k = this.pendingRideAction()?.kind;
    return k === 'refund'
      ? 'Refund this ride?'
      : k === 'override'
        ? 'Override dispatch?'
        : 'Force-complete this ride?';
  });
  readonly rideActionDesc = computed(() => {
    const k = this.pendingRideAction()?.kind;
    return k === 'refund'
      ? 'This issues a real refund to the customer’s card and notifies them. It cannot be undone.'
      : k === 'override'
        ? 'This overrides the automatic dispatch for this ride.'
        : 'This marks the ride complete regardless of crew check-out.';
  });
  readonly rideActionConfirmLabel = computed(() => {
    const k = this.pendingRideAction()?.kind;
    return k === 'refund' ? 'Refund' : k === 'override' ? 'Override' : 'Force complete';
  });
  /** The money action (refund) demands a typed REFUND slug; the others are a plain confirm. */
  readonly rideActionSlug = computed(() =>
    this.pendingRideAction()?.kind === 'refund' ? 'REFUND' : null,
  );
  readonly loadError = signal<string | null>(null);
  /** True until the FIRST metrics fetch resolves — gates the empty-states so the
   *  operator sees a skeleton on initial load, not a false "no active rides". */
  readonly initialLoading = signal(true);
  /** Consecutive failure count — surfaces panel only after 2 misses so a single blip is silent. */
  private consecutiveFailures = 0;

  /**
   * Grouped admin nav — 15 flat tabs were unwieldy + overflowed the row, so they're
   * organized into 4 labeled domains (Operations / Finance / Growth / System) that wrap.
   * `tabs` (flattened) is preserved for any consumer/test that wants the full list.
   */
  readonly tabGroups: ReadonlyArray<{
    readonly group: string;
    readonly items: ReadonlyArray<{ readonly label: string; readonly route: string }>;
  }> = [
    {
      group: 'Operations',
      items: [
        { label: 'Live ops', route: '/admin' },
        { label: 'Ops health', route: '/admin/ops-health' },
        { label: 'System health', route: '/admin/system-health' },
        { label: 'Config', route: '/admin/env-config' },
        { label: 'SQL copilot', route: '/admin/sql-copilot' },
        { label: 'Notifications', route: '/admin/notifications' },
        { label: 'Actions', route: '/admin/operator-actions' },
        { label: 'Widgets', route: '/admin/operator-widgets' },
        { label: 'Photo estimates', route: '/admin/photo-quotes' },
        { label: 'Surge sandbox', route: '/admin/surge-sandbox' },
        { label: 'U-Haul risk', route: '/admin/rental-approvals' },
      ],
    },
    {
      group: 'Finance',
      items: [
        { label: 'Finance', route: '/admin/finance' },
        { label: 'Subscriptions', route: '/admin/subscriptions' },
        { label: 'Coupons', route: '/admin/coupons' },
        { label: 'Fraud', route: '/admin/fraud' },
        { label: 'Unit economics', route: '/admin/unit-economics' },
        { label: '1099-NEC', route: '/admin/tax-1099' },
      ],
    },
    {
      group: 'Growth',
      items: [
        { label: 'Marketing', route: '/admin/marketing' },
        { label: 'SMS console', route: '/admin/sms' },
        { label: 'Content', route: '/admin/content' },
        { label: 'Impact report', route: '/admin/impact-report' },
        { label: 'Social', route: '/admin/social' },
        { label: 'Referrals', route: '/admin/referrals' },
        { label: 'Segments', route: '/admin/segments' },
      ],
    },
    {
      group: 'System',
      items: [
        { label: 'Feature flags', route: '/admin/flags' },
        { label: 'Tenants', route: '/admin/tenants' },
        { label: 'Compliance', route: '/admin/compliance' },
        { label: 'Classification risk', route: '/admin/classification-risk' },
        { label: 'Safety', route: '/admin/safety' },
        { label: 'Disputes', route: '/admin/disputes' },
        { label: 'Applicants', route: '/admin/applicants' },
        { label: 'Impersonate', route: '/admin/impersonate' },
        { label: 'Backups', route: '/admin/backups' },
      ],
    },
  ];

  /** Flattened list (every admin sub-route) — kept for completeness/consumers. */
  readonly tabs = this.tabGroups.flatMap((g) => g.items);

  readonly rides = computed<readonly RideRow[]>(() => this.metrics()?.rides ?? []);
  /** Mutable array copy for SmartTable's data input. */
  readonly ridesArray = computed<RideRow[]>(() => [...this.rides()]);

  readonly kpis = computed(() => {
    const m = this.metrics();
    return [
      {
        label: 'Active rides',
        value: m?.activeRides ?? 0,
        decimals: 0,
        prefix: null,
        suffix: null,
      },
      { label: 'Online crew', value: m?.onlineCrew ?? 0, decimals: 0, prefix: null, suffix: null },
      {
        label: 'Pending offers',
        value: m?.pendingOffers ?? 0,
        decimals: 0,
        prefix: null,
        suffix: null,
      },
      {
        label: 'Completed today',
        value: m?.completedToday ?? 0,
        decimals: 0,
        prefix: null,
        suffix: null,
      },
      {
        label: 'Gross today',
        value: (m?.grossTodayCents ?? 0) / 100,
        decimals: 0,
        prefix: '$',
        suffix: null,
      },
      { label: 'Surge', value: m?.surgeMultiplier ?? 1, decimals: 2, prefix: null, suffix: '×' },
    ] as const;
  });

  readonly rideCols: ColumnDef<RideRow>[] = [
    {
      accessorKey: 'started_at',
      header: 'Started',
      cell: (info) => new Date(info.getValue<string>()).toLocaleTimeString(),
    },
    { accessorKey: 'crew_name', header: 'Crew' },
    { accessorKey: 'state', header: 'State' },
    { accessorKey: 'pickup', header: 'Pickup' },
    { accessorKey: 'customer_phone', header: 'Customer' },
  ];

  readonly cxTotalLabel = computed<string>(() =>
    this.cancellations()
      .map((r) => `${r.reason} ${r.count}`)
      .join(', '),
  );

  private timer: ReturnType<typeof setInterval> | null = null;

  ngOnInit(): void {
    void this.refresh();
    this.timer = setInterval(() => void this.refresh(), POLL_MS);
  }

  ngOnDestroy(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  async refresh(): Promise<void> {
    let metricsOk = false;
    try {
      const r = await firstValueFrom(
        this.http.get<MetricsResp>('/api/admin/live-ops/metrics', { withCredentials: true }),
      );
      this.metrics.set(r.metrics ?? null);
      metricsOk = true;
    } catch (err) {
      this.consecutiveFailures += 1;
      if (this.consecutiveFailures >= 2) {
        this.loadError.set((err as Error).message ?? "Couldn't reach live-ops API");
      }
    }
    if (metricsOk) {
      this.consecutiveFailures = 0;
      this.loadError.set(null);
    }
    try {
      const c = await firstValueFrom(
        this.http.get<CancellationsResp>('/api/admin/live-ops/cancellations', {
          withCredentials: true,
        }),
      );
      this.cancellations.set(c.cancellations ?? []);
    } catch {
      /* cancellations are secondary — silently fail */
    } finally {
      // First fetch round resolved (success or error) — drop the skeleton.
      this.initialLoading.set(false);
    }
  }

  openRide(row: RideRow): void {
    this.rideOpen.set(row);
  }

  closeRide(): void {
    this.rideOpen.set(null);
  }

  onDialogOpenChange(open: boolean): void {
    if (!open) this.closeRide();
  }

  /**
   * Open the confirm dialog for a destructive ride action. The Refund / Override /
   * Force-complete buttons route HERE, never to the mutators directly — a misclicked
   * refund issues real money + notifies the customer (irreversible).
   */
  requestRideAction(r: RideRow, kind: 'refund' | 'override' | 'forceComplete'): void {
    this.pendingRideAction.set({ r, kind });
  }

  /** The dialog's explicit confirmation → fire the real ride action. */
  async confirmRideAction(): Promise<void> {
    const p = this.pendingRideAction();
    this.pendingRideAction.set(null);
    if (!p) return;
    if (p.kind === 'refund') await this.refund(p.r);
    else if (p.kind === 'override') await this.overrideDispatch(p.r);
    else await this.forceComplete(p.r);
  }

  async overrideDispatch(r: RideRow): Promise<void> {
    await this.postRideAction(r.ride_id, '/api/admin/dispatch/override', 'Dispatch overridden');
  }
  async forceComplete(r: RideRow): Promise<void> {
    await this.postRideAction(r.ride_id, '/api/admin/today/force-complete', 'Ride force-completed');
  }
  async refund(r: RideRow): Promise<void> {
    await this.postRideAction(
      r.ride_id,
      '/api/admin/refund-and-apologize',
      'Refund issued + customer notified',
    );
  }

  private async postRideAction(rideId: string, url: string, successMsg: string): Promise<void> {
    try {
      await firstValueFrom(this.http.post(url, { rideId }, { withCredentials: true }));
      this.toast.success(`${successMsg} · ride ${rideId.slice(0, 8)}…`);
    } catch (err) {
      this.toast.error('Action failed — try again', undefined, (err as Error).message);
    } finally {
      this.closeRide();
      void this.refresh();
    }
  }

  barWidth(count: number): number {
    const max = Math.max(1, ...this.cancellations().map((r) => r.count));
    return Math.max(2, Math.round((count / max) * 220));
  }

  surgeTint(mult: number): string {
    // 1.0 → no tint; 1.6 → strong red wash. Linear interp.
    const clamped = Math.max(1, Math.min(1.6, mult));
    const alpha = ((clamped - 1) / 0.6) * 0.35;
    return `linear-gradient(90deg, rgba(239,68,68,${alpha.toFixed(2)}) 0%, transparent 100%)`;
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'admin-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
