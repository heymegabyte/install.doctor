/**
 * QuotesComponent — list of saved quotes, rebuilt on Spartan (Wave 3b).
 * GET /api/customer/quotes → { ok, items }. 4-state via <app-state-block>,
 * status via HlmBadge + statusBadge(), RxJS-first (toObservable → switchMap →
 * toSignal). A 404 (endpoint not yet wired) degrades silently to the empty
 * state — only real errors surface. Card-list, like bookings.
 */
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { RouterLink, Router } from '@angular/router';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { of, switchMap, map, startWith, catchError } from 'rxjs';
import { HlmBadge, StateBlockComponent, type SurfaceState } from '../../shared/ui-spartan';
import { statusBadge } from '@theme.tools/crm/field-service/status-badge';
import { AuthService } from '../../core/auth.service';
import { routeFade, reducedMotion } from '../../shared/animations';
import { formatUsdCents } from '@theme.tools/billing/field-service/money';
import {
  CANONICAL_SERVICES,
  HOURLY_RATE_USD,
  type CanonicalServicePreset,
  type CanonicalServiceSlug,
} from './quote-detail.component';
import { buildComprehensiveCategoryDiagnostic } from '@theme.tools/scheduling/field-service/theme-tools-field-service-bridge';

interface QuoteListItem {
  readonly id: string;
  readonly service: string;
  readonly status: string;
  readonly totalCents: number;
  readonly preferredDate: string;
  readonly createdAt: string;
  readonly address: string;
  readonly city: string;
}

interface QuotesResponse {
  readonly ok: boolean;
  readonly items: readonly QuoteListItem[];
}

interface LoadState {
  readonly state: SurfaceState;
  readonly items: readonly QuoteListItem[];
  readonly error: string;
}

@Component({
  selector: 'app-quotes',
  standalone: true,
  imports: [HlmBadge, StateBlockComponent, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header class="mb-6 flex items-start justify-between gap-4">
      <div>
        <h1 class="text-2xl font-bold text-foreground">Quotes</h1>
        <p class="mt-1 text-sm text-muted-foreground">Saved quotes ready to book in one click.</p>
      </div>
      <a
        routerLink="/quotes/new"
        class="inline-flex min-h-[44px] items-center justify-center rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        data-testid="new-quote-cta"
      >
        New quote →
      </a>
    </header>

    <section
      class="mb-6 rounded-xl border border-border bg-card p-4"
      aria-labelledby="instant-estimator-title"
      data-testid="instant-scope-estimator"
    >
      <div class="mb-3 flex flex-wrap items-baseline justify-between gap-2">
        <div>
          <h2 id="instant-estimator-title" class="text-sm font-semibold text-foreground">
            Instant 9-Service Scope Estimator
          </h2>
          <p class="text-xs text-muted-foreground">
            Pick a Brick Labor category to preview crew, hours, and engineering readiness.
          </p>
        </div>
        <span class="font-mono text-xs text-primary">20% deposit now · 80% after completion</span>
      </div>

      <div class="flex flex-wrap gap-2" role="group" aria-label="Service categories">
        @for (svc of services; track svc.slug) {
          <button
            type="button"
            (click)="selectService(svc.slug)"
            [attr.data-testid]="'estimator-pill-' + svc.slug"
            [attr.aria-pressed]="selectedService().slug === svc.slug"
            class="inline-flex min-h-[38px] items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors duration-[333ms] focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
            [class.border-primary]="selectedService().slug === svc.slug"
            [class.bg-primary/15]="selectedService().slug === svc.slug"
            [class.text-primary]="selectedService().slug === svc.slug"
            [class.border-border]="selectedService().slug !== svc.slug"
            [class.bg-background]="selectedService().slug !== svc.slug"
            [class.text-foreground]="selectedService().slug !== svc.slug"
          >
            <span>{{ svc.label }}</span>
            <span class="font-mono text-[11px] text-muted-foreground">
              {{ svc.crew }}c · {{ svc.hours }}h
            </span>
          </button>
        }
      </div>

      <div
        class="mt-4 flex flex-wrap items-center justify-between gap-4 rounded-lg border border-border/80 bg-background/60 p-3"
      >
        <div class="min-w-0 flex-1">
          <p class="text-sm font-semibold text-foreground" data-testid="estimator-selected-label">
            {{ selectedService().label }}
          </p>
          <p class="mt-0.5 text-xs text-muted-foreground">
            {{ selectedService().scopeHint }}
          </p>
          <p class="mt-1 font-mono text-xs text-foreground" data-testid="estimator-breakdown">
            Recommended: {{ selectedService().crew }} crew × {{ selectedService().hours }} hrs ×
            $60/hr/person =
            <span class="font-bold text-primary">{{ '$' + estimatedTotalDollars() }}</span>
            ({{ '$' + depositDollars() }} deposit today)
          </p>
          <p
            class="mt-1 font-mono text-[11px] text-muted-foreground"
            data-testid="estimator-engineering-summary"
          >
            {{ selectedDiagnostic().engineeringSummary }}
          </p>
        </div>
        <a
          [routerLink]="['/quotes', 'new']"
          [queryParams]="{
            service: selectedService().slug,
            crew: selectedService().crew,
            hours: selectedService().hours,
          }"
          data-testid="estimator-launch-quote"
          class="inline-flex min-h-[40px] shrink-0 items-center justify-center rounded-lg bg-primary px-3.5 py-2 text-xs font-semibold text-primary-foreground transition-colors duration-[333ms] hover:bg-primary/90 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        >
          Prefill {{ selectedService().label }} quote →
        </a>
      </div>
    </section>

    <app-state-block
      [state]="view().state"
      [errorDetail]="view().error"
      errorTitle="Couldn't load your quotes"
      [emptyTitle]="emptyTitle()"
      [emptyHint]="emptyHint()"
      [emptyCta]="emptyCta()"
      (retry)="reload()"
      (emptyAction)="emptyAction()"
    >
      <ul class="space-y-2">
        @for (q of view().items; track q.id) {
          <li>
            <a
              [routerLink]="['/quotes', q.id]"
              class="block min-h-[44px] rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
              [attr.data-testid]="'quote-row-' + q.id"
            >
              <div class="flex items-start justify-between gap-3">
                <div class="min-w-0 flex-1">
                  <div class="mb-1 flex items-center gap-2">
                    <span hlmBadge [variant]="badge(q.status).variant">{{
                      badge(q.status).label
                    }}</span>
                    <span class="font-mono text-xs uppercase text-muted-foreground">{{
                      q.service
                    }}</span>
                  </div>
                  <p class="truncate text-sm font-medium text-foreground">
                    {{ q.address }}
                    @if (q.city) {
                      <span>, {{ q.city }}</span>
                    }
                  </p>
                  <p class="mt-1 text-xs text-muted-foreground">Requested {{ q.preferredDate }}</p>
                </div>
                <p class="font-mono text-base tabular-nums text-primary">
                  {{ dollars(q.totalCents) }}
                </p>
              </div>
            </a>
          </li>
        }
      </ul>
    </app-state-block>
  `,
})
export class QuotesComponent {
  /** Bound to host [@.disabled] — skips the route-entrance fade for reduced-motion users. */
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly auth = inject(AuthService);

  protected readonly badge = statusBadge;
  private readonly reloadTick = signal(0);

  readonly services = CANONICAL_SERVICES;
  readonly hourlyRate = HOURLY_RATE_USD;
  readonly selectedSlug = signal<CanonicalServiceSlug>('power-washing');
  readonly selectedService = computed<CanonicalServicePreset>(
    () => this.services.find((s) => s.slug === this.selectedSlug()) ?? CANONICAL_SERVICES[0]!,
  );
  readonly estimatedTotalDollars = computed<number>(
    () => this.selectedService().crew * this.selectedService().hours * HOURLY_RATE_USD,
  );
  readonly depositDollars = computed<number>(() => Math.round(this.estimatedTotalDollars() * 0.2));
  readonly selectedDiagnostic = computed(() =>
    buildComprehensiveCategoryDiagnostic(this.selectedService().slug, {
      crewSize: this.selectedService().crew,
      estimatedHours: this.selectedService().hours,
    }),
  );

  selectService(slug: CanonicalServiceSlug): void {
    this.selectedSlug.set(slug);
  }

  /**
   * A guest reaching /dashboard/quotes (the `requireRole('customer')` guard
   * passes because `RoleService.viewAs` defaults to 'customer' when whoami is
   * empty) must NOT fire the authed `/api/customer/quotes` fetch — the worker
   * 401s it, leaking a console error and degrading the surface to a generic
   * "couldn't load" panel. Signed out we skip the request and show a sign-in
   * affordance instead. (Mirrors BookingsComponent.)
   */
  protected readonly needsAuth = computed(() => !this.auth.authenticated());
  protected readonly emptyTitle = computed(() =>
    this.needsAuth() ? 'Sign in to see your quotes' : 'No quotes yet',
  );
  protected readonly emptyHint = computed(() =>
    this.needsAuth()
      ? 'Log in to review saved quotes and book your preferred crew in one tap.'
      : 'Build a quote with your preferred crew size, services, and dates — then book in one tap.',
  );
  protected readonly emptyCta = computed(() => (this.needsAuth() ? 'Sign in →' : 'Get a quote →'));

  protected readonly view = toSignal(
    toObservable(
      computed(() => ({ tick: this.reloadTick(), authed: this.auth.authenticated() })),
    ).pipe(
      switchMap(({ authed }) => {
        // Signed out → skip the authed fetch (no console 401); render sign-in empty state.
        if (!authed) return of<LoadState>({ state: 'empty', items: [], error: '' });
        return this.http
          .get<QuotesResponse>('/api/customer/quotes', { withCredentials: true })
          .pipe(
            map((resp): LoadState => {
              const items = resp?.items ?? [];
              return { state: items.length ? 'ready' : 'empty', items, error: '' };
            }),
            catchError((err: HttpErrorResponse) =>
              // 404 = endpoint not yet wired → degrade silently to empty.
              of<LoadState>(
                err?.status === 404
                  ? { state: 'empty', items: [], error: '' }
                  : { state: 'error', items: [], error: err?.message ?? 'Network error' },
              ),
            ),
            startWith<LoadState>({ state: 'loading', items: [], error: '' }),
          );
      }),
    ),
    { initialValue: { state: 'loading', items: [], error: '' } as LoadState },
  );

  protected reload(): void {
    this.reloadTick.update((n) => n + 1);
  }
  protected newQuote(): void {
    void this.router.navigateByUrl('/quotes/new');
  }

  /** Empty-state primary action: sign in when signed out, else start a quote. */
  protected emptyAction(): void {
    if (this.needsAuth()) {
      void this.router.navigate(['/login'], { queryParams: { as: 'customer', next: '/quotes' } });
      return;
    }
    this.newQuote();
  }
  protected dollars(cents: number): string {
    return formatUsdCents(cents);
  }
}
