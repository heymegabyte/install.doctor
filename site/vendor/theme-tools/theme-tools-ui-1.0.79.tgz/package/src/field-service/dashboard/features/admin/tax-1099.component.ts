import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * AdminTax1099Component — annual 1099-NEC ledger on the admin console. Angular
 * port of the read half of the React 1099 surface. Live surface =
 * Angular /dashboard/admin (super-admin session).
 *
 * Verified by mount (`app.route('/api/admin/1099-nec', admin1099Nec)`, auth
 * migrated 2026-06-04 to `ownerOrSuperAdmin`; the sub-app is ALSO flag-gated by
 * `1099_automation_export` → 404 when dark):
 *   GET /api/admin/1099-nec/year/:year → { ok, taxYear, forms:[…] }
 *
 * READ-ONLY by design. Form GENERATION + e-file SUBMISSION are activation-tier
 * (they create tax documents + file with the IRS via Track1099/TaxBandits) →
 * operator-run, NOT wired here per "ship the STATUS, gate the ACTION". TINs are
 * PII — masked to the last 4. Full 4-state (incl. a flag-dark state), rolling-
 * counter summary, dark cockpit. Pure helpers unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmButton, HlmSkeleton } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { BclRollingCounterComponent } from '../_shared/rolling-counter.component';

export interface Form1099 {
  readonly id: string;
  readonly workerId: string;
  readonly name: string;
  readonly email: string | null;
  readonly phone: string;
  readonly ein: string | null;
  readonly amount: number; // box-1 cents
  readonly pdfUrl: string | null;
  readonly status: string;
  readonly submittedAt: string | null;
  readonly acceptedAt: string | null;
}

interface YearResponse {
  readonly ok: boolean;
  readonly taxYear?: number;
  readonly forms?: readonly Form1099[];
}

/** Pure: cents → "$N,NNN.NN" (tax docs want exact cents). Unit-tested. */
export function formatUsd(cents: number): string {
  return `$${((cents || 0) / 100).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

/** Pure: mask a TIN/EIN to its last 4 (PII — never render the full value). Unit-tested. */
export function maskTin(tin: string | null): string {
  if (!tin) return 'TIN missing';
  const digits = tin.replace(/\D/g, '');
  if (digits.length < 4) return '•••';
  return `•••-••-${digits.slice(-4)}`;
}

/** Pure: chip classes for a 1099 form status. Unit-tested. */
export function formStatusChip(status: string): string {
  switch (status) {
    case 'accepted':
      return 'bg-bcl-success/10 text-bcl-success ring-bcl-success/30';
    case 'submitted':
    case 'queued':
      return 'bg-bcl-accent/10 text-bcl-accent ring-bcl-accent/30';
    case 'rejected':
    case 'error':
      return 'bg-destructive/10 text-destructive ring-destructive/30';
    default: // draft / generated / unknown
      return 'bg-bcl-warn/10 text-bcl-warn ring-bcl-warn/30';
  }
}

/** Pure: summary strip — count, total box-1 dollars, # accepted. Unit-tested. */
export function summary1099(forms: readonly Form1099[]): {
  count: number;
  totalDollars: number;
  accepted: number;
} {
  let cents = 0;
  let accepted = 0;
  for (const f of forms) {
    cents += f.amount || 0;
    if (f.status === 'accepted') accepted += 1;
  }
  return { count: forms.length, totalDollars: Math.round(cents / 100), accepted };
}

@Component({
  selector: 'app-admin-tax-1099',
  standalone: true,
  imports: [HlmButton, HlmSkeleton, BclRevealDirective, BclRollingCounterComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="mb-4 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 class="text-2xl font-bold text-foreground">1099-NEC ledger</h1>
        <p class="text-sm text-muted-foreground">
          Contractor tax forms for {{ year() }}. Generation + e-file are operator-run.
        </p>
      </div>
      <label class="flex items-center gap-2 text-xs text-muted-foreground">
        Tax year
        <select
          class="rounded-md border border-input bg-background px-2 py-1 text-sm text-foreground"
          [value]="year()"
          (change)="onYear($event)"
          data-testid="tax-1099-year"
        >
          @for (y of years; track y) {
            <option [value]="y">{{ y }}</option>
          }
        </select>
      </label>
    </header>

    @if (forms().length > 0) {
      <section
        bclReveal
        class="mb-4 grid grid-cols-1 gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-3"
        aria-label="1099 summary"
      >
        <div class="bg-card px-4 py-3">
          <p class="font-mono text-[11px] uppercase tracking-wider text-bcl-accent">Forms</p>
          <p class="bcl-tabular mt-1 text-2xl font-bold text-foreground">
            <bcl-rolling-counter [value]="summary().count" />
          </p>
        </div>
        <div class="bg-card px-4 py-3">
          <p class="font-mono text-[11px] uppercase tracking-wider text-bcl-success">Box-1 total</p>
          <p class="bcl-tabular mt-1 text-2xl font-bold text-foreground">
            <bcl-rolling-counter [value]="summary().totalDollars" prefix="$" />
          </p>
        </div>
        <div class="bg-card px-4 py-3">
          <p class="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">IRS-accepted</p>
          <p class="bcl-tabular mt-1 text-2xl font-bold text-foreground">
            <bcl-rolling-counter [value]="summary().accepted" />
          </p>
        </div>
      </section>
    }

    @if (error(); as e) {
      <div
        class="mb-4 flex items-center justify-between gap-3 rounded-xl border border-destructive/40 bg-destructive/5 px-4 py-3"
        role="alert"
      >
        <p class="text-sm text-foreground">1099-NEC — {{ e }}</p>
        <button hlmBtn variant="outline" size="sm" (click)="refresh()">Try again</button>
      </div>
    }

    @if (loading() && forms().length === 0) {
      <div class="space-y-2" aria-label="Loading 1099 ledger">
        <div hlmSkeleton class="h-12 w-full"></div>
        <div hlmSkeleton class="h-12 w-full"></div>
      </div>
    } @else if (disabled()) {
      <div class="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
        1099-NEC automation is dark. Enable <code class="text-bcl-accent">1099_automation_export</code>
        to generate + file contractor tax forms.
      </div>
    } @else if (forms().length === 0 && !error()) {
      <div class="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
        No 1099-NEC forms for {{ year() }} yet. Forms are generated for contractors paid ≥ $600.
      </div>
    } @else {
      <ul class="space-y-2">
        @for (f of forms(); track f.id) {
          <li
            bclReveal
            class="flex flex-wrap items-center gap-3 rounded-lg border border-border bg-card/60 px-4 py-3"
          >
            <div class="min-w-0">
              <p class="truncate text-sm font-medium text-foreground">{{ f.name }}</p>
              <p class="bcl-tabular text-xs text-muted-foreground">{{ tin(f.ein) }}</p>
            </div>
            <span
              class="rounded-full px-2 py-0.5 text-xs font-semibold ring-1"
              [class]="chip(f.status)"
              >{{ f.status }}</span
            >
            <span class="bcl-tabular ml-auto text-sm font-semibold text-foreground">{{ usd(f.amount) }}</span>
            @if (f.pdfUrl) {
              <a
                hlmBtn
                variant="outline"
                size="sm"
                [href]="f.pdfUrl"
                target="_blank"
                rel="noopener noreferrer"
                [attr.data-testid]="'tax-1099-pdf-' + f.workerId"
                >View</a
              >
            }
          </li>
        }
      </ul>
    }
  `,
})
export class AdminTax1099Component implements OnInit {
  private readonly http = inject(HttpClient);

  /** Filing years: current + the prior 3 (1099s file for the prior calendar year). */
  readonly years: readonly number[] = (() => {
    const now = new Date().getFullYear();
    return [now - 1, now - 2, now - 3, now];
  })();

  readonly year = signal<number>(new Date().getFullYear() - 1);
  readonly loading = signal(false);
  readonly forms = signal<readonly Form1099[]>([]);
  readonly error = signal<string | null>(null);
  /** True when the worker sub-app is flag-dark (404) — distinct from an error. */
  readonly disabled = signal(false);

  readonly summary = computed(() => summary1099(this.forms()));

  ngOnInit(): void {
    void this.refresh();
  }

  usd(cents: number): string {
    return formatUsd(cents);
  }
  tin(ein: string | null): string {
    return maskTin(ein);
  }
  chip(status: string): string {
    return formStatusChip(status);
  }

  onYear(ev: Event): void {
    const y = Number.parseInt((ev.target as HTMLSelectElement).value, 10);
    if (!Number.isNaN(y)) {
      this.year.set(y);
      void this.refresh();
    }
  }

  async refresh(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    this.disabled.set(false);
    try {
      const r = await firstValueFrom(
        this.http.get<YearResponse>(`/api/admin/1099-nec/year/${this.year()}`, {
          withCredentials: true,
        }),
      );
      this.forms.set(r?.forms ?? []);
    } catch (err) {
      const status = (err as { status?: number }).status;
      if (status === 404) {
        // Sub-app flag is off → feature dark, not an error.
        this.disabled.set(true);
        this.forms.set([]);
      } else {
        this.error.set(`Failed to load 1099 ledger: ${(err as Error).message}`);
        this.forms.set([]);
      }
    } finally {
      this.loading.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'tax-1099-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
