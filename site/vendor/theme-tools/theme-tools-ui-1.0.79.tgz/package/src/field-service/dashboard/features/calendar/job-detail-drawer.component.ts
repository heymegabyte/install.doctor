import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * JobDetailDrawerComponent — a right-side Spartan sheet that opens when an
 * operator clicks a job chip in any calendar view. Shows the booking's detail
 * (customer · city · date/time · service · hours · crew · revenue) and lets the
 * operator change status + add an internal note in one tap, via the existing
 * PATCH /api/admin/bookings/:id endpoint (status enum + notes_internal).
 *
 * Frontend port only — the admin booking-update API already exists. Pricing is
 * read-only canonical (total_cents from the server); the drawer never recomputes
 * or creates billing. Reusable across month/week/day views: parent holds a
 * `selected` signal, binds [booking], handles (updated)/(closed).
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  effect,
  inject,
  input,
  linkedSignal,
  output,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { A11yModule } from '@angular/cdk/a11y';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, finalize, of } from 'rxjs';
import { HOURLY_RATE_CENTS } from './week-view.component';
import { FeatureFlagService } from '../../core/feature-flag.service';

interface AssignedCrew {
  readonly workerId: string;
  readonly name: string;
  readonly claimStatus: string;
}

export interface DrawerBooking {
  readonly id: string;
  readonly status: string;
  readonly customer_name: string | null;
  readonly city: string | null;
  readonly preferred_date: string | null;
  readonly preferred_time: string | null;
  readonly services_csv: string | null;
  readonly hours: number | null;
  readonly crew: number | null;
  readonly total_cents: number | null;
}

type Status = 'confirmed' | 'in_progress' | 'completed' | 'canceled' | 'no_show';
const STATUSES: readonly { value: Status; label: string }[] = [
  { value: 'confirmed', label: 'Confirmed' },
  { value: 'in_progress', label: 'In progress' },
  { value: 'completed', label: 'Completed' },
  { value: 'canceled', label: 'Canceled' },
  { value: 'no_show', label: 'No-show' },
];

@Component({
  selector: 'app-job-detail-drawer',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [A11yModule],
  template: `
    @if (booking(); as b) {
      <!-- backdrop -->
      <div
        class="fixed inset-0 z-40 bg-black/60 bcl-fade-in"
        (click)="close()"
        aria-hidden="true"
        data-testid="job-drawer-backdrop"
      ></div>
      <!-- sheet -->
      <aside
        class="fixed right-0 top-0 z-50 flex h-full w-full max-w-md flex-col border-l border-bcl-border bg-bcl-bg shadow-2xl"
        role="dialog"
        aria-modal="true"
        [attr.aria-label]="'Job detail for ' + (b.customer_name ?? 'customer')"
        data-testid="job-drawer"
        cdkTrapFocus
        [cdkTrapFocusAutoCapture]="true"
        (keydown.escape)="close()"
      >
        <header class="flex items-start justify-between gap-3 border-b border-bcl-border p-5">
          <div class="min-w-0">
            <p class="bcl-eyebrow mb-1">Job detail</p>
            <h2 class="truncate font-display text-xl font-bold text-bcl-ink">
              {{ b.customer_name ?? 'Customer' }}
            </h2>
            <p class="text-sm text-bcl-ink-muted">
              {{ primaryService(b) }}{{ b.city ? ' · ' + b.city : '' }}
            </p>
          </div>
          <button
            type="button"
            (click)="close()"
            class="grid size-9 place-items-center rounded-lg border border-bcl-border text-bcl-ink-muted transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            aria-label="Close"
            data-testid="job-drawer-close"
          >
            ✕
          </button>
        </header>

        <div class="flex-1 overflow-y-auto p-5">
          <dl class="grid grid-cols-2 gap-3 text-sm">
            <div>
              <dt class="bcl-eyebrow text-[10px]">Date</dt>
              <dd class="text-bcl-ink">{{ b.preferred_date ?? '—' }}</dd>
            </div>
            <div>
              <dt class="bcl-eyebrow text-[10px]">Time</dt>
              <dd class="text-bcl-ink">{{ b.preferred_time ?? '—' }}</dd>
            </div>
            <div>
              <dt class="bcl-eyebrow text-[10px]">Hours</dt>
              <dd class="bcl-tabular text-bcl-ink">{{ b.hours ?? '—' }}</dd>
            </div>
            <div>
              <dt class="bcl-eyebrow text-[10px]">Crew</dt>
              <dd class="bcl-tabular text-bcl-ink">{{ b.crew ?? '—' }}</dd>
            </div>
            @if (crewFlagOn()) {
              <div class="col-span-2">
                <dt class="bcl-eyebrow text-[10px]">Assigned crew</dt>
                <dd class="mt-1">
                  @if (crewLoading()) {
                    <span class="text-xs text-bcl-ink-muted">Loading…</span>
                  } @else if (assignedCrew().length) {
                    <ul
                      class="flex flex-wrap gap-2"
                      aria-label="Assigned crew"
                      data-testid="job-drawer-crew"
                    >
                      @for (m of assignedCrew(); track m.workerId) {
                        <li
                          class="rounded-full border border-bcl-border bg-bcl-bg-elev px-3 py-1 text-xs font-medium text-bcl-ink transition-all duration-[333ms] hover:border-bcl-accent hover:text-bcl-accent"
                          [attr.title]="m.claimStatus"
                        >
                          {{ m.name }}
                        </li>
                      }
                    </ul>
                  } @else {
                    <span class="text-xs text-bcl-ink-muted" data-testid="job-drawer-crew-empty"
                      >No crew claimed yet</span
                    >
                  }
                </dd>
              </div>
            }
            <div class="col-span-2">
              <dt class="bcl-eyebrow text-[10px]">Labor revenue</dt>
              <dd class="bcl-tabular font-display text-lg font-extrabold text-bcl-accent">
                {{ revenueLabel(b) }}
              </dd>
            </div>
          </dl>

          <div class="mt-5">
            <label for="job-status" class="bcl-eyebrow text-[10px]">Status</label>
            <select
              id="job-status"
              [value]="status()"
              (change)="status.set($any($event.target).value)"
              class="mt-1 w-full rounded-lg border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm text-bcl-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
              data-testid="job-drawer-status"
            >
              @for (s of statuses; track s.value) {
                <option [value]="s.value">{{ s.label }}</option>
              }
            </select>
          </div>

          <div class="mt-4">
            <label for="job-hours" class="bcl-eyebrow text-[10px]"
              >Duration (hours · 1-hr min)</label
            >
            <div class="mt-1 flex items-center gap-3">
              <input
                id="job-hours"
                type="number"
                min="1"
                max="24"
                step="0.25"
                [value]="hours()"
                (input)="hours.set(toNum($any($event.target).value))"
                class="w-28 rounded-lg border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm text-bcl-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                data-testid="job-drawer-hours"
              />
              <span class="text-xs text-bcl-ink-muted">
                New est:
                <span
                  class="bcl-tabular font-semibold text-bcl-accent"
                  data-testid="job-drawer-price"
                  >{{ livePriceLabel() }}</span
                >
                <span class="text-bcl-ink-muted/70"> · $50/hr × {{ b.crew ?? 1 }} crew</span>
              </span>
            </div>
          </div>

          <div class="mt-4">
            <label for="job-notes" class="bcl-eyebrow text-[10px]"
              >Internal note (operator-only)</label
            >
            <textarea
              id="job-notes"
              [value]="notes()"
              (input)="notes.set($any($event.target).value)"
              rows="3"
              maxlength="4000"
              class="mt-1 w-full rounded-lg border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm text-bcl-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
              placeholder="Add a dispatch note…"
              data-testid="job-drawer-notes"
            ></textarea>
          </div>

          @if (error()) {
            <p
              class="mt-3 rounded-lg border border-rose-500/30 bg-rose-500/5 p-3 text-xs text-rose-300"
              role="alert"
            >
              {{ error() }}
            </p>
          }
        </div>

        <footer class="border-t border-bcl-border p-5">
          <button
            type="button"
            (click)="save()"
            [disabled]="saving() || !dirty()"
            class="w-full rounded-lg bg-bcl-accent px-4 py-2.5 text-sm font-semibold text-bcl-bg transition-all duration-[333ms] disabled:opacity-50 hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bcl-bg"
            data-testid="job-drawer-save"
          >
            {{ saving() ? 'Saving…' : 'Save changes' }}
          </button>
        </footer>
      </aside>
    }
  `,
})
export class JobDetailDrawerComponent {
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);
  private readonly flags = inject(FeatureFlagService);

  readonly booking = input<DrawerBooking | null>(null);
  readonly updated = output<DrawerBooking>();
  readonly closed = output<void>();

  // Assigned-crew identity (calendar_crew_resource_view). When the flag is on,
  // opening a booking fetches the workers claimed to its gig and renders their
  // names as pills. Flag off → the endpoint 404s and the panel is hidden.
  readonly crewFlagOn = this.flags.isOn('calendar_crew_resource_view');
  readonly assignedCrew = signal<readonly AssignedCrew[]>([]);
  readonly crewLoading = signal(false);

  constructor() {
    effect(() => {
      const b = this.booking();
      if (!b || !this.crewFlagOn()) {
        this.assignedCrew.set([]);
        return;
      }
      this.crewLoading.set(true);
      this.http
        .get<{ ok: boolean; crew?: readonly AssignedCrew[] }>(`/api/admin/bookings/${b.id}/crew`, {
          withCredentials: true,
        })
        .pipe(
          takeUntilDestroyed(this.destroyRef),
          catchError(() => of({ ok: false } as { ok: boolean; crew?: readonly AssignedCrew[] })),
          finalize(() => this.crewLoading.set(false)),
        )
        .subscribe((r) => this.assignedCrew.set(r.ok && r.crew ? r.crew : []));
    });
  }

  readonly statuses = STATUSES;
  // linkedSignal resets to the booking's value when a different chip is opened,
  // while still allowing local edits before save.
  readonly status = linkedSignal<string>(() => this.booking()?.status ?? 'confirmed');
  readonly notes = linkedSignal<string>(() => '');
  readonly hours = linkedSignal<number>(() => this.booking()?.hours ?? 1);
  readonly saving = signal(false);
  readonly error = signal<string | null>(null);

  /** Live re-price preview: HOURLY_RATE_CENTS × edited-hours × crew (canonical;
   *  the server recomputes authoritatively on save). */
  readonly livePriceCents = computed<number>(() => {
    const b = this.booking();
    const crew = Math.max(1, b?.crew ?? 1);
    return HOURLY_RATE_CENTS * this.hours() * crew;
  });
  livePriceLabel(): string {
    return `$${(this.livePriceCents() / 100).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
  }
  toNum(v: string): number {
    const n = Number(v);
    return Number.isFinite(n) && n >= 1 ? n : 1;
  }

  dirty(): boolean {
    const b = this.booking();
    if (!b) return false;
    return (
      this.status() !== b.status ||
      this.notes().trim().length > 0 ||
      this.hours() !== (b.hours ?? 1)
    );
  }

  primaryService(b: DrawerBooking): string {
    return (b.services_csv ?? '').split(',')[0]?.trim().replace(/-/g, ' ') || 'job';
  }
  revenueLabel(b: DrawerBooking): string {
    return b.total_cents != null
      ? `$${(b.total_cents / 100).toLocaleString(undefined, { maximumFractionDigits: 0 })}`
      : '—';
  }

  close(): void {
    this.error.set(null);
    this.closed.emit();
  }

  save(): void {
    const b = this.booking();
    if (!b || !this.dirty()) return;
    const body: { status?: string; notes_internal?: string; hours?: number } = {};
    if (this.status() !== b.status) body.status = this.status();
    const note = this.notes().trim();
    if (note) body.notes_internal = note;
    const hoursChanged = this.hours() !== (b.hours ?? 1);
    if (hoursChanged) body.hours = this.hours();
    this.saving.set(true);
    this.error.set(null);
    this.http
      .patch<{ ok: boolean; total_cents?: number }>(`/api/admin/bookings/${b.id}`, body, {
        withCredentials: true,
      })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() => of({ ok: false } as { ok: boolean; total_cents?: number })),
        finalize(() => this.saving.set(false)),
      )
      .subscribe((r) => {
        if (!r.ok) {
          this.error.set('Could not save. Check your operator session and try again.');
          return;
        }
        // On a resize the server returns the re-priced total; reflect both.
        this.updated.emit({
          ...b,
          status: this.status(),
          hours: hoursChanged ? this.hours() : b.hours,
          total_cents: hoursChanged && r.total_cents != null ? r.total_cents : b.total_cents,
        });
        this.notes.set('');
        this.closed.emit();
      });
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'job-detail-drawer-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
