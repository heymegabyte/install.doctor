import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminMarketingComponent — AI marketing-content run history on the admin console.
 * Live surface = Angular /dashboard/admin. `/api/admin/marketing` is already
 * session-gated (`marketingAi.use('*', requireSuperAdmin)`) — no auth migration.
 *
 *   GET /api/admin/marketing/runs → { ok, runs:[{id,kind,input_summary,model,
 *        tokens_in,tokens_out,status,error,created_at}], limit, offset }
 * READ-ONLY: the POST /generate/:kind trigger spends tokens → operator action.
 * Pure helpers statusTone/totalTokens/formatTs unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmCardImports } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export interface MarketingRun {
  readonly id: string;
  readonly kind: string;
  readonly input_summary: string | null;
  readonly model: string | null;
  readonly tokens_in: number | null;
  readonly tokens_out: number | null;
  readonly status: string;
  readonly error: string | null;
  readonly created_at: string;
}

/** Pure: tone band for a run status. */
export function statusTone(status: string): 'safe' | 'warn' | 'danger' {
  const s = (status ?? '').toLowerCase();
  if (s === 'succeeded' || s === 'success') return 'safe';
  if (s === 'failed' || s === 'error') return 'danger';
  return 'warn'; // running / pending / queued
}

/** Pure: total tokens for a run (in + out), 0 when absent. */
export function totalTokens(run: Pick<MarketingRun, 'tokens_in' | 'tokens_out'>): number {
  return (run.tokens_in ?? 0) + (run.tokens_out ?? 0);
}

/** Pure: short local date-time, tolerant of junk. */
export function formatTs(ts: string): string {
  const t = Date.parse(ts);
  if (Number.isNaN(t)) return ts;
  return new Date(t).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}

interface RunsResponse {
  readonly ok: boolean;
  readonly runs?: readonly MarketingRun[];
}

export interface WinbackCandidate {
  readonly customer_email: string;
  readonly customer_name: string;
  readonly last_booking_at: string;
  readonly total_lifetime_cents: number;
  readonly bookings_count: number;
}

interface WinbackResponse {
  readonly ok: boolean;
  readonly candidates?: readonly WinbackCandidate[];
}

@Component({
  selector: 'app-admin-marketing',
  standalone: true,
  imports: [...HlmCardImports, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard bclReveal data-testid="admin-marketing">
      <div hlmCardHeader>
        <h3 hlmCardTitle>Marketing studio · AI runs</h3>
        <p hlmCardDescription>Recent AI content generations (review responses, SEO, social…).</p>
      </div>
      <div hlmCardContent>
        @if (loading()) {
          <p class="text-sm text-bcl-ink-muted">Loading run history…</p>
        } @else if (error()) {
          <p class="text-sm text-bcl-warn" role="status">{{ error() }}</p>
        } @else if (runs().length === 0) {
          <p class="text-sm text-bcl-ink-muted">No marketing AI runs yet.</p>
        } @else {
          <ul class="grid gap-2">
            @for (r of runs(); track r.id) {
              <li class="rounded-md border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm">
                <div class="flex items-center justify-between gap-2">
                  <span class="flex items-center gap-2 min-w-0">
                    <span class="shrink-0 rounded-full px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider ring-1 ring-bcl-border text-bcl-ink-muted">{{ r.kind }}</span>
                    <span
                      class="shrink-0 text-xs"
                      [class.text-bcl-success]="tone(r.status) === 'safe'"
                      [class.text-bcl-warn]="tone(r.status) === 'warn'"
                      [class.text-destructive]="tone(r.status) === 'danger'"
                    >{{ r.status }}</span>
                  </span>
                  <span class="shrink-0 font-mono text-xs tabular-nums text-bcl-ink-muted">{{ when(r.created_at) }}</span>
                </div>
                @if (r.input_summary) {
                  <p class="mt-1 truncate text-xs text-bcl-ink-muted">{{ r.input_summary }}</p>
                }
                @if (tokens(r) > 0) {
                  <p class="mt-0.5 font-mono text-[10px] text-bcl-ink-muted">{{ tokens(r) }} tokens</p>
                }
              </li>
            }
          </ul>
        }
      </div>
    </div>
  `,
})
export class AdminMarketingComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly runs = signal<readonly MarketingRun[]>([]);
  readonly winbackCandidates = signal<readonly WinbackCandidate[]>([]);
  readonly loading = signal(true);
  readonly error = signal<string>('');

  readonly tone = statusTone;
  readonly tokens = totalTokens;
  readonly when = formatTs;

  ngOnInit(): void {
    void this.load();
  }

  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set('');
    try {
      const [r, wb] = await Promise.all([
        firstValueFrom(
          this.http.get<RunsResponse>('/api/admin/marketing/runs?limit=50', { withCredentials: true }),
        ),
        firstValueFrom(
          this.http.get<WinbackResponse>('/api/admin/winback', { withCredentials: true }),
        ).catch(() => ({ ok: false, candidates: [] as readonly WinbackCandidate[] })),
      ]);
      this.runs.set(r?.ok ? (r.runs ?? []) : []);
      this.winbackCandidates.set(wb?.ok ? (wb.candidates ?? []) : []);
    } catch {
      this.error.set('Sign in as an operator to view marketing AI runs.');
    } finally {
      this.loading.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'marketing-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
