import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * Past history lazy routes (GP-08). /dashboard/past is gated by
 * featureFlagGuard('past_bookings_unified') — dark by default, so the route
 * redirects to '/' until the flag is promoted from /dashboard. The
 * `validate-orphaned-flag-guards.mjs` build gate enforces the flag stays live.
 *
 * Open to whichever persona can HAVE history — customer OR crew (super-admins
 * always pass, that's what View-As is for). `requireCustomerOrCrew` keeps a
 * signed-out visitor out; the component + service self-scope the two branches
 * so a user only ever sees their own rows.
 */
import { CanMatchFn, Route, Router } from '@angular/router';
import { inject } from '@angular/core';
import { featureFlagGuard } from '../../core/feature-flag-guard';
import { RoleService } from '../../core/role.service';

/** CanMatch: succeed for a customer, a crew member, or a super-admin. */
const requireCustomerOrCrew: CanMatchFn = () => {
  const roleSvc = inject(RoleService);
  const router = inject(Router);
  const view = roleSvc.viewAs();
  if (roleSvc.isSuperAdmin() || view === 'customer' || view === 'crew') return true;
  return router.parseUrl('/');
};

export const PAST_BOOKINGS_ROUTES: Route[] = [
  {
    path: '',
    canMatch: [requireCustomerOrCrew],
    canActivate: [featureFlagGuard('past_bookings_unified')],
    loadComponent: () =>
      import('./past-bookings.component').then((m) => m.PastBookingsComponent),
  },
];
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'past-bookings-routes',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
