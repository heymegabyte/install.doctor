import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CommLogCardComponent — "messages we've sent you" recent-activity card on the
 * dashboard home. Angular port of the React `customer/MyCommLog` (compact card
 * form; the React version was a button+drawer). Live surface = Angular /dashboard.
 *
 * Fetches GET /api/customer/comm-log?limit=5 (session-gated → 401 anon, returns
 * { ok, items }). Self-gates: hides when not signed in or there are no messages.
 * Admin-only fields are stripped server-side. Dark-cockpit styling.
 */
import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '../../core/auth.service';

export type CommKind = 'email' | 'sms' | 'push' | 'voice';

export interface CommLogItem {
  readonly id: string;
  readonly kind: CommKind;
  readonly subject: string | null;
  readonly body_preview: string | null;
  readonly status: string;
  readonly sent_at: number | null;
}

interface CommLogResponse {
  readonly ok: boolean;
  readonly items?: readonly CommLogItem[];
}

const KIND_LABEL: Readonly<Record<CommKind, string>> = {
  email: 'Email',
  sms: 'Text',
  push: 'Push',
  voice: 'Call',
};

export function kindLabel(kind: CommKind): string {
  return KIND_LABEL[kind] ?? 'Message';
}

/** Pure: a one-line title from subject → body preview → kind. */
export function commTitle(item: CommLogItem): string {
  return (item.subject ?? item.body_preview ?? kindLabel(item.kind)).trim() || kindLabel(item.kind);
}

/** Pure: unix-seconds → short local date, or '' when absent. */
export function formatSentAt(unixSec: number | null): string {
  if (!unixSec) return '';
  const d = new Date(unixSec * 1000);
  if (Number.isNaN(d.getTime())) return '';
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

@Component({
  selector: 'app-comm-log-card',
  standalone: true,
  imports: [BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <section bclReveal bclReveal
        bclReveal
        data-testid="comm-log-card"
        class="rounded-xl border border-bcl-border bg-bcl-bg-elev/40 p-5 mb-6"
        aria-labelledby="commlog-title"
      >
        <header class="mb-3">
          <p class="font-mono text-xs uppercase tracking-wide text-bcl-accent">Transparency</p>
          <h2 id="commlog-title" class="text-lg font-semibold text-bcl-ink">
            Messages we've sent you
          </h2>
        </header>
        <ul class="space-y-1.5">
          @for (m of items(); track m.id) {
            <li class="flex items-center gap-3 rounded-md px-2 py-1.5 text-sm">
              <span
                class="shrink-0 rounded-full px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider ring-1 ring-bcl-border text-bcl-ink-muted"
              >
                {{ label(m.kind) }}
              </span>
              <span class="flex-1 truncate text-bcl-ink">{{ title(m) }}</span>
              <span class="shrink-0 font-mono text-xs tabular-nums text-bcl-ink-muted">
                {{ when(m.sent_at) }}
              </span>
            </li>
          }
        </ul>
      </section>
    }
  `,
})
export class CommLogCardComponent implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);

  readonly items = signal<readonly CommLogItem[]>([]);
  readonly visible = computed(() => this.items().length > 0);

  ngOnInit(): void {
    void this.refresh();
  }

  async refresh(): Promise<void> {
    // The home index (/dashboard) renders for guests too; skip the authed
    // /api/customer/comm-log fetch when signed out (no wasted 401, card hides).
    if (!this.auth.authenticated()) {
      this.items.set([]);
      return;
    }
    try {
      const r = await firstValueFrom(
        this.http.get<CommLogResponse>('/api/customer/comm-log?limit=5', {
          withCredentials: true,
        }),
      );
      this.items.set(r?.ok ? (r.items ?? []) : []);
    } catch {
      this.items.set([]);
    }
  }

  label(kind: CommKind): string {
    return kindLabel(kind);
  }
  title(item: CommLogItem): string {
    return commTitle(item);
  }
  when(unixSec: number | null): string {
    return formatSentAt(unixSec);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'comm-log-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
