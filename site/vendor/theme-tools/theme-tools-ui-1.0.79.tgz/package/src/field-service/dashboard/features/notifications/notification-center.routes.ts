import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { Route } from '@angular/router';

/**
 * Notification center — the standalone full-history inbox at /dashboard/notifications.
 * Open to every persona (the feed endpoint is guest-safe and self-scopes per session).
 */
export const NOTIFICATIONS_ROUTES: Route[] = [
  {
    path: '',
    loadComponent: () =>
      import('./notification-center.component').then((m) => m.NotificationCenterComponent),
  },
];
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'notification-center-routes',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
