import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * App — root standalone shell. Identity is hydrated by the awaited app-initializer
 * at boot; this shell additionally arms whoami re-hydration on focus/visibility/
 * bfcache-restore (see AuthService.startAutoRehydrate) so a login completed on the
 * separate React surface is reflected without a hard reload. It then
 * delegates to the routed feature components inside the Spartan cockpit AppShell
 * (sidebar nav + topbar + Cmd+K palette + view-as switcher). The existing
 * notifications-bell + account-menu (sign-out) are projected into the shell's
 * [shellActions] slot during the transition off the old shared/layout chrome;
 * the minimal footer, help drawer, and the legacy toast-host stay mounted as
 * siblings until their consumers migrate to the Spartan equivalents (W12).
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, inject } from '@angular/core';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';
import { filter, map } from 'rxjs';
import { AuthService } from './core/auth.service';
import { TenantService } from './core/tenant.service';
import { AppShellComponent } from './shared/ui-spartan';
import { DASHBOARD_NAV } from './app-nav';
import { NotificationsBellComponent } from './shared/layout/notifications-bell.component';
import { AccountMenuComponent } from './shared/layout/account-menu.component';
import { WalletButtonComponent } from './shared/layout/wallet-button.component';
import { SidebarNavComponent } from './shared/layout/sidebar-nav.component';
import { MobileNavDrawerComponent } from './shared/layout/mobile-nav-drawer.component';
import { MinimalFooterComponent } from './shared/layout/minimal-footer.component';
import { HelpDrawerComponent } from './shared/help/help-drawer.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    AppShellComponent,
    NotificationsBellComponent,
    AccountMenuComponent,
    WalletButtonComponent,
    SidebarNavComponent,
    MobileNavDrawerComponent,
    MinimalFooterComponent,
    HelpDrawerComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <a
      href="#main"
      class="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-50 focus:rounded focus:bg-primary focus:px-3 focus:py-2 focus:font-semibold focus:text-primary-foreground"
    >
      Skip to content
    </a>

    @if (isAuthRoute()) {
      <!-- Unauthenticated auth surface (/login): bare chrome — no app sidebar,
           topbar, bell, account menu, or help FAB. The login redirect owns its
           own centered <main> landmark + minimal footer per one-canonical-chrome. -->
      <router-outlet />
      <app-minimal-footer />
    } @else {
      <app-shell [navItems]="nav" appName="Brick Labor">
        <app-wallet-button shellSidebarTop />
        <app-sidebar-nav shellNav [navItems]="nav" />
        <app-mobile-nav-drawer shellMobileNav [navItems]="nav" appName="Brick Labor" />
        <app-notifications-bell shellActions />
        <app-account-menu shellActions />
        <router-outlet />
      </app-shell>

      <app-minimal-footer />
      <app-help-drawer />
    }
  `,
})
export class App implements OnInit {
  private readonly auth = inject(AuthService);
  private readonly tenant = inject(TenantService);
  private readonly router = inject(Router);

  protected readonly nav = DASHBOARD_NAV;

  /** Current in-app path, tracking navigations (initial value = boot URL). */
  private readonly url = toSignal(
    this.router.events.pipe(
      filter((e): e is NavigationEnd => e instanceof NavigationEnd),
      map((e) => e.urlAfterRedirects),
    ),
    { initialValue: this.router.url },
  );

  /** Auth routes (/login, /login/*) render bare — no authenticated app shell. */
  protected readonly isAuthRoute = computed(() => {
    const path = (this.url().split(/[?#]/)[0] ?? '').replace(/\/+$/, '');
    return path === '/login' || path.startsWith('/login/');
  });

  ngOnInit(): void {
    // whoami is hydrated by an awaited app-initializer (app.config.ts) so role
    // guards resolve before initial navigation; here we only seed tenant state.
    this.tenant.hydrate();
    // Re-hydrate whoami on focus/visibility/bfcache-restore so a session
    // established on the SEPARATE React /login + /me surface is picked up without
    // a hard reload — the root fix for the stale-"Guest" dashboard after login.
    this.auth.startAutoRehydrate();
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'app',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
