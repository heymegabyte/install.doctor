import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * CrewEarningsService — crew instant-payout + earnings-ledger data layer.
 *
 * The earnings-dashboard / hours-coach / tier-ladder data methods were removed
 * with their cut features (flags deleted in migrations 0119 + 0127). The crew
 * pay-transparency LEDGER was resurrected (migration 0144, roadmap decision #1)
 * because crew are Stripe Connect contractors who legally need a 1099-NEC record;
 * `ledger$` reads it from the flag-gated `/api/earnings/ledger`.
 *
 * Per [[rxjs-first-angular]]: each backend call returns Observable<T>, retries
 * once, and normalizes errors into a typed result the component renders.
 *
 * Backend routes:
 *  POST /api/crew/payout-instant            instant_payout_rtp
 *  GET  /api/earnings/ledger?year=YYYY      crew_earnings_dashboard
 *  GET  /api/earnings/ledger-export?year=…  crew_earnings_dashboard (CSV download)
 */

import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { catchError, of, retry } from 'rxjs';

export interface PayoutResult {
  readonly ok: boolean;
  readonly payout_id?: string;
  readonly amount_cents?: number;
  readonly fee_cents?: number;
  readonly rail?: 'rtp' | 'ach';
  readonly status?: string;
  readonly error?: string;
}

/** One completed-gig pay line from GET /api/earnings/ledger. */
export interface LedgerEntry {
  readonly date: string;
  readonly gigId: string;
  readonly baseCents: number;
  readonly tipCents: number;
  readonly totalCents: number;
}

/** Full crew earnings ledger for a tax year (gated by crew_earnings_dashboard). */
export interface LedgerResult {
  readonly ok: boolean;
  readonly year?: number;
  readonly entries?: readonly LedgerEntry[];
  readonly summary?: {
    readonly grossCents: number;
    readonly tipsCents: number;
    readonly totalCents: number;
    readonly gigsCount: number;
  };
  readonly error?: string;
}

@Injectable({ providedIn: 'root' })
export class CrewEarningsService {
  private readonly http = inject(HttpClient);

  /** Request an instant payout. Idempotency key minted server-side per crew + day. */
  requestPayout$(rail: 'rtp' | 'ach', amount_cents: number): Observable<PayoutResult> {
    return this.http.post<PayoutResult>('/api/crew/payout-instant', { rail, amount_cents }).pipe(
      retry({ count: 1, delay: 600 }),
      catchError((err) =>
        of<PayoutResult>({
          ok: false,
          error: err?.error?.error ?? err?.message ?? 'payout_failed',
        }),
      ),
    );
  }

  /** Fetch the crew earnings ledger for a tax year. 404 when the flag is off. */
  ledger$(year: number): Observable<LedgerResult> {
    return this.http
      .get<LedgerResult>(`/api/earnings/ledger?year=${year}`, { withCredentials: true })
      .pipe(
        retry({ count: 1, delay: 600 }),
        catchError((err) =>
          of<LedgerResult>({
            ok: false,
            error: err?.status === 404 ? 'unavailable' : (err?.error?.error ?? 'ledger_failed'),
          }),
        ),
      );
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'crew-earnings-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
