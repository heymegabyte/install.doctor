import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * hlm-input — styled text-input directive (vendored helm). Applies to
 * <input hlmInput> + <textarea hlmInput>; themed by HLM border/ring/background.
 * Error state via [error]=true (red ring) for form validation surfaces.
 */
import { Directive, computed, input } from '@angular/core';
import { resolveHlmInputClasses } from '@theme-tools/ui/spartan-helm-variants';
import { cn } from '../utils/cn';

@Directive({
  selector: 'input[hlmInput], textarea[hlmInput]',
  standalone: true,
  host: { '[class]': '_computedClass()' },
})
export class HlmInput {
  readonly error = input<boolean>(false);
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly _computedClass = computed(() =>
    cn(...resolveHlmInputClasses(this.error()), this.userClass()),
  );
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'hlm-input',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
