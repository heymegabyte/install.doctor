import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SettingsService — typed wrapper around `/api/settings/*` + identity-adjacent
 * endpoints. Each surface owns its own form state; this service is the
 * I/O boundary so components stay declarative.
 */
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';

export interface UserProfile {
  readonly name: string;
  readonly email: string;
  readonly phone: string;
  readonly avatarUrl: string | null;
  readonly timezone: string;
  readonly language: string;
}

export interface NotificationPrefs {
  // Granular per-event, grouped at the UI layer.
  readonly [eventKey: string]: {
    readonly email: boolean;
    readonly push: boolean;
    readonly sms: boolean;
    readonly inApp: boolean;
  };
}

export interface NotificationChannelPrefs {
  readonly in_app: boolean;
  readonly email: boolean;
  readonly sms: boolean;
  readonly push: boolean;
}

export interface ApiKey {
  readonly id: string;
  readonly name: string;
  readonly scopes: readonly string[];
  readonly createdAt: string;
  readonly lastUsedAt: string | null;
  readonly tokenPreview: string; // `bcl_xxxx…xxxx` (server redacts)
}

export interface Webhook {
  readonly id: string;
  readonly url: string;
  readonly events: readonly string[];
  readonly enabled: boolean;
  readonly secretPreview: string;
}

export interface ActiveSession {
  readonly id: string;
  readonly userAgent: string;
  readonly ip: string;
  readonly createdAt: string;
  readonly current: boolean;
}

interface ErrEnvelope {
  readonly ok: false;
  readonly error: string;
}

@Injectable({ providedIn: 'root' })
export class SettingsService {
  private readonly http = inject(HttpClient);
  readonly loading = signal<boolean>(false);
  readonly error = signal<string | null>(null);

  async getProfile(): Promise<UserProfile> {
    return this.unwrap(
      await firstValueFrom(
        this.http.get<{ ok: true; profile: UserProfile } | ErrEnvelope>('/api/settings/profile'),
      ),
      (r) => r.profile,
    );
  }

  async saveProfile(p: Partial<UserProfile>): Promise<void> {
    this.unwrap(
      await firstValueFrom(this.http.put<{ ok: true } | ErrEnvelope>('/api/settings/profile', p)),
      () => undefined,
    );
  }

  async startTotpEnrollment(): Promise<{ qrSvg: string; secret: string }> {
    return this.unwrap(
      await firstValueFrom(
        this.http.post<{ ok: true; qrSvg: string; secret: string } | ErrEnvelope>(
          '/api/settings/security/totp/start',
          {},
        ),
      ),
      (r) => ({ qrSvg: r.qrSvg, secret: r.secret }),
    );
  }

  async verifyTotp(code: string): Promise<void> {
    this.unwrap(
      await firstValueFrom(
        this.http.post<{ ok: true } | ErrEnvelope>('/api/settings/security/totp/verify', { code }),
      ),
      () => undefined,
    );
  }

  async listSessions(): Promise<readonly ActiveSession[]> {
    return this.unwrap(
      await firstValueFrom(
        this.http.get<{ ok: true; sessions: ActiveSession[] } | ErrEnvelope>(
          '/api/settings/security/sessions',
        ),
      ),
      (r) => r.sessions,
    );
  }

  async revokeSession(id: string): Promise<void> {
    this.unwrap(
      await firstValueFrom(
        this.http.delete<{ ok: true } | ErrEnvelope>(
          `/api/settings/security/sessions/${encodeURIComponent(id)}`,
        ),
      ),
      () => undefined,
    );
  }

  async getNotificationPrefs(): Promise<NotificationPrefs> {
    return this.unwrap(
      await firstValueFrom(
        this.http.get<{ ok: true; prefs: NotificationPrefs } | ErrEnvelope>(
          '/api/push/preferences',
        ),
      ),
      (r) => r.prefs,
    );
  }

  async saveNotificationPrefs(prefs: NotificationPrefs): Promise<void> {
    this.unwrap(
      await firstValueFrom(
        this.http.put<{ ok: true } | ErrEnvelope>('/api/push/preferences', { prefs }),
      ),
      () => undefined,
    );
  }

  async getNotificationChannelPrefs(): Promise<NotificationChannelPrefs> {
    return this.unwrap(
      await firstValueFrom(
        this.http.get<{ ok: true; channels: NotificationChannelPrefs } | ErrEnvelope>(
          '/api/notification-orchestration/preferences',
        ),
      ),
      (r) => r.channels,
    );
  }

  async saveNotificationChannelPrefs(channels: NotificationChannelPrefs): Promise<void> {
    this.unwrap(
      await firstValueFrom(
        this.http.put<{ ok: true; channels: NotificationChannelPrefs } | ErrEnvelope>(
          '/api/notification-orchestration/preferences',
          { channels },
        ),
      ),
      () => undefined,
    );
  }

  async listApiKeys(): Promise<readonly ApiKey[]> {
    return this.unwrap(
      await firstValueFrom(
        this.http.get<{ ok: true; keys: ApiKey[] } | ErrEnvelope>('/api/settings/api-keys'),
      ),
      (r) => r.keys,
    );
  }

  async createApiKey(
    name: string,
    scopes: readonly string[],
  ): Promise<{ id: string; token: string }> {
    return this.unwrap(
      await firstValueFrom(
        this.http.post<{ ok: true; id: string; token: string } | ErrEnvelope>(
          '/api/settings/api-keys',
          { name, scopes },
        ),
      ),
      (r) => ({ id: r.id, token: r.token }),
    );
  }

  async revokeApiKey(id: string): Promise<void> {
    this.unwrap(
      await firstValueFrom(
        this.http.delete<{ ok: true } | ErrEnvelope>(
          `/api/settings/api-keys/${encodeURIComponent(id)}`,
        ),
      ),
      () => undefined,
    );
  }

  async listWebhooks(): Promise<readonly Webhook[]> {
    return this.unwrap(
      await firstValueFrom(
        this.http.get<{ ok: true; webhooks: Webhook[] } | ErrEnvelope>('/api/settings/webhooks'),
      ),
      (r) => r.webhooks,
    );
  }

  async createWebhook(
    url: string,
    events: readonly string[],
  ): Promise<{ id: string; secret: string }> {
    return this.unwrap(
      await firstValueFrom(
        this.http.post<{ ok: true; id: string; secret: string } | ErrEnvelope>(
          '/api/settings/webhooks',
          { url, events },
        ),
      ),
      (r) => ({ id: r.id, secret: r.secret }),
    );
  }

  async deleteWebhook(id: string): Promise<void> {
    this.unwrap(
      await firstValueFrom(
        this.http.delete<{ ok: true } | ErrEnvelope>(
          `/api/settings/webhooks/${encodeURIComponent(id)}`,
        ),
      ),
      () => undefined,
    );
  }

  async requestDataExport(): Promise<{ exportId: string; downloadUrl: string; expiresAt: string }> {
    // Hits the complete GDPR/CCPA export mounted at /api/data-export (route
    // file data-export.ts): builds the JSON archive synchronously, stores it to
    // R2, and returns a ready HMAC-signed download URL. This IS the real,
    // complete handler — an earlier change wrongly repointed this to a
    // never-mounted wave29-prefixed path (which 404'd the whole GDPR export
    // button) on the false belief that /api/data-export was a stub.
    return this.unwrap(
      await firstValueFrom(
        this.http.post<
          | { ok: true; export_id: string; download_url: string; expires_at: string }
          | ErrEnvelope
        >('/api/data-export/request', {}),
      ),
      (r) => ({ exportId: r.export_id, downloadUrl: r.download_url, expiresAt: r.expires_at }),
    );
  }

  async deleteAccount(verifySlug: string): Promise<void> {
    this.unwrap(
      await firstValueFrom(
        this.http.post<{ ok: true } | ErrEnvelope>('/api/settings/delete-account', {
          confirm: verifySlug,
        }),
      ),
      () => undefined,
    );
  }

  private unwrap<R, T>(res: ({ ok: true } & R) | ErrEnvelope, pick: (r: { ok: true } & R) => T): T {
    if (!res.ok) {
      throw new Error(res.error);
    }
    return pick(res);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'settings-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
