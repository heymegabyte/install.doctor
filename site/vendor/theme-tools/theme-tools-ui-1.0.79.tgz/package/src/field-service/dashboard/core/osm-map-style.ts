import type { Map as MapLibreMap, StyleSpecification } from 'maplibre-gl';
import { OSM_DARK_STYLE as RAW_OSM_DARK_STYLE } from '@theme.tools/seo-geo/field-service/osm-map-style';

export type MapLibreMapHandle = MapLibreMap;
export const OSM_DARK_STYLE = RAW_OSM_DARK_STYLE as unknown as StyleSpecification;
