import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * HlmFormField — the form-row composition every Spartan form uses: a label, the
 * projected control (<input hlmInput>/<select>/etc.), an optional hint, and an
 * error message that shows only when `error` is set. Keeps validation UX
 * consistent across /login + settings + admin forms. Pure presentation; the
 * parent owns the FormControl + when to surface the error.
 *
 * Usage:
 *   <app-form-field label="Email" [error]="emailErr()" hint="We never share it">
 *     <input hlmInput type="email" [formControl]="email" [error]="!!emailErr()" />
 *   </app-form-field>
 */
import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  afterRenderEffect,
  computed,
  contentChild,
  input,
} from '@angular/core';
import { HlmInput } from '../input/hlm-input';
import { HlmLabel } from '../label/hlm-label';

let _uid = 0;

@Component({
  selector: 'app-form-field',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [HlmLabel],
  template: `
    <div class="flex flex-col gap-1.5">
      @if (label()) {
        <label hlmLabel [attr.for]="forId()">{{ label() }}</label>
      }
      <ng-content />
      @if (error()) {
        <p class="text-xs font-medium text-destructive" role="alert" [attr.id]="forId() + '-err'">
          {{ error() }}
        </p>
      } @else if (hint()) {
        <p class="text-xs text-muted-foreground">{{ hint() }}</p>
      }
    </div>
  `,
})
export class HlmFormField {
  readonly label = input<string>('');
  readonly hint = input<string>('');
  readonly error = input<string>('');
  /** Optional id to wire label[for] + aria; auto-generated when omitted. */
  readonly fieldId = input<string>('');
  protected readonly forId = computed(() => this.fieldId() || `ff-${++_uid}`);

  /** The projected control (<input hlmInput>/<textarea hlmInput>), if present. */
  private readonly control = contentChild(HlmInput, { read: ElementRef });

  constructor() {
    // Programmatically associate the <label for> with the projected control so
    // every form row is accessible by construction (axe label rule). Content
    // projection can't bind the id in the template, so wire it after render.
    afterRenderEffect(() => {
      const el = this.control()?.nativeElement as HTMLElement | undefined;
      if (!el) return;
      if (!el.id) el.id = this.forId();
      if (this.error()) el.setAttribute('aria-describedby', `${this.forId()}-err`);
      else el.removeAttribute('aria-describedby');
    });
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'hlm-form-field-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
