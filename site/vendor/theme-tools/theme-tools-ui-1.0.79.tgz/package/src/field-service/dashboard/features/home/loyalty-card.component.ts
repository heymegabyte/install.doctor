import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * LoyaltyCardComponent — tier + points + next-tier progress on the dashboard
 * home. Angular port of the React `customer/LoyaltyDashboard` (display half;
 * redemption stays a deeper /rewards surface). Live surface = Angular /dashboard.
 *
 * Fetches GET /api/loyalty/me (cookie auth). Self-gates: hides on 401 (not
 * signed in), 404/no-account (no loyalty row yet — the bug the React version
 * conflated with "not signed in"), or a tier-less payload. Dark-cockpit styling.
 */
import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { BclRollingCounterComponent } from '../_shared/rolling-counter.component';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '../../core/auth.service';

export type LoyaltyTier = 'bronze' | 'silver' | 'gold';

export interface LoyaltyState {
  readonly tier: LoyaltyTier;
  readonly points: number;
  readonly lifetimeCents: number;
  readonly jobsCompleted: number;
  readonly discountPct: number;
  readonly centsToNext: number | null;
}

interface LoyaltyResponse extends Partial<LoyaltyState> {
  readonly authenticated?: boolean;
}

const TIER_LABEL: Readonly<Record<LoyaltyTier, string>> = {
  bronze: 'Bronze',
  silver: 'Silver',
  gold: 'Gold',
};
// Spend thresholds (cents) to REACH each tier — gold is the ceiling.
const TIER_TARGET: Readonly<Record<LoyaltyTier, number>> = {
  bronze: 50_000,
  silver: 200_000,
  gold: 0,
};

/** Pure: is this a renderable loyalty payload? (signed in + has a tier) */
export function hasLoyalty(s: LoyaltyState | null): boolean {
  return !!s && (['bronze', 'silver', 'gold'] as const).includes(s.tier);
}

/** Pure: progress % toward the next tier (0 when at gold / no target). */
export function progressToNext(s: LoyaltyState): number {
  if (s.centsToNext == null) return 100;
  const target = TIER_TARGET[s.tier] || 50_000;
  if (target <= 0) return 100;
  const done = Math.max(0, target - s.centsToNext);
  return Math.min(100, Math.round((done / target) * 100));
}

export function tierLabel(tier: LoyaltyTier): string {
  return TIER_LABEL[tier];
}

@Component({
  selector: 'app-loyalty-card',
  standalone: true,
  imports: [BclRevealDirective, BclRollingCounterComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <section bclReveal bclReveal
        bclReveal
        data-testid="loyalty-card"
        class="rounded-xl bg-gradient-to-br from-bcl-accent/8 to-transparent ring-1 ring-bcl-accent/20 p-5 mb-6"
        aria-labelledby="loyalty-title"
      >
        <header class="mb-3 flex items-center justify-between gap-3">
          <div>
            <p class="font-mono text-xs uppercase tracking-wide text-bcl-accent">Rewards</p>
            <h2 id="loyalty-title" class="text-lg font-semibold text-bcl-ink">
              {{ tierName() }} · {{ state()!.points.toLocaleString() }} pts
            </h2>
          </div>
          <span
            class="rounded-full px-2.5 py-0.5 font-mono text-[11px] uppercase tracking-wider ring-1 ring-bcl-accent/40 text-bcl-accent"
          >
            {{ state()!.discountPct }}% off
          </span>
        </header>

        @if (state()!.centsToNext != null && pct() < 100) {
          <div class="flex items-center gap-3">
            <div
              class="h-2 flex-1 overflow-hidden rounded-full bg-bcl-bg-elev"
              role="progressbar"
              [attr.aria-valuenow]="pct()"
              [attr.aria-valuemin]="0"
              [attr.aria-valuemax]="100"
              [attr.aria-label]="'Progress to next tier: ' + pct() + '%'"
            >
              <div class="h-full bg-bcl-accent transition-[width]" [style.width.%]="pct()"></div>
            </div>
            <span class="font-mono text-xs tabular-nums text-bcl-ink-muted"><bcl-rolling-counter [value]="pct()" suffix="%" /></span>
          </div>
          <p class="mt-2 text-xs text-bcl-ink-muted">
            {{ dollarsToNext() }} more spend to the next tier.
          </p>
        } @else {
          <p class="text-sm text-bcl-ink-muted">
            Top tier reached — {{ state()!.jobsCompleted }} jobs completed. Thank you.
          </p>
        }
      </section>
    }
  `,
})
export class LoyaltyCardComponent implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);

  readonly state = signal<LoyaltyState | null>(null);
  readonly visible = computed(() => hasLoyalty(this.state()));
  readonly tierName = computed(() => {
    const s = this.state();
    return s ? tierLabel(s.tier) : '';
  });
  readonly pct = computed(() => {
    const s = this.state();
    return s ? progressToNext(s) : 0;
  });

  ngOnInit(): void {
    void this.refresh();
  }

  async refresh(): Promise<void> {
    // The home index (/dashboard) renders for guests; skip the authed
    // /api/loyalty/me fetch when signed out (no 401 console error; card hides).
    if (!this.auth.authenticated()) {
      this.state.set(null);
      return;
    }
    try {
      const r = await firstValueFrom(
        this.http.get<LoyaltyResponse>('/api/loyalty/me', { withCredentials: true }),
      );
      if (r?.authenticated && r.tier) {
        this.state.set({
          tier: r.tier,
          points: r.points ?? 0,
          lifetimeCents: r.lifetimeCents ?? 0,
          jobsCompleted: r.jobsCompleted ?? 0,
          discountPct: r.discountPct ?? 0,
          centsToNext: r.centsToNext ?? null,
        });
      } else {
        this.state.set(null);
      }
    } catch {
      this.state.set(null);
    }
  }

  dollarsToNext(): string {
    const c = this.state()?.centsToNext ?? 0;
    return `$${Math.ceil(c / 100).toLocaleString()}`;
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'loyalty-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
