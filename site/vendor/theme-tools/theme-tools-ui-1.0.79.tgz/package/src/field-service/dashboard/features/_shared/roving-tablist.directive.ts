import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { AfterViewInit, Directive, ElementRef, HostListener, inject } from '@angular/core';
import { nextRadioIndex } from '@theme.tools/i18n-a11y/field-service/radio-keynav';

/**
 * Roving-tabindex keyboard navigation for custom ARIA tab lists (Angular).
 *
 * The ARIA Authoring Practices tabs pattern requires the tab list to be a SINGLE
 * tab stop: only the selected (or focused) tab carries `tabindex=0`, every other
 * tab carries `tabindex=-1`, and Arrow/Home/End move focus between tabs (wrapping
 * at the ends). A naive `role="tab"` strip where every tab is independently
 * Tab-focusable FAILS this pattern — a keyboard-only operator must Tab through
 * every tab and cannot arrow between them. axe-core does NOT catch this (it is an
 * interaction-pattern gap, not a static attribute one), so it is unit-pinned here
 * and locked by a behavior spec.
 *
 * Manual activation: this directive only MOVES focus on arrow keys. Activation
 * stays with the native element (a `<button role="tab">` activates on Enter/Space
 * /click; an `<a role="tab">` navigates on Enter), so there are zero state
 * side-effects from arrowing — the panel switches only when the operator commits.
 *
 * Opt-in via the `bclRovingTablist` attribute so it never auto-hijacks a tab list
 * whose `role="tab"` children are non-native custom components.
 *
 * Reuses the role-agnostic index math from the canonical `radio-keynav` helper so
 * tabs and radio groups can never drift apart.
 */
@Directive({
  selector: '[bclRovingTablist]',
  standalone: true,
})
export class RovingTablistDirective implements AfterViewInit {
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef);

  ngAfterViewInit(): void {
    this.syncTabStop();
  }

  /** Establish the single tab stop: the selected tab (or first) carries `tabindex=0`. */
  private syncTabStop(): void {
    const tabs = this.tabs();
    if (tabs.length) this.applyRoving(tabs, this.tabStopIndex(tabs));
  }

  /** All `role="tab"` descendants of the tab list, in DOM order. */
  private tabs(): HTMLElement[] {
    return Array.from(this.host.nativeElement.querySelectorAll<HTMLElement>('[role="tab"]'));
  }

  /**
   * The tab that should be the single tab stop. The focused tab wins while the
   * operator is arrowing (manual activation — focus moves ahead of selection);
   * otherwise the selected tab (Tab-into entry point); otherwise the first.
   */
  private tabStopIndex(tabs: HTMLElement[]): number {
    const focused = tabs.findIndex((t) => t === document.activeElement);
    if (focused >= 0) return focused;
    const selected = tabs.findIndex((t) => t.getAttribute('aria-selected') === 'true');
    return selected >= 0 ? selected : 0;
  }

  private applyRoving(tabs: HTMLElement[], activeIndex: number): void {
    tabs.forEach((t, i) => t.setAttribute('tabindex', i === activeIndex ? '0' : '-1'));
  }

  /** Re-establish the single tab stop whenever focus enters the tab list. */
  @HostListener('focusin')
  onFocusIn(): void {
    this.syncTabStop();
  }

  /** Arrow/Home/End move focus between tabs (focus-follows-arrow), wrapping at the ends. */
  @HostListener('keydown', ['$event'])
  onKeydown(event: KeyboardEvent): void {
    const tabs = this.tabs();
    if (tabs.length === 0) return;
    const focused = tabs.findIndex((t) => t === document.activeElement);
    const current = focused >= 0 ? focused : this.tabStopIndex(tabs);
    const next = nextRadioIndex(current, tabs.length, event.key);
    if (next === null) return;
    event.preventDefault();
    this.applyRoving(tabs, next);
    tabs[next]?.focus();
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'roving-tablist-directive',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
