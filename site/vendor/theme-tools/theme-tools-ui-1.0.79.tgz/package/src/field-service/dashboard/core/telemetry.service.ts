import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { WAVE4_PARTNER_SPECS } from '@theme.tools/integrations/field-service-partner-adapters';
/**
 * TelemetryService — lazy-init Sentry + PostHog for the Angular dashboard.
 *
 * Solo-tier observability per `~/.claude` auto-meta-work rule: PostHog (product
 * + replay) + Sentry (error tracking) + Workers Tracing OTLP at the edge.
 * No GA4 / no AI Gateway here — those live on the marketing shell only.
 *
 * Both vendors are dynamic-imported AFTER `app.config.ts` boot so the SDK
 * chunks never block initial paint. If env keys are missing or the network
 * blocks the script, every method below silently no-ops.
 */
import { Injectable, ErrorHandler, inject, NgZone } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

interface PostHogLike {
  capture: (event: string, properties?: Record<string, unknown>) => void;
  identify: (id: string, properties?: Record<string, unknown>) => void;
  reset: () => void;
  init?: (key: string, options: Record<string, unknown>) => void;
}

interface SentryLike {
  captureException: (err: unknown, ctx?: Record<string, unknown>) => void;
  addBreadcrumb: (b: Record<string, unknown>) => void;
  setUser: (user: { id?: string; email?: string } | null) => void;
}

// Public env exposed by the Worker via /api/env-public — never bundle the
// values into the JS bundle (CI deploys may swap projects without rebuild).
interface PublicEnv {
  SENTRY_DSN?: string;
  SENTRY_RELEASE?: string;
  POSTHOG_PROJECT_API_KEY?: string;
}

@Injectable({ providedIn: 'root' })
export class TelemetryService {
  private posthog: PostHogLike | null = null;
  private sentry: SentryLike | null = null;
  private booted = false;

  async boot(): Promise<void> {
    if (this.booted) return;
    this.booted = true;
    if (typeof window === 'undefined') return;

    let env: PublicEnv = {};
    try {
      const res = await fetch('/api/env-public', { credentials: 'omit' });
      if (res.ok) env = (await res.json()) as PublicEnv;
    } catch {
      // No-op — telemetry stays disabled when the endpoint isn't reachable.
    }

    await Promise.all([this.bootSentry(env), this.bootPostHog(env)]);
  }

  private async bootSentry(env: PublicEnv): Promise<void> {
    if (!env.SENTRY_DSN) return;
    try {
      const sentryMod = await import('@sentry/browser');
      sentryMod.init({
        dsn: env.SENTRY_DSN,
        environment: 'production',
        release: env.SENTRY_RELEASE ?? 'dashboard@unknown',
        integrations: [sentryMod.browserTracingIntegration()],
        tracesSampleRate: 0.1,
        replaysSessionSampleRate: 0,
        replaysOnErrorSampleRate: 1,
      });
      this.sentry = {
        captureException: (err, ctx) => sentryMod.captureException(err, ctx),
        addBreadcrumb: (b) => sentryMod.addBreadcrumb(b),
        setUser: (u) => sentryMod.setUser(u),
      };
    } catch {
      // Sentry SDK failed to load — keep silent.
    }
  }

  private async bootPostHog(env: PublicEnv): Promise<void> {
    const key = env.POSTHOG_PROJECT_API_KEY;
    if (!key) {
      // Reuse the global posthog stub installed by the React shell when present.
      const existing = (globalThis as { posthog?: PostHogLike }).posthog;
      if (existing) this.posthog = existing;
      return;
    }
    try {
      const mod = await import('posthog-js');
      mod.default.init(key, {
        api_host: 'https://us.i.posthog.com',
        ui_host: 'https://us.posthog.com',
        persistence: 'memory', // cookie-free per privacy mandate
        autocapture: true,
        capture_pageview: true,
        capture_pageleave: true,
        session_recording: {
          maskAllInputs: true,
          maskTextSelector: '[data-private], .ph-no-capture, input, textarea',
        },
        disable_session_recording: false,
      });
      this.posthog = mod.default as unknown as PostHogLike;
    } catch {
      // PostHog SDK blocked or failed — leave disabled.
    }
  }

  capture(event: string, properties?: Record<string, unknown>): void {
    this.posthog?.capture(`dashboard:${event}`, properties);
    this.sentry?.addBreadcrumb({
      category: 'telemetry',
      message: event,
      data: properties,
      level: 'info',
    });
  }

  identify(userId: string, properties?: Record<string, unknown>): void {
    this.posthog?.identify(userId, properties);
    this.sentry?.setUser({
      id: userId,
      ...(properties?.['email'] ? { email: String(properties['email']) } : {}),
    });
  }

  reset(): void {
    this.posthog?.reset();
    this.sentry?.setUser(null);
  }

  captureError(err: unknown, ctx?: Record<string, unknown>): void {
    this.sentry?.captureException(err, ctx);
  }
}

/**
 * Global Angular ErrorHandler routing every uncaught error through Sentry.
 * Falls back to console.error in dev (when telemetry hasn't booted).
 */
@Injectable()
export class TelemetryErrorHandler implements ErrorHandler {
  private readonly telemetry = inject(TelemetryService);
  private readonly zone = inject(NgZone);

  handleError(err: unknown): void {
    this.zone.runOutsideAngular(() => {
      this.telemetry.captureError(err, { source: 'angular-error-handler' });
    });
    if (typeof console !== 'undefined' && typeof console.error === 'function') {
      console.error(err);
    }
  }
}

/**
 * NavigationEnd → PostHog pageview breadcrumb. Called once from app
 * initializer. Keeps router transitions captured even when client-side
 * navigation never reloads the document.
 */
export function bindRouterTelemetry(router: Router, telemetry: TelemetryService): void {
  router.events
    .pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd))
    .subscribe((event) => {
      telemetry.capture('route_changed', {
        url: event.urlAfterRedirects,
        ts: Date.now(),
      });
    });
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'telemetry-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
