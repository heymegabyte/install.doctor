import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * OperatorWidgetsComponent — the Angular dashboard surface for the 57 operator
 * "widgets" that previously lived ONLY in the React admin (`/api/admin/widgets/*`).
 *
 * Each widget is a small read-only operator report with a bespoke JSON shape
 * (always `{ ok, …scalars, …one-or-more arrays }`). Rather than 57 hand-built
 * components, this board lazy-loads each endpoint on expand and renders it
 * through a generic view-model: scalar fields → a stat strip (currency-aware
 * for `*_cents`), arrays of objects → tables. Grouped by operator category.
 *
 * Auth: the worker `adminWidgets` middleware now accepts the super-admin session
 * (migrated from bearer-only 2026-06-07), so these calls carry `withCredentials`
 * like every other dashboard request.
 */
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HlmCardImports, ConfirmDialog } from '../../shared/ui-spartan';

interface WidgetDef {
  readonly id: string;
  readonly title: string;
  readonly category: string;
}

/** A per-row operator action (POST {payloadKey: row[idField]} → reload). */
interface RowAction {
  readonly label: string;
  readonly path: string;
  readonly idField: string;
  readonly payloadKey: string;
  readonly confirm: string;
  /** fire-80: when set, the ConfirmDialog requires the operator to TYPE this slug before the
   *  destructive action is enabled (extra safety for irreversible money moves like payout release). */
  readonly verifySlug?: string;
}

/**
 * Widgets that expose a per-row write action (worker POSTs already session-gated
 * via the pass-21 ownerOrSuperAdmin middleware). Read-only widgets have no entry.
 */
const ACTIONS: Readonly<Record<string, RowAction>> = {
  'payout-queue': {
    label: 'Release',
    path: '/payout-queue/release',
    idField: 'id',
    payloadKey: 'payout_id',
    confirm: 'Release this held payout to the crew member? This queues it for payment.',
    verifySlug: 'release',
  },
};

/** A small create-form on a widget card (fields → POST → reload). */
interface FormField {
  readonly key: string;
  readonly label: string;
  readonly placeholder: string;
}
interface FormAction {
  readonly label: string;
  readonly path: string;
  readonly fields: readonly FormField[];
}
const FORM_ACTIONS: Readonly<Record<string, FormAction>> = {
  'customer-tags': {
    label: 'Add tag',
    path: '/customer-tags',
    fields: [
      { key: 'phone', label: 'Phone', placeholder: '(973) 555-0123' },
      { key: 'tag', label: 'Tag', placeholder: 'vip' },
    ],
  },
};

interface StatTile {
  readonly label: string;
  readonly value: string;
}
interface WidgetTable {
  readonly title: string;
  readonly columns: readonly string[];
  readonly rows: readonly Record<string, unknown>[];
}
interface WidgetView {
  readonly stats: readonly StatTile[];
  readonly tables: readonly WidgetTable[];
  readonly empty: boolean;
}
type CellState = {
  status: 'idle' | 'loading' | 'loaded' | 'error';
  view?: WidgetView;
  error?: string;
};

/** Authoritative registry — mirrors every top-level GET in admin-widgets.ts. */
const WIDGETS: readonly WidgetDef[] = ([
  // Finance
  ['1099-status', '1099-NEC status', 'Finance'],
  ['cac-by-channel', 'CAC by channel', 'Finance'],
  ['ltv', 'Customer LTV', 'Finance'],
  ['mileage', 'Crew mileage (30d)', 'Finance'],
  ['payout-queue', 'Payout queue', 'Finance'],
  ['payroll-preview', 'Payroll preview', 'Finance'],
  ['per-job-profit', 'Per-job profit', 'Finance'],
  ['pricing-experiments', 'Pricing experiments', 'Finance'],
  ['square-reconciliation', 'Square reconciliation (30d)', 'Finance'],
  ['tip-summary', 'Tip summary', 'Finance'],
  ['training-rates', 'Training rates', 'Finance'],
  ['discount-history', 'Discount history', 'Finance'],
  ['cause-fund', 'Cause fund', 'Finance'],
  // Quality / CX
  ['nps', 'NPS by dimension', 'Quality & CX'],
  ['negative-escalations', 'Negative escalations', 'Quality & CX'],
  ['review-feed', 'Review feed', 'Quality & CX'],
  ['review-response-queue', 'Review response queue', 'Quality & CX'],
  ['sentiment-trend', 'Sentiment trend', 'Quality & CX'],
  ['top-praise', 'Top praise', 'Quality & CX'],
  ['word-cloud', 'Review word cloud', 'Quality & CX'],
  ['customer-tags', 'Customer tags', 'Quality & CX'],
  ['holiday-impact', 'Holiday impact', 'Quality & CX'],
  // Marketing / SEO
  ['ab-results', 'A/B results', 'Marketing & SEO'],
  ['backlinks', 'Backlinks', 'Marketing & SEO'],
  ['campaign-suggester', 'AI campaign suggester', 'Marketing & SEO'],
  ['channel-attribution', 'Channel attribution', 'Marketing & SEO'],
  ['competitor-watch', 'Competitor watch', 'Marketing & SEO'],
  ['conversion-funnel', 'Conversion funnel', 'Marketing & SEO'],
  ['lead-quality', 'Lead quality', 'Marketing & SEO'],
  ['lead-to-quote-latency', 'Lead→quote latency', 'Marketing & SEO'],
  ['press-mentions', 'Press mentions', 'Marketing & SEO'],
  ['quote-to-booking-latency', 'Quote→booking latency', 'Marketing & SEO'],
  ['seo-health', 'SEO health', 'Marketing & SEO'],
  ['seo-ranks', 'SEO ranks', 'Marketing & SEO'],
  ['speed-to-lead', 'Speed to lead', 'Marketing & SEO'],
  ['segments', 'Customer segments', 'Marketing & SEO'],
  // Ops / Crew
  ['capacity-planner', 'Capacity planner (30d)', 'Ops & Crew'],
  ['cohort-retention', 'Cohort retention', 'Ops & Crew'],
  ['onboarding-pipeline', 'Onboarding pipeline', 'Ops & Crew'],
  ['time-off-requests', 'Time-off requests', 'Ops & Crew'],
  ['worker-coach-recs', 'Worker coaching recs', 'Ops & Crew'],
  ['worker-schedule', 'Worker schedule', 'Ops & Crew'],
  ['bg-check-board', 'Background-check board', 'Ops & Crew'],
  ['cert-renewals', 'Cert renewals', 'Ops & Crew'],
  ['saved-queries', 'Saved queries', 'Ops & Crew'],
  // surge-sandbox is a POST what-if → dedicated interactive tool at
  // /admin/surge-sandbox (not a read-only board card).
  // Compliance / Infra
  ['compliance-checklist', 'Compliance checklist', 'Compliance & Infra'],
  ['console-errors', 'Console errors', 'Compliance & Infra'],
  ['csp-reports', 'CSP reports', 'Compliance & Infra'],
  ['domain-renewals', 'Domain renewals', 'Compliance & Infra'],
  ['email-deliverability', 'Email deliverability (7d)', 'Compliance & Infra'],
  ['sms-deliverability', 'SMS deliverability (7d)', 'Compliance & Infra'],
  ['lighthouse', 'Lighthouse', 'Compliance & Infra'],
  ['posthog-replays', 'PostHog replays', 'Compliance & Infra'],
  ['sentry-errors', 'Sentry errors', 'Compliance & Infra'],
  ['webvitals', 'Web Vitals', 'Compliance & Infra'],
  ['workers-tracing', 'Workers tracing', 'Compliance & Infra'],
] as const).map(([id, title, category]) => ({ id, title, category }));

function humanize(key: string): string {
  const stripped = key.replace(/_cents$/, '').replace(/_/g, ' ');
  return stripped.charAt(0).toUpperCase() + stripped.slice(1);
}

function formatValue(key: string, v: unknown): string {
  if (v == null) return '—';
  if (typeof v === 'boolean') return v ? 'Yes' : 'No';
  if (typeof v === 'number') {
    if (/_cents$/.test(key)) return `$${(v / 100).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    return v.toLocaleString();
  }
  return String(v);
}

/** Turn an arbitrary widget response into a renderable stat-strip + tables. */
function toView(data: Record<string, unknown>): WidgetView {
  const stats: StatTile[] = [];
  const tables: WidgetTable[] = [];
  for (const [k, v] of Object.entries(data)) {
    if (k === 'ok') continue;
    if (Array.isArray(v)) {
      const rows = v.filter((r): r is Record<string, unknown> => r != null && typeof r === 'object' && !Array.isArray(r));
      if (rows.length > 0) {
        const columns = Array.from(new Set(rows.flatMap((r) => Object.keys(r)))).slice(0, 8);
        tables.push({ title: humanize(k), columns, rows: rows.slice(0, 50) });
      } else {
        stats.push({ label: humanize(k), value: `${v.length} item${v.length === 1 ? '' : 's'}` });
      }
    } else if (v != null && typeof v === 'object') {
      for (const [sk, sv] of Object.entries(v as Record<string, unknown>)) {
        if (sv == null || typeof sv === 'object') continue;
        stats.push({ label: `${humanize(k)} · ${humanize(sk)}`, value: formatValue(sk, sv) });
      }
    } else {
      stats.push({ label: humanize(k), value: formatValue(k, v) });
    }
  }
  return { stats, tables, empty: stats.length === 0 && tables.length === 0 };
}

@Component({
  selector: 'app-operator-widgets',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [...HlmCardImports, ConfirmDialog],
  template: `
    <header class="mb-4">
      <h1 class="text-2xl font-bold text-foreground">Operator widgets</h1>
      <p class="text-sm text-muted-foreground">
        {{ total }} read-only operator reports. Load any report below — results render inline.
      </p>
    </header>

    @for (group of groups; track group.category) {
      <section class="mb-6">
        <h2 class="mb-2 font-mono text-xs uppercase tracking-wider text-primary">{{ group.category }}</h2>
        <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          @for (w of group.widgets; track w.id) {
            <div hlmCard class="p-4" [attr.data-widget]="w.id">
              <div class="flex items-center justify-between gap-2">
                <span class="text-sm font-semibold text-foreground">{{ w.title }}</span>
                <button
                  type="button"
                  class="rounded-md border border-border px-2 py-1 text-xs text-primary hover:bg-primary/10 disabled:opacity-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                  [disabled]="cell(w.id).status === 'loading'"
                  (click)="load(w.id)"
                >
                  {{ cell(w.id).status === 'loading' ? 'Loading…' : cell(w.id).status === 'loaded' ? 'Refresh' : 'Load' }}
                </button>
              </div>

              @if (formFor(w.id); as fa) {
                <form class="mt-3 flex flex-wrap items-end gap-2" (submit)="submitForm(w.id, $event)">
                  @for (f of fa.fields; track f.key) {
                    <label class="min-w-[7rem] flex-1">
                      <span class="text-[11px] uppercase tracking-wide text-muted-foreground">{{ f.label }}</span>
                      <input
                        type="text"
                        [placeholder]="f.placeholder"
                        [value]="formVal(w.id, f.key)"
                        (input)="setFormVal(w.id, f.key, $any($event.target).value)"
                        class="mt-0.5 w-full rounded-md border border-input bg-background px-2 py-1 text-sm text-foreground"
                      />
                    </label>
                  }
                  <button
                    type="submit"
                    class="rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground disabled:opacity-50"
                    [disabled]="formBusy() === w.id"
                  >
                    {{ formBusy() === w.id ? '…' : fa.label }}
                  </button>
                </form>
                @if (formMsg()[w.id]; as m) {
                  <p class="mt-1 text-xs" [class.text-destructive]="m.startsWith('!')" [class.text-emerald-400]="!m.startsWith('!')">
                    {{ m.startsWith('!') ? m.slice(1) : m }}
                  </p>
                }
              }

              @if (cell(w.id).status === 'error') {
                <p class="mt-2 text-xs text-destructive">{{ cell(w.id).error }}</p>
              } @else if (cell(w.id).status === 'loaded'; as s) {
                @if (cell(w.id).view!.empty) {
                  <p class="mt-2 text-xs text-muted-foreground">No data.</p>
                } @else {
                  @if (cell(w.id).view!.stats.length > 0) {
                    <div class="mt-3 flex flex-wrap gap-3">
                      @for (st of cell(w.id).view!.stats; track st.label) {
                        <div class="min-w-[5rem]">
                          <div class="text-[11px] uppercase tracking-wide text-muted-foreground">{{ st.label }}</div>
                          <div class="font-mono text-sm text-foreground tabular-nums">{{ st.value }}</div>
                        </div>
                      }
                    </div>
                  }
                  @for (t of cell(w.id).view!.tables; track t.title) {
                    <div class="mt-3 overflow-x-auto">
                      <div class="mb-1 text-[11px] uppercase tracking-wide text-muted-foreground">{{ t.title }}</div>
                      <table class="w-full text-left text-xs">
                        <thead class="border-b border-border">
                          <tr>
                            @for (c of t.columns; track c) { <th class="px-2 py-1 font-mono text-muted-foreground">{{ humanizeCol(c) }}</th> }
                            @if (actionFor(w.id); as act) { <th class="px-2 py-1 font-mono text-muted-foreground">{{ act.label }}</th> }
                          </tr>
                        </thead>
                        <tbody>
                          @for (row of t.rows; track $index) {
                            <tr class="border-b border-border/40">
                              @for (c of t.columns; track c) { <td class="px-2 py-1 font-mono text-foreground">{{ cellText(c, row[c]) }}</td> }
                              @if (actionFor(w.id); as act) {
                                <td class="px-2 py-1">
                                  @if (row[act.idField] != null) {
                                    <button
                                      type="button"
                                      class="rounded-md border border-primary/40 px-2 py-0.5 text-[11px] text-primary hover:bg-primary/10 disabled:opacity-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                                      [disabled]="acting() === str(row[act.idField])"
                                      (click)="runAction(w.id, row)"
                                    >
                                      {{ acting() === str(row[act.idField]) ? '…' : act.label }}
                                    </button>
                                  }
                                </td>
                              }
                            </tr>
                          }
                        </tbody>
                      </table>
                    </div>
                  }
                }
              }
            </div>
          }
        </div>
      </section>
    }

    @if (pendingAction(); as p) {
      <app-confirm-dialog
        [open]="true"
        [title]="p.act.label"
        [description]="p.act.confirm"
        [confirmLabel]="p.act.label"
        [verifySlug]="p.act.verifySlug ?? null"
        (confirmed)="confirmPendingAction()"
        (cancelled)="cancelPendingAction()"
      />
    }
  `,
})
export class OperatorWidgetsComponent {
  private readonly http = inject(HttpClient);
  readonly total = WIDGETS.length;

  readonly groups = computed(() => {
    const byCat = new Map<string, WidgetDef[]>();
    for (const w of WIDGETS) {
      const bucket = byCat.get(w.category) ?? [];
      bucket.push(w);
      byCat.set(w.category, bucket);
    }
    return Array.from(byCat, ([category, widgets]) => ({ category, widgets }));
  })();

  private readonly cells = signal<Record<string, CellState>>({});
  /** Row id currently being actioned (disables its button). */
  readonly acting = signal<string | null>(null);
  /** fire-80: the row-action awaiting confirmation. Was a bare globalThis.confirm(); now drives the
   *  branded, focus-trapped ConfirmDialog so a destructive crew-payout release isn't an un-brandable
   *  OS popup with no focus-trap/Esc/restore. */
  readonly pendingAction = signal<{ widgetId: string; id: string; act: RowAction } | null>(null);

  cell(id: string): CellState {
    return this.cells()[id] ?? { status: 'idle' };
  }

  actionFor(widgetId: string): RowAction | undefined {
    return ACTIONS[widgetId];
  }

  // ── Create-form actions (e.g. customer-tags add) ──────────────────────────
  private readonly formVals = signal<Record<string, Record<string, string>>>({});
  readonly formBusy = signal<string | null>(null);
  readonly formMsg = signal<Record<string, string>>({});

  formFor(widgetId: string): FormAction | undefined {
    return FORM_ACTIONS[widgetId];
  }
  formVal(widgetId: string, key: string): string {
    return this.formVals()[widgetId]?.[key] ?? '';
  }
  setFormVal(widgetId: string, key: string, value: string): void {
    this.formVals.update((m) => ({ ...m, [widgetId]: { ...(m[widgetId] ?? {}), [key]: value } }));
  }

  async submitForm(widgetId: string, ev: Event): Promise<void> {
    ev.preventDefault();
    const fa = FORM_ACTIONS[widgetId];
    if (!fa) return;
    const vals = this.formVals()[widgetId] ?? {};
    if (fa.fields.some((f) => !(vals[f.key] || '').trim())) {
      this.formMsg.update((m) => ({ ...m, [widgetId]: '!Fill every field.' }));
      return;
    }
    this.formBusy.set(widgetId);
    this.formMsg.update((m) => ({ ...m, [widgetId]: '' }));
    const r = await firstValueFrom(
      this.http
        .post<{ ok?: boolean; error?: string }>(`/api/admin/widgets${fa.path}`, vals, { withCredentials: true })
        .pipe(catchError((e) => of({ ok: false, error: e?.error?.error ?? 'Failed' }))),
    );
    this.formBusy.set(null);
    if (r.ok === false) {
      this.formMsg.update((m) => ({ ...m, [widgetId]: `!${r.error ?? 'Failed'}` }));
      return;
    }
    this.formVals.update((m) => ({ ...m, [widgetId]: {} }));
    this.formMsg.update((m) => ({ ...m, [widgetId]: `${fa.label} saved.` }));
    await this.load(widgetId); // refresh the list so the new row shows
  }

  runAction(widgetId: string, row: Record<string, unknown>): void {
    const act = ACTIONS[widgetId];
    if (!act) return;
    const id = row[act.idField];
    if (id == null) return;
    // fire-80: was a bare globalThis.confirm() gating a destructive, irreversible crew-payout
    // release. Route through the branded, focus-trapped ConfirmDialog (verifySlug type-to-confirm on
    // the money release) instead of an un-brandable OS popup with no focus-trap / Esc / focus-restore.
    this.pendingAction.set({ widgetId, id: String(id), act });
  }

  cancelPendingAction(): void {
    this.pendingAction.set(null);
  }

  async confirmPendingAction(): Promise<void> {
    const p = this.pendingAction();
    if (!p) return;
    this.pendingAction.set(null);
    const { widgetId, id, act } = p;
    this.acting.set(id);
    const r = await firstValueFrom(
      this.http
        .post<{ ok?: boolean; error?: string }>(`/api/admin/widgets${act.path}`, { [act.payloadKey]: id }, { withCredentials: true })
        .pipe(catchError((e) => of({ ok: false, error: e?.error?.error ?? 'Action failed' }))),
    );
    this.acting.set(null);
    if (r.ok === false) {
      this.cells.update((m) => ({ ...m, [widgetId]: { ...(m[widgetId] ?? { status: 'idle' }), status: 'error', error: String(r.error ?? 'Action failed') } }));
      return;
    }
    await this.load(widgetId); // refresh the widget so the actioned row leaves the queue
  }

  humanizeCol = humanizeCol;
  cellText = cellText;
  str = (v: unknown): string => String(v);

  async load(id: string): Promise<void> {
    this.cells.update((m) => ({ ...m, [id]: { status: 'loading' } }));
    const r = await firstValueFrom(
      this.http
        .get<Record<string, unknown>>(`/api/admin/widgets/${id}`, { withCredentials: true })
        .pipe(catchError((e) => of({ ok: false, error: e?.error?.error ?? 'Request failed' } as Record<string, unknown>))),
    );
    if (r['ok'] === false) {
      this.cells.update((m) => ({ ...m, [id]: { status: 'error', error: String(r['error'] ?? 'Failed') } }));
      return;
    }
    this.cells.update((m) => ({ ...m, [id]: { status: 'loaded', view: toView(r) } }));
  }
}

function humanizeCol(c: string): string {
  return c.replace(/_cents$/, ' ($)').replace(/_/g, ' ');
}
function cellText(col: string, v: unknown): string {
  return formatValue(col, v);
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'operator-widgets-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
