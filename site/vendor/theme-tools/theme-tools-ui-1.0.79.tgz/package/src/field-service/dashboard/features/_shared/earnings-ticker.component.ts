import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * EarningsTickerComponent — live "today's earnings" pill.
 *
 * Polls /api/earnings/today every 60s. Listens to BroadcastChannel('bcl-earnings')
 * for instant updates the moment a tip lands or a gig closes — eliminates
 * the 60s lag a poll-only ticker would have. Hidden when not authenticated.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  inject,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { interval, startWith } from 'rxjs';

interface EarningsToday {
  readonly grossCents: number;
  readonly tipsCents: number;
  readonly gigsCount: number;
  readonly hoursOnline: number;
}

@Component({
  selector: 'bcl-earnings-ticker',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div
      class="inline-flex items-center gap-3 rounded-full bg-bcl-bg-elev px-4 py-2 ring-1 ring-bcl-border"
      aria-live="polite"
      aria-label="Today's earnings"
      data-testid="earnings-ticker"
    >
      <span class="text-xs uppercase tracking-wider text-bcl-ink-muted">Today</span>
      <span class="font-mono text-base font-semibold text-bcl-accent">{{ gross() }}</span>
      @if (data(); as d) {
        <span class="text-xs text-bcl-ink-muted">
          {{ d.gigsCount }} gigs · {{ tips() }} tips · {{ d.hoursOnline.toFixed(1) }}h
        </span>
      }
    </div>
  `,
})
export class EarningsTickerComponent {
  private readonly destroyRef = inject(DestroyRef);

  readonly data = signal<EarningsToday | null>(null);

  readonly gross = computed(() => {
    const d = this.data();
    return d ? `$${(d.grossCents / 100).toFixed(2)}` : '$0.00';
  });
  readonly tips = computed(() => {
    const d = this.data();
    return d ? `$${(d.tipsCents / 100).toFixed(2)}` : '$0.00';
  });

  constructor() {
    interval(60_000)
      .pipe(startWith(0), takeUntilDestroyed(this.destroyRef))
      .subscribe(() => this.refresh());

    if (typeof BroadcastChannel !== 'undefined') {
      const channel = new BroadcastChannel('bcl-earnings');
      channel.onmessage = (ev) => {
        if (ev?.data && typeof ev.data === 'object' && 'grossCents' in ev.data) {
          this.data.set(ev.data as EarningsToday);
        } else {
          this.refresh();
        }
      };
      this.destroyRef.onDestroy(() => channel.close());
    }
  }

  private async refresh(): Promise<void> {
    try {
      const res = await fetch('/api/earnings/today', { credentials: 'include' });
      if (!res.ok) return;
      const body = (await res.json()) as EarningsToday;
      this.data.set(body);
    } catch {
      // ignore network blips; next interval will retry
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'earnings-ticker-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
