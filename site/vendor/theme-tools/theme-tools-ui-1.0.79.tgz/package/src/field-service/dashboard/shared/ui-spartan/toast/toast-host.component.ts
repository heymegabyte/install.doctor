import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * HlmToastHost — renders the ToastService queue, fixed bottom-right, themed by
 * HLM vars per variant. Mount ONCE in the app shell. aria-live=polite so screen
 * readers announce without stealing focus.
 */
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { ToastService, type ToastVariant } from './toast.service';
import { cn } from '../utils/cn';

@Component({
  selector: 'app-toast-host',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    class: 'pointer-events-none fixed bottom-4 right-4 z-[100] flex w-full max-w-sm flex-col gap-2',
    'aria-live': 'polite',
    'aria-atomic': 'false',
  },
  template: `
    @for (t of toasts(); track t.id) {
      <div
        [class]="cardClass(t.variant)"
        role="status"
        data-testid="toast"
        [attr.data-variant]="t.variant"
      >
        <div class="flex flex-col gap-0.5">
          @if (t.title) {
            <strong class="text-sm font-semibold">{{ t.title }}</strong>
          }
          <span class="text-sm">{{ t.message }}</span>
          @if (t.details) {
            <span class="text-xs opacity-70">{{ t.details }}</span>
          }
        </div>
        <button
          type="button"
          class="ml-auto text-lg leading-none opacity-60 hover:opacity-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
          aria-label="Dismiss"
          (click)="svc.dismiss(t.id)"
        >
          ×
        </button>
      </div>
    }
  `,
})
export class HlmToastHost {
  protected readonly svc = inject(ToastService);
  protected readonly toasts = this.svc.toasts;

  protected cardClass(variant: ToastVariant): string {
    const base =
      'pointer-events-auto flex items-start gap-3 rounded-lg border p-3 shadow-lg backdrop-blur transition-all';
    const byVariant: Record<ToastVariant, string> = {
      default: 'border-border bg-card text-card-foreground',
      success: 'border-[color:hsl(142_71%_45%/0.4)] bg-card text-card-foreground',
      warning: 'border-[color:hsl(38_92%_50%/0.4)] bg-card text-card-foreground',
      error: 'border-destructive/50 bg-card text-card-foreground',
    };
    return cn(base, byVariant[variant]);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'toast-host-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
