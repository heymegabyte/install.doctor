import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SettingsNotificationsComponent — granular per-event toggles, grouped.
 * Persists via `PUT /api/push/preferences`.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { HlmCardImports, HlmButton, HlmSwitch, HlmSpinner } from '../../shared/ui-spartan';
import {
  SettingsService,
  type NotificationChannelPrefs,
  type NotificationPrefs,
} from './settings.service';

interface EventDef {
  readonly key: string;
  readonly label: string;
  readonly group: 'Gigs' | 'Payments' | 'Safety' | 'Marketing';
}

type Channel = 'email' | 'push' | 'sms' | 'inApp';

/**
 * Mirrors the canonical `isTransactionalEvent` in `src/shared/channel-prefs.ts`
 * (inverted): an event is "always on" — un-suppressable by preference — unless
 * its key is in the `marketing.*` namespace. The dashboard build can't import
 * `src/shared`, so the parity Jest spec (`notifications.spec.ts`) locks this to
 * the shared rule and fails if the policy drifts. Without it the panel LIED:
 * it rendered live toggles for payment / gig / safety events the send path
 * always delivers regardless, so flipping them did nothing.
 */
export function isAlwaysOnEvent(key: string): boolean {
  return !key.startsWith('marketing.');
}

const EVENTS: readonly EventDef[] = [
  { key: 'gig.new', label: 'New gig offer', group: 'Gigs' },
  { key: 'gig.accepted', label: 'Gig accepted', group: 'Gigs' },
  { key: 'gig.canceled', label: 'Gig canceled', group: 'Gigs' },
  { key: 'gig.reminder', label: 'Day-of reminders', group: 'Gigs' },
  { key: 'payment.received', label: 'Payment received', group: 'Payments' },
  { key: 'payment.failed', label: 'Payment failed', group: 'Payments' },
  { key: 'payout.cleared', label: 'Payout cleared', group: 'Payments' },
  { key: 'invoice.ready', label: 'Invoice ready', group: 'Payments' },
  { key: 'safety.panic', label: 'Panic alerts', group: 'Safety' },
  { key: 'safety.incident', label: 'Incident report filed', group: 'Safety' },
  { key: 'marketing.tips', label: 'Product tips', group: 'Marketing' },
  { key: 'marketing.newsletter', label: 'Monthly newsletter', group: 'Marketing' },
];

const CHANNELS: readonly { key: Channel; label: string }[] = [
  { key: 'email', label: 'Email' },
  { key: 'push', label: 'Push' },
  { key: 'sms', label: 'SMS' },
  { key: 'inApp', label: 'In-app' },
];

@Component({
  selector: 'app-settings-notifications',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, HlmSwitch, HlmSpinner],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (channelPrefsAvailable()) {
      <div hlmCard class="mb-4" data-testid="notification-delivery-channels">
        <div hlmCardHeader>
          <h3 hlmCardTitle>Delivery channels</h3>
          <p hlmCardDescription>Choose where Brick sends workflow updates.</p>
        </div>
        <div hlmCardContent class="grid gap-3 sm:grid-cols-2">
          @for (channel of deliveryChannels; track channel.key) {
            <div class="flex min-w-0 items-center justify-between gap-4 rounded-lg border border-border p-3">
              <span class="text-sm text-foreground">{{ channel.label }}</span>
              <hlm-switch
                [checked]="channelEnabled(channel.key)"
                [ariaLabel]="channel.label + ' delivery'"
                (changed)="setChannel(channel.key, $event)"
              />
            </div>
          }
        </div>
      </div>
    }
    <p class="mb-4 text-sm text-muted-foreground">
      Transactional alerts — payments, gigs, payouts, and safety — are
      <span class="font-medium text-foreground">always on</span> and can't be
      switched off. You control the marketing channels below.
    </p>
    @for (group of groups; track group) {
      <div hlmCard class="mb-4">
        <div hlmCardHeader><h3 hlmCardTitle>{{ group }}</h3></div>
        <div hlmCardContent>
          <div class="overflow-x-auto">
            <table class="w-full text-sm">
              <thead class="text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th class="px-2 py-2 text-left">Event</th>
                  @for (ch of channels; track ch.key) {
                    <th class="px-2 py-2 text-center">{{ ch.label }}</th>
                  }
                </tr>
              </thead>
              <tbody>
                @for (e of eventsIn(group); track e.key) {
                  <tr class="border-t border-border">
                    <td class="px-2 py-2 text-foreground">
                      {{ e.label }}
                      @if (isAlwaysOn(e.key)) {
                        <span
                          class="ml-2 rounded-full bg-muted px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground"
                          >Always on</span
                        >
                      }
                    </td>
                    @for (ch of channels; track ch.key) {
                      <td class="px-2 py-2 text-center">
                        <hlm-switch
                          [checked]="isAlwaysOn(e.key) || getPref(e.key, ch.key)"
                          [disabled]="isAlwaysOn(e.key)"
                          [ariaLabel]="
                            e.label + ' · ' + ch.label + (isAlwaysOn(e.key) ? ' (always on)' : '')
                          "
                          (changed)="setPref(e.key, ch.key, $event)"
                        />
                      </td>
                    }
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      </div>
    }
    <div class="flex items-center gap-3">
      <button hlmBtn (click)="save()" [disabled]="saving()">
        @if (saving()) { <app-spinner [size]="16" /> Saving… } @else { Save preferences }
      </button>
      @if (saved()) {
        <span class="text-sm text-bcl-success">Saved.</span>
      }
      @if (error(); as e) {
        <span class="text-sm text-destructive" role="alert">{{ e }}</span>
      }
    </div>
  `,
})
export class SettingsNotificationsComponent implements OnInit {
  private readonly svc = inject(SettingsService);

  readonly events = EVENTS;
  readonly channels = CHANNELS;
  readonly groups = Array.from(new Set(EVENTS.map((e) => e.group)));
  readonly deliveryChannels: readonly {
    key: keyof NotificationChannelPrefs;
    label: string;
  }[] = [
    { key: 'in_app', label: 'In-app inbox' },
    { key: 'email', label: 'Email' },
    { key: 'sms', label: 'SMS' },
    { key: 'push', label: 'Push' },
  ];

  readonly prefs = signal<NotificationPrefs>({});
  readonly channelPrefs = signal<NotificationChannelPrefs>({
    in_app: true,
    email: true,
    sms: true,
    push: true,
  });
  readonly channelPrefsAvailable = signal<boolean>(false);
  readonly saving = signal<boolean>(false);
  readonly saved = signal<boolean>(false);
  readonly error = signal<string | null>(null);

  async ngOnInit(): Promise<void> {
    const [events, channels] = await Promise.allSettled([
      this.svc.getNotificationPrefs(),
      this.svc.getNotificationChannelPrefs(),
    ]);
    if (events.status === 'fulfilled') this.prefs.set(events.value);
    // A 404 means the orchestration flag is dark; keep the owning UI dark too.
    if (channels.status === 'fulfilled') {
      this.channelPrefs.set(channels.value);
      this.channelPrefsAvailable.set(true);
    }
  }

  channelEnabled(channel: keyof NotificationChannelPrefs): boolean {
    return this.channelPrefs()[channel];
  }

  setChannel(channel: keyof NotificationChannelPrefs, value: boolean): void {
    this.channelPrefs.update((current) => ({ ...current, [channel]: value }));
    this.saved.set(false);
  }

  eventsIn(g: string): readonly EventDef[] {
    return this.events.filter((e) => e.group === g);
  }

  /** Template helper — transactional events render as a locked "Always on" switch. */
  isAlwaysOn(key: string): boolean {
    return isAlwaysOnEvent(key);
  }

  getPref(event: string, ch: Channel): boolean {
    return this.prefs()[event]?.[ch] ?? false;
  }

  setPref(event: string, ch: Channel, value: boolean): void {
    this.prefs.update((cur) => ({
      ...cur,
      [event]: {
        ...{ email: false, push: false, sms: false, inApp: false },
        ...(cur[event] ?? {}),
        [ch]: value,
      },
    }));
    this.saved.set(false);
  }

  async save(): Promise<void> {
    this.saving.set(true);
    this.error.set(null);
    try {
      // Persist only opt-out-able (non-always-on) events — transactional
      // toggles are decorative and the send path ignores them, so keep them
      // out of the stored blob.
      const cur = this.prefs();
      const meaningful = Object.fromEntries(
        Object.entries(cur).filter(([key]) => !isAlwaysOnEvent(key)),
      );
      await Promise.all([
        this.svc.saveNotificationPrefs(meaningful),
        ...(this.channelPrefsAvailable()
          ? [this.svc.saveNotificationChannelPrefs(this.channelPrefs())]
          : []),
      ]);
      this.saved.set(true);
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Save failed');
    } finally {
      this.saving.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'notifications-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
