import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CrewBriefingsCardComponent — "your pre-job briefings" card on the crew
 * surface. Live surface = Angular /dashboard, crew audience.
 *
 * Consumes the new worker-facing list endpoint (session-gated):
 *   GET /api/work/briefings → { ok, briefings:[{ id, bookingId, generatedAt,
 *       startAt, serviceZip, hasPdf, detailPath }] }
 *
 * Each row links to the existing per-booking detail the worker can already
 * fetch (`detailPath` = /api/dispatch-advanced/pre-briefing/:bookingId). Full
 * 4-state, bclReveal, dark cockpit. Pure helpers unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmButton, HlmSkeleton } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export interface BriefingDto {
  readonly id: string;
  readonly bookingId: string;
  readonly generatedAt: string;
  readonly startAt: string | null;
  readonly serviceZip: string | null;
  readonly hasPdf: boolean;
  readonly detailPath: string;
}

interface BriefingsResponse {
  readonly ok: boolean;
  readonly briefings?: readonly BriefingDto[];
}

/** Pure: short job date for a briefing, blank when absent/junk. Unit-tested. */
export function formatJobDate(iso: string | null): string {
  if (!iso) return 'Date TBD';
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return 'Date TBD';
  return new Date(t).toLocaleString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  });
}

/** Pure: subtitle line — ZIP + generated date. Unit-tested. */
export function briefingSubtitle(b: Pick<BriefingDto, 'serviceZip' | 'generatedAt'>): string {
  const zip = b.serviceZip ? `ZIP ${b.serviceZip}` : 'Service area TBD';
  const t = b.generatedAt ? Date.parse(b.generatedAt) : NaN;
  const gen = Number.isNaN(t)
    ? ''
    : ` · briefing ready ${new Date(t).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}`;
  return `${zip}${gen}`;
}

@Component({
  selector: 'app-crew-briefings-card',
  standalone: true,
  imports: [HlmButton, HlmSkeleton, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section
      bclReveal
      data-testid="crew-briefings-card"
      class="rounded-xl border border-bcl-border bg-bcl-bg-elev/40 p-5"
      aria-labelledby="crew-briefings-title"
    >
      <header class="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <p class="font-mono text-xs uppercase tracking-wide text-bcl-accent">Prep</p>
          <h3 id="crew-briefings-title" class="text-lg font-semibold text-bcl-ink">Pre-job briefings</h3>
        </div>
        @if (count() > 0) {
          <span class="rounded-full bg-bcl-bg-elev px-2.5 py-0.5 text-xs font-semibold text-bcl-ink-muted ring-1 ring-bcl-border">
            {{ count() }}
          </span>
        }
      </header>

      @if (error(); as e) {
        <div class="mb-3 flex items-center justify-between gap-3 rounded-lg border border-destructive/40 bg-destructive/5 px-3 py-2" role="alert">
          <p class="text-sm text-bcl-ink">{{ e }}</p>
          <button hlmBtn variant="outline" size="sm" (click)="refresh()">Try again</button>
        </div>
      }

      @if (loading() && rows().length === 0) {
        <div class="space-y-2" aria-label="Loading briefings">
          <div hlmSkeleton class="h-14 w-full"></div>
          <div hlmSkeleton class="h-14 w-full"></div>
        </div>
      } @else if (rows().length === 0 && !error()) {
        <div class="rounded-lg border border-dashed border-bcl-border p-6 text-center text-sm text-bcl-ink-muted" data-testid="briefings-empty">
          No briefings yet. When dispatch prepares one for an upcoming job, it'll appear here.
        </div>
      } @else {
        <ul class="space-y-2">
          @for (b of rows(); track b.id) {
            <li class="flex items-center gap-3 rounded-lg border border-bcl-border bg-bcl-bg/40 px-3 py-2">
              <div class="min-w-0">
                <p class="truncate text-sm font-medium text-bcl-ink">{{ jobDate(b.startAt) }}</p>
                <p class="truncate text-xs text-bcl-ink-muted">{{ subtitle(b) }}</p>
              </div>
              <a
                hlmBtn
                variant="outline"
                size="sm"
                class="ml-auto shrink-0"
                [href]="b.detailPath"
                target="_blank"
                rel="noopener noreferrer"
                [attr.data-testid]="'briefing-view-' + b.bookingId"
                >View</a
              >
            </li>
          }
        </ul>
      }
    </section>
  `,
})
export class CrewBriefingsCardComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly loading = signal(false);
  readonly rows = signal<readonly BriefingDto[]>([]);
  readonly error = signal<string | null>(null);
  readonly count = computed(() => this.rows().length);

  ngOnInit(): void {
    void this.refresh();
  }

  jobDate(iso: string | null): string {
    return formatJobDate(iso);
  }
  subtitle(b: BriefingDto): string {
    return briefingSubtitle(b);
  }

  async refresh(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    try {
      const r = await firstValueFrom(
        this.http.get<BriefingsResponse>('/api/work/briefings', { withCredentials: true }),
      );
      this.rows.set(r?.ok ? (r.briefings ?? []) : []);
    } catch (err) {
      this.error.set(`Couldn't load briefings: ${(err as Error).message}`);
      this.rows.set([]);
    } finally {
      this.loading.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'briefings-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
