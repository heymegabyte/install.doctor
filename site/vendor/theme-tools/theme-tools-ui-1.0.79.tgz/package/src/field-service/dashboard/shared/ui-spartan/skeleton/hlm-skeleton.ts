import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * hlm-skeleton — loading placeholder (vendored helm). Pulse over a muted
 * surface; used by the 4-state block's loading state + table row shimmer.
 */
import { Directive, computed, input } from '@angular/core';
import { cn } from '../utils/cn';

@Directive({
  selector: '[hlmSkeleton]',
  standalone: true,
  host: { '[class]': '_computedClass()', role: 'status', 'aria-label': 'Loading' },
})
export class HlmSkeleton {
  readonly userClass = input<string>('', { alias: 'class' });
  protected readonly _computedClass = computed(() =>
    cn('animate-pulse rounded-md bg-muted', this.userClass()),
  );
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'hlm-skeleton',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
