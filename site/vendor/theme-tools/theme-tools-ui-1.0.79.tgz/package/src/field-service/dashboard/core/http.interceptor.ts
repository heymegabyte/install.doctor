import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { WAVE4_PARTNER_SPECS } from '@theme.tools/integrations/field-service-partner-adapters';
/**
 * HTTP interceptors — typed functional, registered in app.config.ts.
 *
 * - authInterceptor       — sends `withCredentials` so the Worker can read
 *                           the bcl_cust_sid / bcl_work_sid cookie.
 * - tenantInterceptor     — adds `X-Tenant-Id` for multi-tenant routes.
 * - roleInterceptor       — adds `X-View-As` so the server honors super-admin
 *                           role spoof.
 * - telemetryInterceptor  — Sentry breadcrumb + duration timing per request.
 *
 * All four are pure functions composed in the order listed above.
 */
import { HttpInterceptorFn, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { tap } from 'rxjs/operators';
import { TenantService } from './tenant.service';
import { RoleService } from './role.service';
import { TelemetryService } from './telemetry.service';

/** Always send cookies on same-origin /api/* calls. */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  if (!req.url.startsWith('/api/')) {
    return next(req);
  }
  return next(req.clone({ withCredentials: true }));
};

/** Pin the active tenant onto every /api/* call. */
export const tenantInterceptor: HttpInterceptorFn = (req, next) => {
  if (!req.url.startsWith('/api/')) {
    return next(req);
  }
  const tenant = inject(TenantService).activeTenantId();
  if (!tenant) {
    return next(req);
  }
  return next(req.clone({ setHeaders: { 'X-Tenant-Id': tenant } }));
};

/** Forward the super-admin view-as persona to the Worker. */
export const roleInterceptor: HttpInterceptorFn = (req, next) => {
  if (!req.url.startsWith('/api/')) {
    return next(req);
  }
  const role = inject(RoleService);
  if (!role.isSuperAdmin()) {
    return next(req);
  }
  return next(req.clone({ setHeaders: { 'X-View-As': role.viewAs() } }));
};

/**
 * Emit a Sentry breadcrumb + PostHog `api_call` event for every API request.
 * Captures method, URL, status, duration. Errors flow through the global
 * ErrorHandler — this interceptor only annotates the request lifecycle.
 */
export const telemetryInterceptor: HttpInterceptorFn = (req, next) => {
  if (!req.url.startsWith('/api/')) {
    return next(req);
  }
  const telemetry = inject(TelemetryService);
  const start = performance.now();
  return next(req).pipe(
    tap({
      next: (event) => {
        if (event instanceof HttpResponse) {
          telemetry.capture('http_response', {
            method: req.method,
            url: req.url,
            status: event.status,
            duration_ms: Math.round(performance.now() - start),
          });
        }
      },
      error: (err) => {
        const status = err instanceof HttpErrorResponse ? err.status : 0;
        telemetry.capture('http_error', {
          method: req.method,
          url: req.url,
          status,
          duration_ms: Math.round(performance.now() - start),
        });
      },
    }),
  );
};
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'http-interceptor',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_PARTNER_SPECS_COUNT = Object.keys(WAVE4_PARTNER_SPECS).length;
