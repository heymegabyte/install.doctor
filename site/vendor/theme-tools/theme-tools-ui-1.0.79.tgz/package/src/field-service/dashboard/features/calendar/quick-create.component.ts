import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * QuickCreateComponent — a fast operator "new job" popover for the dispatch
 * calendar. A centered Spartan modal with a mini-form (customer · date · time ·
 * service · crew · hours) and a LIVE hourly price preview computed from the
 * canonical HOURLY_RATE_CENTS × crew × hours (mirrors the worker var; the server
 * recomputes authoritatively on POST). Submits to admin.post('/api/admin/bookings')
 * and emits the created booking so the calendar inserts it without a reload.
 *
 * Client validation guards the obvious (required name/date/time, crew/hours ≥ 1,
 * 1-hour minimum); the server's Zod schema is authoritative + recomputes price.
 * No billing/payment is created — operational schedule entry only. Spartan
 * black/orange, role=dialog + aria-modal + Esc, dirty-safe.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { A11yModule } from '@angular/cdk/a11y';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, finalize, of } from 'rxjs';
import { HOURLY_RATE_CENTS } from './week-view.component';

export interface CreatedBooking {
  readonly id: string;
  readonly status: string;
  readonly customer_name: string | null;
  readonly city: string | null;
  readonly preferred_date: string | null;
  readonly preferred_time: string | null;
  readonly services_csv: string | null;
  readonly hours: number | null;
  readonly crew: number | null;
  readonly total_cents: number | null;
}

const SERVICES: readonly { value: string; label: string }[] = [
  { value: 'moving', label: 'Moving' },
  { value: 'hauling', label: 'Hauling' },
  { value: 'junk-removal', label: 'Junk removal' },
  { value: 'cleanout', label: 'Cleanout' },
  { value: 'yard-work', label: 'Yard work' },
  { value: 'power-washing', label: 'Power washing' },
  { value: 'general-labor', label: 'General labor' },
];

@Component({
  selector: 'app-quick-create',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [A11yModule],
  template: `
    @if (open()) {
      <div
        class="fixed inset-0 z-40 bg-black/60 bcl-fade-in"
        (click)="close()"
        aria-hidden="true"
      ></div>
      <div
        class="fixed left-1/2 top-1/2 z-50 w-[min(92vw,28rem)] -translate-x-1/2 -translate-y-1/2 rounded-2xl border border-bcl-border bg-bcl-bg p-5 shadow-2xl"
        role="dialog"
        aria-modal="true"
        aria-label="Quick-create a job"
        data-testid="quick-create"
        cdkTrapFocus
        [cdkTrapFocusAutoCapture]="true"
        (keydown.escape)="close()"
      >
        <div class="mb-4 flex items-start justify-between gap-3">
          <div>
            <p class="bcl-eyebrow mb-1">Dispatch</p>
            <h2 class="font-display text-xl font-bold text-bcl-ink">Quick-create job</h2>
          </div>
          <button
            type="button"
            (click)="close()"
            class="grid size-9 place-items-center rounded-lg border border-bcl-border text-bcl-ink-muted transition-colors hover:border-bcl-accent hover:text-bcl-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
            aria-label="Close"
            data-testid="quick-create-close"
          >
            ✕
          </button>
        </div>

        <div class="space-y-3">
          <div>
            <label for="qc-name" class="bcl-eyebrow text-[10px]">Customer name</label>
            <input
              id="qc-name"
              type="text"
              [value]="customerName()"
              (input)="customerName.set($any($event.target).value)"
              class="mt-1 w-full rounded-lg border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm text-bcl-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
              data-testid="qc-name"
              placeholder="Jo Rivera"
            />
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label for="qc-date" class="bcl-eyebrow text-[10px]">Date</label>
              <input
                id="qc-date"
                type="date"
                [value]="date()"
                (input)="date.set($any($event.target).value)"
                class="mt-1 w-full rounded-lg border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm text-bcl-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                data-testid="qc-date"
              />
            </div>
            <div>
              <label for="qc-time" class="bcl-eyebrow text-[10px]">Time</label>
              <input
                id="qc-time"
                type="time"
                [value]="time()"
                (input)="time.set($any($event.target).value)"
                class="mt-1 w-full rounded-lg border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm text-bcl-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                data-testid="qc-time"
              />
            </div>
          </div>
          <div>
            <label for="qc-service" class="bcl-eyebrow text-[10px]">Service</label>
            <select
              id="qc-service"
              [value]="service()"
              (change)="service.set($any($event.target).value)"
              class="mt-1 w-full rounded-lg border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm text-bcl-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
              data-testid="qc-service"
            >
              @for (s of services; track s.value) {
                <option [value]="s.value">{{ s.label }}</option>
              }
            </select>
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label for="qc-crew" class="bcl-eyebrow text-[10px]">Crew</label>
              <input
                id="qc-crew"
                type="number"
                min="1"
                max="20"
                [value]="crew()"
                (input)="crew.set(toInt($any($event.target).value, 1))"
                class="mt-1 w-full rounded-lg border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm text-bcl-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                data-testid="qc-crew"
              />
            </div>
            <div>
              <label for="qc-hours" class="bcl-eyebrow text-[10px]">Hours (1-hr min)</label>
              <input
                id="qc-hours"
                type="number"
                min="1"
                max="24"
                step="0.25"
                [value]="hours()"
                (input)="hours.set(toNum($any($event.target).value, 1))"
                class="mt-1 w-full rounded-lg border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm text-bcl-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                data-testid="qc-hours"
              />
            </div>
          </div>

          <div
            class="flex items-center justify-between rounded-lg border border-bcl-border bg-bcl-bg-elev px-3 py-2"
          >
            <span class="bcl-eyebrow text-[10px]"
              >Est. labor ({{ '$' + rateDollars }}/hr × crew × hrs)</span
            >
            <span
              class="bcl-tabular font-display text-lg font-extrabold text-bcl-accent"
              data-testid="qc-price"
              >{{ pricePreview() }}</span
            >
          </div>

          @if (error()) {
            <p
              class="rounded-lg border border-rose-500/30 bg-rose-500/5 p-3 text-xs text-rose-300"
              role="alert"
              data-testid="qc-error"
            >
              {{ error() }}
            </p>
          }
        </div>

        <button
          type="button"
          (click)="submit()"
          [disabled]="saving() || !valid()"
          class="mt-4 w-full rounded-lg bg-bcl-accent px-4 py-2.5 text-sm font-semibold text-bcl-bg transition-all duration-[333ms] disabled:opacity-50 hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bcl-bg"
          data-testid="qc-submit"
        >
          {{ saving() ? 'Scheduling…' : 'Schedule job' }}
        </button>
      </div>
    }
  `,
})
export class QuickCreateComponent {
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);

  readonly open = input<boolean>(false);
  /** Default date (the calendar's active day) — `YYYY-MM-DD`. */
  readonly defaultDate = input<string>('');
  readonly created = output<CreatedBooking>();
  readonly closed = output<void>();

  readonly services = SERVICES;
  readonly rateDollars = HOURLY_RATE_CENTS / 100;

  readonly customerName = signal('');
  readonly date = signal('');
  readonly time = signal('09:00');
  readonly service = signal<string>(SERVICES[0]!.value);
  readonly crew = signal(2);
  readonly hours = signal(2);
  readonly saving = signal(false);
  readonly error = signal<string | null>(null);

  /** Live price preview — canonical rate × crew × hours. Server recomputes. */
  readonly pricePreview = computed<string>(() => {
    const cents = HOURLY_RATE_CENTS * this.crew() * this.hours();
    return `$${(cents / 100).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
  });

  constructor() {
    // Seed the date field from the calendar's active day when the modal opens.
    // (input() default is read lazily in the template; seed on first valid value.)
  }

  valid(): boolean {
    return (
      this.customerName().trim().length > 0 &&
      /^\d{4}-\d{2}-\d{2}$/.test(this.effectiveDate()) &&
      this.time().length > 0 &&
      this.crew() >= 1 &&
      this.hours() >= 1
    );
  }

  private effectiveDate(): string {
    return this.date() || this.defaultDate();
  }

  toInt(v: string, fallback: number): number {
    const n = parseInt(v, 10);
    return Number.isFinite(n) && n >= 1 ? n : fallback;
  }
  toNum(v: string, fallback: number): number {
    const n = Number(v);
    return Number.isFinite(n) && n >= 1 ? n : fallback;
  }

  close(): void {
    this.error.set(null);
    this.closed.emit();
  }

  submit(): void {
    if (!this.valid()) return;
    this.saving.set(true);
    this.error.set(null);
    const body = {
      customerName: this.customerName().trim(),
      preferredDate: this.effectiveDate(),
      preferredTime: this.time(),
      services: [this.service()],
      crew: this.crew(),
      hours: this.hours(),
    };
    this.http
      .post<{ ok: boolean; booking?: CreatedBooking }>('/api/admin/bookings', body, {
        withCredentials: true,
      })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() => of({ ok: false } as { ok: boolean; booking?: CreatedBooking })),
        finalize(() => this.saving.set(false)),
      )
      .subscribe((r) => {
        if (!r.ok || !r.booking) {
          this.error.set('Could not schedule the job. Check your operator session and the fields.');
          return;
        }
        this.created.emit(r.booking);
        this.reset();
        this.closed.emit();
      });
  }

  private reset(): void {
    this.customerName.set('');
    this.crew.set(2);
    this.hours.set(2);
    this.service.set(SERVICES[0]!.value);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'quick-create-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
