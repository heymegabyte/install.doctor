import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * NpsQueueComponent — dispatcher view of pending mid-job NPS checks.
 *
 * Reads /api/mid-job-nps/admin/queue, surfaces detractors (score
 * ≤ 6) prominently, and exposes a one-click "Mark intervened" button
 * that POSTs to /admin/intervened/:id with a notes field.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, finalize, of } from 'rxjs';
import { routeFade, reducedMotion } from '../../shared/animations';

interface NpsCheck {
  readonly id: string;
  readonly gig_id: string;
  readonly booking_id: string | null;
  readonly customer_phone: string;
  readonly scheduled_send_at: string;
  readonly sent_at: string | null;
  readonly reply_at: string | null;
  readonly reply_body: string | null;
  readonly score: number | null;
  readonly status: string;
  readonly intervention_notes: string | null;
  readonly intervention_resolved_at: string | null;
}

@Component({
  selector: 'app-nps-queue',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header class="bcl-rise mb-6 rounded-2xl border border-bcl-border bcl-grain p-6">
      <p class="bcl-eyebrow mb-2">Customer recovery · Dispatcher</p>
      <h1 class="font-display text-3xl font-extrabold tracking-tight text-bcl-ink">
        Mid-Job NPS Queue
      </h1>
      <p class="mt-2 max-w-2xl text-sm text-bcl-ink-muted">
        Customers who replied to the 50%-mark check. Detractors (≤ 6)
        surface at the top with an intervention CTA.
      </p>
    </header>

    @if (loading()) {
      <p class="text-sm text-bcl-ink-muted" role="status">Loading feedback queue…</p>
    } @else if (error()) {
      <div class="rounded-md bg-bcl-danger/10 p-3 text-sm text-bcl-danger" role="alert">
        <p>{{ error() }}</p>
        <button
          type="button"
          class="mt-3 min-h-[44px] rounded-md border border-bcl-danger/40 px-3 py-2 font-bold focus-visible:ring-2 focus-visible:ring-bcl-accent"
          (click)="fetch()"
        >
          Try again
        </button>
      </div>
    } @else if (checks().length === 0) {
      <p
        class="rounded-2xl border border-bcl-border bg-bcl-bg-elev/40 p-6 text-sm text-bcl-ink-muted"
      >
        Nothing in queue. Either no gigs are mid-flight or the trigger hasn't
        run in the last 2 days. Fire it manually:
        <button
          type="button"
          (click)="trigger()"
          [disabled]="triggering()"
          class="ml-2 min-h-[44px] rounded-md bg-bcl-accent px-3 py-2 text-xs font-extrabold text-bcl-bg disabled:opacity-60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        >
          {{ triggering() ? 'Checking…' : 'Check active jobs' }}
        </button>
      </p>
    } @else {
      <ul class="space-y-3">
        @for (c of sortedChecks(); track c.id) {
          <li
            class="bcl-glass relative overflow-hidden p-5"
            [class.ring-2]="isDetractor(c)"
            [class.ring-bcl-danger\\/60]="isDetractor(c)"
          >
            <div class="flex min-w-0 flex-wrap items-start justify-between gap-4">
              <div class="min-w-0 flex-1">
                <div class="flex min-w-0 flex-wrap items-center gap-2">
                  <span
                    class="bcl-tabular rounded-md px-2.5 py-0.5 font-display text-xl font-extrabold"
                    [class.bg-bcl-success\\/20]="(c.score ?? -1) >= 9"
                    [class.text-bcl-success]="(c.score ?? -1) >= 9"
                    [class.bg-bcl-warn\\/20]="(c.score ?? -1) >= 7 && (c.score ?? -1) <= 8"
                    [class.text-bcl-warn]="(c.score ?? -1) >= 7 && (c.score ?? -1) <= 8"
                    [class.bg-bcl-danger\\/20]="(c.score ?? -1) >= 0 && (c.score ?? -1) <= 6"
                    [class.text-bcl-danger]="(c.score ?? -1) >= 0 && (c.score ?? -1) <= 6"
                  >
                    {{ c.score === null ? '—' : c.score }}
                  </span>
                  <span class="min-w-0 break-words font-mono text-xs text-bcl-ink-muted">
                    gig {{ c.gig_id.slice(0, 12) }} · {{ formatTime(c.reply_at ?? c.sent_at) }}
                  </span>
                </div>
                @if (c.reply_body) {
                  <p class="mt-2 text-sm text-bcl-ink">"{{ c.reply_body }}"</p>
                }
                <p class="mt-2 text-xs text-bcl-ink-muted font-mono">
                  {{ c.customer_phone }}
                </p>
              </div>
              <div class="shrink-0 text-right">
                <span
                  class="inline-flex items-center gap-1 rounded-full bg-bcl-bg-elev/60 px-2.5 py-1 text-[11px] font-mono uppercase tracking-wider"
                  [class.text-bcl-success]="c.status === 'intervened'"
                  [class.text-bcl-warn]="c.status === 'replied'"
                  [class.text-bcl-ink-muted]="c.status === 'sent'"
                >
                  {{ c.status }}
                </span>
              </div>
            </div>
            @if (c.status === 'replied' && isDetractor(c)) {
              <div class="mt-4 grid gap-2 sm:grid-cols-[1fr_auto]">
                <input
                  type="text"
                  [value]="noteDrafts()[c.id] ?? ''"
                  (input)="setDraft(c.id, $event)"
                  placeholder="Quick note (e.g. 'credited $50, called crew lead')"
                  [attr.aria-label]="'Intervention note for gig ' + c.gig_id"
                  class="rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-3 py-2 text-sm text-bcl-ink"
                />
                <button
                  type="button"
                  (click)="intervene(c.id)"
                  class="rounded-md bg-bcl-accent px-4 py-2 text-sm font-extrabold text-bcl-bg disabled:opacity-60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                  [disabled]="busy()[c.id] === true"
                >
                  {{ busy()[c.id] ? 'Saving…' : 'Mark intervened' }}
                </button>
              </div>
            }
            @if (c.intervention_notes) {
              <p class="mt-3 break-words text-xs text-bcl-ink-muted">
                <span class="font-mono uppercase tracking-wider">Resolved:</span>
                {{ c.intervention_notes }}
              </p>
            }
          </li>
        }
      </ul>
    }
    @if (actionError()) {
      <p class="mt-4 rounded-md bg-bcl-danger/10 p-3 text-sm text-bcl-danger" role="alert">
        {{ actionError() }}
      </p>
    }
  `,
})
export class NpsQueueComponent {
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);

  readonly checks = signal<NpsCheck[]>([]);
  readonly loading = signal(false);
  readonly error = signal<string | null>(null);
  readonly noteDrafts = signal<Record<string, string>>({});
  readonly busy = signal<Record<string, boolean>>({});
  readonly triggering = signal(false);
  readonly actionError = signal<string | null>(null);

  readonly sortedChecks = computed(() => {
    return this.checks()
      .slice()
      .sort((a, b) => {
        const aIsDetractor = a.status === 'replied' && (a.score ?? 99) <= 6 ? 0 : 1;
        const bIsDetractor = b.status === 'replied' && (b.score ?? 99) <= 6 ? 0 : 1;
        if (aIsDetractor !== bIsDetractor) return aIsDetractor - bIsDetractor;
        return (b.reply_at ?? b.sent_at ?? '').localeCompare(a.reply_at ?? a.sent_at ?? '');
      });
  });

  constructor() {
    this.fetch();
  }

  isDetractor(c: NpsCheck): boolean {
    return c.status === 'replied' && c.score !== null && c.score <= 6;
  }

  formatTime(iso: string | null): string {
    if (!iso) return '';
    try {
      return new Date(iso).toLocaleString(undefined, {
        weekday: 'short',
        hour: 'numeric',
        minute: '2-digit',
      });
    } catch {
      return iso;
    }
  }

  setDraft(id: string, evt: Event): void {
    const value = (evt.target as HTMLInputElement).value;
    this.noteDrafts.update((d) => ({ ...d, [id]: value }));
  }

  fetch(): void {
    this.loading.set(true);
    this.error.set(null);
    this.http
      .get<{ ok: boolean; checks: NpsCheck[] }>('/api/mid-job-nps/admin/queue', {
        withCredentials: true,
      })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((err: { status?: number }) => {
          this.error.set(
            err.status === 404
              ? 'Feature flag mid_job_nps is off in prod.'
              : err.status === 401
                ? 'Admin session required — please re-login.'
                : `Failed to load (HTTP ${err.status ?? '?'}).`,
          );
          return of({ ok: false, checks: [] as NpsCheck[] });
        }),
        finalize(() => this.loading.set(false)),
      )
      .subscribe((r) => this.checks.set(r.checks ?? []));
  }

  trigger(): void {
    this.triggering.set(true);
    this.actionError.set(null);
    this.http
      .post('/api/mid-job-nps/trigger', {}, { withCredentials: true })
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() => {
          this.actionError.set('Could not check active jobs. Nothing was sent. Try again.');
          return of(null);
        }),
        finalize(() => this.triggering.set(false)),
      )
      .subscribe((result) => {
        if (result !== null) this.fetch();
      });
  }

  intervene(id: string): void {
    const notes = this.noteDrafts()[id] ?? '';
    if (!notes.trim()) return;
    this.actionError.set(null);
    this.busy.update((b) => ({ ...b, [id]: true }));
    this.http
      .post(
        `/api/mid-job-nps/admin/intervened/${id}`,
        { notes, outcome: 'resolved' },
        { withCredentials: true },
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        finalize(() => this.busy.update((b) => ({ ...b, [id]: false }))),
        catchError(() => {
          this.actionError.set('Could not save the intervention. Your note is still here. Try again.');
          return of(null);
        }),
      )
      .subscribe((result) => {
        if (result !== null) this.fetch();
      });
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'nps-queue-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
