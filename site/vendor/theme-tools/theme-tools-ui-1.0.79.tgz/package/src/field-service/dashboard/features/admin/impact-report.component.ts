import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * ImpactReportComponent — yearly impact poster admin at /admin/impact-report.
 *
 * Surfaces /api/admin/impact-report (list generated reports, generate one for a
 * year, view the SVG poster). The capability existed but had no dashboard surface +
 * was OWNER_INVOICE_KEY-bearer-only; auth migrated to ownerOrSuperAdmin 2026-06-07.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HlmCardImports } from '../../shared/ui-spartan';

export interface ImpactReport {
  readonly year: number;
  readonly generated_at: string;
  readonly r2_pdf_key: string | null;
  readonly donations_total_cents: number;
  readonly jobs_completed: number;
  readonly crew_earnings_cents: number;
  readonly avg_rating: number | null;
  readonly viral_share_count: number;
}

interface ListResponse {
  readonly ok: boolean;
  readonly reports?: readonly ImpactReport[];
  readonly error?: string;
}

/** Pure: cents → $ string. Tested. */
export function dollars(cents: number | null | undefined): string {
  return `$${Math.round((cents ?? 0) / 100).toLocaleString()}`;
}

@Component({
  selector: 'app-admin-impact-report',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [...HlmCardImports],
  template: `
    <header class="mb-4">
      <h1 class="text-2xl font-bold text-foreground">Impact reports</h1>
      <p class="text-sm text-muted-foreground">
        Yearly impact posters — jobs, crew earnings, donations, ratings.
      </p>
    </header>

    <div hlmCard class="mb-4 flex flex-wrap items-end gap-3 p-4">
      <label class="flex flex-col gap-1 text-xs text-muted-foreground">
        Year
        <select
          class="rounded-md border border-input bg-background px-2 py-1.5 text-sm text-foreground"
          [value]="year()"
          (change)="year.set(+$any($event.target).value)"
        >
          @for (y of years; track y) { <option [value]="y">{{ y }}</option> }
        </select>
      </label>
      <button
        type="button"
        class="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        [disabled]="generating()"
        (click)="generate()"
      >
        {{ generating() ? 'Generating…' : 'Generate for ' + year() }}
      </button>
    </div>

    @if (error(); as e) {
      <div hlmCard class="p-4"><p class="text-sm text-destructive">{{ e }}</p></div>
    } @else if (reports().length > 0) {
      <ul role="list" class="flex flex-col divide-y divide-border rounded-xl border border-border bg-card">
        @for (r of reports(); track r.year) {
          <li class="flex flex-col gap-2 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div class="min-w-0">
              <p class="text-base font-bold text-foreground">{{ r.year }}</p>
              <p class="mt-0.5 text-xs text-muted-foreground">
                {{ r.jobs_completed }} jobs · {{ money(r.crew_earnings_cents) }} crew earnings ·
                {{ money(r.donations_total_cents) }} donated{{ r.avg_rating != null ? ' · ' + r.avg_rating + '★' : '' }}
              </p>
            </div>
            @if (r.r2_pdf_key) {
              <a
                class="shrink-0 rounded-md border border-border px-3 py-1.5 text-sm text-primary hover:bg-primary/10"
                [href]="'/api/admin/impact-report/file/' + r.year"
                target="_blank"
                rel="noopener noreferrer"
              >
                View poster
              </a>
            }
          </li>
        }
      </ul>
    } @else if (loading()) {
      <p class="text-sm text-muted-foreground">Loading…</p>
    } @else {
      <div hlmCard class="p-6 text-center">
        <p class="text-sm text-muted-foreground">No impact reports yet — generate one above.</p>
      </div>
    }
  `,
})
export class ImpactReportComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly reports = signal<readonly ImpactReport[]>([]);
  readonly loading = signal<boolean>(false);
  readonly generating = signal<boolean>(false);
  readonly error = signal<string | null>(null);
  // A fixed recent-year range — the worker validates the year too.
  readonly years: readonly number[] = [2026, 2025, 2024];
  readonly year = signal<number>(2026);

  protected readonly money = dollars;

  ngOnInit(): void {
    void this.load();
  }

  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    const r = await firstValueFrom(
      this.http
        .get<ListResponse>('/api/admin/impact-report/list')
        .pipe(catchError(() => of({ ok: false, error: 'Failed to load reports' } as ListResponse))),
    );
    if (r.ok) this.reports.set(r.reports ?? []);
    else this.error.set(r.error ?? 'Unknown error');
    this.loading.set(false);
  }

  async generate(): Promise<void> {
    this.generating.set(true);
    this.error.set(null);
    const r = await firstValueFrom(
      this.http
        .post<{ ok: boolean; error?: string }>(`/api/admin/impact-report/generate/${this.year()}`, {})
        .pipe(catchError(() => of({ ok: false, error: 'Generation failed' }))),
    );
    this.generating.set(false);
    if (r.ok) await this.load();
    else this.error.set(r.error ?? 'Generation failed');
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'impact-report-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
