import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * JobsComponent — crew jobs list (Wave 4), rebuilt on Spartan.
 *
 * Splits into "Active" (any non-terminal ride state) and "Recent" (completed or
 * cancelled in last 30 days) — a grouped crew view, not a flat sortable table
 * (SmartTable is reserved for the dense admin browsers in W5). Tapping a row
 * routes to /jobs/:id (live tracking). RxJS-first: a 60s polling stream
 * (interval + reload signal) → switchMap(HttpClient GET /api/work/gigs) →
 * signal, replacing the raw fetch() (which also broke the jsdom spec). On a
 * 401/404 it degrades silently (not signed in / endpoint not wired); a 5xx
 * surfaces an error but keeps the last-known list. Status via HlmBadge +
 * statusBadge. Card surfaces via HlmCard; skeletons via HlmSkeleton.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  inject,
  signal,
} from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { RouterLink } from '@angular/router';
import { interval, combineLatest, merge, of, switchMap, map, catchError } from 'rxjs';
import { HlmCardImports, HlmBadge, HlmSkeleton } from '../../shared/ui-spartan';
import { statusBadge } from '@theme.tools/crm/field-service/status-badge';
import { RoleService } from '../../core/role.service';
import { FeatureFlagService } from '../../core/feature-flag.service';
import { isNyToday, isNyUpcoming } from '@theme.tools/scheduling/field-service/jobs-today';
import { routeFade, reducedMotion } from '../../shared/animations';

interface Job {
  readonly id: string;
  readonly customerName: string;
  readonly serviceLabel: string;
  readonly pickup: string;
  readonly state:
    | 'requested'
    | 'matched'
    | 'enroute'
    | 'arrived'
    | 'working'
    | 'complete'
    | 'cancelled';
  readonly scheduledAt: number;
  readonly payoutCents: number;
  readonly claimStatus?: string;
}

/** Raw row from the `invites` array in GET /api/work/gigs */
interface InviteRow {
  readonly id: string;
  readonly booking_id?: string;
  readonly status: string;
  readonly service?: string | null;
  readonly service_type?: string | null;
  readonly crew_needed?: number;
  readonly crew_filled?: number;
  readonly needs_driver?: number;
  readonly hours_estimated?: number;
  readonly start_at: string;
  readonly started_at?: string | null;
  readonly service_address?: string | null;
  readonly service_zip?: string | null;
  readonly worker_pay_cents_per_person?: number;
  readonly shift_lead_bonus_cents?: number;
  readonly rush_bonus_cents?: number;
  readonly customer_notes?: string | null;
  readonly claim_id?: string;
  readonly claim_status?: string;
  readonly invited_at?: string;
  readonly customer_name?: string | null;
}

/** Raw row from the `completed` array in GET /api/work/gigs */
interface CompletedRow {
  readonly id: string;
  readonly start_at: string;
  readonly service?: string | null;
  readonly service_type?: string | null;
  readonly service_address?: string | null;
  readonly earnings_cents?: number;
  readonly tip_cents?: number;
  readonly check_in_at?: string | null;
  readonly check_out_at?: string | null;
  readonly customer_name?: string | null;
}

const JOB_SERVICE_LABELS: Readonly<Record<string, string>> = {
  'power-washing': 'Power Washing',
  'lawn-care': 'Lawn Care',
  hauling: 'Hauling & Junk Removal',
  'light-repairs': 'Light Repairs',
  'moving-labor': 'Moving Labor',
  'furniture-removal': 'Furniture Removal',
  'apartment-cleanout': 'Apartment Cleanout',
  'paint-scraping': 'Paint Scraping',
  'loading-unloading': 'Loading & Unloading',
  'moving-help': 'Moving Help',
  'junk-removal': 'Hauling & Junk Removal',
  'yard-work': 'Lawn Care',
  cleanout: 'Apartment Cleanout',
  painting: 'Paint Scraping',
  'general-labor': 'General Labor',
};

export function formatJobServiceLabel(
  rawService: string | null | undefined,
  needsDriver: number | undefined,
  fallback: string,
): string {
  const cleaned = rawService?.trim();
  if (cleaned) {
    const key = cleaned.toLowerCase();
    const mapped = JOB_SERVICE_LABELS[key];
    if (mapped) return mapped;
    return cleaned
      .split(/[-_\s]+/)
      .filter((w) => w.length > 0)
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      .join(' ');
  }
  return needsDriver ? 'Driving + labor' : fallback;
}

/** Map a raw invite row to the component's Job shape */
function toActiveJob(inv: InviteRow): Job {
  return {
    id: inv.id,
    customerName: inv.customer_name ?? 'Customer',
    serviceLabel: formatJobServiceLabel(
      inv.service ?? inv.service_type,
      inv.needs_driver,
      'Labor crew',
    ),
    pickup: inv.service_address ?? inv.service_zip ?? '—',
    state: inv.status as Job['state'],
    scheduledAt: Date.parse(inv.start_at) || 0,
    payoutCents:
      (inv.worker_pay_cents_per_person ?? 0) * (inv.hours_estimated ?? 0) +
      (inv.shift_lead_bonus_cents ?? 0) +
      (inv.rush_bonus_cents ?? 0),
    claimStatus: inv.claim_status,
  };
}

/** Map a raw completed row to the component's Job shape */
function toRecentJob(c: CompletedRow): Job {
  return {
    id: c.id,
    customerName: c.customer_name ?? 'Customer',
    serviceLabel: formatJobServiceLabel(c.service ?? c.service_type, undefined, 'Completed job'),
    pickup: c.service_address ?? '—',
    state: 'complete',
    scheduledAt: Date.parse(c.start_at) || 0,
    payoutCents: (c.earnings_cents ?? 0) + (c.tip_cents ?? 0),
  };
}

@Component({
  selector: 'app-jobs',
  standalone: true,
  imports: [...HlmCardImports, HlmBadge, HlmSkeleton, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header class="mb-6 flex items-center justify-between gap-3">
      <div>
        <h1 class="text-2xl font-bold text-foreground">Jobs</h1>
        <p class="text-sm text-muted-foreground">Tap any row to follow the trip live.</p>
      </div>
      <span hlmBadge variant="default">{{ active().length }} active</span>
    </header>

    @if (!isCrewView()) {
      <div
        class="mb-4 rounded-xl border border-dashed border-border p-8 text-center"
        data-testid="jobs-not-crew"
      >
        <span aria-hidden="true" class="text-2xl">🧰</span>
        <p class="mt-2 text-sm font-semibold text-foreground">Crew jobs live here</p>
        <p class="mx-auto mt-1 max-w-sm text-sm text-muted-foreground">
          Switch to the crew persona to see live gigs, dispatch offers, and payouts.
        </p>
        @if (roleSvc.canSwitchRole()) {
          <button
            type="button"
            (click)="switchToCrew()"
            class="mt-4 inline-flex min-h-[44px] items-center justify-center rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors duration-[333ms] hover:bg-primary/90 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
          >
            View as crew →
          </button>
        }
      </div>
    } @else {
      @if (loadError(); as err) {
        <div
          class="mb-4 flex items-center justify-between gap-3 rounded-xl border border-destructive/40 bg-destructive/5 px-4 py-3"
          role="alert"
        >
          <p class="text-sm text-foreground">Couldn't fetch your jobs — {{ err }}</p>
          <button
            type="button"
            (click)="refresh()"
            class="rounded-md border border-border px-3 py-1 text-xs text-muted-foreground hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
          >
            Try again
          </button>
        </div>
      }

      <div class="space-y-6">
        @if (loading()) {
          <!-- First-load skeleton — the component starts loading=true and polls every 60s; without
               this the always-on Active/Recent cards flash their "No jobs" empty state before the
               initial poll resolves (lying-empty). Mirrors the sibling JobHistoryComponent. -->
          @for (row of [1, 2, 3]; track row) {
            <div hlmCard data-testid="jobs-loading">
              <div hlmCardContent class="space-y-3 py-4">
                <div hlmSkeleton class="h-4 w-1/3"></div>
                <div hlmSkeleton class="h-11 w-full"></div>
                <div hlmSkeleton class="h-11 w-full"></div>
              </div>
            </div>
          }
        } @else {
        @if (crewJobsOffers()) {
          <div hlmCard data-testid="jobs-offers">
            <div hlmCardHeader>
              <h3 hlmCardTitle>Offers</h3>
              <p hlmCardDescription>Pending job offers — tap to accept or decline.</p>
            </div>
            <div hlmCardContent>
              @if (offers().length === 0) {
                <div
                  class="flex flex-col items-center gap-2 rounded-xl border border-dashed border-border p-8 text-center"
                  data-testid="jobs-offers-empty"
                >
                  <span aria-hidden="true" class="text-2xl">📬</span>
                  <p class="text-sm font-semibold text-foreground">No pending offers</p>
                  <p class="max-w-sm text-sm text-muted-foreground">
                    When dispatch sends you a job offer, it lands here.
                  </p>
                </div>
              } @else {
                <ul class="divide-y divide-border">
                  @for (j of offers(); track j.id) {
                    <li>
                      <a
                        [routerLink]="['/jobs', j.id]"
                        [attr.aria-label]="j.serviceLabel + ' gig, ' + formatMoney(j.payoutCents) + ', ' + badge(j.state).label + (j.pickup ? ', for ' + j.customerName + ' at ' + j.pickup : '')"
                        class="flex min-h-[44px] items-center gap-3 py-3 transition-colors hover:bg-accent/40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                      >
                        <div class="min-w-0 flex-1">
                          <p class="truncate text-sm font-semibold text-foreground">
                            {{ j.serviceLabel }}
                          </p>
                          <p class="truncate text-xs text-muted-foreground">
                            {{ j.customerName }} · {{ j.pickup }}
                          </p>
                        </div>
                        <span hlmBadge [variant]="badge(j.state).variant">{{
                          badge(j.state).label
                        }}</span>
                        <span class="ml-3 font-mono text-sm tabular-nums text-primary">{{
                          formatMoney(j.payoutCents)
                        }}</span>
                      </a>
                    </li>
                  }
                </ul>
              }
            </div>
          </div>
        }

        @if (crewJobsToday()) {
          <div hlmCard data-testid="jobs-today">
            <div hlmCardHeader>
              <h3 hlmCardTitle>Today</h3>
              <p hlmCardDescription>Your active jobs scheduled for today.</p>
            </div>
            <div hlmCardContent>
              @if (today().length === 0) {
                <div
                  class="flex flex-col items-center gap-2 rounded-xl border border-dashed border-border p-8 text-center"
                  data-testid="jobs-today-empty"
                >
                  <span aria-hidden="true" class="text-2xl">📅</span>
                  <p class="text-sm font-semibold text-foreground">Nothing on the schedule today</p>
                  <p class="max-w-sm text-sm text-muted-foreground">
                    Any active job with today's date in America/New_York will appear here.
                  </p>
                </div>
              } @else {
                <ul class="divide-y divide-border">
                  @for (j of today(); track j.id) {
                    <li>
                      <a
                        [routerLink]="['/jobs', j.id]"
                        [attr.aria-label]="j.serviceLabel + ' gig, ' + formatMoney(j.payoutCents) + ', ' + badge(j.state).label + (j.pickup ? ', for ' + j.customerName + ' at ' + j.pickup : '')"
                        class="flex min-h-[44px] items-center gap-3 py-3 transition-colors hover:bg-accent/40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                      >
                        <div class="min-w-0 flex-1">
                          <p class="truncate text-sm font-semibold text-foreground">
                            {{ j.serviceLabel }}
                          </p>
                          <p class="truncate text-xs text-muted-foreground">
                            {{ j.customerName }} · {{ j.pickup }}
                          </p>
                        </div>
                        <span hlmBadge [variant]="badge(j.state).variant">{{
                          badge(j.state).label
                        }}</span>
                        <span class="ml-3 font-mono text-sm tabular-nums text-primary">{{
                          formatMoney(j.payoutCents)
                        }}</span>
                      </a>
                    </li>
                  }
                </ul>
              }
            </div>
          </div>
        }

        @if (crewJobsUpcoming()) {
          <div hlmCard data-testid="jobs-next-up">
            <div hlmCardHeader>
              <h3 hlmCardTitle>Next up</h3>
              <p hlmCardDescription>Your upcoming scheduled jobs.</p>
            </div>
            <div hlmCardContent>
              @if (nextUp().length === 0) {
                <div
                  class="flex flex-col items-center gap-2 rounded-xl border border-dashed border-border p-8 text-center"
                  data-testid="jobs-next-up-empty"
                >
                  <span aria-hidden="true" class="text-2xl">📆</span>
                  <p class="text-sm font-semibold text-foreground">No upcoming jobs scheduled</p>
                  <p class="max-w-sm text-sm text-muted-foreground">
                    Active jobs with a future date in America/New_York will appear here.
                  </p>
                </div>
              } @else {
                <ul class="divide-y divide-border">
                  @for (j of nextUp(); track j.id) {
                    <li>
                      <a
                        [routerLink]="['/jobs', j.id]"
                        [attr.aria-label]="j.serviceLabel + ' gig, ' + formatMoney(j.payoutCents) + ', ' + badge(j.state).label + (j.pickup ? ', for ' + j.customerName + ' at ' + j.pickup : '')"
                        class="flex min-h-[44px] items-center gap-3 py-3 transition-colors hover:bg-accent/40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                      >
                        <div class="min-w-0 flex-1">
                          <p class="truncate text-sm font-semibold text-foreground">
                            {{ j.serviceLabel }}
                          </p>
                          <p class="truncate text-xs text-muted-foreground">
                            {{ j.customerName }} · {{ j.pickup }}
                          </p>
                        </div>
                        <span hlmBadge [variant]="badge(j.state).variant">{{
                          badge(j.state).label
                        }}</span>
                        <span class="ml-3 font-mono text-sm tabular-nums text-primary">{{
                          formatMoney(j.payoutCents)
                        }}</span>
                      </a>
                    </li>
                  }
                </ul>
              }
            </div>
          </div>
        }

        <div hlmCard>
          <div hlmCardHeader>
            <h3 hlmCardTitle>Active</h3>
            <p hlmCardDescription>Open assignments still in motion.</p>
          </div>
          <div hlmCardContent>
            @if (active().length === 0) {
              <div
                class="flex flex-col items-center gap-2 rounded-xl border border-dashed border-border p-8 text-center"
                data-testid="jobs-empty"
              >
                <span aria-hidden="true" class="text-2xl">🟢</span>
                <p class="text-sm font-semibold text-foreground">No active jobs right now</p>
                <p class="max-w-sm text-sm text-muted-foreground">
                  When dispatch sends you an offer, it lands here. Stay online to keep the meter
                  running.
                </p>
              </div>
            } @else {
              <ul class="divide-y divide-border">
                @for (j of active(); track j.id) {
                  <li>
                    <a
                      [routerLink]="['/jobs', j.id]"
                      [attr.aria-label]="j.serviceLabel + ' gig, ' + formatMoney(j.payoutCents) + ', ' + badge(j.state).label + (j.pickup ? ', for ' + j.customerName + ' at ' + j.pickup : '')"
                      class="flex min-h-[44px] items-center gap-3 py-3 transition-colors hover:bg-accent/40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                    >
                      <div class="min-w-0 flex-1">
                        <p class="truncate text-sm font-semibold text-foreground">
                          {{ j.serviceLabel }}
                        </p>
                        <p class="truncate text-xs text-muted-foreground">
                          {{ j.customerName }} · {{ j.pickup }}
                        </p>
                      </div>
                      <span hlmBadge [variant]="badge(j.state).variant">{{
                        badge(j.state).label
                      }}</span>
                      <span class="ml-3 font-mono text-sm tabular-nums text-primary">{{
                        formatMoney(j.payoutCents)
                      }}</span>
                    </a>
                  </li>
                }
              </ul>
            }
          </div>
        </div>

        <div hlmCard>
          <div hlmCardHeader>
            <h3 hlmCardTitle>Recent</h3>
            <p hlmCardDescription>Last 30 days, complete or cancelled.</p>
          </div>
          <div hlmCardContent>
            @if (recent().length === 0) {
              <p class="text-sm text-muted-foreground">
                Nothing in the last 30 days. Completed work shows up here with totals.
              </p>
            } @else {
              <ul class="divide-y divide-border">
                @for (j of recent(); track j.id) {
                  <li>
                    <a
                      [routerLink]="['/jobs', j.id]"
                      [attr.aria-label]="j.serviceLabel + ', ' + badge(j.state).label + (j.scheduledAt ? ', ' + formatDate(j.scheduledAt) : '')"
                      class="flex min-h-[44px] items-center gap-3 py-3 transition-colors hover:bg-accent/40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                    >
                      <div class="min-w-0 flex-1">
                        <p class="truncate text-sm text-foreground">{{ j.serviceLabel }}</p>
                        <p class="truncate text-xs text-muted-foreground">
                          {{ formatDate(j.scheduledAt) }}
                        </p>
                      </div>
                      <span hlmBadge [variant]="badge(j.state).variant">{{
                        badge(j.state).label
                      }}</span>
                    </a>
                  </li>
                }
              </ul>
            }
          </div>
        </div>
        }
      </div>
    }
  `,
})
export class JobsComponent {
  /** Bound to host [@.disabled] — skips the route-entrance fade for reduced-motion users. */
  protected readonly reducedMotion = reducedMotion;
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);
  protected readonly roleSvc = inject(RoleService);
  private readonly flagSvc = inject(FeatureFlagService);

  readonly jobs = signal<Job[]>([]);
  readonly loading = signal<boolean>(true);
  readonly loadError = signal<string | null>(null);
  private readonly reload = signal(0);

  protected readonly badge = statusBadge;

  /**
   * `/api/work/gigs` is a CREW endpoint (worker-session gated). A super-admin
   * viewing the unified dashboard has no `bcl_work_sid`, so firing it
   * unconditionally 401'd on every authed walk. Only fetch when the active
   * persona is crew; the persona signal re-triggers the stream on a flip.
   */
  readonly isCrewView = computed(() => this.roleSvc.viewAs() === 'crew');

  /** crew_jobs_offers flag — "Offers" section rendered ABOVE Today (default OFF). */
  readonly crewJobsOffers = this.flagSvc.isOn('crew_jobs_offers');
  /** crew_jobs_today flag — "Today" section rendered ABOVE Active (default OFF). */
  readonly crewJobsToday = this.flagSvc.isOn('crew_jobs_today');
  /** crew_jobs_upcoming flag — "Next up" section rendered BELOW Today and ABOVE Active (default OFF). */
  readonly crewJobsUpcoming = this.flagSvc.isOn('crew_jobs_upcoming');

  readonly active = computed(() =>
    this.jobs().filter((j) => j.state !== 'complete' && j.state !== 'cancelled'),
  );
  readonly recent = computed(() =>
    this.jobs().filter((j) => j.state === 'complete' || j.state === 'cancelled'),
  );
  /** Active jobs whose scheduledAt falls on today in America/New_York. */
  readonly today = computed(() =>
    this.active().filter((j) => isNyToday(j.scheduledAt, Date.now())),
  );
  /** Active jobs whose scheduledAt falls on a FUTURE America/New_York calendar day. */
  readonly nextUp = computed(() =>
    this.active().filter((j) => isNyUpcoming(j.scheduledAt, Date.now())),
  );
  /** Active jobs offered to this crew member but not yet accepted (claim_status === 'invited'). */
  readonly offers = computed(() =>
    this.active().filter((j) => j.claimStatus === 'invited'),
  );

  constructor() {
    // Polling-as-floor (rxjs-first): combineLatest pairs the persona with the
    // poll trigger (immediate via reload's initial emission, then every 60s) so
    // each trigger fires EXACTLY ONE request — a persona flip re-evaluates the
    // gate, a reload/tick re-fetches. switchMap cancels an in-flight poll.
    combineLatest([
      toObservable(this.isCrewView),
      merge(toObservable(this.reload), interval(60_000)),
    ])
      .pipe(
        switchMap(() => {
          // Skip the crew fetch entirely for non-crew personas — no 401.
          if (!this.isCrewView()) return of({ kind: 'skip' as const });
          // A crew fetch is starting → show the loading skeleton until it resolves. Re-asserting
          // this (not just the initial signal) fixes the empty-state flash when a transient
          // non-crew 'skip' emission already flipped loading→false before the persona settled on crew.
          this.loading.set(true);
          return this.http
            .get<{ invites?: InviteRow[]; completed?: CompletedRow[] }>('/api/work/gigs', {
              withCredentials: true,
            })
            .pipe(
            map((d) => ({
              kind: 'ok' as const,
              gigs: [
                ...(d.invites ?? []).map(toActiveJob),
                ...(d.completed ?? []).map(toRecentJob),
              ],
            })),
            catchError((e: HttpErrorResponse) =>
              of({ kind: 'err' as const, status: e.status, message: e.message ?? 'Network blip' }),
            ),
          );
        }),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((r) => {
        this.loading.set(false);
        if (r.kind === 'skip') {
          this.jobs.set([]);
          this.loadError.set(null);
        } else if (r.kind === 'ok') {
          this.jobs.set(r.gigs);
          this.loadError.set(null);
        } else if (r.status >= 500) {
          // 401/404 → not signed in or endpoint not wired: stay silent, keep last list.
          this.loadError.set(`Server error (${r.status})`);
        }
      });
  }

  refresh(): void {
    this.reload.update((n) => n + 1);
  }

  /** Flip the active persona to crew so the live jobs list renders (super-admin only). */
  switchToCrew(): void {
    this.roleSvc
      .setViewAs('crew')
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        error: () => undefined,
      });
  }

  formatMoney(cents: number): string {
    return `$${(cents / 100).toFixed(2)}`;
  }

  formatDate(ts: number): string {
    return new Date(ts).toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'jobs-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
