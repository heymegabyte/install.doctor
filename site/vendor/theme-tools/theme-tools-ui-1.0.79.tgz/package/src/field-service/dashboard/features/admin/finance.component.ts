import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminFinanceComponent — revenue forecast + profit-by-service on the admin console.
 * Live surface = Angular /dashboard/admin.
 *
 * Unblocked 2026-06-03: `/api/admin/finance` migrated from OWNER_INVOICE_KEY
 * Bearer-only to the shared `ownerOrSuperAdmin` gate.
 *   GET /api/admin/finance/forecast?days=14    → { ok, days, points:[{date,cents}], totalCents }
 *   GET /api/admin/finance/profit-by-service   → { ok, buckets:[{label,revenueCents,profitCents,bookings}] }
 *   GET /api/admin/finance/tips                → { ok, tips:[{worker_name,cents,channel}], totalCents }
 * The tips read was repointed (2026-06-08) off the dead `tips` table onto the live
 * gig_tips + gig_tip_distributions model, so this section now shows real settled tips.
 * Read-only (refund/analyze is an operator action). Pure helpers dollars/topByProfit
 * unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HlmCardImports, HlmSkeleton } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';
import { BclRollingCounterComponent } from '../_shared/rolling-counter.component';

export interface ProfitBucket {
  readonly label: string;
  readonly revenueCents: number;
  readonly profitCents: number;
  readonly bookings: number;
}

/** Pure: cents → whole-dollar with thousands separators. */
export function dollars(cents: number): string {
  if (!Number.isFinite(cents)) return '$0';
  const sign = cents < 0 ? '-' : '';
  return `${sign}$${Math.abs(Math.round(cents / 100)).toLocaleString('en-US')}`;
}

/** Pure: top-N buckets by profit, descending. */
export function topByProfit(buckets: readonly ProfitBucket[], n: number): ProfitBucket[] {
  return [...buckets].sort((a, b) => b.profitCents - a.profitCents).slice(0, Math.max(0, n));
}

interface ForecastResponse {
  readonly ok: boolean;
  readonly days?: number;
  readonly totalCents?: number;
}
interface ProfitResponse {
  readonly ok: boolean;
  readonly buckets?: readonly ProfitBucket[];
}
export interface TipRow {
  readonly id: string;
  readonly worker_id: string;
  readonly worker_name: string | null;
  readonly cents: number;
  readonly channel: string;
}
interface TipsResponse {
  readonly ok: boolean;
  readonly tips?: readonly TipRow[];
  readonly totalCents?: number;
}

export type PayoutHoldReason =
  | 'dispute_open'
  | 'in_review'
  | 'admin_hold'
  | 'refund_pending'
  | 'charge_unsettled'
  | 'window_open';
export interface PayoutHoldEntry {
  readonly workerId: string;
  readonly claimIds: readonly string[];
  readonly reason: PayoutHoldReason;
  readonly centsWithheld: number;
}
interface PayoutHoldsResponse {
  readonly ok: boolean;
  readonly frozen?: readonly PayoutHoldEntry[];
  readonly windowOpen?: readonly PayoutHoldEntry[];
  readonly frozenCents?: number;
  readonly windowOpenCents?: number;
  readonly payableWorkers?: number;
  readonly payableClaims?: number;
  readonly payableCents?: number;
}

/**
 * Pure: only an operator-PLACED admin hold can be lifted from this dashboard.
 * The system money-safety freezes (open dispute / pending refund / unsettled
 * charge / in-review / 24h window) are NOT operator-overridable — releasing one
 * would defeat the SPEC payout release gate. Gates the inline Release control.
 */
export function isOperatorReleasable(reason: PayoutHoldReason): boolean {
  return reason === 'admin_hold';
}

/** Pure: stable per-entry key for confirm/releasing state (worker + first claim). */
export function payoutHoldKey(h: Pick<PayoutHoldEntry, 'workerId' | 'claimIds'>): string {
  return `${h.workerId}:${h.claimIds[0] ?? ''}`;
}

/** Pure: short operator-readable label for a payout-hold reason. */
export function holdReasonLabel(reason: PayoutHoldReason): string {
  switch (reason) {
    case 'dispute_open':
      return 'Dispute open';
    case 'in_review':
      return 'In review';
    case 'admin_hold':
      return 'Admin hold';
    case 'refund_pending':
      return 'Refund pending';
    case 'charge_unsettled':
      return 'Charge unsettled';
    case 'window_open':
      return 'Window open';
  }
}

@Component({
  selector: 'app-admin-finance',
  standalone: true,
  imports: [...HlmCardImports, BclRollingCounterComponent, BclRevealDirective, HlmSkeleton],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard bclReveal data-testid="admin-finance">
      <div hlmCardHeader>
        <h3 hlmCardTitle>Finance</h3>
        <p hlmCardDescription>Revenue forecast + profit by service, ZIP & crew + tips reconciled (last 30 days).</p>
      </div>
      <div hlmCardContent>
        @if (loading()) {
          <div
            class="space-y-3"
            data-testid="admin-finance-loading"
            aria-busy="true"
            aria-label="Loading finance"
          >
            <div hlmSkeleton class="h-8 w-40"></div>
            @for (row of [1, 2, 3]; track row) {
              <div class="flex items-center justify-between gap-2">
                <div hlmSkeleton class="h-4 w-1/3"></div>
                <div hlmSkeleton class="h-4 w-16"></div>
              </div>
            }
          </div>
        } @else if (error()) {
          <p class="text-sm text-bcl-warn" role="status">{{ error() }}</p>
        } @else {
          <div class="mb-4 flex items-baseline gap-3">
            <span class="font-mono text-2xl tabular-nums text-bcl-accent">
              <bcl-rolling-counter [value]="forecastTotal() / 100" prefix="$" />
            </span>
            <span class="text-sm text-bcl-ink-muted">forecast · next {{ forecastDays() }} days</span>
          </div>
          @if (buckets().length > 0) {
            <p class="mb-2 mt-2 font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">Top services by profit</p>
            <ul class="grid gap-1.5">
              @for (b of buckets(); track b.label) {
                <li class="flex items-center justify-between gap-2 text-sm">
                  <span class="text-bcl-ink-muted">{{ b.label }} <span class="text-xs">· {{ b.bookings }} bk</span></span>
                  <span class="font-mono tabular-nums" [class.text-bcl-success]="b.profitCents >= 0" [class.text-destructive]="b.profitCents < 0">{{ money(b.profitCents) }}</span>
                </li>
              }
            </ul>
          }

          @if (zipBuckets().length > 0) {
            <p class="mb-2 mt-4 font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">Top ZIPs by profit</p>
            <ul class="grid gap-1.5">
              @for (b of zipBuckets(); track b.label) {
                <li class="flex items-center justify-between gap-2 text-sm">
                  <span class="text-bcl-ink-muted">{{ b.label }} <span class="text-xs">· {{ b.bookings }} bk</span></span>
                  <span class="font-mono tabular-nums" [class.text-bcl-success]="b.profitCents >= 0" [class.text-destructive]="b.profitCents < 0">{{ money(b.profitCents) }}</span>
                </li>
              }
            </ul>
          }

          @if (workerBuckets().length > 0) {
            <p class="mb-2 mt-4 font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">Top crew by profit</p>
            <ul class="grid gap-1.5">
              @for (b of workerBuckets(); track b.label) {
                <li class="flex items-center justify-between gap-2 text-sm">
                  <span class="text-bcl-ink-muted">{{ b.label }} <span class="text-xs">· {{ b.bookings }} bk</span></span>
                  <span class="font-mono tabular-nums" [class.text-bcl-success]="b.profitCents >= 0" [class.text-destructive]="b.profitCents < 0">{{ money(b.profitCents) }}</span>
                </li>
              }
            </ul>
          }

          @if (tips().length > 0) {
            <p class="mb-2 mt-4 font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted">
              Tips reconciled · <span class="text-bcl-accent">{{ money(tipsTotal()) }}</span>
            </p>
            <ul class="grid gap-1.5">
              @for (t of tips(); track t.id) {
                <li class="flex items-center justify-between gap-2 text-sm">
                  <span class="text-bcl-ink-muted">{{ t.worker_name || 'Crew' }} <span class="text-xs">· {{ t.channel }}</span></span>
                  <span class="font-mono tabular-nums text-bcl-success">{{ money(t.cents) }}</span>
                </li>
              }
            </ul>
          }

          @if (payoutHoldsOk()) {
          <p class="mb-2 mt-4 font-mono text-[10px] uppercase tracking-wider text-bcl-ink-muted" data-testid="payout-holds-heading">
            Crew payout holds · next run
          </p>
            @if (frozen().length > 0) {
              <p class="mb-1.5 text-sm text-destructive" data-testid="payout-holds-frozen">
                Frozen — operator action · <span class="font-mono tabular-nums">{{ money(frozenCents()) }}</span>
              </p>
              <ul class="mb-2 flex flex-wrap gap-2" aria-label="Frozen crew payouts">
                @for (h of frozen(); track h.workerId + h.reason + h.claimIds[0]) {
                  <li
                    class="inline-flex min-h-[24px] items-center gap-1.5 rounded-full border border-destructive/40 bg-destructive/15 px-3 py-1 text-xs font-medium text-destructive transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-destructive/25"
                  >
                    {{ reasonLabel(h.reason) }}
                    <span class="font-mono tabular-nums">{{ money(h.centsWithheld) }}</span>
                    <span class="text-[10px] text-destructive/70">· {{ h.claimIds.length }} job{{ h.claimIds.length === 1 ? '' : 's' }}</span>
                    @if (canRelease(h)) {
                      @if (confirmingId() === holdKey(h)) {
                        <button
                          type="button"
                          (click)="release(h)"
                          [disabled]="releasingId() === holdKey(h)"
                          data-testid="payout-release-confirm"
                          class="ml-1 inline-flex min-h-[24px] items-center rounded-full bg-destructive/30 px-2 py-0.5 text-[10px] font-bold text-destructive transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-destructive/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent disabled:opacity-60"
                        >
                          {{ releasingId() === holdKey(h) ? 'Releasing…' : 'Confirm release' }}
                        </button>
                        <button
                          type="button"
                          (click)="cancelRelease()"
                          [disabled]="releasingId() === holdKey(h)"
                          class="inline-flex min-h-[24px] items-center rounded-full border border-bcl-border px-2 py-0.5 text-[10px] font-medium text-bcl-ink-muted transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-bcl-ink-muted/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent disabled:opacity-60"
                        >
                          Cancel
                        </button>
                      } @else {
                        <button
                          type="button"
                          (click)="askRelease(h)"
                          data-testid="payout-release-btn"
                          [attr.aria-label]="'Release admin hold of ' + money(h.centsWithheld)"
                          class="ml-1 inline-flex min-h-[24px] items-center rounded-full border border-destructive/50 px-2 py-0.5 text-[10px] font-semibold text-destructive transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-destructive hover:text-bcl-bg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
                        >
                          Release
                        </button>
                      }
                    }
                  </li>
                }
              </ul>
              @if (releaseError()) {
                <p class="mb-2 text-xs text-bcl-warn" role="status" data-testid="payout-release-error">{{ releaseError() }}</p>
              }
            }
            @if (windowOpen().length > 0) {
              <p class="mb-1.5 text-sm text-bcl-ink-muted" data-testid="payout-holds-window">
                Waiting — 24h customer window · <span class="font-mono tabular-nums">{{ money(windowOpenCents()) }}</span> · pays next run
              </p>
              <ul class="mb-2 flex flex-wrap gap-2" aria-label="Crew payouts awaiting the dispute window">
                @for (h of windowOpen(); track h.workerId + h.claimIds[0]) {
                  <li
                    class="inline-flex min-h-[24px] items-center gap-1.5 rounded-full border border-bcl-border bg-bcl-ink-muted/10 px-3 py-1 text-xs font-medium text-bcl-ink-muted transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-bcl-ink-muted/20"
                  >
                    {{ reasonLabel(h.reason) }}
                    <span class="font-mono tabular-nums">{{ money(h.centsWithheld) }}</span>
                  </li>
                }
              </ul>
            }
            @if (payableWorkers() > 0) {
              <p class="text-xs text-bcl-success" data-testid="payout-holds-payable">
                Payable now · <span class="font-mono tabular-nums">{{ money(payableCents()) }}</span> across {{ payableWorkers() }} crew
              </p>
            }
            @if (frozen().length === 0 && windowOpen().length === 0 && payableWorkers() === 0) {
              <p class="text-xs text-bcl-success" data-testid="payout-holds-clear">
                ✓ All crew paid out — nothing frozen or on the 24h customer window.
              </p>
            }
          }

          @if (buckets().length === 0 && zipBuckets().length === 0 && workerBuckets().length === 0 && tips().length === 0) {
            <p class="text-sm text-bcl-ink-muted">No profit data in range.</p>
          }
        }
      </div>
    </div>
  `,
})
export class AdminFinanceComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly loading = signal(true);
  readonly error = signal<string>('');
  readonly forecastTotal = signal(0);
  readonly forecastDays = signal(14);
  readonly buckets = signal<readonly ProfitBucket[]>([]);
  readonly zipBuckets = signal<readonly ProfitBucket[]>([]);
  readonly workerBuckets = signal<readonly ProfitBucket[]>([]);
  readonly tips = signal<readonly TipRow[]>([]);
  readonly tipsTotal = signal(0);
  readonly frozen = signal<readonly PayoutHoldEntry[]>([]);
  readonly windowOpen = signal<readonly PayoutHoldEntry[]>([]);
  readonly frozenCents = signal(0);
  readonly windowOpenCents = signal(0);
  readonly payableWorkers = signal(0);
  readonly payableCents = signal(0);
  /** True only after the /payout-holds fetch RESOLVED ok — gates the holds section so a
   *  failed sub-fetch hides it (never a false "✓ all clear" over unloaded data). */
  readonly payoutHoldsOk = signal(false);

  readonly money = dollars;
  readonly reasonLabel = holdReasonLabel;
  readonly holdKey = payoutHoldKey;

  /** Per-entry inline-control state, keyed by {@link payoutHoldKey}. */
  readonly confirmingId = signal<string>('');
  readonly releasingId = signal<string>('');
  readonly releaseError = signal<string>('');

  /** Only operator-placed admin holds get a Release control (see {@link isOperatorReleasable}). */
  canRelease(h: PayoutHoldEntry): boolean {
    return isOperatorReleasable(h.reason) && h.claimIds.length > 0;
  }

  askRelease(h: PayoutHoldEntry): void {
    this.releaseError.set('');
    this.confirmingId.set(payoutHoldKey(h));
  }

  cancelRelease(): void {
    this.confirmingId.set('');
  }

  /**
   * Lift an admin hold from the dashboard. Optimistically drops the released
   * entry + its withheld dollars on success; surfaces an honest message on the
   * no-op (already paid / no longer on hold) so money state never silently lies.
   */
  async release(h: PayoutHoldEntry): Promise<void> {
    const claimId = h.claimIds[0];
    if (!claimId) return;
    const key = payoutHoldKey(h);
    this.releasingId.set(key);
    this.releaseError.set('');
    try {
      const res = await firstValueFrom(
        this.http
          .post<{ ok: boolean; released?: boolean }>(
            '/api/admin/finance/payout-release',
            { claimId, workerId: h.workerId },
            { withCredentials: true },
          )
          .pipe(catchError(() => of({ ok: false } as { ok: boolean }))),
      );
      if (res?.ok) {
        this.frozen.set(this.frozen().filter((e) => payoutHoldKey(e) !== key));
        this.frozenCents.set(Math.max(0, this.frozenCents() - h.centsWithheld));
        this.confirmingId.set('');
      } else {
        this.releaseError.set('Could not release — it may already be paid or no longer on hold. Refresh to re-check.');
      }
    } finally {
      this.releasingId.set('');
    }
  }

  ngOnInit(): void {
    void this.load();
  }

  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set('');
    this.payoutHoldsOk.set(false);
    try {
      const profit = (path: string) =>
        firstValueFrom(
          this.http
            .get<ProfitResponse>(path, { withCredentials: true })
            .pipe(catchError(() => of({ ok: false } as ProfitResponse))),
        );
      const [f, p, z, w, t, h] = await Promise.all([
        firstValueFrom(this.http.get<ForecastResponse>('/api/admin/finance/forecast?days=14', { withCredentials: true })),
        profit('/api/admin/finance/profit-by-service'),
        profit('/api/admin/finance/profit-by-zip'),
        profit('/api/admin/finance/worker-profitability'),
        firstValueFrom(
          this.http
            .get<TipsResponse>('/api/admin/finance/tips', { withCredentials: true })
            .pipe(catchError(() => of({ ok: false } as TipsResponse))),
        ),
        firstValueFrom(
          this.http
            .get<PayoutHoldsResponse>('/api/admin/finance/payout-holds', { withCredentials: true })
            .pipe(catchError(() => of({ ok: false } as PayoutHoldsResponse))),
        ),
      ]);
      if (!f?.ok) throw new Error('not_ok');
      this.forecastTotal.set(f.totalCents ?? 0);
      this.forecastDays.set(f.days ?? 14);
      this.buckets.set(p?.ok ? topByProfit(p.buckets ?? [], 6) : []);
      this.zipBuckets.set(z?.ok ? topByProfit(z.buckets ?? [], 6) : []);
      this.workerBuckets.set(w?.ok ? topByProfit(w.buckets ?? [], 6) : []);
      this.tips.set(t?.ok ? (t.tips ?? []).slice(0, 8) : []);
      this.tipsTotal.set(t?.ok ? (t.totalCents ?? 0) : 0);
      this.frozen.set(h?.ok ? (h.frozen ?? []) : []);
      this.windowOpen.set(h?.ok ? (h.windowOpen ?? []) : []);
      this.frozenCents.set(h?.ok ? (h.frozenCents ?? 0) : 0);
      this.windowOpenCents.set(h?.ok ? (h.windowOpenCents ?? 0) : 0);
      this.payableWorkers.set(h?.ok ? (h.payableWorkers ?? 0) : 0);
      this.payableCents.set(h?.ok ? (h.payableCents ?? 0) : 0);
      this.payoutHoldsOk.set(h?.ok === true);
    } catch {
      this.error.set('Sign in as an operator to view finance.');
    } finally {
      this.loading.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'finance-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
