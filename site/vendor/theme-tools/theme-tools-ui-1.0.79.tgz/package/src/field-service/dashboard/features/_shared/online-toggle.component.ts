import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * OnlineToggleComponent — 3-state crew status switch.
 *
 * Offline → Online → On Trip. Emits the new state via output(); parent
 * decides whether to start the geolocation watcher + open the crew-stream
 * WebSocket. ARIA: role="radiogroup" with 3 radios for screen-reader clarity.
 */
import { ChangeDetectionStrategy, Component, computed, input, output } from '@angular/core';
import { focusRadioAtIndex, nextRadioIndex, rovingTabIndex } from '@theme.tools/i18n-a11y/field-service/radio-keynav';

export type CrewOnlineState = 'offline' | 'online' | 'on_trip';

interface Option {
  readonly key: CrewOnlineState;
  readonly label: string;
}

const OPTIONS: readonly Option[] = [
  { key: 'offline', label: 'Offline' },
  { key: 'online', label: 'Online' },
  { key: 'on_trip', label: 'On Trip' },
];

@Component({
  selector: 'bcl-online-toggle',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div
      role="radiogroup"
      aria-label="Crew availability"
      class="inline-flex rounded-full bg-bcl-bg-elev p-1 ring-1 ring-bcl-border"
      data-testid="online-toggle"
      (keydown)="onKey($event)"
    >
      @for (opt of options; track opt.key; let i = $index) {
        <button
          type="button"
          role="radio"
          [attr.aria-checked]="opt.key === state()"
          [attr.aria-label]="opt.label"
          [attr.tabindex]="rove(i)"
          (click)="changed.emit(opt.key)"
          class="min-h-[44px] min-w-[44px] rounded-full px-4 text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-bcl-accent"
          [class.bg-bcl-accent]="opt.key === state()"
          [class.text-bcl-bg]="opt.key === state()"
          [class.text-bcl-ink-muted]="opt.key !== state()"
        >
          {{ opt.label }}
        </button>
      }
    </div>
  `,
})
export class OnlineToggleComponent {
  readonly state = input<CrewOnlineState>('offline');
  readonly changed = output<CrewOnlineState>();
  readonly options = OPTIONS;

  /** Index of the selected option — the single tab stop for the group. */
  private readonly activeIndex = computed(() => {
    const i = OPTIONS.findIndex((o) => o.key === this.state());
    return i < 0 ? 0 : i;
  });

  /** Roving tabindex for the option at `i`: 0 for the selected option, else -1. */
  rove(i: number): 0 | -1 {
    return rovingTabIndex(i, this.activeIndex());
  }

  /** ARIA radio-group arrow/Home/End navigation: move selection + focus together. */
  onKey(event: KeyboardEvent): void {
    const next = nextRadioIndex(this.activeIndex(), OPTIONS.length, event.key);
    if (next === null) return;
    event.preventDefault();
    const opt = OPTIONS[next];
    if (opt === undefined) return;
    this.changed.emit(opt.key);
    focusRadioAtIndex(event.currentTarget as HTMLElement, next);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'online-toggle-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
