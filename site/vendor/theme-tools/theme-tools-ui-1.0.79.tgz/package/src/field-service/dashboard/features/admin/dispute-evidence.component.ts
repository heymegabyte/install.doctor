import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * DisputeEvidenceComponent — the operator's completion-package evidence panel,
 * embedded in each dispute card on the admin console.
 *
 * It is the THIRD surface the shared completion-package engine
 * (`src/shared/completion-package.ts`, served read-only at
 * `GET /api/jobs/:bookingId/completion-package`) feeds — crew "complete" button ·
 * customer proof view · THIS operator dispute evidence. All three render the
 * IDENTICAL requirement set so a dispute is judged against the same documented
 * record the crew and customer saw: 4 before + 4 after photos, the close-out
 * checklist, and (on $500+ jobs) a walkthrough video.
 *
 * The read is authorized for super_admin (the operator's cookie session) via the
 * `ownerOrSuperAdmin` widening on the endpoint — so the operator sees evidence for
 * a booking they don't own. Read-only: it REPORTS the package, it never changes
 * the completion gate or moves money. Self-hides when the incident has no booking,
 * when the job has no package state yet, or when the fetch is unauthorized /
 * not-found (no console error). Dark-cockpit Spartan styling, mirrors the
 * customer `app-completion-proof` shape but with operator-framed evidence copy.
 */
import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  input,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import {
  type CompletionAssessment,
  completionProofProgressPct,
} from '../bookings/completion-proof.component';

interface CompletionPackageResponse {
  readonly ok: boolean;
  readonly bookingId?: string;
  readonly completionLockedAt?: string | null;
  readonly assessment?: CompletionAssessment;
}

/**
 * Operator-framed headline summarizing the completion evidence for a dispute.
 *
 * @param a - The completion assessment from the read-only endpoint.
 * @returns "Fully documented" when complete, else an "N of M evidence items" count.
 * @example disputeEvidenceHeadline({ complete: false, satisfiedCount: 4, requiredCount: 6, ... })
 * // → '4 of 6 evidence items documented'
 */
export function disputeEvidenceHeadline(a: CompletionAssessment): string {
  if (a.complete) return 'Fully documented';
  return `${a.satisfiedCount} of ${a.requiredCount} evidence items documented`;
}

/**
 * Same-origin download URL for the 1-page completion-evidence PDF — the exported
 * form of the identical shared-engine verdict this panel renders. Served by
 * `GET /api/jobs/:bookingId/completion-package/export`; the operator's cookie
 * session is sent on navigation so no token plumbing is needed.
 *
 * @param bookingId - The booking whose evidence record to export.
 * @returns The encoded export endpoint path.
 * @example completionEvidenceExportUrl('bk 1') // → '/api/jobs/bk%201/completion-package/export'
 */
export function completionEvidenceExportUrl(bookingId: string): string {
  return `/api/jobs/${encodeURIComponent(bookingId)}/completion-package/export`;
}

@Component({
  selector: 'app-dispute-evidence',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (assessment(); as a) {
      <section
        class="mt-3 rounded-lg border border-border bg-bcl-bg-elev/60 p-3"
        data-testid="dispute-evidence"
      >
        <header class="mb-2 flex items-center justify-between gap-3">
          <div>
            <p class="font-mono text-[10px] uppercase tracking-wider text-bcl-accent">
              Completion evidence
            </p>
            <p class="mt-0.5 text-xs text-muted-foreground">{{ headline() }}</p>
          </div>
          @if (a.complete) {
            <span
              class="rounded-full border border-bcl-success/40 bg-bcl-success/10 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-bcl-success"
              data-testid="dispute-evidence-complete"
              >✓ Documented</span
            >
          } @else {
            <span
              class="rounded-full border border-bcl-warn/30 bg-bcl-warn/10 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-bcl-warn"
              >Incomplete</span
            >
          }
        </header>

        <!-- Progress bar -->
        <div
          class="mb-2 h-1.5 w-full overflow-hidden rounded-full bg-white/10"
          role="progressbar"
          [attr.aria-valuenow]="pct()"
          aria-valuemin="0"
          aria-valuemax="100"
          [attr.aria-label]="'Completion evidence ' + pct() + ' percent documented'"
        >
          <div
            class="h-full rounded-full bg-bcl-accent transition-[width] duration-[333ms] ease-out motion-reduce:transition-none"
            [style.width.%]="pct()"
          ></div>
        </div>

        <!-- Requirement rows -->
        <ul role="list" class="space-y-1" aria-label="Completion evidence items">
          @for (r of a.requirements; track r.id) {
            <li class="flex items-center gap-2 text-xs">
              <span
                class="flex size-4 flex-none items-center justify-center rounded-full font-mono text-[10px] leading-none"
                [class]="
                  r.satisfied
                    ? 'bg-bcl-success/20 text-bcl-success'
                    : 'bg-white/10 text-muted-foreground'
                "
                aria-hidden="true"
                >{{ r.satisfied ? '✓' : '·' }}</span
              >
              <span [class]="r.satisfied ? 'text-foreground' : 'text-muted-foreground'">{{
                r.label
              }}</span>
            </li>
          }
        </ul>

        <!-- Download the portable evidence record (PDF) for the dispute file -->
        <a
          [href]="exportUrl()"
          target="_blank"
          rel="noopener"
          class="mt-3 inline-flex items-center gap-1.5 rounded-md border border-bcl-accent/40 bg-bcl-accent/10 px-3 py-1.5 font-mono text-[10px] uppercase tracking-wider text-bcl-accent transition-all duration-[333ms] hover:-translate-y-0.5 hover:bg-bcl-accent/20 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent motion-reduce:transition-none"
          data-testid="dispute-evidence-export"
          >Download evidence PDF</a
        >
      </section>
    }
  `,
})
export class DisputeEvidenceComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly bookingId = input.required<string>();

  readonly assessment = signal<CompletionAssessment | null>(null);

  protected readonly pct = computed(() => {
    const a = this.assessment();
    return a ? completionProofProgressPct(a) : 0;
  });
  protected readonly headline = computed(() => {
    const a = this.assessment();
    return a ? disputeEvidenceHeadline(a) : '';
  });
  protected readonly exportUrl = computed(() => completionEvidenceExportUrl(this.bookingId()));

  async ngOnInit(): Promise<void> {
    const id = this.bookingId();
    if (!id) return;
    try {
      const res = await firstValueFrom(
        this.http.get<CompletionPackageResponse>(
          `/api/jobs/${encodeURIComponent(id)}/completion-package`,
          { withCredentials: true },
        ),
      );
      if (res?.ok && res.assessment) {
        this.assessment.set(res.assessment);
      }
    } catch {
      // not-found / unauthorized / dark → self-hide (assessment stays null).
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'dispute-evidence-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
