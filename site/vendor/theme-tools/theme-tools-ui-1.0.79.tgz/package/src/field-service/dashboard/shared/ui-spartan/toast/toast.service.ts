import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * ToastService — signal-driven transient notifications. The design-system toast
 * layer (per spartan-ui-design-system). Ephemeral feedback only; the durable
 * record is the notification center (Novu, later). A single HlmToastHost renders
 * the queue. Auto-dismiss with a per-toast timeout; manual dismiss supported.
 *
 * Toasts are for ephemeral feedback; never the only signal for a critical event.
 */
import { Injectable, signal } from '@angular/core';

export type ToastVariant = 'default' | 'success' | 'error' | 'warning';

export interface Toast {
  readonly id: number;
  readonly message: string;
  readonly variant: ToastVariant;
  readonly title?: string;
  /** Optional secondary detail line (e.g. an error reason / next step). */
  readonly details?: string;
}

let _id = 0;

@Injectable({ providedIn: 'root' })
export class ToastService {
  private readonly _toasts = signal<Toast[]>([]);
  /** Read-only view for the host. */
  readonly toasts = this._toasts.asReadonly();

  /** Default auto-dismiss window (ms). Errors linger longer. */
  private windowFor(variant: ToastVariant): number {
    return variant === 'error' ? 8000 : 4000;
  }

  show(message: string, variant: ToastVariant = 'default', title?: string, details?: string): number {
    const id = ++_id;
    const toast: Toast = {
      id,
      message,
      variant,
      ...(title ? { title } : {}),
      ...(details ? { details } : {}),
    };
    this._toasts.update((list) => [...list, toast]);
    const ms = this.windowFor(variant);
    if (typeof setTimeout !== 'undefined' && ms > 0) {
      setTimeout(() => this.dismiss(id), ms);
    }
    return id;
  }

  info(message: string, title?: string, details?: string): number {
    return this.show(message, 'default', title, details);
  }
  success(message: string, title?: string, details?: string): number {
    return this.show(message, 'success', title, details);
  }
  error(message: string, title?: string, details?: string): number {
    return this.show(message, 'error', title, details);
  }
  warning(message: string, title?: string, details?: string): number {
    return this.show(message, 'warning', title, details);
  }

  dismiss(id: number): void {
    this._toasts.update((list) => list.filter((t) => t.id !== id));
  }

  clear(): void {
    this._toasts.set([]);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'toast-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
