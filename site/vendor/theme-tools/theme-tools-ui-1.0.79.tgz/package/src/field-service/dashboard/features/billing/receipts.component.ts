import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * BillingReceiptsComponent — per-job receipts downloaded via the session-gated,
 * ownership-checked `/api/customer/jobs/:id/receipt.pdf`. Customers find them
 * here after every move. Was pointing at `/recap.pdf`, which 404s `recap_pending`
 * for every job without a pre-generated completion recap (most of them); the
 * on-demand `receipt.pdf` renders live from the booking pricing so a paid
 * customer ALWAYS has a portable record.
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, inject } from '@angular/core';
import { type ColumnDef } from '@tanstack/angular-table';
import { SmartTableComponent } from '../../shared/ui-spartan';
import { money } from '@theme.tools/billing/field-service/money';
import { BillingService } from './billing.service';

interface ReceiptRow extends Record<string, unknown> {
  readonly id: string;
  readonly jobId: string;
  readonly date: string;
  readonly amount: string;
  readonly customer: string;
}

@Component({
  selector: 'app-billing-receipts',
  standalone: true,
  imports: [SmartTableComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (svc.error(); as err) {
      <div
        class="flex items-center justify-between gap-3 rounded-xl border border-destructive/40 bg-destructive/5 px-4 py-3"
        role="alert"
      >
        <p class="text-sm text-foreground">Couldn't load receipts — {{ err }}</p>
        <button
          type="button"
          (click)="reload()"
          class="rounded-md border border-border px-3 py-1 text-xs text-muted-foreground hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        >
          Try again
        </button>
      </div>
    } @else if (svc.receipts().length === 0 && !svc.loading()) {
      <div class="rounded-xl border border-dashed border-border p-10 text-center">
        <p class="text-2xl" aria-hidden="true">🧾</p>
        <p class="mt-2 text-base font-semibold text-foreground">No receipts yet</p>
        <p class="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
          Every completed job gets a downloadable PDF receipt here — your portable record of the
          hourly work, rendered live from the booking.
        </p>
      </div>
    } @else {
      <app-smart-table
        [data]="rows()"
        [columns]="cols"
        [loading]="svc.loading() && svc.receipts().length === 0"
        [filterable]="true"
        filterPlaceholder="Filter receipts…"
        emptyText="No receipts match this filter."
        (rowActivate)="download($event)"
      />
    }
  `,
})
export class BillingReceiptsComponent implements OnInit {
  readonly svc = inject(BillingService);

  readonly cols: ColumnDef<ReceiptRow>[] = [
    { accessorKey: 'date', header: 'Date' },
    { accessorKey: 'jobId', header: 'Job' },
    { accessorKey: 'customer', header: 'Customer' },
    { accessorKey: 'amount', header: 'Amount' },
  ];

  readonly rows = computed<ReceiptRow[]>(() =>
    this.svc.receipts().map((r) => ({
      id: r.id,
      jobId: r.jobId,
      date: new Date(r.date).toLocaleDateString(),
      amount: money(r.amountCents),
      customer: r.customerName,
    })),
  );

  ngOnInit(): void {
    this.svc.error.set(null); // clear a stale sibling-tab error on entry — the shared error signal is
    // only cleared INSIDE a load, which a cached tab skips, so a prior tab's failure would show here.
    if (this.svc.receipts().length === 0) void this.svc.loadReceipts();
  }

  reload(): void {
    void this.svc.loadReceipts();
  }

  download(r: ReceiptRow): void {
    globalThis.open(
      `/api/customer/jobs/${encodeURIComponent(r.jobId)}/receipt.pdf`,
      '_blank',
      'noopener,noreferrer',
    );
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'receipts-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
