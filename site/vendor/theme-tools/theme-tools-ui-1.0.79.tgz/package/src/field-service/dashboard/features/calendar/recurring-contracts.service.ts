import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * RecurringContractsService — loads active recurring hourly contracts for the
 * dispatch calendar's occurrence overlay from GET /api/admin/recurring.
 *
 * The backend route is flag-gated (calendar_recurring_contracts → 404 when off),
 * so the client just fetches and degrades a 404/error to an empty list — the
 * server flag is the single source of truth for whether the overlay has data.
 * Shared (providedIn root) so month/week/day grids reuse the one fetch.
 */
import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, of } from 'rxjs';
import type { RecurringContract } from '@theme.tools/scheduling/field-service/recurring-occurrences';

@Injectable({ providedIn: 'root' })
export class RecurringContractsService {
  private readonly http = inject(HttpClient);
  /** Active recurring contracts (empty when the flag is off → endpoint 404s). */
  readonly contracts = signal<RecurringContract[]>([]);
  private loaded = false;

  /** Load once per session; safe to call from every grid's constructor. */
  load(): void {
    if (this.loaded) return;
    this.loaded = true;
    this.http
      .get<{ ok: boolean; contracts?: RecurringContract[] }>('/api/admin/recurring', {
        withCredentials: true,
      })
      .pipe(catchError(() => of({ ok: false, contracts: [] as RecurringContract[] })))
      .subscribe((r) => this.contracts.set(r.contracts ?? []));
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'recurring-contracts-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
