import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * HlmSpinner — inline loading spinner (vendored helm). Cyan accent ring; used
 * in buttons (busy state) + inline async affordances. Respects reduced-motion.
 * Usage: <app-spinner [size]="16" />
 */
import { ChangeDetectionStrategy, Component, input } from '@angular/core';

@Component({
  selector: 'app-spinner',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { role: 'status', 'aria-label': 'Loading' },
  template: `
    <span
      [style.width.px]="size()"
      [style.height.px]="size()"
      [style.border-width.px]="borderWidth()"
    ></span>
  `,
  styles: [
    `
      @keyframes hlm-spin {
        to {
          transform: rotate(360deg);
        }
      }
      span {
        display: inline-block;
        border-radius: 9999px;
        border-style: solid;
        border-color: hsl(var(--primary));
        border-top-color: transparent;
        animation: hlm-spin 0.6s linear infinite;
      }
      @media (prefers-reduced-motion: reduce) {
        span {
          animation-duration: 1.5s;
        }
      }
    `,
  ],
})
export class HlmSpinner {
  /** px diameter of the spinner. */
  readonly size = input<number>(16);
  protected borderWidth(): number {
    return Math.max(2, Math.round(this.size() / 8));
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'hlm-spinner-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
