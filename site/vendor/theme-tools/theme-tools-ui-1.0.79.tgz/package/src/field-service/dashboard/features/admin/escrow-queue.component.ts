import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { CommonModule } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

interface EscrowRecord {
  id: string;
  booking_id: string;
  held_cents: number;
  state: string;
  crew_complete: number;
  customer_signoff: number;
  ai_clean: number;
  capture_error?: string | null;
  refund_error?: string | null;
}

@Component({
  selector: 'bcl-escrow-queue',
  standalone: true,
  imports: [CommonModule],
  template: `
    <main class="mx-auto max-w-5xl space-y-5 p-4 sm:p-6">
      <header><p class="text-sm text-muted-foreground">Payments</p><h1 class="text-2xl font-bold">Bonded escrow</h1></header>
      @if (loading()) { <p role="status">Loading protected payments…</p> }
      @else if (error()) {
        <div role="alert" class="rounded-lg border border-destructive/40 p-4">
          <p>Escrow queue is temporarily unavailable.</p>
          <button class="mt-3 min-h-11 rounded-md border px-4 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring" (click)="load()">Try again</button>
        </div>
      } @else if (records().length === 0) { <p class="rounded-lg border p-4">No protected payments need review.</p> }
      @for (record of records(); track record.id) {
        <article class="space-y-3 rounded-xl border p-4" [attr.data-state]="record.state">
          <div class="flex flex-wrap items-start justify-between gap-3">
            <div><h2 class="font-semibold">Booking {{ record.booking_id }}</h2><p class="text-sm text-muted-foreground">{{ record.held_cents / 100 | currency }}</p></div>
            <span class="rounded-full border px-3 py-1 text-sm">{{ label(record.state) }}</span>
          </div>
          <p class="text-sm">Crew {{ mark(record.crew_complete) }} · Customer {{ mark(record.customer_signoff) }} · Photo review {{ mark(record.ai_clean) }}</p>
          @if (record.capture_error || record.refund_error) { <p role="status" class="text-sm text-destructive">Provider confirmation failed. Retry is safe and idempotent.</p> }
          @if (actionError()[record.id]) { <p role="alert" class="text-sm text-destructive">{{ actionError()[record.id] }}</p> }
          <div class="flex flex-wrap gap-2">
            @if (!record.ai_clean && !terminal(record.state)) { <button class="min-h-11 rounded-md border px-4 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring" [disabled]="busy() === record.id" (click)="act(record, 'verify')">Mark photo review clean</button> }
            @if (record.state === 'fully_verified') { <button class="min-h-11 rounded-md bg-primary px-4 text-primary-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring" [disabled]="busy() === record.id" (click)="act(record, 'capture')">Release payment</button> }
            @if (record.state === 'disputed') { <button class="min-h-11 rounded-md border px-4 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring" [disabled]="busy() === record.id" (click)="act(record, 'refund')">Release payment hold</button> }
          </div>
        </article>
      }
    </main>
  `,
})
export class EscrowQueueComponent implements OnInit {
  private readonly http = inject(HttpClient);
  readonly records = signal<EscrowRecord[]>([]);
  readonly loading = signal(true);
  readonly error = signal(false);
  readonly busy = signal<string | null>(null);
  readonly actionError = signal<Record<string, string>>({});

  ngOnInit(): void { void this.load(); }
  async load(): Promise<void> {
    this.loading.set(true); this.error.set(false);
    try {
      const body = await firstValueFrom(this.http.get<{ records: EscrowRecord[] }>('/api/smart-bonded-escrow/admin/recent'));
      this.records.set(body.records ?? []);
    } catch { this.error.set(true); }
    finally { this.loading.set(false); }
  }
  async act(record: EscrowRecord, action: 'verify' | 'capture' | 'refund'): Promise<void> {
    this.busy.set(record.id); this.actionError.update((v) => ({ ...v, [record.id]: '' }));
    const url = action === 'verify' ? `/api/smart-bonded-escrow/verify/${record.booking_id}` : `/api/smart-bonded-escrow/${action}/${record.id}`;
    const body = action === 'verify' ? { kind: 'ai_clean' } : action === 'capture' ? { force: false } : { note: 'Operator-approved customer resolution' };
    try { await firstValueFrom(this.http.post(url, body)); await this.load(); }
    catch { this.actionError.update((v) => ({ ...v, [record.id]: 'Action did not complete. No settled state was recorded; retry when ready.' })); }
    finally { this.busy.set(null); }
  }
  label(state: string): string { return state.replaceAll('_', ' '); }
  mark(value: number): string { return value ? 'verified' : 'pending'; }
  terminal(state: string): boolean { return ['captured', 'refunded'].includes(state); }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'escrow-queue-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
