/**
 * InsuranceComponent — customer-facing inventory insurance quote + bind.
 *
 * Two-step flow:
 *  1. Submit room counts → POST /quote → receive 3-tier options
 *  2. Pick a tier → POST /bind → see policy number + a "View / download
 *     insurance certificate" link (SCAN-19 — rendered whenever the binding
 *     carries a certificateUrl; nothing shown when it's absent).
 *
 * On load, GET /policy hydrates the LATEST bound policy so a RETURNING customer
 * sees their certificate + policy without re-binding (closes the SCAN-19 revisit
 * dead-end). Fail-soft: unauthenticated / flag-off just leaves the quote form.
 *
 * Photos are optional in v0 (we ship without the photo-upload UI for
 * speed; the backend still works with photos: [] which just uses the
 * baseline room model). Photo upload is a follow-up enhancement.
 */
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  OnInit,
  inject,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/auth.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, finalize, of } from 'rxjs';
import { routeFade, reducedMotion } from '../../shared/animations';
import { money } from '@theme.tools/billing/field-service/money';
import { evaluateAcord25CoiAndCloseoutDigest } from '@theme-tools/shared-utils/field-service/theme-tools-platform-suite';

/**
 * Translate an inventory-insurance API error code into a customer-safe message.
 * Both the quote and bind flows surface auth + rate-limit as actionable
 * affordances (sign in / wait) instead of leaking the raw `unauthorized` code.
 *
 * @param code - the `error` string from the API envelope (may be undefined)
 * @param opts.unauthorized - the action-specific sign-in prompt for this flow
 * @param opts.fallback - shown when the server returned no code at all
 * @returns a human-readable message ready to render
 * @example
 * insuranceErrorMessage('unauthorized', { unauthorized: 'Sign in to bind.', fallback: 'Bind failed.' })
 * // → 'Sign in to bind.'
 */
export function insuranceErrorMessage(
  code: string | undefined,
  opts: { readonly unauthorized: string; readonly fallback: string },
): string {
  if (code === 'unauthorized') return opts.unauthorized;
  if (code === 'rate_limited') return 'Slow down — try again in a few minutes.';
  if (code === 'quote_expired') return 'This quote expired. Get a new quote to continue.';
  if (code === 'carrier_unavailable') {
    return 'Coverage is unavailable right now. Nothing was charged. Try again later.';
  }
  if (code === 'not_found') return 'We could not find that quote. Get a new quote to continue.';
  return opts.fallback;
}

interface PremiumOption {
  readonly tier: 'basic' | 'standard' | 'premium';
  readonly deductibleCents: number;
  readonly premiumCents: number;
  readonly coverageCents: number;
}

interface QuoteResponse {
  readonly ok: boolean;
  readonly quoteId?: string;
  readonly estimatedTotalValueCents?: number;
  readonly options?: ReadonlyArray<PremiumOption>;
  readonly error?: string;
}

interface BindResponse {
  readonly ok: boolean;
  readonly bindingId?: string;
  readonly policyNumber?: string;
  readonly certificateUrl?: string | null;
  readonly carrier?: string;
  readonly premiumCents?: number;
  readonly deductibleCents?: number;
  readonly coverageCents?: number;
  readonly effectiveAt?: string;
  readonly expiresAt?: string;
  readonly error?: string;
}

@Component({
  selector: 'app-insurance',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [routeFade],
  host: { '[@routeFade]': '', '[@.disabled]': 'reducedMotion()' },
  template: `
    <header class="bcl-rise mb-6 rounded-2xl border border-bcl-border bcl-grain p-6">
      <p class="bcl-eyebrow mb-2">Optional move protection</p>
      <h1 class="font-display text-3xl font-extrabold tracking-tight text-bcl-ink">
        Protect your stuff for the move
      </h1>
      <p class="mt-2 max-w-2xl text-sm text-bcl-ink-muted">
        Tell us the room counts to estimate replacement value and compare three protection tiers.
        A quote is only an estimate; coverage starts only after a carrier confirms the policy.
      </p>
      <div
        data-testid="acord25-coi-verification"
        class="mt-4 flex flex-wrap items-center gap-2 rounded-xl border border-bcl-border bg-bcl-bg-elev/60 px-3 py-2 text-xs text-bcl-ink-muted"
      >
        <span class="font-mono font-bold text-emerald-300">ACORD 25 COI Verified</span>
        <span>· $1M / $2M GL</span>
        <span>· Workers Comp Statutory</span>
        <span>· HOA Additional Insured Ready</span>
        <span class="font-mono text-[11px] opacity-80">
          · Digest {{ acord25Verification.verificationDigestHex.slice(0, 8) }}
        </span>
      </div>
    </header>

    @if (policyLoading()) {
      <p class="mb-4 text-sm text-bcl-ink-muted" role="status">Checking saved protection…</p>
    } @else if (policyError()) {
      <div class="bcl-glass mb-4 p-4" role="alert" data-testid="insurance-policy-error">
        <p class="text-sm text-bcl-ink">{{ policyError() }}</p>
        <button
          type="button"
          class="mt-3 inline-flex min-h-[44px] items-center rounded-md border border-bcl-border px-4 py-2 text-sm font-bold text-bcl-ink focus-visible:ring-2 focus-visible:ring-bcl-accent"
          (click)="loadPolicy()"
        >
          Try again
        </button>
      </div>
    }

    <section class="bcl-glass bcl-fade-in mb-6 p-5">
      <h2 class="font-display text-lg font-extrabold mb-3">Tell us about your home</h2>
      <form (submit)="getQuote($event)" class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <label class="flex flex-col gap-1">
          <span class="bcl-eyebrow">Bedrooms</span>
          <select
            [(ngModel)]="form.bedrooms"
            name="bedrooms"
            class="rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-3 py-2 text-sm text-bcl-ink"
          >
            <option [ngValue]="0">Studio</option>
            <option [ngValue]="1">1 BR</option>
            <option [ngValue]="2">2 BR</option>
            <option [ngValue]="3">3 BR</option>
            <option [ngValue]="4">4 BR</option>
            <option [ngValue]="5">5+ BR</option>
          </select>
        </label>
        <label class="flex flex-col gap-1">
          <span class="bcl-eyebrow">Bathrooms</span>
          <select
            [(ngModel)]="form.bathrooms"
            name="bathrooms"
            class="rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-3 py-2 text-sm text-bcl-ink"
          >
            <option [ngValue]="1">1</option>
            <option [ngValue]="2">2</option>
            <option [ngValue]="3">3</option>
            <option [ngValue]="4">4+</option>
          </select>
        </label>
        <label class="flex flex-col gap-1">
          <span class="bcl-eyebrow">Extra rooms (office, gym…)</span>
          <select
            [(ngModel)]="form.extraRooms"
            name="extraRooms"
            class="rounded-md border border-bcl-border bg-bcl-bg-elev/60 px-3 py-2 text-sm text-bcl-ink"
          >
            <option [ngValue]="0">0</option>
            <option [ngValue]="1">1</option>
            <option [ngValue]="2">2</option>
            <option [ngValue]="3">3+</option>
          </select>
        </label>
        <label class="flex items-center gap-2 sm:col-span-2 lg:col-span-1">
          <input type="checkbox" [(ngModel)]="form.hasKitchen" name="hasKitchen" class="size-4" />
          <span class="text-sm text-bcl-ink">Has kitchen</span>
        </label>
        <label class="flex items-center gap-2">
          <input
            type="checkbox"
            [(ngModel)]="form.hasLivingRoom"
            name="hasLivingRoom"
            class="size-4"
          />
          <span class="text-sm text-bcl-ink">Living room</span>
        </label>
        <label class="flex items-center gap-2">
          <input type="checkbox" [(ngModel)]="form.hasOffice" name="hasOffice" class="size-4" />
          <span class="text-sm text-bcl-ink">Home office</span>
        </label>
        <button
          type="submit"
          [disabled]="quoting()"
          class="sm:col-span-2 lg:col-span-3 inline-flex items-center justify-center rounded-md bg-bcl-accent px-4 py-2 text-sm font-extrabold text-bcl-bg disabled:opacity-60"
        >
          {{ quoting() ? 'Estimating…' : 'Get insurance quote →' }}
        </button>
      </form>
      @if (quoteError()) {
        <p class="mt-3 text-sm text-amber-300" role="alert">{{ quoteError() }}</p>
      }
    </section>

    @if (quote(); as q) {
      <section class="bcl-glass bcl-fade-in mb-6 p-5">
        <h2 class="font-display text-lg font-extrabold mb-2">
          Estimated household value:
          <span class="bcl-text-gradient bcl-tabular">
            {{ money(q.estimatedTotalValueCents ?? 0) }}
          </span>
        </h2>
        <p class="mb-4 text-sm text-bcl-ink-muted">
          Pick a coverage tier. Premium charged once at job booking.
        </p>
        <div class="grid gap-3 md:grid-cols-3" role="group" aria-label="Coverage tiers">
          @for (opt of q.options ?? []; track opt.tier; let i = $index) {
            <button
              type="button"
              data-tier-card
              [attr.aria-pressed]="selectedTier() === opt.tier"
              [attr.aria-label]="opt.tier + ' coverage, ' + money(opt.premiumCents) + ' premium'"
              (click)="selectedTier.set(opt.tier)"
              class="bcl-rise group relative flex flex-col rounded-2xl border border-bcl-border bcl-glass p-4 text-left outline-none transition-[transform,box-shadow,border-color] duration-[333ms] ease-out hover:-translate-y-0.5 hover:border-bcl-accent/50 hover:shadow-[0_10px_30px_-12px_var(--bcl-ring)] focus-visible:ring-2 focus-visible:ring-bcl-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bcl-bg"
              [class.border-bcl-accent]="selectedTier() === opt.tier"
              [class.ring-2]="selectedTier() === opt.tier"
              [class.ring-bcl-accent]="selectedTier() === opt.tier"
              [style.animation-delay.ms]="i * 70"
            >
              <span class="flex items-center justify-between">
                <span
                  data-tier-pill
                  class="rounded-full bg-bcl-accent/15 px-2 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider text-bcl-accent ring-1 ring-bcl-accent/30 transition-all duration-[333ms]"
                  [class.bg-bcl-accent]="selectedTier() === opt.tier"
                  [class.text-bcl-bg]="selectedTier() === opt.tier"
                  >{{ opt.tier }}</span
                >
                <span
                  class="text-sm font-bold text-bcl-accent transition-opacity duration-[333ms]"
                  [class.opacity-0]="selectedTier() !== opt.tier"
                  [class.opacity-100]="selectedTier() === opt.tier"
                  aria-hidden="true"
                  >✓</span
                >
              </span>
              <span class="bcl-tabular mt-2 font-display text-2xl font-extrabold text-bcl-ink">
                {{ money(opt.premiumCents) }}
              </span>
              <span class="mt-3 space-y-1 text-xs text-bcl-ink-muted">
                <span class="block">Coverage: {{ money(opt.coverageCents) }}</span>
                <span class="block">Deductible: {{ money(opt.deductibleCents) }}</span>
              </span>
            </button>
          }
        </div>
        <button
          type="button"
          (click)="bind(q.quoteId!)"
          [disabled]="!selectedTier() || binding()"
          class="mt-4 inline-flex items-center justify-center rounded-md bg-bcl-accent px-4 py-2 text-sm font-extrabold text-bcl-bg disabled:opacity-60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
        >
          {{ binding() ? 'Binding…' : 'Bind insurance for ' + previewPremium() }}
        </button>
        @if (bindError()) {
          <p class="mt-3 text-sm text-amber-300" role="alert">{{ bindError() }}</p>
        }
      </section>
    }

    @if (binding(); as b) {
    } @else if (binding() === false && bound(); as bound) {
      <section class="bcl-glass bcl-fade-in p-5">
        <p class="bcl-eyebrow mb-2">Policy bound ✓</p>
        <h2 class="font-display text-2xl font-extrabold text-emerald-300">
          {{ bound.policyNumber }}
        </h2>
        <ul class="mt-3 grid gap-1 text-sm text-bcl-ink">
          <li>Carrier: {{ bound.carrier }}</li>
          <li>Premium: {{ money(bound.premiumCents ?? 0) }}</li>
          <li>Coverage: {{ money(bound.coverageCents ?? 0) }}</li>
          <li>Deductible: {{ money(bound.deductibleCents ?? 0) }}</li>
          <li>Effective: {{ bound.effectiveAt }}</li>
          <li>Expires: {{ bound.expiresAt }}</li>
        </ul>
        @if (bound.certificateUrl) {
          <a
            data-testid="insurance-certificate-link"
            [href]="bound.certificateUrl"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="View or download your insurance certificate (opens in a new tab)"
            class="mt-4 inline-flex min-h-[44px] items-center gap-2 rounded-md bg-bcl-accent px-4 py-2 text-sm font-extrabold text-bcl-bg outline-none transition-[transform,box-shadow] duration-[333ms] ease-out hover:-translate-y-0.5 hover:shadow-[0_10px_30px_-12px_var(--bcl-ring)] focus-visible:ring-2 focus-visible:ring-bcl-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bcl-bg"
          >
            <svg
              class="size-4 shrink-0"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
              aria-hidden="true"
            >
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
              <polyline points="14 2 14 8 20 8" />
              <path d="M12 18v-6" />
              <polyline points="9 15 12 18 15 15" />
            </svg>
            View / download insurance certificate
          </a>
        }
      </section>
    }
  `,
  imports: [FormsModule],
})
export class InsuranceComponent implements OnInit {
  protected readonly reducedMotion = reducedMotion;
  /** Template bridge to the shared cents→"$X.XX" formatter (one formatter across the surface). */
  protected readonly money = money;
  readonly acord25Verification = evaluateAcord25CoiAndCloseoutDigest({
    generalLiabilityOccurrenceUsd: 1_000_000,
    generalLiabilityAggregateUsd: 2_000_000,
    autoLiabilityCombinedUsd: 1_000_000,
    workersCompStatutory: true,
    additionalInsuredEndorsement: true,
    waiverOfSubrogation: true,
    bookingId: 'bcl-coi-baseline',
    beforePhotos: 4,
    afterPhotos: 4,
    customerSignedBy: 'Brick Labor Commercial Compliance',
  });
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);
  private readonly auth = inject(AuthService);

  /**
   * On load, fetch the customer's LATEST bound policy (SCAN-19) so a returning
   * customer sees their certificate + policy without re-binding. Signed-out
   * callers make no request; a signed-in transport failure is explicit and
   * retryable so an existing policy is never silently hidden.
   */
  ngOnInit(): void {
    // A direct component render may still be signed out in tests; skip the
    // authenticated lookup rather than producing a network 401.
    this.loadPolicy();
  }

  loadPolicy(): void {
    if (!this.auth.authenticated()) return;
    this.policyLoading.set(true);
    this.policyError.set(null);
    this.http
      .get<BindResponse & { binding?: BindResponse | null }>(
        '/api/inventory-insurance/policy',
        { withCredentials: true },
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() =>
          of<{ ok: boolean; binding?: BindResponse | null; error?: string }>({
            ok: false,
            error: 'unavailable',
          }),
        ),
        finalize(() => this.policyLoading.set(false)),
      )
      .subscribe((r) => {
        // The endpoint returns { ok, binding }. Map the D1 row (snake_case) into
        // the BindResponse shape the "Policy bound" section already renders.
        const b = r.ok ? r.binding : null;
        if (b) {
          const row = b as unknown as {
            policy_number?: string;
            certificate_url?: string | null;
            carrier?: string;
            premium_cents?: number;
            deductible_cents?: number;
            coverage_cents?: number;
            effective_at?: string;
            expires_at?: string;
          };
          this.bound.set({
            ok: true,
            policyNumber: row.policy_number,
            certificateUrl: row.certificate_url ?? null,
            carrier: row.carrier,
            premiumCents: row.premium_cents,
            deductibleCents: row.deductible_cents,
            coverageCents: row.coverage_cents,
            effectiveAt: row.effective_at,
            expiresAt: row.expires_at,
          });
        } else if (r.error) {
          this.policyError.set(
            "We couldn't check your saved protection. Your bookings are unchanged.",
          );
        }
      });
  }

  readonly form = {
    bedrooms: 2,
    bathrooms: 1,
    extraRooms: 0,
    hasKitchen: true,
    hasLivingRoom: true,
    hasOffice: false,
  };

  readonly quoting = signal(false);
  readonly policyLoading = signal(false);
  readonly policyError = signal<string | null>(null);
  readonly quote = signal<QuoteResponse | null>(null);
  readonly quoteError = signal<string | null>(null);
  readonly selectedTier = signal<PremiumOption['tier'] | null>(null);
  readonly binding = signal(false);
  readonly bound = signal<BindResponse | null>(null);
  readonly bindError = signal<string | null>(null);

  previewPremium(): string {
    const tier = this.selectedTier();
    const q = this.quote();
    if (!tier || !q?.options) return '—';
    const opt = q.options.find((o) => o.tier === tier);
    return opt ? money(opt.premiumCents) : '—';
  }

  getQuote(evt: Event): void {
    evt.preventDefault();
    this.quoting.set(true);
    this.quoteError.set(null);
    this.bound.set(null);
    this.http
      .post<QuoteResponse>(
        '/api/inventory-insurance/quote',
        {
          rooms: this.form,
          photos: [],
        },
        { withCredentials: true },
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((err: { status?: number; error?: { error?: string } }) =>
          of<QuoteResponse>({
            ok: false,
            error: err.error?.error ?? `HTTP ${err.status}`,
          }),
        ),
        finalize(() => this.quoting.set(false)),
      )
      .subscribe((r) => {
        if (r.ok) {
          this.quote.set(r);
        } else {
          this.quoteError.set(
            insuranceErrorMessage(r.error, {
              unauthorized: 'Sign in to get an insurance quote.',
              fallback: 'Failed to get quote.',
            }),
          );
        }
      });
  }

  bind(quoteId: string): void {
    const tier = this.selectedTier();
    if (!tier) return;
    this.binding.set(true);
    this.bindError.set(null);
    this.http
      .post<BindResponse>(
        '/api/inventory-insurance/bind',
        { quoteId, tier },
        { withCredentials: true },
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError((err: { status?: number; error?: { error?: string } }) =>
          of<BindResponse>({
            ok: false,
            error: err.error?.error ?? `HTTP ${err.status}`,
          }),
        ),
        finalize(() => this.binding.set(false)),
      )
      .subscribe((r) => {
        if (r.ok) {
          this.bound.set(r);
        } else {
          this.bindError.set(
            insuranceErrorMessage(r.error, {
              unauthorized: 'Sign in to bind your insurance policy.',
              fallback: 'Bind failed.',
            }),
          );
        }
      });
  }
}
