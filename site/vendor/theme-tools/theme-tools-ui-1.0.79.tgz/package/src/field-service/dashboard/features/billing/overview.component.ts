import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
/**
 * BillingOverviewComponent — current plan, next-invoice ETA, payment
 * method on file. Reads from BillingService.overview() signal.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { HlmCardImports, HlmBadge, HlmButton } from '../../shared/ui-spartan';
import { fadeUpItem, listStagger, routeFade, reducedMotion } from '../../shared/animations';
import { money } from '@theme.tools/billing/field-service/money';
import { ContractUpsellComponent } from '../_shared/contract-upsell.component';
import { BillingService, type RecurringContract } from './billing.service';

@Component({
  selector: 'app-billing-overview',
  standalone: true,
  imports: [...HlmCardImports, HlmBadge, HlmButton, RouterLink, ContractUpsellComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [listStagger, fadeUpItem, routeFade],
  template: `
    <!-- SCAN-24: contract-conversion upsell for a repeat one-time booker. Self-gated
         on the contract_conversion_upsell flag + eligibility — renders nothing while
         dark or when the customer already runs a recurring contract. -->
    <div class="mb-6">
      <bcl-contract-upsell />
    </div>
    @if (svc.loading() && !svc.overview()) {
      <p class="text-sm text-muted-foreground">Loading…</p>
    } @else if (svc.overview(); as o) {
      <!-- Billing info cards — staggered fade-up entrance -->
      <div
        class="grid gap-4 md:grid-cols-3"
        [@listStagger]="3"
        [@.disabled]="reducedMotion()"
      >
        <div hlmCard [@fadeUpItem]>
          <div hlmCardHeader>
            <h3 hlmCardTitle>Your rate</h3>
            <p hlmCardDescription>$/hour per crew member · 1-hour minimum</p>
          </div>
          <div hlmCardContent>
            <p class="text-3xl font-bold text-foreground">
              {{ money(o.hourlyRatePerPersonCents) }}<span class="text-base font-normal text-muted-foreground">/hr · person</span>
            </p>
            <p class="mt-1 text-sm text-muted-foreground">
              {{ contractLabel(o.contract) }}@if (contractDiscount(o.contract) > 0) {
                · <span class="text-foreground">{{ contractDiscount(o.contract) }}% off</span>
              }
            </p>
            <div class="mt-4">
              <!-- Recurring hourly contracts live on the marketing /recurring page. -->
              <a hlmBtn variant="secondary" size="sm" href="/recurring">
                {{ o.contract === 'pay_as_you_go' ? 'Set up a recurring contract' : 'Manage contract' }}
              </a>
            </div>
          </div>
        </div>
        <div hlmCard [@fadeUpItem]>
          <div hlmCardHeader>
            <h3 hlmCardTitle>How you're billed</h3>
            <p hlmCardDescription>Pay as you go — no monthly bill</p>
          </div>
          <div hlmCardContent>
            <p class="text-sm text-foreground">
              Billed per job when the crew finishes —
              {{ money(o.hourlyRatePerPersonCents) }}/hr per crew member, 1-hour minimum, then
              15-minute blocks.
            </p>
            @if (contractDiscount(o.contract) > 0) {
              <p class="mt-2 text-sm text-muted-foreground">
                Your {{ contractLabel(o.contract).toLowerCase() }} applies
                <span class="font-medium text-foreground">{{ contractDiscount(o.contract) }}% off</span>
                every visit automatically.
              </p>
            }
            <div class="mt-4">
              <a hlmBtn variant="secondary" size="sm" routerLink="../receipts">View receipts</a>
            </div>
          </div>
        </div>
        <div hlmCard [@fadeUpItem]>
          <div hlmCardHeader>
            <h3 hlmCardTitle>Payment method</h3>
            <p hlmCardDescription>Card on file via Stripe</p>
          </div>
          <div hlmCardContent>
            @if (o.paymentMethodLast4) {
              <p class="text-base text-foreground">{{ o.paymentMethodBrand }} ····{{ o.paymentMethodLast4 }}</p>
              <div class="mt-4">
                <a hlmBtn variant="secondary" size="sm" routerLink="../payment-methods">Manage</a>
              </div>
            } @else {
              <span hlmBadge variant="warning">No payment method</span>
              <div class="mt-3">
                <a hlmBtn size="sm" routerLink="../payment-methods">Add card</a>
              </div>
            }
          </div>
        </div>
      </div>
    } @else if (svc.error(); as e) {
      <div hlmCard>
        <div hlmCardHeader><h3 hlmCardTitle>Error</h3></div>
        <div hlmCardContent><p class="text-sm text-destructive">{{ e }}</p></div>
      </div>
    }
  `,
})
export class BillingOverviewComponent implements OnInit {
  readonly svc = inject(BillingService);
  protected readonly money = money;
  /** Bound to [@.disabled] — skips all triggers for reduced-motion users. */
  protected readonly reducedMotion = reducedMotion;

  ngOnInit(): void {
    void this.svc.loadOverview();
  }

  contractLabel(id: RecurringContract): string {
    return this.svc.contractInfo(id).label;
  }

  contractDiscount(id: RecurringContract): number {
    return this.svc.contractInfo(id).discountPct;
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'overview-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
