import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CrewCommLogCardComponent — "messages sent to you" recent-activity card on the
 * crew surface. Angular port of the React `work/MyCommLog` (compact card form).
 * Live surface = Angular /dashboard, crew audience.
 *
 * Fetches GET /api/work/comm-log?limit=5 (worker-cookie gated → 401 anon, returns
 * { ok, items } filtered to recipient_user_kind='worker'). Same row shape as the
 * customer comm-log, so it reuses the tested pure helpers from the home card.
 * Self-gates: hides when not signed in or there are no messages. Dark cockpit.
 */
import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import {
  kindLabel,
  commTitle,
  formatSentAt,
  type CommKind,
  type CommLogItem,
} from '../home/comm-log-card.component';
import { BclRevealDirective } from '../../shared/reveal.directive';

interface CommLogResponse {
  readonly ok: boolean;
  readonly items?: readonly CommLogItem[];
}

@Component({
  selector: 'app-crew-comm-log-card',
  standalone: true,
  imports: [BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <section
        bclReveal
        data-testid="crew-comm-log-card"
        class="rounded-xl border border-bcl-border bg-bcl-bg-elev/40 p-5"
        aria-labelledby="crew-commlog-title"
      >
        <header class="mb-3">
          <p class="font-mono text-xs uppercase tracking-wide text-bcl-accent">Transparency</p>
          <h3 id="crew-commlog-title" class="text-lg font-semibold text-bcl-ink">
            Messages sent to you
          </h3>
        </header>
        <ul class="space-y-1.5">
          @for (m of items(); track m.id) {
            <li class="flex items-center gap-3 rounded-md px-2 py-1.5 text-sm">
              <span
                class="shrink-0 rounded-full px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider ring-1 ring-bcl-border text-bcl-ink-muted"
              >{{ label(m.kind) }}</span>
              <span class="flex-1 truncate text-bcl-ink">{{ title(m) }}</span>
              <span class="shrink-0 font-mono text-xs tabular-nums text-bcl-ink-muted">{{ when(m.sent_at) }}</span>
            </li>
          }
        </ul>
      </section>
    }
  `,
})
export class CrewCommLogCardComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly items = signal<readonly CommLogItem[]>([]);
  readonly visible = computed(() => this.items().length > 0);

  ngOnInit(): void {
    void this.refresh();
  }

  async refresh(): Promise<void> {
    try {
      const r = await firstValueFrom(
        this.http.get<CommLogResponse>('/api/work/comm-log?limit=5', { withCredentials: true }),
      );
      this.items.set(r?.ok ? (r.items ?? []) : []);
    } catch {
      this.items.set([]);
    }
  }

  label(kind: CommKind): string {
    return kindLabel(kind);
  }
  title(item: CommLogItem): string {
    return commTitle(item);
  }
  when(unixSec: number | null): string {
    return formatSentAt(unixSec);
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'crew-comm-log-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
