import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AppShellComponent — the Spartan cockpit shell with the Universal `@theme.tools`
 * Mega-Menu Navbar, Ideogram Brand Emblem, Global "Book the crew" CTA, and
 * Login / Avatar Circle Indicator across all `/dashboard/*` routes.
 */
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  input,
  output,
  signal,
  viewChild,
} from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService, type DashboardRole } from '../../../core/auth.service';
import { RoleService } from '../../../core/role.service';
import { FeatureFlagService } from '../../../core/feature-flag.service';
import { HlmToastHost } from '../toast/toast-host.component';
import { CommandPaletteComponent, type PaletteCommand } from '../command/command-palette.component';
import { RoleSwitcherComponent } from '../../layout/role-switcher.component';

export interface ShellNavItem {
  readonly label: string;
  readonly route: string;
  readonly icon?: string;
  readonly section?: string;
  readonly badge?: string;
  readonly roles?: DashboardRole[];
  readonly flag?: string;
}

export interface DashboardMegaMenuItem {
  readonly id: string;
  readonly category: string;
  readonly title: string;
  readonly href: string;
  readonly badge: string;
  readonly description: string;
  readonly featuredImage: string;
  readonly metaLabel: string;
}

const DASHBOARD_MEGA_MENU_ITEMS: readonly DashboardMegaMenuItem[] = [
  {
    id: 'svc-flagship-sample',
    category: 'Services & 3D Guides',
    title: 'Newark Power Washing — Free 2ft × 2ft Sample Spot First',
    href: '/c/newark/power-washing/newark-power-washing-free-sample-work',
    badge: '★ FLAGSHIP GUIDE · FREE SAMPLE',
    description:
      'We wash a free 2ft × 2ft sample patch on your Newark brick, brownstone, bluestone, or concrete driveway before finishing at $50/hr.',
    featuredImage: '/guides/power-washing/hero.jpg',
    metaLabel: '$50/hr per worker · $0 travel & gear fee',
  },
  {
    id: 'svc-power-washing',
    category: 'Services & 3D Guides',
    title: 'Power Washing & Gentle Masonry Soft-Wash',
    href: '/services/power-washing',
    badge: 'POWER WASHING · $50/HR',
    description:
      '4.0 GPM commercial rotary surface cleaner for driveways & sidewalks plus gentle low-pressure soft-washing for brick and siding.',
    featuredImage: '/guides/power-washing/surface-cleaner.jpg',
    metaLabel: '1-hr minimum · 15-min increments',
  },
  {
    id: 'svc-lawn-care',
    category: 'Services & 3D Guides',
    title: 'Lawn Care, Mowing, Mulch & Seasonal Yard Cleanups',
    href: '/services/lawn-care',
    badge: 'LAWN & YARD · $50/HR',
    description:
      'Mowing, string-trimming, hedge shaping, spring/fall leaf cleanups, and mulch installation across Newark and Essex County.',
    featuredImage: '/cities/newark/3.jpg',
    metaLabel: 'Standing weekly (-8%) & biweekly (-5%) plans',
  },
  {
    id: 'svc-hauling',
    category: 'Services & 3D Guides',
    title: 'Hauling, Junk Removal, Moving Labor & Cleanouts',
    href: '/services/hauling',
    badge: 'MOVING & HAULING · $50/HR',
    description:
      'Walk-up apartment moves, U-Haul & PODS loading/unloading, basement/estate cleanouts, and heavy furniture carry.',
    featuredImage: '/cities/newark/local-2.jpg',
    metaLabel: 'Dollies, moving pads & straps included ($0)',
  },
  {
    id: 'blog-sample-work',
    category: 'Blog & Audio Guides',
    title: 'Newark Power Washing & Free Sample Test-Patch Work',
    href: '/blog/newark-power-washing-free-sample-work',
    badge: 'POWER WASHING · PODCAST',
    description:
      'Why guess what soft-washing or a rotary surface cleaner will do to your Newark brick or concrete? We wash a free 2ft × 2ft test spot first.',
    featuredImage: '/guides/power-washing/hero.jpg',
    metaLabel: '12 min read · Spoken WebGL Audio Guide',
  },
  {
    id: 'blog-mistakes',
    category: 'Blog & Audio Guides',
    title: 'Newark Power Washing Mistakes That Ruin Brick & Siding',
    href: '/blog/newark-power-washing-mistakes',
    badge: 'MASONRY CARE · PODCAST',
    description:
      'How to protect 19th-century Ironbound lime mortar, Belleville brownstone steps, and vinyl siding from high-pressure etching.',
    featuredImage: '/cities/newark/local-1.jpg',
    metaLabel: '9 min read · Spoken WebGL Audio Guide',
  },
  {
    id: 'city-newark',
    category: 'Newark & NJ/NYC Hubs',
    title: 'Newark, NJ Home Base (Ironbound, Forest Hill, Central Ward)',
    href: '/c/newark',
    badge: 'HOME BASE · $0 TRAVEL FEE',
    description:
      'Dispatched directly from our Newark home base across all 5 wards — Ironbound, Forest Hill, University Heights, Roseville & Vailsburg.',
    featuredImage: '/cities/newark/hero.jpg',
    metaLabel: '0 mi from Newark · Same-day & next-day slots',
  },
  {
    id: 'co-sources',
    category: 'Dashboards & Company',
    title: 'Verified Research Library & Municipal Citations',
    href: '/sources',
    badge: 'PRIMARY SOURCES & DATA',
    description:
      'Explore our full bibliography of U.S. Census ACS, BLS, National Park Service masonry briefs, EPA Safer Choice, and NJ DCA standards.',
    featuredImage: '/cities/newark/local-4.jpg',
    metaLabel: 'Fact-checked quarterly by Newark Operations',
  },
];

export function visibleNavItems(
  items: ShellNavItem[],
  role: DashboardRole | null,
  flags: Record<string, boolean> = {},
): ShellNavItem[] {
  return items.filter(
    (i) =>
      (!i.roles || (role != null && i.roles.includes(role))) && (!i.flag || flags[i.flag] === true),
  );
}

export function navItemsToCommands(items: ShellNavItem[]): PaletteCommand[] {
  return items.map((it) => ({ id: it.route, label: it.label, hint: it.route, group: it.section }));
}

@Component({
  selector: 'app-shell',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    RouterLink,
    RouterLinkActive,
    HlmToastHost,
    CommandPaletteComponent,
    RoleSwitcherComponent,
  ],
  host: { class: 'block min-h-screen', '(document:keydown)': 'onGlobalKeydown($event)' },
  template: `
    <a
      href="#main"
      class="sr-only focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:z-50 focus:rounded-md focus:bg-bcl-accent focus:px-3 focus:py-2 focus:text-sm focus:font-semibold focus:text-black"
      data-testid="shell-skip-link"
      >Skip to content</a
    >
    <div class="flex min-h-screen">
      <!-- Sidebar -->
      <aside
        class="hidden w-60 shrink-0 flex-col border-r border-border bg-[hsl(var(--sidebar))] md:flex"
        style="view-transition-name: bcl-shell-sidebar"
        data-testid="shell-sidebar"
      >
        <a
          href="/"
          class="group flex h-16 items-center px-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
          [attr.aria-label]="appName() + ' — home'"
        >
          <picture class="inline-flex items-center">
            <source srcset="/brand/bcl-wordmark-512.webp?v=16" type="image/webp" />
            <img
              src="/brand/bcl-wordmark-512.png?v=16"
              srcset="
                /brand/bcl-wordmark-256.png?v=16   256w,
                /brand/bcl-wordmark-512.png?v=16   512w,
                /brand/bcl-wordmark-1024.png?v=16 1024w
              "
              sizes="210px"
              [attr.alt]="appName()"
              data-testid="brand-ideogram-emblem"
              style="position: relative; top: -5px;"
              class="relative -top-[5px] h-9 w-auto max-w-[210px] object-contain drop-shadow-[0_2px_12px_rgba(255,107,26,0.32)]"
              width="1024"
              height="173"
            />
          </picture>
        </a>
        <ng-content select="[shellSidebarTop]" />
        <ng-content select="[shellNav]">
          <nav class="flex flex-1 flex-col gap-0.5 px-3 py-2" aria-label="Primary">
            @for (item of nav(); track item.route) {
              <a
                [routerLink]="item.route"
                routerLinkActive="bg-accent text-accent-foreground"
                class="flex items-center gap-2 rounded-md px-3 py-2 text-sm text-muted-foreground hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent"
              >
                {{ item.label }}
              </a>
            }
          </nav>
        </ng-content>
      </aside>

      <!-- Main column -->
      <div class="flex min-w-0 flex-1 flex-col">
        <!-- Universal Top Navbar -->
        <header
          class="relative sticky top-0 z-40 flex h-16 min-w-0 items-center justify-between gap-2 border-b border-border bg-[#080b10]/95 px-3 backdrop-blur-xl sm:gap-3 sm:px-5"
          style="view-transition-name: bcl-shell-topbar"
          data-testid="shell-topbar"
        >
          <div class="flex items-center gap-2.5 min-w-0">
            <button
              type="button"
              class="grid h-10 w-10 shrink-0 place-items-center rounded-lg text-muted-foreground transition
                     hover:bg-accent hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bcl-accent md:hidden"
              aria-label="Open navigation menu"
              data-testid="shell-hamburger"
              (click)="openMobileNav($event)"
            >
              <svg
                viewBox="0 0 24 24"
                width="22"
                height="22"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
              >
                <path d="M3.5 6.5h17M3.5 12h17M3.5 17.5h17" />
              </svg>
            </button>
            <a
              href="/"
              class="flex items-center md:hidden focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
              [attr.aria-label]="appName() + ' — home'"
            >
              <img
                src="/brand/bcl-wordmark-512.png"
                [attr.alt]="appName()"
                style="position: relative; top: -5px;"
                class="relative -top-[5px] h-7 w-auto max-w-[165px] object-contain"
                width="165"
                height="29"
              />
            </a>

            <!-- Single Universal Mega-Menu Trigger Button -->
            <button
              type="button"
              data-testid="universal-mega-menu-trigger"
              [attr.aria-expanded]="megaOpen()"
              aria-controls="universal-mega-menu-panel"
              (click)="megaOpen.update((v) => !v)"
              class="inline-flex h-10 items-center gap-2 rounded-full border border-black/80 bg-[#0d121a] px-3.5 py-1.5 font-mono text-xs font-bold uppercase tracking-wider text-[#f5f2ed] shadow-[0_6px_18px_rgba(0,0,0,0.75),inset_0_1px_0_rgba(255,255,255,0.04)] transition hover:border-[#ff6b1a] hover:bg-[#ff6b1a]/15"
            >
              <span>Explore &amp; Guides</span>
              <span class="text-[10px]">{{ megaOpen() ? '▲' : '▼' }}</span>
            </button>

            <button
              type="button"
              class="hidden sm:flex h-10 shrink-0 items-center gap-2 rounded-full border border-border px-3 text-xs text-muted-foreground hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
              (click)="palette()?.toggle()"
              data-testid="shell-cmdk"
              aria-label="Open command palette"
            >
              <span>Search</span>
              <kbd class="rounded bg-muted px-1.5 py-0.5 font-mono text-[10px]">⌘K</kbd>
            </button>
          </div>

          <div class="ml-auto flex min-w-0 items-center gap-2 sm:gap-2.5">
            <app-role-switcher />
            <ng-content select="[shellActions]" />
            <a
              href="/book?from=dashboard-header-cta"
              data-testid="navbar-book-crew-cta"
              class="inline-flex min-h-[38px] items-center rounded-full bg-[#ff6b1a] px-3.5 py-1.5 font-display text-xs font-extrabold text-[#080b10] shadow-[0_6px_20px_rgba(255,107,26,0.35)] hover:bg-[#ff823d] transition"
            >
              Book the crew
            </a>
          </div>
        </header>

        <!-- Universal @theme.tools Mega Menu Panel Inside Dashboard -->
        @if (megaOpen()) {
          <div
            id="universal-mega-menu-panel"
            data-testid="universal-mega-menu-panel"
            role="region"
            aria-label="Brick Labor Sitewide Mega Menu"
            class="border-b border-white/15 bg-[#0a0e15]/98 p-5 shadow-2xl"
          >
            <div class="grid gap-6 lg:grid-cols-12 items-start max-w-7xl mx-auto">
              <div class="lg:col-span-8 grid gap-3 sm:grid-cols-2">
                @for (item of megaItems; track item.id) {
                  <a
                    [href]="item.href"
                    [attr.data-testid]="'mega-menu-link-' + item.id"
                    (mouseenter)="activePreview.set(item)"
                    (focus)="activePreview.set(item)"
                    class="flex items-center gap-3 rounded-xl border border-white/10 bg-[#0e141d] p-2.5 text-left transition hover:border-[#ff6b1a]/60"
                  >
                    <img
                      [src]="item.featuredImage"
                      alt=""
                      width="56"
                      height="40"
                      class="h-10 w-14 shrink-0 rounded-lg object-cover"
                    />
                    <div class="min-w-0 flex-1">
                      <span class="block truncate font-mono text-[9px] font-bold uppercase tracking-wider text-[#ff8a47]">
                        {{ item.badge }}
                      </span>
                      <span class="block truncate font-display text-xs font-bold text-white">
                        {{ item.title }}
                      </span>
                    </div>
                  </a>
                }
              </div>

              <aside
                data-testid="mega-menu-featured-preview"
                class="lg:col-span-4 overflow-hidden rounded-2xl border border-[#ff6b1a]/45 bg-[#0e141d]"
              >
                <div class="relative aspect-[16/10] w-full overflow-hidden bg-[#06080d]">
                  <img
                    [src]="activePreview().featuredImage"
                    [attr.alt]="activePreview().title"
                    data-testid="mega-menu-preview-image"
                    width="640"
                    height="400"
                    class="h-full w-full object-cover"
                  />
                  <span class="absolute left-3 top-3 rounded-full border border-[#ff6b1a]/60 bg-[#080b10]/90 px-2.5 py-0.5 font-mono text-[10px] font-bold text-[#ff8a47]">
                    {{ activePreview().badge }}
                  </span>
                </div>
                <div class="p-4 space-y-2">
                  <p class="font-mono text-[10px] text-emerald-300">● {{ activePreview().metaLabel }}</p>
                  <h4 data-testid="mega-menu-preview-title" class="font-display text-sm font-extrabold text-white">
                    {{ activePreview().title }}
                  </h4>
                  <p class="text-xs text-[#c5c0b8]">{{ activePreview().description }}</p>
                  <a
                    [href]="activePreview().href"
                    data-testid="mega-menu-preview-cta"
                    class="mt-2 inline-block w-full rounded-xl bg-[#ff6b1a] px-3 py-2 text-center font-mono text-xs font-extrabold uppercase text-[#080b10]"
                  >
                    Open Page →
                  </a>
                </div>
              </aside>
            </div>
          </div>
        }

        <main
          id="main"
          tabindex="-1"
          class="min-w-0 flex-1 p-4 sm:p-6 focus:outline-none"
          style="view-transition-name: bcl-main"
        >
          <ng-content />
        </main>
      </div>
    </div>

    <ng-content select="[shellMobileNav]" />

    <app-toast-host />
    <app-command-palette [commands]="effectiveCommands()" (run)="onPaletteRun($event)" />
  `,
})
export class AppShellComponent {
  readonly appName = input<string>('Brick Labor');
  readonly navItems = input<ShellNavItem[]>([]);
  readonly commands = input<PaletteCommand[]>([]);
  readonly runCommand = output<PaletteCommand>();

  protected readonly auth = inject(AuthService);
  protected readonly role = inject(RoleService);
  private readonly flags = inject(FeatureFlagService);
  private readonly router = inject(Router);
  protected readonly displayName = computed(() => this.auth.displayName() || 'Account');
  protected readonly nav = computed(() =>
    visibleNavItems(this.navItems(), this.role.viewAs(), this.flags.flags()),
  );

  protected readonly megaOpen = signal<boolean>(false);
  protected readonly megaItems = DASHBOARD_MEGA_MENU_ITEMS;
  protected readonly activePreview = signal<DashboardMegaMenuItem>(DASHBOARD_MEGA_MENU_ITEMS[0]!);

  protected readonly effectiveCommands = computed<PaletteCommand[]>(() =>
    this.commands().length ? this.commands() : navItemsToCommands(this.nav()),
  );

  protected readonly palette = viewChild(CommandPaletteComponent);

  protected onGlobalKeydown(ev: KeyboardEvent): void {
    if (ev.key === 'Escape' && this.megaOpen()) {
      this.megaOpen.set(false);
    }
    this.palette()?.onGlobalHotkey(ev);
  }

  protected onPaletteRun(cmd: PaletteCommand): void {
    this.runCommand.emit(cmd);
    if (cmd.id.startsWith('/')) void this.router.navigateByUrl(cmd.id);
  }

  protected openMobileNav(ev: Event): void {
    window.dispatchEvent(new CustomEvent('bcl:toggle-mobile-nav', { detail: ev.currentTarget }));
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'app-shell-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
export const THEME_TOOLS_PREP_COUNT = UNIVERSAL_PREP.length;
