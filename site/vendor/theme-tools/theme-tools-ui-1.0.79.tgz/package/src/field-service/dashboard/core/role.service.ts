import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { WAVE4_PARTNER_SPECS } from '@theme.tools/integrations/field-service-partner-adapters';
/**
 * RoleService — single source of truth for the active role on the dashboard.
 *
 * The dashboard is one unified surface; what the user SEES is driven by
 * `viewAs`. For everyone but super-admins, `viewAs === actualRole`. Super
 * admins can flip between Customer / Crew / Super Admin from the top-nav
 * role-switcher; the chosen value is sent on the `X-View-As` header so the
 * Worker returns a persona-faithful payload.
 *
 * Implementation note: derived signals (`actualRole`, `viewAs`) are
 * `linkedSignal`s computed from `auth.whoami()` so a refresh of whoami
 * doesn't trigger the write-in-effect loop the previous `effect()`-based
 * implementation was vulnerable to. The user can override `viewAs` via
 * `setViewAs()` — the linked signal honors the local override until the
 * next whoami emission switches identity.
 */
import { HttpClient } from '@angular/common/http';
import { Injectable, computed, effect, inject, linkedSignal, signal } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, catchError, switchMap, tap, throwError, from, of } from 'rxjs';
import type { DashboardRole } from './auth.service';
import { AuthService } from './auth.service';
import { TelemetryService } from './telemetry.service';

const VIEW_AS_STORAGE_KEY = 'bcl_dashboard_view_as';

/**
 * The dashboard home route each persona lands on when the switcher flips to it.
 * Customer → their bookings; Crew → their jobs board; Super-admin → the admin
 * console. Kept beside the service (its single source of truth) so the switcher
 * component + tests reference one map.
 */
export const ROLE_HOME: Record<DashboardRole, string> = {
  customer: '/bookings',
  crew: '/jobs',
  super_admin: '/admin',
};

function readPersisted(): DashboardRole | null {
  try {
    const v = globalThis.localStorage?.getItem(VIEW_AS_STORAGE_KEY);
    if (v === 'customer' || v === 'crew' || v === 'super_admin') return v;
  } catch {
    // private mode / SSR — ignore
  }
  return null;
}

@Injectable({ providedIn: 'root' })
export class RoleService {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);
  private readonly telemetry = inject(TelemetryService);
  private readonly router = inject(Router);

  /**
   * `actualRole` mirrors whoami.role and stays in sync without manual sets.
   */
  readonly actualRole = linkedSignal<DashboardRole | null>(() => this.auth.whoami().role);

  /**
   * The personas this identity can switch between (server-authoritative, from
   * whoami). Drives the navbar switcher's visibility + its option list.
   */
  readonly availableRoles = computed<readonly DashboardRole[]>(
    () => this.auth.whoami().availableRoles ?? [],
  );

  /**
   * `viewAs` defaults to whoami.viewAs (server-authoritative) or the persisted
   * client choice. Computation re-runs on every whoami refresh; user overrides
   * via `setViewAs` flow through the http post + the next whoami eventually
   * reflects the new authoritative state.
   */
  readonly viewAs = linkedSignal<DashboardRole>(() => {
    const w = this.auth.whoami();
    return w.viewAs ?? readPersisted() ?? w.role ?? 'customer';
  });

  readonly isSuperAdmin = computed(() => this.actualRole() === 'super_admin');
  readonly isCrew = computed(() => this.viewAs() === 'crew');
  readonly isCustomer = computed(() => this.viewAs() === 'customer');
  /**
   * Show the navbar role-switcher when the identity holds MORE THAN ONE persona.
   * A super-admin (all three) OR a genuine dual customer+crew both qualify; a
   * plain single-role user does not. (Previously gated on super-admin only, which
   * hid the switcher from legitimate dual-role accounts — Brian req 2026-09-29.)
   */
  readonly canSwitchRole = computed(() => this.availableRoles().length > 1);

  /** Tracks transient pending state from setViewAs$ — UI can show a spinner. */
  readonly viewAsPending = signal(false);

  constructor() {
    // Persist view-as locally so a hard refresh keeps the chosen persona.
    // This effect READS one signal and WRITES nothing back to a signal — safe.
    effect(() => {
      const v = this.viewAs();
      try {
        globalThis.localStorage?.setItem(VIEW_AS_STORAGE_KEY, v);
      } catch {
        // localStorage may be unavailable in private mode; tolerate silently.
      }
    });
  }

  /**
   * Server-authoritative flip — only super-admins are allowed by the Worker.
   * Observable shape per [[rxjs-first-angular]]. The optimistic local set is
   * reverted on error. Callers bridge to a signal only at the template layer.
   */
  setViewAs(role: DashboardRole): Observable<void> {
    const previous = this.viewAs();
    this.viewAs.set(role); // optimistic
    this.viewAsPending.set(true);
    return this.http.post<void>('/api/auth/view-as', { role }, { withCredentials: true }).pipe(
      tap(() => {
        this.viewAsPending.set(false);
        this.telemetry.capture('view_as_changed', { from: previous, to: role });
      }),
      catchError((err: unknown) => {
        this.viewAs.set(previous);
        this.viewAsPending.set(false);
        this.telemetry.capture('view_as_failed', { from: previous, to: role });
        return throwError(() => err);
      }),
    );
  }

  /**
   * Switch the active persona AND route to that persona's dashboard home.
   *
   * This is what the navbar role-switcher calls: it drives the server-authoritative
   * `setViewAs` (optimistic local flip + POST) and, ONLY once the server accepts,
   * navigates to `ROLE_HOME[role]` so the dashboard visibly becomes that role's view
   * (customer → /bookings, crew → /jobs, super-admin → /admin). On rejection the
   * optimistic flip is already reverted by `setViewAs` and we do NOT navigate.
   * Observable shape per [[rxjs-first-angular]]; the template subscribes.
   */
  switchRole(role: DashboardRole): Observable<void> {
    return this.setViewAs(role).pipe(
      switchMap(() => from(this.router.navigateByUrl(ROLE_HOME[role]))),
      // Map the navigation boolean back to void so callers see a uniform stream.
      switchMap(() => of(undefined as void)),
    );
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'role-service',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
