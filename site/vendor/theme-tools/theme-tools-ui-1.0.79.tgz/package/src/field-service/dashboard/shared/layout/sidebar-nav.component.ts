import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * SidebarNavComponent — the gorgeous, animated, interactive primary nav for the
 * Spartan cockpit sidebar. Renders the role/flag-filtered nav items (via the
 * shared `visibleNavItems` pure fn) with:
 *   • a per-item inline SVG glyph (icon+label balance) that inherits colour,
 *   • an orange active RAIL + soft glow + elevated tile (brand-locked),
 *   • wallet-button-grade hover (lift + sheen) / active (press) / focus-visible,
 *   • section grouping with hairline dividers + eyebrow labels,
 *   • a roving-tablist keyboard model (↑↓ Home End, single Tab stop),
 *   • a `@starting-style` staggered reveal on first paint,
 *   • optional trailing badge — all `motion-reduce:` + WCAG-AA safe.
 *
 * It OWNS presentation only: routing (`routerLink`) + active detection
 * (`routerLinkActive`) + the `visibleNavItems` contract are unchanged, so nav
 * routing / active-link / flag-gated items keep working exactly as before.
 * strictTemplates-safe: every template expression is total (no nullable deref).
 */
import { ChangeDetectionStrategy, Component, computed, inject, input } from '@angular/core';
import { RouterLink, RouterLinkActive, Router, NavigationEnd } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';
import { filter, map } from 'rxjs';
import { DomSanitizer, type SafeHtml } from '@angular/platform-browser';
import { RoleService } from '../../core/role.service';
import { FeatureFlagService } from '../../core/feature-flag.service';
import { visibleNavItems, type ShellNavItem } from '../ui-spartan/shell/app-shell.component';
import { iconForRoute } from '@theme-tools/ui/field-service/nav-icons';

/** A visible nav item enriched with its resolved icon SVG (trusted, static
 *  markup — never user input) + whether it opens a new section group (first
 *  item under a distinct `section`). Pure derivation. */
interface RenderNavItem {
  readonly item: ShellNavItem;
  readonly icon: SafeHtml;
  readonly startsSection: boolean;
  readonly section: string;
  readonly index: number;
}

@Component({
  selector: 'app-sidebar-nav',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, RouterLinkActive],
  host: { class: 'block' },
  template: `
    <nav
      class="bcl-nav flex flex-1 flex-col gap-px overflow-y-auto py-3 pl-2.5 pr-3"
      aria-label="Primary"
      role="navigation"
    >
      @for (row of rows(); track row.item.route) {
        @if (row.startsSection) {
          <p
            class="bcl-nav-eyebrow flex select-none items-center gap-1.5 px-3 pb-1 pt-3 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/85 first:pt-1"
            [class.bcl-nav-eyebrow--active]="row.section === activeSection()"
            aria-hidden="true"
          >
            <span class="bcl-nav-eyebrow-tick" aria-hidden="true"></span>
            {{ row.section }}
          </p>
        }
        <a
          [routerLink]="row.item.route"
          routerLinkActive="bcl-nav-item--active"
          #rla="routerLinkActive"
          [attr.aria-current]="rla.isActive ? 'page' : null"
          [attr.tabindex]="rla.isActive ? 0 : -1"
          [attr.data-testid]="'nav-' + row.item.route"
          [attr.title]="row.item.label"
          [style.--bcl-nav-i]="row.index"
          (keydown)="onKeydown($event)"
          class="bcl-nav-item group relative flex min-h-[42px] items-center gap-2.5 overflow-hidden rounded-xl px-2.5 py-2
                 text-sm font-medium text-muted-foreground outline-none transition-[color,background-color,transform,box-shadow]
                 duration-200 ease-out
                 hover:-translate-y-px hover:bg-accent/50 hover:text-foreground
                 active:translate-y-0 active:duration-75
                 focus-visible:ring-2 focus-visible:ring-bcl-accent focus-visible:ring-offset-2 focus-visible:ring-offset-[hsl(var(--sidebar))]
                 motion-reduce:transition-none motion-reduce:hover:translate-y-0"
        >
          <!-- active rail (left) — grows in from the top; orange, glowing -->
          <span aria-hidden="true" class="bcl-nav-rail"></span>
          <!-- hover sheen sweep (transform/opacity only; reduced-motion hides) -->
          <span aria-hidden="true" class="bcl-nav-sheen motion-reduce:hidden"></span>
          <!-- icon tile — full <svg> is trusted static markup (never user input),
               injected as one blob so the SVG child shapes survive sanitization. -->
          <span
            aria-hidden="true"
            [innerHTML]="row.icon"
            class="bcl-nav-ico grid h-8 w-8 shrink-0 place-items-center rounded-lg text-muted-foreground/90
                   transition-[color,background-color,transform,box-shadow] duration-200 ease-out
                   group-hover:text-foreground motion-reduce:transition-none"
          ></span>
          <span
            class="bcl-nav-label min-w-0 flex-1 truncate transition-transform duration-200 ease-out
                   group-hover:translate-x-0.5 motion-reduce:transition-none motion-reduce:group-hover:translate-x-0"
            >{{ row.item.label }}</span
          >
          @if (row.item.badge) {
            <span
              class="bcl-nav-badge shrink-0 rounded-full px-1.5 py-[3px] text-[9px] font-bold uppercase leading-none tracking-wide tabular-nums"
              >{{ row.item.badge }}</span
            >
          }
          <!-- active chevron dot -->
          <span aria-hidden="true" class="bcl-nav-dot shrink-0"></span>
        </a>
      }
    </nav>
  `,
  styles: [
    `
      /* Long nav lists fade softly at the top/bottom scroll edges instead of a
         hard cut (premium, and hints scrollability). Purely cosmetic. */
      .bcl-nav {
        -webkit-mask-image: linear-gradient(
          to bottom,
          transparent 0,
          #000 12px,
          #000 calc(100% - 14px),
          transparent 100%
        );
        mask-image: linear-gradient(
          to bottom,
          transparent 0,
          #000 12px,
          #000 calc(100% - 14px),
          transparent 100%
        );
        scrollbar-width: thin;
        scrollbar-color: color-mix(in oklch, var(--bcl-accent, #ff6b1a) 30%, transparent) transparent;
      }
      .bcl-nav::-webkit-scrollbar {
        width: 6px;
      }
      .bcl-nav::-webkit-scrollbar-thumb {
        border-radius: 9999px;
        background: color-mix(in oklch, var(--bcl-accent, #ff6b1a) 28%, transparent);
      }

      /* Section eyebrow tick — a tiny bar that lights orange for the section
         owning the active route ("you are here" anchor). */
      .bcl-nav-eyebrow-tick {
        display: inline-block;
        height: 2px;
        width: 10px;
        border-radius: 9999px;
        background: currentColor;
        opacity: 0.4;
        transition:
          width 0.24s var(--bcl-ease-out, cubic-bezier(0.16, 1, 0.3, 1)),
          background-color 0.2s ease,
          opacity 0.2s ease;
      }
      .bcl-nav-eyebrow--active {
        color: var(--bcl-accent-ink-neon, #ffb27a);
      }
      .bcl-nav-eyebrow--active .bcl-nav-eyebrow-tick {
        width: 14px;
        opacity: 1;
        background: var(--bcl-accent, #ff6b1a);
        box-shadow: 0 0 8px -1px var(--bcl-accent, #ff6b1a);
      }

      /* Section eyebrow — a hairline divider sits above every group but the
         first, tying the rhythm together. */
      .bcl-nav-eyebrow:not(:first-child) {
        position: relative;
        margin-top: 0.25rem;
      }
      .bcl-nav-eyebrow:not(:first-child)::before {
        content: '';
        position: absolute;
        left: 0.75rem;
        right: 0.75rem;
        top: 0;
        height: 1px;
        background: linear-gradient(
          to right,
          transparent,
          color-mix(in oklch, var(--bcl-ink, #f4f4f5) 12%, transparent) 30%,
          color-mix(in oklch, var(--bcl-ink, #f4f4f5) 12%, transparent) 70%,
          transparent
        );
      }

      /* Staggered @starting-style reveal — each item rises + fades on first
         paint, offset by its index (capped) via the --bcl-nav-i custom prop.
         Pure CSS; disabled under prefers-reduced-motion. */
      @supports (transition-behavior: allow-discrete) {
        .bcl-nav-item {
          opacity: 1;
          transform: translateY(0);
          transition:
            opacity 0.42s var(--bcl-ease-out, cubic-bezier(0.16, 1, 0.3, 1)),
            transform 0.42s var(--bcl-ease-out, cubic-bezier(0.16, 1, 0.3, 1)),
            color 0.2s ease,
            background-color 0.2s ease,
            box-shadow 0.2s ease;
          transition-delay: calc(min(var(--bcl-nav-i, 0), 11) * 34ms);
        }
        @starting-style {
          .bcl-nav-item {
            opacity: 0;
            transform: translateY(7px);
          }
        }
      }

      /* Active-state orange RAIL — a vertical bar pinned to the left edge that
         scales in from the top when the item is active. */
      .bcl-nav-rail {
        position: absolute;
        left: 0;
        top: 50%;
        height: 0;
        width: 3px;
        border-radius: 9999px;
        background: linear-gradient(
          to bottom,
          var(--bcl-accent, #ff6b1a),
          var(--bcl-accent-2, #ff8a47)
        );
        box-shadow: 0 0 10px -1px color-mix(in oklch, var(--bcl-accent, #ff6b1a) 80%, transparent);
        transform: translateY(-50%);
        transition:
          height 0.24s var(--bcl-ease-out, cubic-bezier(0.16, 1, 0.3, 1)),
          opacity 0.2s ease;
        opacity: 0;
      }
      .bcl-nav-item:hover .bcl-nav-rail {
        height: 40%;
        opacity: 0.5;
      }
      .bcl-nav-item--active .bcl-nav-rail {
        height: 62%;
        opacity: 1;
      }

      /* Hover sheen — a diagonal highlight that sweeps across on hover. */
      .bcl-nav-sheen {
        pointer-events: none;
        position: absolute;
        inset: 0;
        transform: translateX(-120%);
        background: linear-gradient(
          105deg,
          transparent,
          color-mix(in oklch, var(--bcl-accent, #ff6b1a) 14%, transparent),
          transparent
        );
        transition: transform 0.7s var(--bcl-ease-out, cubic-bezier(0.16, 1, 0.3, 1));
      }
      .bcl-nav-item:hover .bcl-nav-sheen {
        transform: translateX(120%);
      }

      /* Active tile — elevated background + subtle inset ring + warm text. */
      .bcl-nav-item--active {
        color: var(--bcl-ink, #f4f4f5);
        background: linear-gradient(
          100deg,
          color-mix(in oklch, var(--bcl-accent, #ff6b1a) 18%, transparent),
          color-mix(in oklch, var(--bcl-accent, #ff6b1a) 7%, transparent)
        );
        box-shadow:
          inset 0 0 0 1px color-mix(in oklch, var(--bcl-accent, #ff6b1a) 30%, transparent),
          0 6px 18px -10px color-mix(in oklch, var(--bcl-accent, #ff6b1a) 70%, transparent);
      }

      /* Icon tile responds to active — filled orange chip + dark glyph. */
      .bcl-nav-ico {
        background: color-mix(in oklch, var(--bcl-ink, #f4f4f5) 8%, transparent);
        box-shadow: inset 0 0 0 1px color-mix(in oklch, var(--bcl-ink, #f4f4f5) 8%, transparent);
      }
      .bcl-nav-item:hover .bcl-nav-ico {
        background: color-mix(in oklch, var(--bcl-accent, #ff6b1a) 16%, transparent);
        box-shadow: inset 0 0 0 1px color-mix(in oklch, var(--bcl-accent, #ff6b1a) 22%, transparent);
        transform: scale(1.06);
      }
      .bcl-nav-item--active .bcl-nav-ico {
        color: #1a0f06;
        background: linear-gradient(
          135deg,
          var(--bcl-accent, #ff6b1a),
          var(--bcl-accent-2, #ff8a47)
        );
        box-shadow: 0 0 14px -3px color-mix(in oklch, var(--bcl-accent, #ff6b1a) 85%, transparent);
      }
      /* One-shot glow ripple the instant an item becomes active (route change).
         Pure transform/opacity on a pseudo-ring; respects reduced-motion. */
      .bcl-nav-item--active .bcl-nav-ico::after {
        content: '';
        position: absolute;
        inset: -3px;
        border-radius: inherit;
        box-shadow: 0 0 0 2px color-mix(in oklch, var(--bcl-accent, #ff6b1a) 60%, transparent);
        opacity: 0;
        animation: bcl-nav-ping 0.6s var(--bcl-ease-out, cubic-bezier(0.16, 1, 0.3, 1)) 1;
      }
      .bcl-nav-ico {
        position: relative;
      }
      @keyframes bcl-nav-ping {
        0% {
          opacity: 0.85;
          transform: scale(0.7);
        }
        100% {
          opacity: 0;
          transform: scale(1.35);
        }
      }
      @media (prefers-reduced-motion: reduce) {
        .bcl-nav-item--active .bcl-nav-ico::after {
          animation: none;
        }
      }
      /* Active label locks in — slightly tighter tracking + full-strength ink. */
      .bcl-nav-item--active > span.flex-1 {
        letter-spacing: -0.01em;
        font-weight: 600;
      }
      @media (prefers-reduced-motion: reduce) {
        .bcl-nav-item:hover .bcl-nav-ico {
          transform: none;
        }
      }

      /* Trailing active dot — hidden until active, then pops. */
      .bcl-nav-dot {
        height: 6px;
        width: 6px;
        border-radius: 9999px;
        background: var(--bcl-accent, #ff6b1a);
        box-shadow: 0 0 8px -1px var(--bcl-accent, #ff6b1a);
        opacity: 0;
        transform: scale(0.4);
        transition:
          opacity 0.2s ease,
          transform 0.24s var(--bcl-ease-bounce, cubic-bezier(0.34, 1.56, 0.64, 1));
      }
      .bcl-nav-item--active .bcl-nav-dot {
        opacity: 1;
        transform: scale(1);
      }

      /* Badge — soft orange chip; inverts on active. */
      .bcl-nav-badge {
        background: color-mix(in oklch, var(--bcl-accent, #ff6b1a) 20%, transparent);
        color: var(--bcl-accent-ink-neon, #ffb27a);
      }
      .bcl-nav-item--active .bcl-nav-badge {
        background: color-mix(in oklch, var(--bcl-ink, #f4f4f5) 90%, transparent);
        color: #1a0f06;
      }
    `,
  ],
})
export class SidebarNavComponent {
  /** The full nav config; role/flag filtering happens here (same contract as
   *  the shell used before). */
  readonly navItems = input<ShellNavItem[]>([]);

  private readonly role = inject(RoleService);
  private readonly flags = inject(FeatureFlagService);
  private readonly sanitizer = inject(DomSanitizer);
  private readonly router = inject(Router);

  /** Current URL, tracking navigations (initial = boot URL). */
  private readonly url = toSignal(
    this.router.events.pipe(
      filter((e): e is NavigationEnd => e instanceof NavigationEnd),
      map((e) => e.urlAfterRedirects),
    ),
    { initialValue: this.router.url },
  );

  /** Visible items for the active view-as role + enabled flags. */
  private readonly visible = computed(() =>
    visibleNavItems(this.navItems(), this.role.viewAs(), this.flags.flags()),
  );

  /** The section that owns the currently-active route (longest route-prefix
   *  match), so its eyebrow can carry a subtle "you are here" accent. Empty
   *  string when nothing matches. */
  protected readonly activeSection = computed<string>(() => {
    const path = (this.url().split(/[?#]/)[0] ?? '').replace(/\/+$/, '') || '/';
    // Strip the /dashboard base so it matches the nav's app-relative routes.
    const rel = path.replace(/^\/dashboard/, '') || '/';
    let best = '';
    let bestLen = -1;
    for (const it of this.visible()) {
      const r = it.route;
      if ((rel === r || rel.startsWith(r + '/')) && r.length > bestLen) {
        best = it.section ?? '';
        bestLen = r.length;
      }
    }
    return best;
  });

  /** Wrap the inner icon markup in a full stroked <svg> and trust it. The
   *  markup is a compile-time constant from `nav-icons` (never user input), so
   *  bypassing the sanitizer here is safe and is what keeps the SVG child
   *  shapes from being stripped by Angular's default HTML sanitizer. */
  private svgFor(route: string, iconKey?: string): SafeHtml {
    const inner = iconForRoute(route, iconKey);
    const svg =
      '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" ' +
      'stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" ' +
      'style="height:19px;width:19px">' +
      inner +
      '</svg>';
    return this.sanitizer.bypassSecurityTrustHtml(svg);
  }

  /** Enriched render rows: icon resolved + section-break flags for grouping. */
  protected readonly rows = computed<RenderNavItem[]>(() => {
    const items = this.visible();
    let prevSection = '';
    return items.map((item, index) => {
      const section = item.section ?? '';
      const startsSection = section !== '' && section !== prevSection;
      prevSection = section;
      return { item, icon: this.svgFor(item.route, item.icon), startsSection, section, index };
    });
  });

  /**
   * Roving-tablist keyboard model: exactly one nav link is Tab-focusable (the
   * active one, tabindex 0; the rest -1). ↑/↓ move focus between links, Home/End
   * jump to first/last, wrapping. Left/Right also work (vertical list, but
   * common muscle memory). Enter/Space fall through to the native link.
   */
  protected onKeydown(ev: KeyboardEvent): void {
    const keys = ['ArrowDown', 'ArrowUp', 'ArrowRight', 'ArrowLeft', 'Home', 'End'];
    if (!keys.includes(ev.key)) return;
    const current = ev.currentTarget as HTMLElement;
    const list = current.closest('.bcl-nav');
    if (!list) return;
    const links = Array.from(list.querySelectorAll<HTMLElement>('a.bcl-nav-item'));
    if (links.length === 0) return;
    const i = links.indexOf(current);
    if (i < 0) return;
    ev.preventDefault();
    let next = i;
    switch (ev.key) {
      case 'ArrowDown':
      case 'ArrowRight':
        next = (i + 1) % links.length;
        break;
      case 'ArrowUp':
      case 'ArrowLeft':
        next = (i - 1 + links.length) % links.length;
        break;
      case 'Home':
        next = 0;
        break;
      case 'End':
        next = links.length - 1;
        break;
    }
    const target = links[next];
    if (target) target.focus();
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'sidebar-nav-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
