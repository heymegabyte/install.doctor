import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { Route } from '@angular/router';
import { featureFlagGuard } from '../../core/feature-flag-guard';

export const ADMIN_ROUTES: Route[] = [
  {
    path: '',
    pathMatch: 'full',
    loadComponent: () => import('./admin.component').then((m) => m.AdminComponent),
  },
  {
    path: 'flags',
    loadComponent: () => import('./flags.component').then((m) => m.FlagsComponent),
  },
  {
    path: 'tenants',
    loadComponent: () => import('./tenants.component').then((m) => m.TenantsComponent),
  },
  {
    path: 'coupons',
    loadComponent: () => import('./coupons.component').then((m) => m.AdminCouponsComponent),
  },
  {
    path: 'fraud',
    loadComponent: () => import('./fraud.component').then((m) => m.AdminFraudComponent),
  },
  {
    path: 'subscriptions',
    loadComponent: () =>
      import('./subscriptions.component').then((m) => m.AdminSubscriptionsComponent),
  },
  {
    path: 'unit-economics',
    loadComponent: () =>
      import('./cost-per-booking.component').then((m) => m.AdminCostPerBookingComponent),
  },
  {
    path: 'compliance',
    loadComponent: () => import('./compliance.component').then((m) => m.AdminComplianceComponent),
  },
  {
    path: 'classification-risk',
    loadComponent: () =>
      import('./classification-risk.component').then((m) => m.AdminClassificationRiskComponent),
  },
  {
    path: 'marketing',
    loadComponent: () => import('./marketing.component').then((m) => m.AdminMarketingComponent),
  },
  {
    path: 'content',
    loadComponent: () => import('./content.component').then((m) => m.ContentComponent),
  },
  {
    path: 'photo-quotes',
    canActivate: [featureFlagGuard('photo_sms_intake')],
    loadComponent: () =>
      import('./photo-quotes.component').then((m) => m.AdminPhotoQuotesComponent),
  },
  {
    path: 'escrow',
    canActivate: [featureFlagGuard('smart_bonded_escrow')],
    loadComponent: () =>
      import('./escrow-queue.component').then((m) => m.EscrowQueueComponent),
  },
  {
    path: 'weather-offers',
    canActivate: [featureFlagGuard('weather_reschedule_agent')],
    loadComponent: () =>
      import('./weather-offers.component').then((m) => m.WeatherOffersComponent),
  },
  {
    path: 'ops-health',
    loadComponent: () => import('./ops-health.component').then((m) => m.AdminOpsHealthComponent),
  },
  {
    path: 'system-health',
    loadComponent: () => import('./system-health.component').then((m) => m.SystemHealthComponent),
  },
  {
    path: 'notifications',
    loadComponent: () =>
      import('./notifications.component').then((m) => m.AdminNotificationsComponent),
  },
  {
    path: 'env-config',
    loadComponent: () => import('./env-config.component').then((m) => m.EnvConfigComponent),
  },
  {
    path: 'impact-report',
    loadComponent: () => import('./impact-report.component').then((m) => m.ImpactReportComponent),
  },
  {
    path: 'sql-copilot',
    loadComponent: () => import('./sql-copilot.component').then((m) => m.SqlCopilotComponent),
  },
  {
    path: 'operator-widgets',
    loadComponent: () =>
      import('./operator-widgets.component').then((m) => m.OperatorWidgetsComponent),
  },
  {
    path: 'surge-sandbox',
    loadComponent: () => import('./surge-sandbox.component').then((m) => m.SurgeSandboxComponent),
  },
  {
    path: 'segments',
    loadComponent: () => import('./segments.component').then((m) => m.SegmentsComponent),
  },
  {
    path: 'social',
    loadComponent: () => import('./social.component').then((m) => m.AdminSocialComponent),
  },
  {
    path: 'backups',
    loadComponent: () => import('./backups.component').then((m) => m.AdminBackupsComponent),
  },
  {
    path: 'operator-actions',
    loadComponent: () =>
      import('./operator-actions.component').then((m) => m.AdminOperatorActionsComponent),
  },
  {
    path: 'finance',
    loadComponent: () => import('./finance.component').then((m) => m.AdminFinanceComponent),
  },
  {
    path: 'applicants',
    loadComponent: () => import('./applicants.component').then((m) => m.AdminApplicantsComponent),
  },
  {
    path: 'referrals',
    loadComponent: () => import('./referrals.component').then((m) => m.AdminReferralsComponent),
  },
  {
    path: 'tax-1099',
    loadComponent: () => import('./tax-1099.component').then((m) => m.AdminTax1099Component),
  },
  {
    path: 'safety',
    loadComponent: () => import('./safety.component').then((m) => m.AdminSafetyComponent),
  },
  {
    // SCAN-11 — Admin SMS console (quarterly nudge preview + templates + recent
    // sends). Wires the previously-dead /api/admin/sms route into a reachable
    // surface; live outreach stays env-gated (SMS_QUARTERLY_LIVE_SEND).
    path: 'sms',
    loadComponent: () => import('./sms-console.component').then((m) => m.SmsConsoleComponent),
  },
  {
    path: 'disputes',
    loadComponent: () => import('./disputes.component').then((m) => m.AdminDisputesComponent),
  },
  {
    path: 'impersonate',
    loadComponent: () => import('./impersonate.component').then((m) => m.AdminImpersonateComponent),
  },
  {
    path: 'rental-approvals',
    loadComponent: () =>
      import('./rental-approvals.component').then((m) => m.RentalApprovalsComponent),
  },
  // 'claims-queue' (AI claims-adjudicator) was cut in migration 0128 — auto-approve/deny on
  // damage claims wants a human. Its route + component + dead /api/wave28/claims-adjudicator/*
  // calls were removed so the live admin surface ships no unmounted-route reference.
];
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'admin-routes',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
