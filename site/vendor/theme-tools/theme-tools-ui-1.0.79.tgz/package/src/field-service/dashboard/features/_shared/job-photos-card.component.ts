import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * JobPhotosCardComponent — crew-facing before/after photo capture on the live
 * job HUD. Closes BACKLOG item 10's "media upload" gap on the LIVE Angular
 * surface: the job-tracking HUD previously punted photos to the chat panel
 * (which posts a generic /api/ride/arrival-photo), so the crew could never add
 * the STRUCTURED before/after `gig_photos` that gate /complete. Without those,
 * the crew can't finish a job — the money loop stalls at "documented".
 *
 * Backend (all `bcl_work_sid`-gated):
 *   GET  /api/work/gigs/:id/photos      — progress (beforeCount/afterCount/canComplete) + claimId
 *   POST /api/work/upload/gig-photo     — multipart: claimId, kind, file, lat?, lng? (GPS-gated 250m)
 *
 * Crew-only: parent gates render on `isCrew`. Self-gates anyway — a 404 no_claim
 * or 401 hides the card; an upload error becomes specific, actionable copy, never
 * a false "uploaded". Geolocation is best-effort: captured when granted (enforces
 * the on-site geofence), omitted when denied (upload still succeeds, no fence).
 */
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  inject,
  input,
  output,
  signal,
  DestroyRef,
} from '@angular/core';

/** Photo kinds the crew captures from the live HUD. */
export type JobPhotoKind = 'before' | 'after';

/** Shape of `GET /api/work/gigs/:id/photos`. */
export interface JobPhotosState {
  readonly ok: boolean;
  readonly claimId: string;
  readonly beforeCount: number;
  readonly afterCount: number;
  readonly canComplete: boolean;
}

/**
 * Map a worker upload error to honest crew-facing copy. The card NEVER shows a
 * false "uploaded" — every non-2xx becomes a specific, actionable message.
 *
 * @example jobPhotoUploadErrorMessage(400, 'outside_geofence') // → "You're too far from the job…"
 * @example jobPhotoUploadErrorMessage(413) // → "That photo is too large…"
 */
export function jobPhotoUploadErrorMessage(status: number, code?: string): string {
  if (code === 'outside_geofence')
    return "You're too far from the job address to add a photo. Move closer and try again.";
  if (status === 401 || code === 'unauthorized')
    return 'Your crew session expired. Sign in again to add photos.';
  if (status === 403 || code === 'forbidden') return "This job isn't assigned to you.";
  if (status === 404 || code === 'claim_not_found') return 'That job is no longer active.';
  if (status === 413 || code === 'too_large')
    return 'That photo is too large. Try again — most phone photos are fine.';
  if (status === 415 || code === 'unsupported_mime')
    return 'That file type isn’t a photo. Use your camera or pick a JPG/PNG.';
  if (status === 400 && code === 'too_small') return 'That photo looks empty. Retake it.';
  if (status === 429 || code === 'rate_limited') return 'Too many uploads. Wait a moment and retry.';
  if (status === 400 && code === 'claim_wrong_status')
    return "You can add photos once you've accepted and started the job.";
  return 'The photo didn’t upload. Check your signal and try again.';
}

/**
 * One-line progress hint for the crew: what's still needed before /complete
 * unlocks, or the all-clear once it does.
 *
 * @example photoProgressLabel(1, 1, true) // → "Ready to mark complete"
 * @example photoProgressLabel(1, 0, false) // → "Add 1 after photo to finish"
 * @example photoProgressLabel(0, 0, false) // → "Add 1 before photo to start"
 */
export function photoProgressLabel(
  beforeCount: number,
  afterCount: number,
  canComplete: boolean,
): string {
  if (canComplete) return 'Ready to mark complete';
  const needs: string[] = [];
  if (beforeCount < 1) needs.push('1 before photo');
  if (afterCount < 1) needs.push('1 after photo');
  if (needs.length === 0) return 'Ready to mark complete';
  return `Add ${needs.join(' and ')} to finish`;
}

@Component({
  selector: 'bcl-job-photos-card',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (gated()) {
      <div
        class="rounded-xl border border-border bg-card p-4"
        data-testid="job-photos-card"
      >
        <div class="flex items-start justify-between gap-3">
          <div>
            <h3 class="text-sm font-semibold text-foreground">Document the job</h3>
            <p class="text-xs text-muted-foreground">
              Add before &amp; after photos so we can finish and bill the work.
            </p>
          </div>
          <span
            class="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium transition-all duration-[333ms]"
            [class]="
              canComplete()
                ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-600'
                : 'border-border bg-muted/40 text-muted-foreground'
            "
            role="status"
            data-testid="job-photos-progress"
            [attr.aria-label]="'Photo progress: ' + progressLabel()"
          >
            <span
              class="h-2 w-2 rounded-full"
              [class]="canComplete() ? 'bg-emerald-500' : 'bg-muted-foreground/60'"
              aria-hidden="true"
            ></span>
            {{ progressLabel() }}
          </span>
        </div>

        <div class="mt-4 grid grid-cols-2 gap-3">
          @for (k of kinds; track k.kind) {
            <label
              class="group relative flex min-h-[120px] cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed p-3 text-center transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-primary hover:shadow-md focus-within:ring-2 focus-within:ring-primary"
              [class]="
                count(k.kind) > 0 ? 'border-emerald-500/50 bg-emerald-500/5' : 'border-border bg-background'
              "
              [attr.data-testid]="'job-photo-tile-' + k.kind"
            >
              <input
                type="file"
                accept="image/*"
                capture="environment"
                class="sr-only"
                [disabled]="uploading() !== null"
                (change)="onPick(k.kind, $event)"
                [attr.aria-label]="'Add ' + k.label + ' photo'"
              />
              <span class="text-2xl" aria-hidden="true">{{ uploading() === k.kind ? '⏳' : '📷' }}</span>
              <span class="text-sm font-medium text-foreground">{{ k.label }}</span>
              <span
                class="inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold transition-all duration-[333ms]"
                [class]="
                  count(k.kind) > 0
                    ? 'bg-emerald-500/15 text-emerald-600'
                    : 'bg-muted/60 text-muted-foreground'
                "
              >
                {{ count(k.kind) }} {{ count(k.kind) === 1 ? 'photo' : 'photos' }}
              </span>
            </label>
          }
        </div>

        @if (error()) {
          <p
            class="mt-3 rounded-lg bg-destructive/10 px-3 py-2 text-xs text-destructive"
            role="alert"
            data-testid="job-photos-error"
          >
            {{ error() }}
          </p>
        }
      </div>
    }
  `,
})
export class JobPhotosCardComponent {
  private readonly destroyRef = inject(DestroyRef);

  /** Gig id (the live job route `:id`). */
  readonly gigId = input.required<string>();

  /** Emits the refreshed `canComplete` after every successful upload so the
   * parent HUD can enable its own Complete button without re-fetching. */
  readonly progress = output<JobPhotosState>();

  private readonly claimId = signal<string | null>(null);
  private readonly beforeCount = signal(0);
  private readonly afterCount = signal(0);
  readonly canComplete = signal(false);
  readonly uploading = signal<JobPhotoKind | null>(null);
  readonly error = signal<string | null>(null);
  /** False until a claim is resolved; hides the card for non-assigned crew. */
  readonly gated = signal(false);

  readonly kinds: ReadonlyArray<{ kind: JobPhotoKind; label: string }> = [
    { kind: 'before', label: 'Before' },
    { kind: 'after', label: 'After' },
  ];

  readonly progressLabel = computed(() =>
    photoProgressLabel(this.beforeCount(), this.afterCount(), this.canComplete()),
  );

  count(kind: JobPhotoKind): number {
    return kind === 'before' ? this.beforeCount() : this.afterCount();
  }

  constructor() {
    // Re-fetch progress whenever the gig id resolves.
    effect(() => {
      const id = this.gigId();
      if (id) void this.refresh(id);
    });
  }

  private async refresh(gigId: string): Promise<void> {
    try {
      const res = await fetch(`/api/work/gigs/${encodeURIComponent(gigId)}/photos`, {
        credentials: 'include',
      });
      if (!res.ok) {
        // 404 no_claim / 401 → not this crew's job; hide silently.
        this.gated.set(false);
        return;
      }
      const body = (await res.json()) as Partial<JobPhotosState>;
      if (!body.claimId) {
        this.gated.set(false);
        return;
      }
      this.claimId.set(body.claimId);
      this.beforeCount.set(body.beforeCount ?? 0);
      this.afterCount.set(body.afterCount ?? 0);
      this.canComplete.set(body.canComplete ?? false);
      this.gated.set(true);
      this.progress.emit(body as JobPhotosState);
    } catch {
      // Network hiccup — keep prior state; don't flash an error on initial load.
    }
  }

  async onPick(kind: JobPhotoKind, event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = ''; // allow re-picking the same file
    const claim = this.claimId();
    if (!file || !claim) return;

    this.error.set(null);
    this.uploading.set(kind);

    const pos = await this.capturePosition();
    const form = new FormData();
    form.append('claimId', claim);
    form.append('kind', kind);
    form.append('file', file, file.name || `${kind}.jpg`);
    if (pos) {
      form.append('lat', String(pos.lat));
      form.append('lng', String(pos.lng));
    }

    try {
      const res = await fetch('/api/work/upload/gig-photo', {
        method: 'POST',
        credentials: 'include',
        body: form,
      });
      if (!res.ok) {
        let code: string | undefined;
        try {
          code = ((await res.json()) as { code?: string }).code;
        } catch {
          /* non-JSON body */
        }
        this.error.set(jobPhotoUploadErrorMessage(res.status, code));
        return;
      }
      await this.refresh(this.gigId());
    } catch {
      this.error.set(jobPhotoUploadErrorMessage(0));
    } finally {
      this.uploading.set(null);
    }
  }

  /** Best-effort geolocation. Resolves null on denial/timeout so the upload
   * still proceeds (the backend skips the geofence when coords are absent). */
  private capturePosition(): Promise<{ lat: number; lng: number } | null> {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      return Promise.resolve(null);
    }
    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (p) => resolve({ lat: p.coords.latitude, lng: p.coords.longitude }),
        () => resolve(null),
        { enableHighAccuracy: true, timeout: 8000, maximumAge: 30000 },
      );
    });
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'job-photos-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
