import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * CrewBlackoutsCardComponent — date-range blackouts (vacation / sick / conflict)
 * on the crew surface. Angular port of React `work/BlackoutPicker`. Live surface =
 * Angular /dashboard, crew audience. Self-contained loop (list + add + remove).
 *
 * Paths verified by MOUNT (NOT the React component — its `/api/work/blackouts` 404s;
 * the route is mounted at `/api/work/availability` with an internal `/blackouts`):
 *   GET    /api/work/availability/blackouts        → { ok, blackouts:[{id,start_date,end_date,reason}] }
 *   POST   /api/work/availability/blackouts        { startDate, endDate, reason? }
 *   DELETE /api/work/availability/blackouts/:id
 * Self-gates 401 → hide. Pure helpers formatRange/isValidRange/sortByStart unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HlmCardImports, HlmButton, HlmInput } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export interface Blackout {
  readonly id: string;
  readonly start_date: string;
  readonly end_date: string;
  readonly reason: string | null;
}

/** Pure: a YYYY-MM-DD range as a short label (collapses a single day). */
export function formatRange(start: string, end: string): string {
  const fmt = (ymd: string): string => {
    const t = Date.parse(`${ymd}T00:00:00`);
    if (Number.isNaN(t)) return ymd;
    return new Date(t).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  };
  return start === end ? fmt(start) : `${fmt(start)} – ${fmt(end)}`;
}

/** Pure: both YYYY-MM-DD and end not before start. */
export function isValidRange(start: string, end: string): boolean {
  const re = /^\d{4}-\d{2}-\d{2}$/;
  if (!re.test(start) || !re.test(end)) return false;
  return end >= start;
}

/** Pure: soonest start first. */
export function sortByStart(rows: readonly Blackout[]): Blackout[] {
  return [...rows].sort((a, b) => a.start_date.localeCompare(b.start_date));
}

interface BlackoutsResponse {
  readonly ok: boolean;
  readonly blackouts?: readonly Blackout[];
}

@Component({
  selector: 'app-crew-blackouts-card',
  standalone: true,
  imports: [...HlmCardImports, HlmButton, HlmInput, FormsModule, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (visible()) {
      <div hlmCard bclReveal data-testid="crew-blackouts-card">
        <div hlmCardHeader>
          <h3 hlmCardTitle>Blackout dates</h3>
          <p hlmCardDescription>Days you can't work — we won't dispatch gigs then.</p>
        </div>
        <div hlmCardContent>
          @if (items().length > 0) {
            <ul class="mb-4 grid gap-2">
              @for (b of items(); track b.id) {
                <li class="flex items-center justify-between gap-2 rounded-md border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm">
                  <span class="min-w-0">
                    <span class="text-bcl-ink">{{ range(b.start_date, b.end_date) }}</span>
                    @if (b.reason) { <span class="ml-2 text-bcl-ink-muted">— {{ b.reason }}</span> }
                  </span>
                  <button hlmBtn variant="ghost" class="text-xs text-destructive" [disabled]="pending().has(b.id)" (click)="remove(b.id)">Remove</button>
                </li>
              }
            </ul>
          } @else {
            <p class="mb-4 text-sm text-bcl-ink-muted">No blackout dates set.</p>
          }

          <div class="grid gap-2 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
            <label class="text-xs text-bcl-ink-muted">From
              <input hlmInput type="date" class="mt-1" [(ngModel)]="startDate" name="startDate" />
            </label>
            <label class="text-xs text-bcl-ink-muted">To
              <input hlmInput type="date" class="mt-1" [(ngModel)]="endDate" name="endDate" />
            </label>
            <button hlmBtn [disabled]="adding() || !valid()" (click)="add()" data-testid="blackout-add">
              {{ adding() ? 'Adding…' : 'Add blackout' }}
            </button>
          </div>
          <input hlmInput class="mt-2 w-full" [(ngModel)]="reason" name="reason" maxlength="200" placeholder="Reason (optional) — vacation, sick, conflict…" />

          @if (error(); as e) {
            <p class="mt-3 text-sm text-destructive" role="alert">{{ e }}</p>
          }
        </div>
      </div>
    }
  `,
})
export class CrewBlackoutsCardComponent implements OnInit {
  private static readonly BASE = '/api/work/availability/blackouts';

  readonly visible = signal(false);
  readonly items = signal<readonly Blackout[]>([]);
  readonly pending = signal<Set<string>>(new Set());
  readonly adding = signal(false);
  readonly error = signal<string>('');

  startDate = '';
  endDate = '';
  reason = '';

  readonly range = formatRange;

  ngOnInit(): void {
    void this.reload();
  }

  valid(): boolean {
    return isValidRange(this.startDate, this.endDate);
  }

  async reload(): Promise<void> {
    this.error.set('');
    try {
      const res = await fetch(CrewBlackoutsCardComponent.BASE, { credentials: 'include' });
      if (!res.ok) {
        this.visible.set(false);
        return;
      }
      const data = (await res.json().catch(() => null)) as BlackoutsResponse | null;
      if (!data?.ok) {
        this.visible.set(false);
        return;
      }
      this.items.set(sortByStart(data.blackouts ?? []));
      this.visible.set(true);
    } catch {
      this.visible.set(false);
    }
  }

  async add(): Promise<void> {
    if (!this.valid()) return;
    this.adding.set(true);
    this.error.set('');
    try {
      const res = await fetch(CrewBlackoutsCardComponent.BASE, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          startDate: this.startDate,
          endDate: this.endDate,
          reason: this.reason.trim() || undefined,
        }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      this.startDate = '';
      this.endDate = '';
      this.reason = '';
      await this.reload();
    } catch {
      this.error.set('Could not add that blackout. Check the dates and try again.');
    } finally {
      this.adding.set(false);
    }
  }

  async remove(id: string): Promise<void> {
    const next = new Set(this.pending()).add(id);
    this.pending.set(next);
    this.error.set('');
    try {
      const res = await fetch(`${CrewBlackoutsCardComponent.BASE}/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      await this.reload();
    } catch {
      this.error.set('Could not remove that blackout. Try again.');
    } finally {
      const p = new Set(this.pending());
      p.delete(id);
      this.pending.set(p);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'blackouts-card-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
