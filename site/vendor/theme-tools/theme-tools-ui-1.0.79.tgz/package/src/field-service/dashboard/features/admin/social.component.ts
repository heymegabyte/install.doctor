import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AdminSocialComponent — social-post scheduler queue on the admin console.
 * Live surface = Angular /dashboard/admin.
 *
 * Unblocked 2026-06-03: `/api/admin/social` migrated from OWNER_INVOICE_KEY
 * Bearer-only to the shared `ownerOrSuperAdmin` gate.
 *   GET /api/admin/social/queue → { ok, posts:[{id,channel,kind,draft_text,posted_at,post_url,status}] }
 * READ-ONLY: the draft-from-job / queue POSTs (which spend AI tokens / schedule
 * posts) are operator actions. Pure helpers statusTone/channelLabel unit-tested.
 */
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { HlmCardImports } from '../../shared/ui-spartan';
import { BclRevealDirective } from '../../shared/reveal.directive';

export type SocialStatus = 'draft' | 'queued' | 'posted' | 'archived';

export interface SocialPost {
  readonly id: string;
  readonly channel: string;
  readonly kind: string;
  readonly draft_text: string;
  readonly posted_at: string | null;
  readonly post_url: string | null;
  readonly status: SocialStatus;
}

const CHANNEL_LABEL: Readonly<Record<string, string>> = {
  tiktok: 'TikTok',
  ig: 'Instagram',
  fb: 'Facebook',
  nextdoor: 'Nextdoor',
};

/** Pure: human channel label. */
export function channelLabel(channel: string): string {
  return CHANNEL_LABEL[channel] ?? channel ?? 'Social';
}

/** Pure: tone band for a post status. */
export function statusTone(status: string): 'safe' | 'warn' | 'info' | 'muted' {
  switch (status) {
    case 'posted':
      return 'safe';
    case 'queued':
      return 'warn';
    case 'archived':
      return 'muted';
    default:
      return 'info'; // draft
  }
}

interface QueueResponse {
  readonly ok: boolean;
  readonly posts?: readonly SocialPost[];
}

@Component({
  selector: 'app-admin-social',
  standalone: true,
  imports: [...HlmCardImports, BclRevealDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div hlmCard bclReveal data-testid="admin-social">
      <div hlmCardHeader>
        <h3 hlmCardTitle>Social scheduler</h3>
        <p hlmCardDescription>Drafted + queued + posted social content across channels.</p>
      </div>
      <div hlmCardContent>
        @if (loading()) {
          <p class="text-sm text-bcl-ink-muted">Loading social queue…</p>
        } @else if (error()) {
          <p class="text-sm text-bcl-warn" role="status">{{ error() }}</p>
        } @else if (posts().length === 0) {
          <p class="text-sm text-bcl-ink-muted">No social posts drafted yet.</p>
        } @else {
          <ul class="grid gap-2">
            @for (p of posts(); track p.id) {
              <li class="rounded-md border border-bcl-border bg-bcl-bg-elev px-3 py-2 text-sm">
                <div class="flex items-center justify-between gap-2">
                  <span class="flex items-center gap-2 min-w-0">
                    <span class="shrink-0 rounded-full px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider ring-1 ring-bcl-border text-bcl-ink-muted">{{ label(p.channel) }} · {{ p.kind }}</span>
                    <span
                      class="shrink-0 text-xs"
                      [class.text-bcl-success]="tone(p.status) === 'safe'"
                      [class.text-bcl-warn]="tone(p.status) === 'warn'"
                      [class.text-bcl-ink-muted]="tone(p.status) === 'muted'"
                      [class.text-bcl-accent]="tone(p.status) === 'info'"
                    >{{ p.status }}</span>
                  </span>
                  @if (p.post_url) {
                    <a [href]="p.post_url" target="_blank" rel="noopener noreferrer" class="shrink-0 text-xs text-bcl-accent">View →</a>
                  }
                </div>
                @if (p.draft_text) {
                  <p class="mt-1 truncate text-xs text-bcl-ink-muted">{{ p.draft_text }}</p>
                }
              </li>
            }
          </ul>
        }
      </div>
    </div>
  `,
})
export class AdminSocialComponent implements OnInit {
  private readonly http = inject(HttpClient);

  readonly posts = signal<readonly SocialPost[]>([]);
  readonly loading = signal(true);
  readonly error = signal<string>('');

  readonly label = channelLabel;
  readonly tone = statusTone;

  ngOnInit(): void {
    void this.load();
  }

  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set('');
    try {
      const r = await firstValueFrom(
        this.http.get<QueueResponse>('/api/admin/social/queue', { withCredentials: true }),
      );
      this.posts.set(r?.ok ? (r.posts ?? []) : []);
    } catch {
      this.error.set('Sign in as an operator to view the social queue.');
    } finally {
      this.loading.set(false);
    }
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'social-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
