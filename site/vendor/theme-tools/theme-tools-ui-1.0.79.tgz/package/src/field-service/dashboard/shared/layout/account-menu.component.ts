import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
/**
 * AccountMenu — top-nav avatar button with a dropdown.
 *
 * Items: Profile · Settings · Help · Sign out. When the whoami payload
 * surfaces `linked_accounts` siblings (e.g. a super-admin who is ALSO a
 * customer on the same email), the menu renders a "Switch account" submenu
 * listing each linked identity. (It switches between linked IDENTITIES on one
 * email — NOT SaaS tenants/workspaces; Brick Labor is a single business.)
 *
 * Sign-out POSTs `/api/auth/logout`, clears cookies server-side, then
 * navigates to /login. The component already trusts AuthService.signOut
 * to clear local state, but we also explicitly call the new dedicated
 * logout route for the unified surface.
 */
import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  computed,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { OverlayModule } from '@angular/cdk/overlay';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '../../core/auth.service';
import { RovingMenuDirective } from '../../features/_shared/roving-menu.directive';

@Component({
  selector: 'app-account-menu',
  standalone: true,
  imports: [OverlayModule, RovingMenuDirective],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div
      cdkOverlayOrigin
      #trigger="cdkOverlayOrigin"
      data-testid="universal-navbar-auth-slot"
      class="inline-flex items-center"
    >
      @if (isGuest()) {
        <a
          href="/login"
          data-testid="navbar-login-avatar-button"
          data-bcl-auth="anon"
          aria-label="Log in to your Brick Labor account"
          class="group inline-flex min-h-[38px] items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] pl-1.5 pr-3.5 py-1 text-xs font-semibold text-[#f5f2ed] transition-all hover:border-[#ff6b1a]/70 hover:bg-[#ff6b1a]/10 hover:text-white"
        >
          <span
            data-testid="navbar-avatar-circle"
            aria-hidden="true"
            class="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-white/25 bg-[#121822] text-[#ff8a47]"
          >
            ●
          </span>
          <span>Login</span>
        </a>
      } @else {
        <button
          #triggerBtn
          type="button"
          data-testid="navbar-logged-in-avatar-circle"
          (click)="open.update((v) => !v)"
          class="relative inline-flex items-center justify-center rounded-full size-9 bg-gradient-to-br from-[#ff6b1a] to-[#d94e06] text-[#080b10] ring-2 ring-[#ff6b1a]/50 hover:opacity-95 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
          [attr.aria-expanded]="open()"
          aria-haspopup="menu"
          aria-label="Open account menu"
        >
          <span
            data-testid="navbar-avatar-circle"
            class="font-mono text-xs font-extrabold uppercase tracking-wider text-[#080b10]"
          >
            {{ initials() }}
          </span>
          <span
            aria-hidden="true"
            class="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-[#0c1118] bg-emerald-400"
          ></span>
        </button>
      }
    </div>

    <ng-template
      cdkConnectedOverlay
      [cdkConnectedOverlayOrigin]="trigger"
      [cdkConnectedOverlayOpen]="open()"
      [cdkConnectedOverlayHasBackdrop]="true"
      cdkConnectedOverlayBackdropClass="bg-transparent"
      [cdkConnectedOverlayPositions]="[
        { originX: 'end', originY: 'bottom', overlayX: 'end', overlayY: 'top', offsetY: 8 },
      ]"
      (backdropClick)="open.set(false)"
    >
      <ul
        role="menu"
        bclRovingMenu
        (dismiss)="onDismiss()"
        class="mt-1 min-w-64 rounded-lg bg-bcl-bg-elev p-1 ring-1 ring-bcl-border shadow-xl"
      >
        <li class="px-3 py-2 border-b border-bcl-border mb-1">
          <p class="text-sm text-bcl-ink truncate">{{ displayName() }}</p>
          @if (email(); as e) {
            <p class="text-xs text-bcl-ink-muted truncate">{{ e }}</p>
          }
        </li>

        @if (linkedAccounts().length > 0) {
          <li class="px-3 py-1 font-mono text-[10px] uppercase tracking-wide text-bcl-ink-muted">
            Switch account
          </li>
          @for (w of linkedAccounts(); track w.id) {
            <li>
              <button
                role="menuitem"
                type="button"
                (click)="switchAccount(w.id)"
                class="flex w-full items-center justify-between gap-3 rounded-md px-3 py-2 text-left text-sm text-bcl-ink hover:bg-white/5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
              >
                <span>{{ w.label }}</span>
                <span class="font-mono text-[10px] uppercase text-bcl-ink-muted">{{ w.kind }}</span>
              </button>
            </li>
          }
          <li class="my-1 border-t border-bcl-border"></li>
        }

        <li>
          <button
            role="menuitem"
            type="button"
            (click)="go('/settings?tab=profile')"
            class="block w-full rounded-md px-3 py-2 text-left text-sm text-bcl-ink hover:bg-white/5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
          >
            Profile
          </button>
        </li>
        <li>
          <button
            role="menuitem"
            type="button"
            (click)="go('/settings')"
            class="block w-full rounded-md px-3 py-2 text-left text-sm text-bcl-ink hover:bg-white/5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
          >
            Settings
          </button>
        </li>
        <li>
          <button
            role="menuitem"
            type="button"
            (click)="openHelp()"
            class="block w-full rounded-md px-3 py-2 text-left text-sm text-bcl-ink hover:bg-white/5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
          >
            Help
          </button>
        </li>
        <li class="my-1 border-t border-bcl-border"></li>
        <li>
          <button
            role="menuitem"
            type="button"
            (click)="signOut()"
            class="block w-full rounded-md px-3 py-2 text-left text-sm text-bcl-danger hover:bg-bcl-danger/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-bcl-accent"
          >
            Sign out
          </button>
        </li>
      </ul>
    </ng-template>
  `,
})
export class AccountMenuComponent {
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  private readonly http = inject(HttpClient);

  readonly open = signal<boolean>(false);

  /** The avatar trigger — focus returns here when the menu is dismissed by keyboard. */
  private readonly triggerBtn = viewChild<ElementRef<HTMLButtonElement>>('triggerBtn');

  /**
   * Escape/Tab inside the open menu (per WCAG APG): close it AND return focus to the
   * trigger so a keyboard operator is never stranded on a detached overlay element.
   */
  onDismiss(): void {
    this.open.set(false);
    this.triggerBtn()?.nativeElement.focus();
  }

  readonly isGuest = computed(() => this.auth.whoami().role === null);
  readonly displayName = computed(() => this.auth.displayName());
  readonly email = computed(() => this.auth.whoami().email);

  readonly initials = computed(() => {
    const name = this.auth.displayName() || this.auth.whoami().email || 'G';
    const parts = name
      .split(/[\s@.]+/)
      .filter(Boolean)
      .slice(0, 2);
    return parts.map((p) => p[0]?.toUpperCase() ?? '').join('') || 'G';
  });

  readonly linkedAccounts = computed(() => {
    const w = this.auth.whoami();
    const linked =
      (w as unknown as { linked_accounts?: Record<string, string> }).linked_accounts ?? {};
    const me = w.email ?? '';
    const list: Array<{ id: string; label: string; kind: string }> = [];
    const customerId = linked['customer_id'];
    const workerId = linked['worker_id'];
    const adminEmail = linked['admin_email'];
    if (customerId && customerId !== me) {
      list.push({ id: customerId, label: customerId, kind: 'customer' });
    }
    if (workerId) {
      list.push({ id: workerId, label: 'Crew ' + workerId.slice(0, 6), kind: 'crew' });
    }
    if (adminEmail && adminEmail !== me) {
      list.push({ id: adminEmail, label: adminEmail, kind: 'admin' });
    }
    return list;
  });

  go(path: string): void {
    this.open.set(false);
    const [p, q] = path.split('?');
    if (q) {
      const params: Record<string, string> = {};
      for (const part of q.split('&')) {
        const [k, v] = part.split('=');
        if (k) params[k] = decodeURIComponent(v ?? '');
      }
      void this.router.navigate([p], { queryParams: params });
    } else {
      void this.router.navigateByUrl(path);
    }
  }

  openHelp(): void {
    this.open.set(false);
    // Dispatch a custom event the HelpDrawer listens for, so we don't
    // hardwire a service dependency between the two.
    window.dispatchEvent(new CustomEvent('bcl:help-drawer:open'));
  }

  async switchAccount(id: string): Promise<void> {
    this.open.set(false);
    try {
      await firstValueFrom(
        this.http.post(
          '/api/auth/link-workspace/switch',
          { target_id: id },
          { withCredentials: true },
        ),
      );
      await this.auth.hydrate();
      void this.router.navigateByUrl('/');
    } catch {
      // Server keeps current workspace on failure — ignore.
    }
  }

  async signOut(): Promise<void> {
    this.open.set(false);
    try {
      await firstValueFrom(this.http.post('/api/auth/logout', {}, { withCredentials: true }));
    } catch {
      // Even if the network call fails, clear client state.
    }
    await this.auth.signOut();
    window.location.href = '/login';
  }
}
export const THEME_TOOLS_DASHBOARD_SURFACE = {
  surface: 'account-menu-component',
  pillars: FIELD_SERVICE_PLATFORM_PILLARS.length,
} as const;
