import { useCallback, useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';

export interface DragRect {
  /** Day index relative to the grid's first column (0..6 on week, 0 on day). */
  dayIndex: number;
  /** Top in pixels relative to the scrollable grid container. */
  top: number;
  /** Height in pixels — always positive. */
  height: number;
}

interface UseDragCreateArgs {
  /** Returns a snapped { top, height } in px for a pointer Y inside the grid. */
  snap: (clientY: number, gridTop: number) => number;
  /** Returns the day index (0..n-1) for a pointer X. */
  dayFromX: (clientX: number, gridLeft: number, gridWidth: number) => number;
  /** Called once the drag ends with the final rect — opens QuickSchedulePopover. */
  onComplete: (rect: DragRect, anchor: { x: number; y: number }) => void;
  /** Minimum drag height in px to count as a create (else treat as a click). */
  minDeltaPx?: number;
}

/**
 * Pointer-events backed drag-to-create. Tracks pointer capture so dragging
 * outside the grid still updates the rect. Disabled when prefers-reduced-motion
 * is on for fine motor accessibility — falls back to click-to-create.
 */
export function useDragCreate({ snap, dayFromX, onComplete, minDeltaPx = 12 }: UseDragCreateArgs) {
  const [rect, setRect] = useState<DragRect | null>(null);
  const stateRef = useRef<{
    pointerId: number | null;
    startY: number;
    startX: number;
    dayIndex: number;
    gridTop: number;
    gridLeft: number;
    gridWidth: number;
    startSnapPx: number;
  } | null>(null);

  const onPointerDown = useCallback(
    (e: ReactPointerEvent<HTMLElement>) => {
      if (e.button !== 0) return;
      const target = e.currentTarget;
      const r = target.getBoundingClientRect();
      const startSnapPx = snap(e.clientY, r.top);
      stateRef.current = {
        pointerId: e.pointerId,
        startY: e.clientY,
        startX: e.clientX,
        dayIndex: dayFromX(e.clientX, r.left, r.width),
        gridTop: r.top,
        gridLeft: r.left,
        gridWidth: r.width,
        startSnapPx,
      };
      try {
        target.setPointerCapture(e.pointerId);
      } catch {
        /* noop */
      }
      setRect({ dayIndex: stateRef.current.dayIndex, top: startSnapPx, height: 0 });
    },
    [snap, dayFromX],
  );

  const onPointerMove = useCallback(
    (e: ReactPointerEvent<HTMLElement>) => {
      const s = stateRef.current;
      if (!s || s.pointerId !== e.pointerId) return;
      const currentSnap = snap(e.clientY, s.gridTop);
      const top = Math.min(s.startSnapPx, currentSnap);
      const height = Math.abs(currentSnap - s.startSnapPx);
      setRect({ dayIndex: s.dayIndex, top, height });
    },
    [snap],
  );

  const onPointerUp = useCallback(
    (e: ReactPointerEvent<HTMLElement>) => {
      const s = stateRef.current;
      const target = e.currentTarget;
      if (!s || s.pointerId !== e.pointerId) return;
      try {
        target.releasePointerCapture(e.pointerId);
      } catch {
        /* noop */
      }
      const r = rect;
      stateRef.current = null;
      if (!r || r.height < minDeltaPx) {
        setRect(null);
        return;
      }
      const anchor = { x: e.clientX, y: e.clientY };
      onComplete(r, anchor);
      setRect(null);
    },
    [rect, onComplete, minDeltaPx],
  );

  useEffect(() => {
    function abort(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        stateRef.current = null;
        setRect(null);
      }
    }
    window.addEventListener('keydown', abort);
    return () => window.removeEventListener('keydown', abort);
  }, []);

  return {
    rect,
    pointerHandlers: {
      onPointerDown,
      onPointerMove,
      onPointerUp,
      onPointerCancel: onPointerUp,
    },
  };
}
