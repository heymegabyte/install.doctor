/**
 * Exit-intent navigation guard (shared by every exit-intent surface).
 *
 * `visibilitychange → hidden` fires both when a visitor genuinely leaves (tab
 * switch / browser close) AND when they click an internal link or submit a form
 * to move DEEPER into the funnel. The latter is a conversion signal, not a
 * bounce. Treating it as exit-intent:
 *   1. burns the one-per-session rescue on the exact high-intent visitor who is
 *      advancing (e.g. homepage → /book),
 *   2. fires a wasted AI exit-rescue call that aborts on navigation, and
 *   3. starves that visitor of a GENUINE rescue on /book — where the offer
 *      would actually matter — because the one-shot is already spent.
 *
 * This module lets exit surfaces ignore a `hidden` event that immediately
 * follows an internal forward-navigation click, so the rescue fires only on
 * real bounces.
 */

/** Window (ms) after an internal-nav click during which a `hidden` event is a navigation, not a bounce. */
export const INTERNAL_NAV_SUPPRESS_MS = 1_500;

/** Facts about the nearest actionable ancestor of a click target. */
export interface NavClickInfo {
  /** Tag of the nearest actionable ancestor, or `null` if the click hit no link/button. */
  readonly tag: 'a' | 'button' | null;
  /** For an `<a>`: its raw `href` attribute. */
  readonly href?: string | null;
  /** For an `<a>`: its `target` attribute (`_blank` etc. = opens elsewhere). */
  readonly target?: string | null;
  /** For an `<a>`: whether it carries a `download` attribute. */
  readonly download?: boolean;
  /** For a `<button>`/`<input>`: whether it submits a form. */
  readonly submits?: boolean;
}

/**
 * True when a click described by `info` moves the visitor forward through the
 * site — an internal `<a href>` (relative or same-origin, same tab, not a
 * download / mailto / tel / sms / hash / pseudo-scheme) or a form-submit
 * control. These are conversions; a `hidden` event right after one is a
 * navigation, NOT a bounce.
 */
export function isInternalForwardNav(info: NavClickInfo, origin: string): boolean {
  if (info.tag === 'a') {
    const href = info.href ?? '';
    if (!href) return false;
    // A new tab/window means the visitor is leaving the CURRENT page either way.
    if (info.target && info.target !== '_self') return false;
    if (info.download) return false;
    if (href.startsWith('#')) return false; // same-page anchor — no navigation
    if (/^(mailto:|tel:|sms:)/i.test(href)) return false;
    if (href.startsWith('//')) {
      // Protocol-relative — resolve against https to compare origins.
      try {
        return new URL(`https:${href}`).origin === origin;
      } catch {
        return false;
      }
    }
    if (href.startsWith('/')) return true; // root-relative path → internal
    if (/^https?:\/\//i.test(href)) {
      try {
        return new URL(href).origin === origin;
      } catch {
        return false;
      }
    }
    // Bare relative ("book", "./x") is internal; any other scheme (javascript:, data:) is not.
    return !/^[a-z][a-z0-9+.-]*:/i.test(href);
  }
  if (info.tag === 'button') return Boolean(info.submits);
  return false;
}

/** True when `now` is within the suppression window after the last internal-nav click. */
export function isWithinNavWindow(lastNavAt: number, now: number): boolean {
  return now - lastNavAt < INTERNAL_NAV_SUPPRESS_MS;
}

/** Walk up from a click target to the nearest actionable ancestor and read its nav facts. */
export function extractNavInfo(start: EventTarget | null): NavClickInfo {
  let el = start instanceof Element ? start : null;
  for (let hops = 0; el && hops < 8; el = el.parentElement, hops++) {
    const tag = el.tagName.toLowerCase();
    if (tag === 'a') {
      const anchor = el as HTMLAnchorElement;
      return {
        tag: 'a',
        href: anchor.getAttribute('href'),
        target: anchor.getAttribute('target'),
        download: anchor.hasAttribute('download'),
      };
    }
    if (tag === 'button') {
      const button = el as HTMLButtonElement;
      const explicitType = button.getAttribute('type');
      const submits = explicitType === 'submit' || (!explicitType && Boolean(button.closest('form')));
      return { tag: 'button', submits };
    }
    if (tag === 'input' && (el as HTMLInputElement).type === 'submit') {
      return { tag: 'button', submits: true };
    }
  }
  return { tag: null };
}

/**
 * Binds capture-phase pointer/click listeners that record the timestamp of the
 * last internal forward-navigation click, and exposes `recentlyNavigated()`.
 * `now` is injectable for tests. Returns a `cleanup()` to unbind.
 */
export function createInternalNavWatcher(now: () => number = () => Date.now()): {
  recentlyNavigated: (at?: number) => boolean;
  cleanup: () => void;
} {
  let lastNavAt = Number.NEGATIVE_INFINITY;
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const onClick = (e: Event): void => {
    if (isInternalForwardNav(extractNavInfo(e.target), origin)) lastNavAt = now();
  };
  if (typeof document !== 'undefined') {
    // Capture phase + pointerdown so we record intent even when a click handler
    // calls preventDefault and routes the navigation via JS.
    document.addEventListener('pointerdown', onClick, true);
    document.addEventListener('click', onClick, true);
  }
  return {
    recentlyNavigated: (at: number = now()): boolean => isWithinNavWindow(lastNavAt, at),
    cleanup: (): void => {
      if (typeof document !== 'undefined') {
        document.removeEventListener('pointerdown', onClick, true);
        document.removeEventListener('click', onClick, true);
      }
    },
  };
}
