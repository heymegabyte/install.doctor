/**
 * offline-queue.ts — Wave 23
 *
 * Tiny IndexedDB wrapper for offline-tolerant POSTs. When the page goes
 * offline (or a fetch times out), we drop the payload into one of two
 * stores in the `bcl-queue` database and register a Background Sync tag
 * so the service worker drains it once connectivity returns.
 *
 * Stores:
 *   - 'offers' — queued gig accept/decline responses ({ gigId, action })
 *   - 'gps'    — queued crew GPS pings ({ lat, lng, accuracy, ts, gigId })
 *
 * Hand-rolled (no idb-keyval / Dexie dep) — promises wrapped around the
 * raw IDBRequest event model. Mirrors the SW-side schema declared in
 * public/sw.js so both producer (this file) and consumer (sw.js) agree
 * on store names + keyPath.
 */

const DB_NAME = 'bcl-queue';
const DB_VERSION = 1;
const STORE_OFFERS = 'offers';
const STORE_GPS = 'gps';

export interface OfferResponsePayload {
  gigId: string;
  action: 'accept' | 'decline';
  queuedAt?: number;
}

export interface GpsPingPayload {
  lat: number;
  lng: number;
  accuracy?: number;
  ts?: number;
  gigId?: string;
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB unavailable'));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_GPS)) {
        db.createObjectStore(STORE_GPS, { keyPath: 'id', autoIncrement: true });
      }
      if (!db.objectStoreNames.contains(STORE_OFFERS)) {
        db.createObjectStore(STORE_OFFERS, { keyPath: 'id', autoIncrement: true });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function addRecord(storeName: string, record: Record<string, unknown>): Promise<boolean> {
  try {
    const db = await openDb();
    return await new Promise<boolean>((resolve) => {
      const tx = db.transaction(storeName, 'readwrite');
      tx.objectStore(storeName).add(record);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
      tx.onabort = () => resolve(false);
    });
  } catch {
    return false;
  }
}

async function getAllRecords<T>(storeName: string): Promise<Array<T & { id: number }>> {
  try {
    const db = await openDb();
    return await new Promise((resolve) => {
      const tx = db.transaction(storeName, 'readonly');
      const req = tx.objectStore(storeName).getAll();
      req.onsuccess = () => resolve((req.result || []) as Array<T & { id: number }>);
      req.onerror = () => resolve([]);
    });
  } catch {
    return [];
  }
}

async function deleteRecord(storeName: string, id: number): Promise<boolean> {
  try {
    const db = await openDb();
    return await new Promise<boolean>((resolve) => {
      const tx = db.transaction(storeName, 'readwrite');
      tx.objectStore(storeName).delete(id);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
      tx.onabort = () => resolve(false);
    });
  } catch {
    return false;
  }
}

export interface OfflineQueueDrainerDependencies<T extends { id: number }> {
  readonly read: () => Promise<readonly T[]>;
  readonly deliver: (record: T) => Promise<boolean>;
  readonly remove: (id: number) => Promise<boolean>;
  readonly compare?: (left: T, right: T) => number;
}

/**
 * Build a deterministic, single-flight queue drain. Concurrent reconnect and
 * Background Sync signals share one promise, so they cannot submit the same
 * durable record twice from this page context. A server rejection, transport
 * error, or failed IndexedDB deletion stops the ordered pass immediately.
 */
export function createOfflineQueueDrainer<T extends { id: number }>(
  dependencies: OfflineQueueDrainerDependencies<T>,
): () => Promise<number> {
  let activeDrain: Promise<number> | null = null;
  return () => {
    if (activeDrain) return activeDrain;
    const run = (async () => {
      const records = [...(await dependencies.read())];
      records.sort(dependencies.compare ?? ((left, right) => left.id - right.id));
      let drained = 0;
      for (const record of records) {
        try {
          if (!(await dependencies.deliver(record))) break;
          if (!(await dependencies.remove(record.id))) break;
          drained += 1;
        } catch {
          break;
        }
      }
      return drained;
    })();
    activeDrain = run.finally(() => {
      activeDrain = null;
    });
    return activeDrain;
  };
}

async function registerSync(tag: string): Promise<void> {
  if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) return;
  try {
    const reg = await navigator.serviceWorker.ready;
    const syncManager = (reg as unknown as { sync?: { register: (t: string) => Promise<void> } })
      .sync;
    if (syncManager) await syncManager.register(tag);
  } catch {
    /* Background Sync unsupported (Safari, Firefox) — drain on next page load instead */
  }
}

/** Enqueue an Accept/Decline response for the crew's offline-tolerant flow. */
export async function enqueueOfferResponse(payload: OfferResponsePayload): Promise<boolean> {
  const ok = await addRecord(STORE_OFFERS, {
    ...payload,
    queuedAt: payload.queuedAt ?? Date.now(),
  });
  if (ok) await registerSync('accept-flush');
  return ok;
}

/** Enqueue a GPS ping for crews moving through cell-signal dead zones. */
export async function enqueueGpsPing(payload: GpsPingPayload): Promise<boolean> {
  const ok = await addRecord(STORE_GPS, { ...payload, ts: payload.ts ?? Date.now() });
  if (ok) await registerSync('gps-flush');
  return ok;
}

const drainOffers = createOfflineQueueDrainer<OfferResponsePayload & { id: number }>({
  read: () => getAllRecords<OfferResponsePayload>(STORE_OFFERS),
  compare: (left, right) =>
    (left.queuedAt ?? 0) - (right.queuedAt ?? 0) || left.id - right.id,
  deliver: async (record) => {
    const response = await fetch('/api/gig/respond', {
        method: 'POST',
        credentials: 'include',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ gigId: record.gigId, action: record.action }),
      });
    return response.ok;
  },
  remove: (id) => deleteRecord(STORE_OFFERS, id),
});

/** Drain the offers queue from the main thread (fallback for browsers without Background Sync). */
export function drainOfferQueue(): Promise<number> {
  return drainOffers();
}

const drainGps = createOfflineQueueDrainer<GpsPingPayload & { id: number }>({
  read: () => getAllRecords<GpsPingPayload>(STORE_GPS),
  compare: (left, right) => (left.ts ?? 0) - (right.ts ?? 0) || left.id - right.id,
  deliver: async (record) => {
    const response = await fetch('/api/work/gps/ping', {
        method: 'POST',
        credentials: 'include',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(record),
      });
    return response.ok;
  },
  remove: (id) => deleteRecord(STORE_GPS, id),
});

/** Drain the GPS queue from the main thread. */
export function drainGpsQueue(): Promise<number> {
  return drainGps();
}
