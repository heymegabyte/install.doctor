/**
 * fire-169 — derive an HONEST, actionable error message for a failed `/book`
 * submit (single-day AND each multi-day leg).
 *
 * The worker returns JSON envelopes for its own errors — 400 validation + 429
 * rate-limit carry a user-facing `{ok:false, message}`; an unhandled 500 returns
 * `{error:'Internal server error', code, requestId}` (note: `error`, NOT
 * `message`, and NO `ok`). CF-edge failures (502/503/520/524) and a dropped
 * connection return non-JSON (or make `res.json()` throw). The old client read
 * only `data.message ?? 'Something went wrong'`, so a 500 showed a generic
 * string AND silently discarded its `requestId` (the one token support can trace
 * in the logs), and a non-JSON 5xx threw into the generic catch.
 *
 * Rule: a server-provided USER-FACING `message` (already friendly — "Pick a date
 * in the future.", "Too many requests…") wins verbatim. Otherwise fall back to a
 * friendly, actionable, status-specific message and append the `requestId` when
 * the server gave us one.
 */
export interface SubmitErrorBody {
  readonly ok?: boolean;
  readonly message?: string;
  readonly error?: string;
  readonly requestId?: string;
}

const PHONE = '(855) 82LABOR';

/** Friendly, actionable fallback when the server gave no user-facing `message`. */
function statusFallback(status: number): string {
  if (status === 0) return `Network error — check your connection and try again, or call ${PHONE}.`;
  if (status === 429) return 'Too many requests — wait a minute and try again.';
  if (status >= 500 || status === 0)
    return `Server hiccup on our end — your booking didn’t go through. Try again, or call ${PHONE}.`;
  return `Something went wrong — try again, or call ${PHONE}.`;
}

/**
 * @param status HTTP status (use 0 for a thrown fetch / network failure)
 * @param body   the parsed JSON envelope, or null when the response wasn't JSON
 */
export function bookingSubmitError(status: number, body: SubmitErrorBody | null | undefined): string {
  const userMsg = typeof body?.message === 'string' ? body.message.trim() : '';
  if (userMsg) return userMsg; // a server-provided, already-friendly message wins
  const base = statusFallback(status);
  const ref = typeof body?.requestId === 'string' ? body.requestId.trim() : '';
  return ref ? `${base} (ref: ${ref})` : base;
}
