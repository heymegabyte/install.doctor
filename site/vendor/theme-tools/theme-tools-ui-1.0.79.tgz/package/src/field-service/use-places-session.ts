/**
 * usePlacesSession — Places API session token management for Booking.tsx.
 *
 * Extracted from the inline useRef + ensureSession pattern.
 * Google bills one autocomplete+details lookup per session token,
 * so each address field gets its own rolling token.
 */
import { useRef, useCallback } from 'react';

export function usePlacesSession() {
  const ref = useRef('');

  const ensure = useCallback(() => {
    if (!ref.current) ref.current = crypto.randomUUID();
    return ref.current;
  }, []);

  /** Rotate the session token after a place is selected (Google billing boundary). */
  const rotate = useCallback(() => {
    ref.current = '';
  }, []);

  return { ensure, rotate };
}
