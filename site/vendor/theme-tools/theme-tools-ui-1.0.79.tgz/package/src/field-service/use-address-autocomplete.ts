/**
 * useAddressAutocomplete — address + business autocomplete for Booking.tsx.
 *
 * Extracted from the inline useEffect + useState patterns. Encapsulates:
 * - Address query state + suggestions + loading/error states
 * - Business name query state + suggestions
 * - Session token management (Google Places billing boundary)
 * - Debounced fetch effects
 *
 * Does NOT render JSX — the caller owns the input + suggestion list markup.
 */
import { useState, useEffect, useRef, useCallback } from 'react';

interface PlaceSuggestion {
  placeId: string;
  primary: string;
  secondary: string;
}

interface PlaceDetailsResult {
  ok: boolean;
  message?: string;
  place?: {
    id: string;
    formatted: string;
    street: string;
    city: string;
    state: string;
    zip: string;
    lat?: number;
    lng?: number;
    name: string;
    phone: string;
    website: string;
    isBusiness: boolean;
  };
}

interface UseAddressAutocompleteProps {
  /** Pre-filled initial address value */
  initialQuery?: string;
  /** When true, skip all fetches (Places API unavailable) */
  disabled?: boolean;
}

export function useAddressAutocomplete(props: UseAddressAutocompleteProps = {}) {
  const { initialQuery = '', disabled = false } = props;

  const [addressQuery, setAddressQuery] = useState(initialQuery);
  const [addressSuggestions, setAddressSuggestions] = useState<PlaceSuggestion[]>([]);
  const [addressLoading, setAddressLoading] = useState(false);
  const [addressError, setAddressError] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [addressFocused, setAddressFocused] = useState(false);
  const [activeSuggestion, setActiveSuggestion] = useState(-1);
  const placesSessionRef = useRef('');

  const ensureSession = useCallback(() => {
    if (!placesSessionRef.current) placesSessionRef.current = crypto.randomUUID();
    return placesSessionRef.current;
  }, []);

  const [businessSuggestions, setBusinessSuggestions] = useState<PlaceSuggestion[]>([]);
  const [businessLoading, setBusinessLoading] = useState(false);
  const [businessError, setBusinessError] = useState('');
  const [showBusinessSuggestions, setShowBusinessSuggestions] = useState(false);
  const [businessFocused, setBusinessFocused] = useState(false);
  const [activeBusinessSuggestion, setActiveBusinessSuggestion] = useState(-1);
  const businessSessionRef = useRef('');

  const ensureBusinessSession = useCallback(() => {
    if (!businessSessionRef.current) businessSessionRef.current = crypto.randomUUID();
    return businessSessionRef.current;
  }, []);

  // ── Address autocomplete fetch ──
  const [isDisabled, setIsDisabled] = useState(disabled);

  useEffect(() => {
    const q = addressQuery.trim();
    if (q.length < 3 || isDisabled || disabled) {
      setAddressSuggestions([]);
      setAddressLoading(false);
      return;
    }
    let cancelled = false;
    const controller = new AbortController();
    setAddressLoading(true);
    setAddressError('');
    const t = setTimeout(() => {
      fetch(`/api/places/autocomplete?q=${encodeURIComponent(q)}&session=${encodeURIComponent(ensureSession())}`, {
        signal: controller.signal,
      })
        .then(async (r) => {
          const json = await r.json() as { ok: boolean; suggestions?: PlaceSuggestion[]; message?: string; disabled?: boolean };
          if (cancelled) return;
          if (json.disabled) { setIsDisabled(true); setAddressSuggestions([]); return; }
          if (!json.ok) {
            setAddressSuggestions([]);
            if (json.message === 'rate-limited') setAddressError('Too many lookups — try again in a moment.');
            return;
          }
          setAddressSuggestions(json.suggestions ?? []);
        })
        .catch(() => { if (!cancelled) setAddressSuggestions([]); })
        .finally(() => { if (!cancelled) setAddressLoading(false); });
    }, 220);
    return () => {
      cancelled = true;
      clearTimeout(t);
      controller.abort();
    };
  }, [addressQuery, isDisabled, disabled, ensureSession]);

  // ── Business name autocomplete ──
  const [businessName, setBusinessName] = useState('');

  useEffect(() => {
    const q = businessName.trim();
    if (q.length < 3 || isDisabled || disabled) { setBusinessSuggestions([]); return; }
    let cancelled = false;
    const controller = new AbortController();
    setBusinessLoading(true);
    setBusinessError('');
    const t = setTimeout(() => {
      fetch(`/api/places/autocomplete?q=${encodeURIComponent(q)}&mode=business&session=${encodeURIComponent(ensureBusinessSession())}`, {
        signal: controller.signal,
      })
        .then(async (r) => {
          const json = await r.json() as { ok: boolean; suggestions?: PlaceSuggestion[]; message?: string; disabled?: boolean };
          if (cancelled) return;
          if (json.disabled) { setIsDisabled(true); setBusinessSuggestions([]); return; }
          if (!json.ok) { setBusinessSuggestions([]); return; }
          setBusinessSuggestions(json.suggestions ?? []);
        })
        .catch(() => { if (!cancelled) setBusinessSuggestions([]); })
        .finally(() => { if (!cancelled) setBusinessLoading(false); });
    }, 220);
    return () => {
      cancelled = true;
      clearTimeout(t);
      controller.abort();
    };
  }, [businessName, isDisabled, disabled, ensureBusinessSession]);

  // ── Place selection handler ──
  const selectAddressSuggestion = useCallback(async (s: PlaceSuggestion) => {
    setAddressQuery(s.primary + (s.secondary ? `, ${s.secondary}` : ''));
    setAddressSuggestions([]);
    setShowSuggestions(false);
    setActiveSuggestion(0);
    try {
      const r = await fetch(`/api/places/details?place_id=${encodeURIComponent(s.placeId)}&session=${encodeURIComponent(ensureSession())}`);
      const json = await r.json() as PlaceDetailsResult;
      if (json.ok && json.place) {
        return json.place;
      }
    } catch { /* swallow */ }
    placesSessionRef.current = ''; // rotate session
    return null;
  }, [ensureSession]);

  const selectBusinessSuggestion = useCallback(async (s: PlaceSuggestion) => {
    setBusinessName(s.primary);
    setBusinessSuggestions([]);
    setShowBusinessSuggestions(false);
    setActiveBusinessSuggestion(0);
    try {
      const r = await fetch(`/api/places/details?place_id=${encodeURIComponent(s.placeId)}&session=${encodeURIComponent(ensureBusinessSession())}`);
      const json = await r.json() as PlaceDetailsResult;
      if (json.ok && json.place) {
        return { name: json.place.name, phone: json.place.phone, website: json.place.website, address: json.place, formatted: json.place.formatted };
      }
    } catch { /* swallow */ }
    businessSessionRef.current = '';
    return null;
  }, [ensureBusinessSession]);

  // ── Keyboard navigation ──
  const handleAddressKeyDown = useCallback((e: React.KeyboardEvent, listLength: number, onSelect: (idx: number) => void) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setActiveSuggestion((p) => Math.min(p + 1, listLength - 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActiveSuggestion((p) => Math.max(p - 1, 0)); }
    else if (e.key === 'Enter' && activeSuggestion >= 0 && activeSuggestion < listLength) {
      e.preventDefault();
      onSelect(activeSuggestion);
    } else if (e.key === 'Escape') { setShowSuggestions(false); setActiveSuggestion(-1); }
  }, [activeSuggestion]);

  const handleBusinessKeyDown = useCallback((e: React.KeyboardEvent, listLength: number, onSelect: (idx: number) => void) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setActiveBusinessSuggestion((p) => Math.min(p + 1, listLength - 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActiveBusinessSuggestion((p) => Math.max(p - 1, 0)); }
    else if (e.key === 'Enter' && activeBusinessSuggestion >= 0 && activeBusinessSuggestion < listLength) {
      e.preventDefault();
      onSelect(activeBusinessSuggestion);
    } else if (e.key === 'Escape') { setShowBusinessSuggestions(false); setActiveBusinessSuggestion(-1); }
  }, [activeBusinessSuggestion]);

  return {
    // Address
    addressQuery, setAddressQuery,
    addressSuggestions, addressLoading, addressError,
    showSuggestions, setShowSuggestions,
    addressFocused, setAddressFocused,
    activeSuggestion, setActiveSuggestion,
    isDisabled,
    selectAddressSuggestion,
    handleAddressKeyDown,
    // Business
    businessName, setBusinessName,
    businessSuggestions, businessLoading, businessError,
    showBusinessSuggestions, setShowBusinessSuggestions,
    businessFocused, setBusinessFocused,
    activeBusinessSuggestion, setActiveBusinessSuggestion,
    selectBusinessSuggestion,
    handleBusinessKeyDown,
  };
}
