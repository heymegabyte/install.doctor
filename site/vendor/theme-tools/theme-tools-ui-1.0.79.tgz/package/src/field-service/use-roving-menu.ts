import { useEffect, useRef, useState } from 'react';
import type { KeyboardEvent } from 'react';
import { nextMenuIndex } from "./menu-keynav.js";
import { rovingTabIndex } from "./radio-keynav.js";

/**
 * Props a single `role="menuitem"` spreads onto its `<button>`/`<a>` to satisfy
 * the ARIA roving-tabindex menu keyboard contract.
 */
export interface RovingMenuItemProps {
  ref: (el: HTMLElement | null) => void;
  tabIndex: 0 | -1;
  onKeyDown: (e: KeyboardEvent<HTMLElement>) => void;
}

/**
 * React adapter over the pure `menu-keynav` helper. A custom `role="menu"` whose
 * items are `onClick`-only `<button role="menuitem">`/`<a role="menuitem">` rows
 * FAILS the ARIA Authoring Practices menu pattern: every item is independently
 * Tab-focusable and arrows do nothing. axe-core cannot detect this
 * interaction-pattern gap, so it shipped green across the account menu
 * (UserAvatarMenu) and the add-to-calendar dropdown even though the radiogroup
 * twin was fixed earlier.
 *
 * Call once per menu at component top with the total menuitem count + the menu's
 * open state; spread the returned getter on each item, indexed in DOM order. The
 * menu becomes a single tab stop (only the active item is focusable), focus moves
 * to the first item when the menu opens (APG), and ArrowDown/ArrowUp/Home/End
 * move focus, wrapping at the ends. ArrowLeft/ArrowRight/Tab/Enter pass through.
 *
 * @param count - Total menuitems in the menu (≥ 1).
 * @param open - Whether the menu is currently open (drives focus-to-first on open).
 * @returns A getter `(index) => props` to spread on each menuitem.
 * @example
 * const item = useRovingMenu(3, open);
 * // <button role="menuitem" {...item(0)}>Apple</button>
 * // <button role="menuitem" {...item(1)}>Google</button>
 */
export function useRovingMenu(
  count: number,
  open: boolean,
): (index: number) => RovingMenuItemProps {
  const refs = useRef<(HTMLElement | null)[]>([]);
  const [active, setActive] = useState(0);

  // APG menu pattern: when the menu opens, reset to the first item and move
  // focus there so arrow keys work immediately without a manual Tab into it.
  useEffect(() => {
    if (!open) {
      setActive(0);
      return;
    }
    const id =
      typeof requestAnimationFrame === 'function'
        ? requestAnimationFrame(() => refs.current[0]?.focus())
        : null;
    return () => {
      if (id !== null) cancelAnimationFrame(id);
    };
  }, [open]);

  return (index) => ({
    ref: (el) => {
      refs.current[index] = el;
    },
    tabIndex: rovingTabIndex(index === active),
    onKeyDown: (e) => {
      const target = nextMenuIndex(index, count, e.key);
      if (target === null) return;
      e.preventDefault();
      setActive(target);
      refs.current[target]?.focus();
    },
  });
}
