export interface GoogleMapsMapTypeStyle {
  elementType?: string;
  featureType?: string;
  stylers: Array<Record<string, string>>;
}
export interface GoogleMapsNamespace {
  maps?: unknown;
}
// Shared Google Maps JS SDK loader. Extracted from MapInner so every map
// surface (coverage map, live Job map) loads the SDK exactly once per page and
// shares the same brand-dark style + Map-ID handling.
//
// The config (key + optional Cloud Map ID) comes from `/api/maps/config`,
// which prefers the browser-restricted GOOGLE_MAPS_BROWSER_KEY.

export interface MapsConfig {
  ok: boolean;
  apiKey: string;
  mapId: string;
}

// Brand-aligned dark map styling (used when no Cloud Map ID is configured).
// Mirrors MapInner's palette so both maps look identical.
export const DARK_MAP_STYLES: GoogleMapsMapTypeStyle[] = [
  { elementType: 'geometry', stylers: [{ color: '#0a0e14' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#6f7886' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#0a0e14' }] },
  { featureType: 'administrative.land_parcel', elementType: 'labels', stylers: [{ visibility: 'off' }] },
  { featureType: 'administrative.locality', elementType: 'labels.text.fill', stylers: [{ color: '#a8b0bd' }] },
  { featureType: 'poi', elementType: 'geometry', stylers: [{ color: '#11151c' }] },
  { featureType: 'poi', elementType: 'labels', stylers: [{ visibility: 'off' }] },
  { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#0f1a14' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#1a1f29' }] },
  { featureType: 'road', elementType: 'labels.icon', stylers: [{ visibility: 'off' }] },
  { featureType: 'road.arterial', elementType: 'geometry', stylers: [{ color: '#1f2530' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#2b323d' }] },
  { featureType: 'road.highway', elementType: 'geometry.stroke', stylers: [{ color: '#0a0e14' }] },
  { featureType: 'road.highway', elementType: 'labels.text.fill', stylers: [{ color: '#8a93a3' }] },
  { featureType: 'road.local', elementType: 'labels.text.fill', stylers: [{ color: '#5a6272' }] },
  { featureType: 'transit', elementType: 'labels', stylers: [{ visibility: 'off' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#04060a' }] },
  { featureType: 'water', elementType: 'labels.text.fill', stylers: [{ color: '#2a3a4a' }] },
];

let sdkPromise: Promise<GoogleMapsNamespace> | null = null;
let configPromise: Promise<MapsConfig> | null = null;

/** Fetch + cache the Maps config from the worker (once per page load). */
export function fetchMapsConfig(): Promise<MapsConfig> {
  if (configPromise) return configPromise;
  configPromise = fetch('/api/maps/config')
    .then((r) => r.json() as Promise<MapsConfig>)
    .catch(() => ({ ok: false, apiKey: '', mapId: '' }));
  return configPromise;
}

/** Load the Google Maps JS SDK (with the marker library) exactly once. */
export function loadGoogleMaps(apiKey: string): Promise<GoogleMapsNamespace> {
  if (typeof window !== 'undefined' && (window as unknown as { google: GoogleMapsNamespace }).google?.maps) {
    return Promise.resolve((window as unknown as { google: GoogleMapsNamespace }).google);
  }
  if (sdkPromise) return sdkPromise;
  sdkPromise = new Promise((resolve, reject) => {
    const cbName = `__bcl_gmaps_cb_${Math.floor(performance.now())}`;
    (window as unknown as Record<string, unknown>)[cbName] = () => {
      delete (window as unknown as Record<string, unknown>)[cbName];
      resolve((window as unknown as { google: GoogleMapsNamespace }).google);
    };
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(apiKey)}&v=weekly&loading=async&libraries=marker&callback=${cbName}`;
    script.async = true;
    script.defer = true;
    script.onerror = () => reject(new Error('gmaps-load-failed'));
    document.head.appendChild(script);
  });
  return sdkPromise;
}

/** Format ETA seconds → "7 min" / "1 hr 5 min". */
export function formatEta(seconds: number): string {
  const mins = Math.max(1, Math.round(seconds / 60));
  if (mins < 60) return `${mins} min`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m ? `${h} hr ${m} min` : `${h} hr`;
}

/** Format meters → "0.5 mi" / "850 ft". */
export function formatDistance(meters: number): string {
  const miles = meters / 1609.344;
  if (miles >= 0.1) return `${miles.toFixed(1)} mi`;
  return `${Math.round(meters * 3.28084)} ft`;
}
