import { useThemeToolsSurface } from '../../field-service-primitives.js';
interface Props {
  /** A human address / place query (e.g. "123 Main St, Newark, NJ"). */
  readonly address: string;
  readonly className?: string;
  /** Tailwind height class for the map frame (default h-44 ≈ 176px). */
  readonly heightClass?: string;
}

// Stylish, keyless Google Maps panel for any address surface. Uses the classic
// `maps.google.com/maps?q=…&output=embed` iframe — NO API key required (this repo
// runs keyless for Google) — framed on-brand: brand border + gradient top-accent,
// a muted grayscale filter that colorises on hover, and a bottom scrim with a pin
// badge + the address. Frame-src is allowed for www.google.com/maps.google.com in
// the worker CSP + public/_headers. Prefer this on every page that shows a place.
export function AddressMap({ address, className = '', heightClass = 'h-44' }: Props) {
  useThemeToolsSurface('address-map');
  const q = encodeURIComponent(address.trim());
  if (!q) return null;
  const src = `https://maps.google.com/maps?q=${q}&z=15&hl=en&output=embed`;
  return (
    <div
      data-testid="address-map"
      className={`group relative overflow-hidden rounded-xl border border-brand-line bg-bg-elevated shadow-[0_12px_34px_-18px_rgba(0,0,0,0.75)] ${className}`}
    >
      {/* Subtle brand backdrop + pin glyph shown BEHIND the iframe so a slow tile
          load never flashes as a black void — the map paints over it on arrival. */}
      <div
        className="pointer-events-none absolute inset-0 flex items-center justify-center bg-[radial-gradient(circle_at_50%_40%,rgba(255,107,26,0.08),transparent_70%)]"
        aria-hidden
      >
        <svg viewBox="0 0 24 24" className="h-8 w-8 text-brand-line" fill="currentColor">
          <path d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z" />
        </svg>
      </div>
      <div
        className="pointer-events-none absolute inset-x-0 top-0 z-10 h-0.5 bg-gradient-to-r from-transparent via-brand-accent/70 to-transparent"
        aria-hidden
      />
      <iframe
        title={`Map showing ${address}`}
        src={src}
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
        className={`relative z-[1] block w-full ${heightClass} border-0 [filter:grayscale(0.3)_contrast(1.05)_brightness(0.92)] transition-[filter] duration-500 group-hover:[filter:none]`}
      />
      <div
        className="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex items-center gap-2 bg-gradient-to-t from-bg-primary/95 via-bg-primary/70 to-transparent px-3 pb-2.5 pt-7"
      >
        <span
          className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-brand-accent text-bg-primary shadow-[0_0_10px_-1px_rgba(255,107,26,0.7)]"
          aria-hidden
        >
          <svg viewBox="0 0 24 24" className="h-3 w-3" fill="currentColor">
            <path d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z" />
          </svg>
        </span>
        <span className="truncate text-xs font-semibold text-brand-ink">{address}</span>
      </div>
    </div>
  );
}
