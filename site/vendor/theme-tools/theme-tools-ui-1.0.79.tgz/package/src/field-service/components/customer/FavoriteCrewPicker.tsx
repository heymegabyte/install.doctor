import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useState } from 'react';

/**
 * Post-job tap-to-favorite UI. Mounted by the post-job flow (caller passes
 * the booking + crew roster). Each crew member shows a heart toggle; tapping
 * POSTs to `/api/loyalty/favorites` (wave-integration adds the route).
 *
 * Optimistic UI — the heart flips immediately; if the network call fails,
 * we revert and surface an inline error. Idempotent on the server side: a
 * second POST for the same (phone, crew) pair is a no-op.
 */

export interface CrewMember {
  readonly userId: string;
  readonly displayName: string;
  readonly photoUrl?: string;
}

interface Props {
  readonly bookingId: string;
  readonly crew: readonly CrewMember[];
  readonly onChange?: (favorites: readonly string[]) => void;
}

export function FavoriteCrewPicker({ bookingId, crew, onChange }: Props) {
  useThemeToolsSurface('favorite-crew-picker');
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [pending, setPending] = useState<Set<string>>(new Set());
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Probe current favorites — safe to call even if endpoint missing.
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/api/loyalty/favorites', { credentials: 'same-origin' });
        if (!res.ok || cancelled) return;
        const data = (await res.json()) as { favorites?: string[] };
        if (cancelled) return;
        if (Array.isArray(data.favorites)) setFavorites(new Set(data.favorites));
      } catch {
        /* swallow — empty set is fine */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const toggle = useCallback(
    async (member: CrewMember) => {
      if (pending.has(member.userId)) return;
      const wasFavorite = favorites.has(member.userId);

      // Optimistic update.
      const nextFav = new Set(favorites);
      if (wasFavorite) nextFav.delete(member.userId);
      else nextFav.add(member.userId);
      setFavorites(nextFav);
      setPending((prev) => new Set(prev).add(member.userId));
      setError(null);

      try {
        const res = await fetch('/api/loyalty/favorites', {
          method: wasFavorite ? 'DELETE' : 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ crewUserId: member.userId, bookingId }),
        });
        if (!res.ok) {
          // Revert.
          setFavorites(favorites);
          setError('Could not update favorite. Try again.');
          return;
        }
        onChange?.(Array.from(nextFav));
      } catch {
        setFavorites(favorites);
        setError('Network error. Try again.');
      } finally {
        setPending((prev) => {
          const next = new Set(prev);
          next.delete(member.userId);
          return next;
        });
      }
    },
    [bookingId, favorites, onChange, pending],
  );

  if (crew.length === 0) {
    return <p className="text-brand-mute text-sm">No crew roster on this job yet.</p>;
  }

  return (
    <section aria-label="Favorite crew members">
      <h3 className="text-base font-semibold">Tap to favorite your crew</h3>
      <p className="text-brand-mute mt-1 text-sm">
        Next time, we will try to dispatch the same team.
      </p>
      <ul className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {crew.map((member) => {
          const isFav = favorites.has(member.userId);
          const isPending = pending.has(member.userId);
          return (
            <li key={member.userId}>
              <button
                type="button"
                onClick={() => toggle(member)}
                aria-pressed={isFav}
                aria-label={`${isFav ? 'Unfavorite' : 'Favorite'} ${member.displayName}`}
                className={`group border-brand-line bg-brand-card flex w-full items-center gap-3 rounded-xl border p-3 text-left transition ${
                  isPending ? 'opacity-60' : 'hover:border-brand-accent'
                }`}
              >
                {member.photoUrl ? (
                  <img
                    src={member.photoUrl}
                    alt=""
                    width={40}
                    height={40}
                    className="rounded-full object-cover"
                  />
                ) : (
                  <div className="bg-brand-line h-10 w-10 rounded-full" aria-hidden="true" />
                )}
                <span className="flex-1 truncate text-sm font-medium">{member.displayName}</span>
                <span
                  className={`text-xl transition ${isFav ? 'text-red-400' : 'text-brand-mute group-hover:text-red-300'}`}
                  aria-hidden="true"
                >
                  {isFav ? '♥' : '♡'}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
      {error && <p className="mt-2 text-sm text-red-300" role="alert">{error}</p>}
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
