import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useMemo, useState } from 'react';

// Wave 21B — projected next-7-day earnings chart.
//
// Pulls accepted/invited gigs from `/api/work/gigs` and bins their pay by
// calendar day. Renders a simple inline SVG bar chart (no external chart
// dep) so it stays lightweight and prints cleanly in screen readers via
// the table fallback.

interface GigLite {
  start_at: string;
  worker_pay_cents_per_person: number;
  shift_lead_bonus_cents: number;
  rush_bonus_cents: number;
  claim_status: 'invited' | 'accepted' | 'confirmed' | 'checked_in';
}

interface GigsApiResponse {
  invites: GigLite[];
}

interface DayBucket {
  date: string;
  label: string;
  acceptedCents: number;
  potentialCents: number;
}

function dateKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function shortLabel(d: Date): string {
  return d.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric' });
}

export function EarningsForecast(): JSX.Element {
  useThemeToolsSurface('earnings-forecast');
  const [gigs, setGigs] = useState<GigLite[]>([]);
  const [busy, setBusy] = useState(true);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch('/api/work/gigs', {
          credentials: 'include',
          headers: { Accept: 'application/json' },
        });
        if (!res.ok) return;
        const j = (await res.json()) as GigsApiResponse;
        if (!cancelled) setGigs(j.invites ?? []);
      } catch {
        /* ignore */
      } finally {
        if (!cancelled) setBusy(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const buckets = useMemo<DayBucket[]>(() => {
    const out: DayBucket[] = [];
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    for (let i = 0; i < 7; i++) {
      const d = new Date(now.getTime() + i * 86_400_000);
      out.push({ date: dateKey(d), label: shortLabel(d), acceptedCents: 0, potentialCents: 0 });
    }
    for (const g of gigs) {
      const start = new Date(g.start_at);
      const k = dateKey(start);
      const bucket = out.find((b) => b.date === k);
      if (!bucket) continue;
      const pay =
        (g.worker_pay_cents_per_person ?? 0) +
        (g.shift_lead_bonus_cents ?? 0) +
        (g.rush_bonus_cents ?? 0);
      if (g.claim_status === 'invited') {
        bucket.potentialCents += pay;
      } else {
        bucket.acceptedCents += pay;
      }
    }
    return out;
  }, [gigs]);

  const max = useMemo(
    () => Math.max(1, ...buckets.map((b) => b.acceptedCents + b.potentialCents)),
    [buckets],
  );
  const totalAccepted = buckets.reduce((s, b) => s + b.acceptedCents, 0);
  const totalPotential = buckets.reduce((s, b) => s + b.potentialCents, 0);

  return (
    <section
      aria-label="Next 7 days forecast"
      className="rounded-2xl border border-brand-line bg-brand-card p-5"
    >
      <header className="mb-4 flex items-start justify-between gap-3">
        <div>
          <p className="eyebrow text-brand-accent mb-1">Next 7 days</p>
          <h3 className="text-lg font-extrabold text-brand-ink">Earnings forecast</h3>
          <p className="text-xs text-brand-mute mt-1">
            Accepted gigs + potential from open invites. Pay shown is per worker.
          </p>
        </div>
        <div className="text-right text-xs">
          <p className="text-brand-mute">Accepted</p>
          <p className="text-lg font-extrabold text-emerald-300">
            ${(totalAccepted / 100).toFixed(0)}
          </p>
          <p className="text-brand-mute mt-1">+ Potential</p>
          <p className="text-sm font-bold text-brand-ink">${(totalPotential / 100).toFixed(0)}</p>
        </div>
      </header>

      {busy ? (
        <p className="text-sm text-brand-mute">Loading…</p>
      ) : (
        <>
          <div className="grid grid-cols-7 gap-2 items-end h-32 mb-2">
            {buckets.map((b) => {
              const acceptedPct = (b.acceptedCents / max) * 100;
              const potentialPct = (b.potentialCents / max) * 100;
              return (
                <div key={b.date} className="flex flex-col items-center gap-1 h-full justify-end">
                  <div className="w-full flex flex-col-reverse h-full">
                    <div
                      className="w-full bg-emerald-400 rounded-t-sm"
                      style={{ height: `${acceptedPct}%` }}
                      aria-hidden="true"
                    />
                    <div
                      className="w-full bg-amber-300/60"
                      style={{ height: `${potentialPct}%` }}
                      aria-hidden="true"
                    />
                  </div>
                </div>
              );
            })}
          </div>
          <div className="grid grid-cols-7 gap-2 text-center text-[11px] text-brand-mute">
            {buckets.map((b) => (
              <span key={`l-${b.date}`}>{b.label}</span>
            ))}
          </div>
          <table className="sr-only">
            <caption>Earnings forecast by day</caption>
            <thead>
              <tr>
                <th>Day</th>
                <th>Accepted ($)</th>
                <th>Potential ($)</th>
              </tr>
            </thead>
            <tbody>
              {buckets.map((b) => (
                <tr key={`s-${b.date}`}>
                  <td>{b.label}</td>
                  <td>{(b.acceptedCents / 100).toFixed(2)}</td>
                  <td>{(b.potentialCents / 100).toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
