import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { PHONE_SMS_HREF, PHONE_DISPLAY } from '@theme.tools/i18n-a11y/field-service/contact-phone';

interface CancelByTextPromptProps {
  bookingRef: string;
}

/**
 * Compact inline prompt: "Need to cancel? Text CANCEL to (855) 82LABOR"
 * with a pre-filled SMS body. Always renders on active (non-terminal) bookings.
 * The customer texts CANCEL + their booking reference → the /api/sms-inbound
 * webhook handles the actual cancellation.
 */
export function CancelByTextPrompt({ bookingRef }: CancelByTextPromptProps) {
  useThemeToolsSurface('cancel-by-text-prompt');
  const smsHref = `${PHONE_SMS_HREF}?body=CANCEL%20${encodeURIComponent(bookingRef)}`;

  return (
    <div
      data-testid="cancel-by-text-prompt"
      className="border-l-2 border-brand-accent/50 pl-3 text-brand-mute text-xs"
    >
      <p>
        <span className="text-brand-ink font-semibold">Need to cancel?</span>{' '}
        <a
          href={smsHref}
          className="text-brand-accent underline-hover font-semibold"
        >
          Text CANCEL to {PHONE_DISPLAY}
        </a>
      </p>
    </div>
  );
}
