export { JsonLd, type JsonLdProps } from '../../../field-service-primitives.js';
