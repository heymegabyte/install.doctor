import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function DiscountHistory({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('discount-history');
  return (
    <GenericTable
      title="Discount + surge history"
      endpoint="/discount-history"
      adminKey={adminKey}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
