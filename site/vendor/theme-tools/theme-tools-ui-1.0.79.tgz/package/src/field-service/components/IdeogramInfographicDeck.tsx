import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { CollapsibleCitationsDrawer } from './CollapsibleCitationsDrawer.js';
import type {
  IdeogramInfographicSpec,
  LongFormPageAuthorityDossier,
  NostalgicLandmarkPhotoSpec,
  WikipediaTownHeritage,
} from '@theme.tools/seo-geo/field-service/matrix-3d-engine';

export interface IdeogramInfographicDeckProps {
  readonly town: WikipediaTownHeritage;
  readonly crewPhotos: readonly NostalgicLandmarkPhotoSpec[];
  readonly infographics: readonly IdeogramInfographicSpec[];
  readonly bookingUrl?: string;
  readonly mode?: 'photos-only' | 'charts-only' | 'all';
}

/**
 * Nostalgic Town Landmark Photography, Crew-Scenario Visuals & 4-Figure Ideogram
 * Technical Infographic Deck (`@theme.tools/ui/field-service/components/IdeogramInfographicDeck`).
 */
export function IdeogramInfographicDeck({
  town,
  crewPhotos,
  infographics,
  bookingUrl = 'https://bricklabor.com/book',
  mode = 'all',
}: IdeogramInfographicDeckProps) {
  useThemeToolsSurface('ideogram-infographic-deck');

  const allPhotos = [...town.nostalgicPhotos, ...crewPhotos];

  return (
    <div className="space-y-12 mb-12">
      {/* Section 1: Nostalgic Town Landmark & Crew-Scenario Photography Gallery */}
      {mode !== 'charts-only' && (
      <section
        data-testid="nostalgic-photo-gallery"
        aria-label={`Nostalgic ${town.townName} Landmark & Crew Scenario Photography`}
        className="rounded-2xl border border-brand-line bg-bg-elevated p-6 sm:p-8"
      >
        <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.18em] text-brand-accent mb-1">
              {town.townName.toUpperCase()}, {town.state} ARCHITECTURE &amp; FIELD EQUIPMENT GALLERY · 6 HIGH-RES PHOTOS
            </p>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-brand-ink">
              {town.townName} Surfaces We Wash &amp; Our Commercial Equipment in Action
            </h2>
            <p className="mt-1 text-sm text-brand-mute max-w-3xl">
              Real photographs of {town.townName}&apos;s historic masonry, brownstone stoops, bluestone walkways, and concrete corridors paired with our 4.0 GPM commercial washers and 16-inch rotary surface cleaners.
            </p>
          </div>
          <a
            href={bookingUrl}
            data-testid="gallery-book-cta"
            className="rounded-xl bg-brand-accent px-4 py-2.5 font-mono text-xs font-extrabold uppercase tracking-wider text-bg-primary hover:opacity-90 transition-opacity"
          >
            Reserve Crew at bricklabor.com/book →
          </a>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {allPhotos.map((photo) => (
            <figure
              key={photo.id}
              data-testid="custom-page-photo-card"
              data-photo-kind={photo.kind}
              className="group flex flex-col overflow-hidden rounded-2xl border border-brand-line bg-bg-primary/80 transition-colors hover:border-brand-accent/60"
            >
              <div className="relative aspect-[16/10] w-full overflow-hidden bg-[#090910]">
                <img
                  src={photo.imageUrl}
                  alt={photo.altText}
                  width={800}
                  height={500}
                  loading="eager"
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <span className="absolute left-3 top-3 rounded-full border border-brand-accent/50 bg-bg-primary/90 px-2.5 py-1 font-mono text-[10px] font-bold uppercase tracking-wider text-brand-accent">
                  {photo.eraOrSetupBadge}
                </span>
              </div>
              <figcaption className="flex flex-1 flex-col justify-between p-4 space-y-3">
                <div>
                  <h3 className="text-base font-bold text-brand-ink leading-snug">
                    {photo.title}
                  </h3>
                  <p className="mt-1.5 text-xs text-brand-mute leading-relaxed">
                    {photo.caption}
                  </p>
                </div>
                <div className="flex items-center justify-between border-t border-brand-line/70 pt-2.5 text-[11px] font-mono text-brand-mute">
                  <span className="truncate">{photo.photographerCredit}</span>
                  <a
                    href={photo.wikimediaOrSourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="shrink-0 text-brand-accent hover:underline ml-2"
                  >
                    Source ↗
                  </a>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>
      )}

      {/* Section 2: 4 Simple Visual Summary Cards */}
      {mode !== 'photos-only' && (
      <section
        data-testid="ideogram-infographic-deck"
        aria-label="Visual Overview and Summary Cards"
        className="tt-card rounded-2xl border border-brand-line bg-bg-elevated p-6 sm:p-8"
      >
        <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.18em] text-brand-accent mb-1">
              AT-A-GLANCE VISUAL OVERVIEW · 4 SUMMARY CARDS
            </p>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-brand-ink">
              Simple $50/hr Pricing, Surface Care &amp; 4-Step On-Site Routine
            </h2>
            <p className="mt-1 text-sm text-brand-mute max-w-3xl">
              Four simple visual cards summarizing our $50/hr hourly pricing in {town.townName}, how we match gentle soap or our circular surface cleaner to your surfaces, our 20-minute free sample routine, and our $0 travel fee coverage.
            </p>
          </div>
          <a
            href={bookingUrl}
            data-testid="ideogram-book-cta"
            className="tt-btn tt-btn--primary rounded-xl bg-brand-accent px-4 py-2.5 font-mono text-xs font-extrabold uppercase tracking-wider text-bg-primary hover:opacity-90 transition-opacity"
          >
            Book Online ($50/hr) →
          </a>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {infographics.map((fig) => (
            <article
              key={fig.id}
              data-testid="ideogram-figure-card"
              className="flex flex-col justify-between rounded-2xl border border-brand-line bg-bg-primary/80 p-5"
            >
              <div>
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                  <span className="tt-badge rounded-md bg-brand-accent/15 px-2.5 py-1 font-mono text-[11px] font-bold text-brand-accent">
                    {fig.ideogramModelTag}
                  </span>
                  <span className="font-mono text-xs font-extrabold text-emerald-400">
                    {fig.keyTakeawayMetric} · {fig.keyTakeawayLabel}
                  </span>
                </div>

                <h3 className="text-lg font-extrabold text-brand-ink leading-snug">
                  {fig.title}
                </h3>
                <p className="mt-1 text-xs text-brand-mute">{fig.subtitle}</p>

                <div className="mt-4 overflow-hidden rounded-xl border border-brand-line bg-[#070912]">
                  <img
                    src={fig.imageUrl}
                    alt={fig.altText}
                    width={800}
                    height={500}
                    loading="eager"
                    className="w-full h-auto object-cover"
                  />
                </div>
              </div>

              <div className="mt-4 border-t border-brand-line/70 pt-3">
                <p className="text-xs text-brand-mute leading-relaxed">{fig.caption}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
      )}
    </div>
  );
}

export function AuthorityDossierTail({
  dossier,
}: {
  readonly dossier: LongFormPageAuthorityDossier;
}) {
  return (
    <div className="container-pad py-6">
      {/* Universal Collapsed-by-Default Gorgeous Citations & Reference Table [1–8] */}
      <CollapsibleCitationsDrawer
        references={dossier.references}
        townName={dossier.townHeritage.townName}
        bookingUrl="https://bricklabor.com/book"
      />
    </div>
  );
}
export default IdeogramInfographicDeck;
