import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useState } from 'react';

const DISMISS_KEY = 'bcl_me_a2hs_dismissed_v1';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

/**
 * Pinned "Add to home screen" pill at the top of the calendar canvas. Renders
 * only when the browser fires `beforeinstallprompt` AND the user hasn't already
 * dismissed it. Standalone PWA visits never see it.
 */
export function InstallBanner() {
  useThemeToolsSurface('install-banner');
  const [evt, setEvt] = useState<BeforeInstallPromptEvent | null>(null);
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      if (localStorage.getItem(DISMISS_KEY)) {
        setHidden(true);
        return;
      }
    } catch {
      /* private mode */
    }
    const isStandalone =
      window.matchMedia?.('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    if (isStandalone) {
      setHidden(true);
      return;
    }
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setEvt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener('beforeinstallprompt', onPrompt);
    return () => window.removeEventListener('beforeinstallprompt', onPrompt);
  }, []);

  if (hidden || !evt) return null;

  const dismiss = () => {
    try {
      localStorage.setItem(DISMISS_KEY, '1');
    } catch {
      /* noop */
    }
    setHidden(true);
  };

  const install = async () => {
    try {
      await evt.prompt();
      const { outcome } = await evt.userChoice;
      if (outcome === 'accepted') setHidden(true);
    } catch {
      setHidden(true);
    }
  };

  return (
    <div
      role="region"
      aria-label="Install Brick Labor"
      className="flex items-center justify-between gap-3 rounded-xl border border-brand-accent/40 bg-brand-accent/10 px-3 py-2 text-xs"
    >
      <p className="text-brand-ink">
        <strong className="text-brand-accent">Install BCL</strong> · skip the browser, get push
        reminders.
      </p>
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={install}
          className="rounded-md bg-brand-accent px-3 py-1 text-[11px] font-extrabold text-bg-primary hover:bg-brand-accentHover min-h-[28px]"
        >
          Install
        </button>
        <button
          type="button"
          onClick={dismiss}
          aria-label="Dismiss install banner"
          className="rounded-md border border-brand-line px-2 py-1 text-[11px] text-brand-mute hover:text-brand-ink min-h-[28px]"
        >
          ✕
        </button>
      </div>
    </div>
  );
}

/** Connection-state pill at the bottom of the canvas. */
export function OfflineIndicator() {
  const [offline, setOffline] = useState(false);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    setOffline(!window.navigator.onLine);
    const on = () => setOffline(false);
    const off = () => setOffline(true);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);
  if (!offline) return null;
  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-4 left-1/2 z-40 -translate-x-1/2 rounded-full border border-yellow-500/40 bg-yellow-500/15 px-4 py-2 text-xs font-semibold text-yellow-100 shadow-glow animate-fade-up"
    >
      Offline · cached view. Changes sync when you reconnect.
    </div>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
