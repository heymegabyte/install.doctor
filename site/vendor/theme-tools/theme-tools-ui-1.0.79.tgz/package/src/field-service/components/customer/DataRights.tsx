import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useState } from 'react';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

/**
 * `/me/data-rights` — CCPA + GDPR self-service surface. Lives under the
 * existing `/me` customer surface and assumes the caller has a valid
 * `bcl_cust_sid` cookie (the integrator's job to route only when signed
 * in).
 *
 * Two main flows:
 *
 *  1. Export — POST /api/data-rights/export → 202 with an id; the UI polls
 *     /status until the row flips to `ready`, then renders the download link.
 *  2. Delete — POST /api/data-rights/delete → returns the 30-day cancel
 *     window; the UI shows it with a Cancel button until the window elapses.
 *
 * Wave 37 addition: when the `account_self_delete` flag is on, an
 * additional banner section renders the explicit
 * `/api/account-self-delete/*` flow. Foreground will gate that section
 * via `useFeatureFlag('account_self_delete')`; here we expose
 * `<DataRights accountSelfDeleteEnabled />` as the wiring point.
 */

interface RequestRow {
  id: string;
  kind: 'ccpa' | 'gdpr' | 'manual';
  status: 'pending' | 'processing' | 'ready' | 'delivered' | 'cancelled';
  cancel_window_ends_at: string | null;
  requested_at: string;
  fulfilled_at: string | null;
}

interface AccountSelfDeleteStatus {
  id: string;
  cron_eligible_at: string;
  cancelled_at: string | null;
  status: 'open' | 'cancelled' | 'executed' | 'overdue';
  daysRemaining: number;
}

interface Props {
  /** When true, render the explicit account-self-delete banner section
   *  alongside the legacy export/delete flow. Foreground passes
   *  `useFeatureFlag('account_self_delete')`. */
  accountSelfDeleteEnabled?: boolean;
}

export function DataRights({ accountSelfDeleteEnabled = false }: Props = {}) {
  useThemeToolsSurface('data-rights');
  const [requests, setRequests] = useState<RequestRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [working, setWorking] = useState<'export' | 'delete' | null>(null);
  const [notice, setNotice] = useState('');
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [asdStatus, setAsdStatus] = useState<AccountSelfDeleteStatus | null>(null);
  const [asdWorking, setAsdWorking] = useState(false);
  const [asdConfirming, setAsdConfirming] = useState(false);
  const [asdReason, setAsdReason] = useState('');
  const [asdError, setAsdError] = useState('');

  const reloadAccountSelfDelete = useCallback(async () => {
    if (!accountSelfDeleteEnabled) return;
    setAsdError('');
    try {
      const res = await fetch('/api/account-self-delete/status', {
        credentials: 'same-origin',
      });
      if (res.status === 404 || res.status === 401) {
        setAsdStatus(null);
        return;
      }
      if (!res.ok) {
        setAsdError('We could not load your deletion status. Try again.');
        return;
      }
      const data = (await res.json()) as {
        ok?: boolean;
        request?: AccountSelfDeleteStatus | null;
      };
      setAsdStatus(data.request ?? null);
    } catch {
      setAsdError('You appear to be offline. Reconnect and try again.');
    }
  }, [accountSelfDeleteEnabled]);

  const reload = useCallback(async () => {
    setError('');
    try {
      const res = await fetch('/api/data-rights/status', { credentials: 'same-origin' });
      if (res.status === 401) {
        setError('Sign in to manage your data.');
        return;
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as { requests?: RequestRow[] };
      setRequests(data.requests ?? []);
    } catch (err) {
      setError((err as Error).message);
    }
  }, []);

  useEffect(() => {
    document.title = 'Your data — Brick Labor';
    let cancelled = false;
    setLoading(true);
    (async () => {
      await Promise.all([reload(), reloadAccountSelfDelete()]);
      if (!cancelled) setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [reload, reloadAccountSelfDelete]);

  async function asdRequestDeletion() {
    setAsdWorking(true);
    setAsdError('');
    try {
      const res = await fetch('/api/account-self-delete/request-deletion', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason: asdReason || undefined }),
      });
      const data = (await res.json()) as { ok?: boolean; error?: string };
      if (!data.ok) throw new Error(data.error ?? 'request_failed');
      setAsdConfirming(false);
      setAsdReason('');
      await reloadAccountSelfDelete();
    } catch (err) {
      setAsdError(
        (err as Error).message === 'request_failed'
          ? 'We could not schedule deletion. Try again.'
          : 'We could not schedule deletion. Check your connection and try again.',
      );
    } finally {
      setAsdWorking(false);
    }
  }

  async function asdCancelDeletion() {
    setAsdWorking(true);
    setAsdError('');
    try {
      const res = await fetch('/api/account-self-delete/cancel-deletion', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      const data = (await res.json()) as { ok?: boolean; error?: string };
      if (!data.ok) throw new Error(data.error ?? 'cancel_failed');
      await reloadAccountSelfDelete();
    } catch (err) {
      setAsdError(
        (err as Error).message === 'cancel_failed'
          ? 'We could not cancel deletion. Try again.'
          : 'We could not cancel deletion. Check your connection and try again.',
      );
    } finally {
      setAsdWorking(false);
    }
  }

  async function startExport() {
    setWorking('export');
    setNotice('');
    try {
      const res = await fetch('/api/data-rights/export', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kind: 'ccpa' }),
      });
      const data = (await res.json()) as {
        ok?: boolean;
        id?: string;
        status?: string;
        error?: string;
      };
      if (!data.ok) throw new Error(data.error ?? 'export_failed');
      setNotice(
        `Export started (id ${data.id}). Refresh in a moment, then use the Download button below.`,
      );
      await reload();
    } catch (err) {
      setNotice(`Error: ${(err as Error).message}`);
    } finally {
      setWorking(null);
    }
  }

  async function startDelete() {
    setWorking('delete');
    setNotice('');
    try {
      const res = await fetch('/api/data-rights/delete', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ confirm: true }),
      });
      const data = (await res.json()) as {
        ok?: boolean;
        id?: string;
        cancelWindowEndsAt?: string;
        error?: string;
      };
      if (!data.ok) throw new Error(data.error ?? 'delete_failed');
      setNotice(
        `Delete scheduled. You have until ${formatLocal(data.cancelWindowEndsAt ?? '')} to cancel.`,
      );
      await reload();
    } catch (err) {
      setNotice(`Error: ${(err as Error).message}`);
    } finally {
      setWorking(null);
      setConfirmingDelete(false);
    }
  }

  async function cancelDelete(id: string) {
    setWorking('delete');
    try {
      await fetch('/api/data-rights/cancel-delete', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      await reload();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setWorking(null);
    }
  }

  return (
    <article className="section">
      <div className="container-pad max-w-3xl">
        <p className="eyebrow">Your data</p>
        <h1 className="text-3xl font-extrabold mb-2">Data rights</h1>
        <p className="text-brand-mute mb-8 text-sm">
          Download everything we have about you, or ask us to delete it. We honor CCPA and GDPR
          requests within 30 days.
        </p>

        {error && (
          <div
            className="mb-6 rounded-lg border border-rose-900/40 bg-rose-900/20 p-3 text-sm text-rose-200"
            role="alert"
          >
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <div className="rounded-xl border border-brand-line bg-brand-ink/40 p-5">
            <h2 className="text-lg font-bold mb-1">Download my data</h2>
            <p className="text-brand-mute text-sm mb-4">
              JSON bundle of every booking, review, incident, and session row tied to your account.
            </p>
            <button
              type="button"
              onClick={startExport}
              disabled={working === 'export'}
              className="btn btn-primary text-sm disabled:opacity-60"
            >
              {working === 'export' ? 'Requesting…' : 'Request export'}
            </button>
          </div>
          <div className="rounded-xl border border-rose-900/40 bg-rose-900/10 p-5">
            <h2 className="text-lg font-bold mb-1">Delete my data</h2>
            <p className="text-brand-mute text-sm mb-4">
              Anonymizes every row tied to your account after a 30-day cancellation window.
            </p>
            {!confirmingDelete && (
              <button
                type="button"
                onClick={() => setConfirmingDelete(true)}
                className="btn btn-secondary text-sm"
              >
                Start delete
              </button>
            )}
            {confirmingDelete && (
              <div className="space-y-2">
                <p className="text-rose-200 text-sm">
                  This is irreversible after 30 days. Continue?
                </p>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={startDelete}
                    disabled={working === 'delete'}
                    className="btn text-sm bg-rose-700 text-white hover:bg-rose-800 disabled:opacity-60"
                  >
                    {working === 'delete' ? 'Scheduling…' : 'Yes, delete'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmingDelete(false)}
                    className="btn btn-secondary text-sm"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {notice && (
          <p className="mb-6 rounded-md border border-brand-accent/40 bg-brand-accent/10 px-3 py-2 text-sm text-brand-accent">
            {notice}
          </p>
        )}

        {accountSelfDeleteEnabled && (
          <section
            data-testid="account-self-delete-section"
            className="mb-8 rounded-xl border border-rose-900/40 bg-rose-900/5 p-5"
          >
            <h2 className="text-lg font-bold mb-1">Delete my entire account</h2>
            <p className="text-brand-mute text-sm mb-3">
              Permanently removes your profile, bookings PII, and all sessions
              after a 30-day cancellation window.
            </p>

            {asdError && (
              <div
                role="alert"
                className="mb-3 rounded-md border border-rose-900/50 bg-rose-950/40 p-3 text-sm text-rose-100"
              >
                <p>{asdError}</p>
                <button
                  type="button"
                  onClick={() => void reloadAccountSelfDelete()}
                  className="btn btn-secondary mt-2 text-sm"
                  data-testid="asd-retry"
                >
                  Try again
                </button>
              </div>
            )}

            {asdStatus && asdStatus.status === 'open' && (
              <div className="rounded-md border border-amber-900/40 bg-amber-900/15 p-3 text-sm text-amber-200 mb-3">
                <p className="font-semibold">
                  Account scheduled for deletion in {asdStatus.daysRemaining} day
                  {asdStatus.daysRemaining === 1 ? '' : 's'}.
                </p>
                <p className="mt-1 text-xs">
                  Final removal on {formatLocal(asdStatus.cron_eligible_at)}. Cancel any time before then.
                </p>
                <button
                  type="button"
                  onClick={asdCancelDeletion}
                  disabled={asdWorking}
                  className="btn btn-secondary text-sm mt-2 disabled:opacity-60"
                  data-testid="asd-cancel"
                >
                  {asdWorking ? 'Cancelling…' : 'Cancel deletion'}
                </button>
              </div>
            )}

            {!asdStatus && !asdConfirming && (
              <button
                type="button"
                onClick={() => setAsdConfirming(true)}
                className="btn text-sm bg-rose-700 text-white hover:bg-rose-800"
                data-testid="asd-start"
              >
                Delete my account
              </button>
            )}

            {!asdStatus && asdConfirming && (
              <div className="space-y-2">
                <p className="text-rose-200 text-sm">
                  This anonymizes every booking, removes your saved data, and signs
                  you out everywhere after 30 days. Continue?
                </p>
                <label className="block text-xs">
                  <span className="text-brand-mute">Reason (optional)</span>
                  <input
                    type="text"
                    value={asdReason}
                    onChange={(e) => setAsdReason(e.target.value)}
                    maxLength={500}
                    placeholder="Help us understand why you're leaving"
                    className="mt-1 w-full rounded border border-brand-line bg-black/40 px-2 py-1 text-sm"
                  />
                </label>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={asdRequestDeletion}
                    disabled={asdWorking}
                    className="btn text-sm bg-rose-700 text-white hover:bg-rose-800 disabled:opacity-60"
                    data-testid="asd-confirm"
                  >
                    {asdWorking ? 'Scheduling…' : 'Yes, schedule deletion'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setAsdConfirming(false)}
                    className="btn btn-secondary text-sm"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </section>
        )}

        <h2 className="text-lg font-bold mb-3">Your requests</h2>
        {loading && <p className="text-brand-mute text-sm">Loading…</p>}
        {!loading && requests.length === 0 && (
          <p className="text-brand-mute text-sm">No data-rights requests yet.</p>
        )}
        {requests.length > 0 && (
          <ul className="space-y-2 text-sm">
            {requests.map((r) => (
              <li key={r.id} className="rounded-md border border-brand-line bg-brand-ink/40 p-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-mono text-xs">{r.id.slice(0, 10)}</span>
                  <span className="text-brand-mute text-xs">{r.kind}</span>
                  <span
                    className={
                      'rounded-full px-2 py-0.5 text-xs ' +
                      (r.status === 'ready' || r.status === 'delivered'
                        ? 'bg-emerald-900/30 text-emerald-200'
                        : r.status === 'cancelled'
                          ? 'bg-brand-line text-brand-mute'
                          : 'bg-amber-900/30 text-amber-200')
                    }
                  >
                    {r.status}
                  </span>
                  {r.status === 'ready' && (
                    <a
                      className="text-brand-accent text-xs underline"
                      href={`/api/data-rights/export?id=${r.id}`}
                    >
                      Download
                    </a>
                  )}
                  {r.status === 'pending' && r.cancel_window_ends_at && (
                    <button
                      type="button"
                      onClick={() => cancelDelete(r.id)}
                      className="btn btn-secondary text-xs"
                    >
                      Cancel delete
                    </button>
                  )}
                </div>
                <p className="mt-1 text-brand-mute text-xs">
                  Requested {formatLocal(r.requested_at)}
                  {r.cancel_window_ends_at &&
                    ` · cancellable until ${formatLocal(r.cancel_window_ends_at)}`}
                </p>
              </li>
            ))}
          </ul>
        )}

        <p className="mt-8 text-brand-mute text-xs">
          Questions? Email{' '}
          <a className="text-brand-accent underline" href="mailto:hey@bricklabor.com">
            hey@bricklabor.com
          </a>{' '}
          or call{' '}
          <a className="text-brand-accent underline" href={PHONE_TEL_HREF}>
            (855) 825-2267
          </a>
          .
        </p>
      </div>
    </article>
  );
}

function formatLocal(iso: string): string {
  if (!iso) return '';
  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
