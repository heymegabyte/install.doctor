import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useRovingTabs } from '../../use-roving-radio.js';
import { adminFetch, formatCents, formatRelative, getAdminToken, pushLocalRecent } from '@theme.tools/crm/field-service/admin-api';
import { JobDetail } from './JobDetail.js';
import { RecentlyViewed } from './RecentlyViewed.js';
import { OverrideDispatchModal } from './OverrideDispatchModal.js';
import { RefundApologizeModal } from './RefundApologizeModal.js';

/**
 * Wave 17 — Jobs browser.
 * Tabs: Active · Pending · Archived · Deleted · All.
 * Search across address / customer / id / phone, cursor-paged at 50/page.
 * Click a row to open the JobDetail drawer with full sub-data + actions.
 */

type JobState = 'active' | 'pending' | 'archived' | 'deleted' | 'all';

interface JobRow {
  id: string;
  created_at: string;
  status: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string | null;
  address: string;
  city: string;
  zip: string;
  preferred_date: string;
  preferred_time: string;
  services_csv: string;
  hours: number;
  crew: number;
  total_cents: number;
  archived_at: number | null;
  deleted_at: number | null;
  paid_at: string | null;
  completed_at: string | null;
  canceled_at: string | null;
}

interface JobsListResponse {
  ok: true;
  status: JobState;
  jobs: JobRow[];
  next_cursor: string | null;
}

const TABS: Array<{ id: JobState; label: string; hint: string }> = [
  { id: 'active', label: 'Active', hint: 'Confirmed + in-flight + completed' },
  { id: 'pending', label: 'Pending', hint: 'Needs action: unpaid / unconfirmed / errored' },
  { id: 'archived', label: 'Archived', hint: 'Hidden from default views' },
  { id: 'deleted', label: 'Deleted', hint: 'Soft-deleted — restorable' },
  { id: 'all', label: 'All', hint: 'Everything except soft-deleted' },
];

export function JobsBrowser() {
  useThemeToolsSurface('jobs-browser');
  const [state, setState] = useState<JobState>('active');
  // ARIA roving-tabindex for the job-state tablist (axe-blind interaction gap).
  const stateTab = useRovingTabs(TABS.length, (i) => setState(TABS[i]!.id));
  const [q, setQ] = useState('');
  const [rows, setRows] = useState<JobRow[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  // Wave 21C — override dispatch + one-click refund modals.
  const [overrideJob, setOverrideJob] = useState<JobRow | null>(null);
  const [refundJob, setRefundJob] = useState<JobRow | null>(null);

  const abortRef = useRef<AbortController | null>(null);

  const load = useCallback(
    async (mode: 'reset' | 'append') => {
      abortRef.current?.abort();
      const ctrl = new AbortController();
      abortRef.current = ctrl;
      setLoading(true);
      setError(null);
      const params = new URLSearchParams({ status: state, limit: '50' });
      if (q.trim()) params.set('q', q.trim());
      if (mode === 'append' && cursor) params.set('cursor', cursor);
      const result = await adminFetch<JobsListResponse>(`/jobs?${params.toString()}`, {
        signal: ctrl.signal,
      });
      if (!result.ok) {
        if (result.error === 'aborted') return;
        setError(result.error);
        setLoading(false);
        return;
      }
      setRows((prev) => (mode === 'append' ? [...prev, ...result.data.jobs] : result.data.jobs));
      setNextCursor(result.data.next_cursor);
      setLoading(false);
    },
    [state, q, cursor],
  );

  useEffect(() => {
    setCursor(null);
    void load('reset');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  // Debounced search.
  useEffect(() => {
    const t = setTimeout(() => {
      setCursor(null);
      void load('reset');
    }, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  const counts = useMemo(() => rows.length, [rows]);

  return (
    <section className="space-y-4">
      <header className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-black/85 bg-[#0c1017] p-5 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.92),0_0_0_1px_rgba(0,0,0,0.9),inset_0_1px_0_rgba(255,255,255,0.035)]">
        <div>
          <p className="eyebrow mb-1">Admin · operations</p>
          <h2 className="font-display text-2xl font-extrabold text-brand-ink">Jobs Browser</h2>
          <p className="text-sm text-brand-mute">
            Browse every booking across active, pending, archived, and soft-deleted state.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search address, customer, id, phone…"
            className="rounded-xl border border-black/85 bg-[#080b12] px-3.5 py-2 text-sm text-white placeholder:text-brand-mute focus:border-brand-accent focus:outline-none w-72"
            aria-label="Search jobs"
          />
          <button
            type="button"
            onClick={() => void load('reset')}
            className="rounded-xl border border-black/85 bg-[#080b12] px-3.5 py-2 font-mono text-xs font-semibold text-brand-ink hover:border-brand-accent transition"
          >
            Refresh
          </button>
        </div>
      </header>

      <div
        role="tablist"
        aria-label="Job state"
        className="flex flex-wrap items-center gap-1.5 rounded-2xl border border-black/85 bg-[#0c1017] p-2.5"
      >
        {TABS.map((t, i) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={state === t.id}
            onClick={() => setState(t.id)}
            {...stateTab(i, state === t.id)}
            className={`px-3.5 py-1.5 font-mono text-xs rounded-xl border transition-colors ${
              state === t.id
                ? 'bg-brand-accent/15 text-brand-accent border-brand-accent font-bold'
                : 'border-black/85 bg-[#080b12] text-brand-mute hover:text-white hover:border-brand-accent/50'
            }`}
            title={t.hint}
          >
            {t.label}
          </button>
        ))}
        <span className="ml-auto font-mono text-xs text-brand-mute self-center pr-2">
          {loading ? 'Loading…' : `${counts} row${counts === 1 ? '' : 's'}`}
        </span>
      </div>

      {error && (
        <div
          role="alert"
          className="rounded-xl border border-red-500/40 bg-red-950/30 p-3.5 text-sm text-red-300"
        >
          {error}
        </div>
      )}

      <div className="overflow-x-auto rounded-2xl border border-black/85 bg-[#0c1017] shadow-[0_24px_60px_-20px_rgba(0,0,0,0.92),0_0_0_1px_rgba(0,0,0,0.9),inset_0_1px_0_rgba(255,255,255,0.035)]">
        <table className="w-full text-sm">
          <thead className="bg-black/45 text-left font-mono text-xs uppercase text-brand-accent border-b border-black/85">
            <tr>
              <th className="px-3 py-2">When</th>
              <th className="px-3 py-2">Customer</th>
              <th className="px-3 py-2">Address</th>
              <th className="px-3 py-2">Status</th>
              <th className="px-3 py-2 text-right">Total</th>
              <th className="px-3 py-2 text-right">Crew · Hrs</th>
              <th className="px-3 py-2 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && !loading && (
              <tr>
                <td colSpan={7} className="px-3 py-12 text-center text-brand-mute">
                  No jobs in this view.
                </td>
              </tr>
            )}
            {rows.map((r) => (
              <tr
                key={r.id}
                onClick={() => {
                  setSelectedId(r.id);
                  pushLocalRecent('job', r.id, `${r.customer_name} · ${r.preferred_date}`);
                }}
                className="cursor-pointer border-t border-white/5 hover:bg-brand-cyan/5"
              >
                <td className="px-3 py-2">
                  <div className="text-white">{r.preferred_date}</div>
                  <div className="text-xs text-brand-mute">{formatRelative(r.created_at)}</div>
                </td>
                <td className="px-3 py-2">
                  <div className="text-white">{r.customer_name}</div>
                  <div className="text-xs text-brand-mute">
                    {r.customer_phone || r.customer_email}
                  </div>
                </td>
                <td className="px-3 py-2 text-brand-mute">
                  <div className="text-white">{r.address}</div>
                  <div className="text-xs">
                    {r.city}, {r.zip}
                  </div>
                </td>
                <td className="px-3 py-2">
                  <StatusPill
                    status={r.status}
                    archived={!!r.archived_at}
                    deleted={!!r.deleted_at}
                  />
                </td>
                <td className="px-3 py-2 text-right text-white">{formatCents(r.total_cents)}</td>
                <td className="px-3 py-2 text-right text-brand-mute">
                  {r.crew} × {r.hours}h
                </td>
                <td className="px-3 py-2 text-right">
                  <div className="flex justify-end gap-1" onClick={(e) => e.stopPropagation()}>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setOverrideJob(r);
                      }}
                      className="rounded border border-amber-500/40 px-2 py-0.5 text-xs text-amber-200 hover:bg-amber-950/30"
                      title="Force-assign a worker, bypassing the AI rules engine"
                      data-testid={`override-dispatch-${r.id}`}
                    >
                      Override
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setRefundJob(r);
                      }}
                      disabled={!r.paid_at}
                      className="rounded border border-red-500/40 px-2 py-0.5 text-xs text-red-200 hover:bg-red-950/30 disabled:opacity-30"
                      title={r.paid_at ? 'Refund + apology email/SMS' : 'No payment to refund'}
                      data-testid={`refund-${r.id}`}
                    >
                      Refund
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {nextCursor && (
        <div className="flex justify-center">
          <button
            type="button"
            onClick={() => {
              setCursor(nextCursor);
              void load('append');
            }}
            disabled={loading}
            className="rounded border border-brand-cyan/30 px-4 py-1.5 text-sm text-brand-cyan hover:bg-brand-cyan/10 disabled:opacity-50"
          >
            {loading ? 'Loading…' : 'Load more'}
          </button>
        </div>
      )}

      {selectedId && (
        <JobDetail
          jobId={selectedId}
          onClose={() => setSelectedId(null)}
          onMutated={() => void load('reset')}
        />
      )}

      <RecentlyViewed
        onOpen={(kind, id) => {
          if (kind === 'job') setSelectedId(id);
        }}
      />

      {overrideJob && (
        <OverrideDispatchModal
          bookingId={overrideJob.id}
          customerName={overrideJob.customer_name}
          onClose={() => setOverrideJob(null)}
          onSuccess={() => {
            setOverrideJob(null);
            void load('reset');
          }}
        />
      )}
      {refundJob && (
        <RefundApologizeModal
          bookingId={refundJob.id}
          customerName={refundJob.customer_name}
          totalCents={refundJob.total_cents}
          onClose={() => setRefundJob(null)}
          onSuccess={() => {
            setRefundJob(null);
            void load('reset');
          }}
        />
      )}
    </section>
  );
}

// `getAdminToken` re-exported for inline modal use without duplicating logic.
export { getAdminToken };

function StatusPill({
  status,
  archived,
  deleted,
}: {
  status: string;
  archived: boolean;
  deleted: boolean;
}) {
  if (deleted) {
    return (
      <span className="inline-block rounded bg-red-950/50 px-2 py-0.5 text-xs font-medium text-red-300">
        deleted
      </span>
    );
  }
  if (archived) {
    return (
      <span className="inline-block rounded bg-zinc-700/40 px-2 py-0.5 text-xs font-medium text-zinc-300">
        archived
      </span>
    );
  }
  const color =
    status === 'completed'
      ? 'bg-emerald-950/50 text-emerald-300'
      : status === 'in_progress'
        ? 'bg-amber-950/50 text-amber-300'
        : status === 'paid' || status === 'confirmed'
          ? 'bg-brand-cyan/10 text-brand-cyan'
          : status === 'canceled'
            ? 'bg-zinc-800/60 text-zinc-400'
            : 'bg-orange-950/40 text-orange-300';
  return (
    <span className={`inline-block rounded px-2 py-0.5 text-xs font-medium ${color}`}>
      {status}
    </span>
  );
}

export default JobsBrowser;
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
