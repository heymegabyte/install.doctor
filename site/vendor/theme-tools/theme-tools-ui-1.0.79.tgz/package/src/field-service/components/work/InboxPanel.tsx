import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useState } from 'react';

// Wave 21B — slide-out inbox list. Mounted by <InboxBadge />; controlled via
// `open` prop. Each item shows kind, subject, body, action link, and
// timestamp. Workers can mark individual items read or bulk-clear with one
// click.
//
// A11y: role="dialog" + aria-modal=false (we treat this as a non-blocking
// side panel — focus stays free, Esc closes). Click outside or the close
// button also dismisses.

interface InboxItem {
  id: string;
  kind: 'dispatch' | 'payout' | 'compliance' | 'tax' | 'training' | 'review' | 'streak';
  subject: string;
  body: string | null;
  action_url: string | null;
  priority: number;
  read_at: string | null;
  created_at: string;
}

interface InboxApiResponse {
  items: InboxItem[];
  unread: number;
}

interface InboxPanelProps {
  open: boolean;
  onClose: () => void;
}

const KIND_TINT: Record<InboxItem['kind'], string> = {
  dispatch: 'text-sky-300',
  payout: 'text-emerald-300',
  compliance: 'text-amber-300',
  tax: 'text-amber-200',
  training: 'text-indigo-300',
  review: 'text-pink-300',
  streak: 'text-yellow-300',
};

export function InboxPanel({ open, onClose }: InboxPanelProps): JSX.Element | null {
  useThemeToolsSurface('inbox-panel');
  const [items, setItems] = useState<InboxItem[]>([]);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      const res = await fetch('/api/work/inbox', {
        credentials: 'include',
        headers: { Accept: 'application/json' },
      });
      if (res.ok) {
        const j = (await res.json()) as InboxApiResponse;
        setItems(j.items ?? []);
      }
    } catch {
      // Render whatever we last had.
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => {
    if (open) void load();
  }, [open, load]);

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e: KeyboardEvent): void => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  const markOne = useCallback(async (id: string) => {
    try {
      await fetch(`/api/work/inbox/${encodeURIComponent(id)}/read`, {
        method: 'POST',
        credentials: 'include',
      });
      setItems((prev) =>
        prev.map((it) => (it.id === id ? { ...it, read_at: new Date().toISOString() } : it)),
      );
    } catch {
      /* ignore — next load will reconcile */
    }
  }, []);

  const bulkRead = useCallback(async () => {
    try {
      await fetch('/api/work/inbox/bulk-read', {
        method: 'POST',
        credentials: 'include',
      });
      const now = new Date().toISOString();
      setItems((prev) => prev.map((it) => (it.read_at ? it : { ...it, read_at: now })));
    } catch {
      /* ignore */
    }
  }, []);

  if (!open) return null;

  return (
    <>
      <div
        aria-hidden="true"
        className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm"
        onClick={onClose}
      />
      <aside
        id="worker-inbox-panel"
        role="dialog"
        aria-label="Inbox"
        className="fixed top-0 right-0 z-50 h-full w-full max-w-md bg-brand-bg border-l border-brand-line shadow-2xl flex flex-col"
      >
        <header className="flex items-center justify-between gap-3 p-4 border-b border-brand-line">
          <div>
            <h2 className="text-lg font-extrabold text-brand-ink">Inbox</h2>
            <p className="text-xs text-brand-mute">
              Dispatch, payouts, compliance, training, reviews
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => void bulkRead()}
              className="text-xs text-brand-mute underline-hover"
            >
              Mark all read
            </button>
            <button
              type="button"
              aria-label="Close inbox"
              onClick={onClose}
              className="h-8 w-8 inline-flex items-center justify-center rounded-lg border border-brand-line text-brand-ink hover:bg-brand-card"
            >
              ×
            </button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto">
          {busy && items.length === 0 ? (
            <p className="p-6 text-sm text-brand-mute">Loading…</p>
          ) : items.length === 0 ? (
            <p className="p-6 text-sm text-brand-mute">No notifications yet.</p>
          ) : (
            <ul className="divide-y divide-brand-line">
              {items.map((it) => (
                <li key={it.id} className={`p-4 ${it.read_at ? 'opacity-60' : 'bg-brand-card/40'}`}>
                  <div className="flex items-start justify-between gap-3 mb-1">
                    <span
                      className={`text-[11px] uppercase tracking-wide font-bold ${KIND_TINT[it.kind]}`}
                    >
                      {it.kind}
                    </span>
                    <time className="text-[11px] text-brand-mute">
                      {new Date(it.created_at).toLocaleString()}
                    </time>
                  </div>
                  <p className="text-sm font-bold text-brand-ink mb-1">{it.subject}</p>
                  {it.body && (
                    <p className="text-xs text-brand-mute mb-2 leading-relaxed">{it.body}</p>
                  )}
                  <div className="flex items-center gap-3 text-xs">
                    {it.action_url && (
                      <a
                        href={it.action_url}
                        className="font-bold text-brand-accent underline-hover"
                      >
                        Open →
                      </a>
                    )}
                    {!it.read_at && (
                      <button
                        type="button"
                        onClick={() => void markOne(it.id)}
                        className="text-brand-mute underline-hover"
                      >
                        Mark read
                      </button>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </aside>
    </>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
