import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function Lighthouse({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('lighthouse');
  return (
    <GenericTable title="Lighthouse score history" endpoint="/lighthouse" adminKey={adminKey} />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
