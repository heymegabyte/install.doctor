import { useThemeToolsSurface } from '../../field-service-primitives.js';
import type { JSX } from 'react';
import { ApplyFlow } from './apply/ApplyFlow.js';

/**
 * ApplyPage — the dedicated full-page `/apply` surface for the "Apply to work"
 * flow. Renders the COMPLETE multi-step crew intake (intro → account →
 * email+phone OTP verify → worker profile + 12-question questionnaire →
 * optional driver/U-Haul track with license uploads → SSN + AI dispatch
 * profile → submit → status checklist) plus the flag-gated paused/waitlist
 * pitch, by mounting <ApplyFlow /> in its standalone (NON-embedded) mode.
 *
 * This replaces the former `/login` popup (`<ApplyDialog>` + `<ApplyFlow embedded />`).
 * Standalone `ApplyFlow` already owns the full-page `<section>` wrapper, the
 * URL step-sync (`/apply/account`, `/apply/verify`, …), `document.title`,
 * popstate handling, resume-on-mount, and the submission logic against the
 * flag-gated `/api/apply/*` worker — so this component is a thin, chrome-level
 * host: App.tsx wraps it with the standard <Header /> + <Footer />, and passes
 * the current `route` so ApplyFlow can resume at the right step from a deep link.
 */
export function ApplyPage({ route = '/apply' }: { route?: string }): JSX.Element {
  useThemeToolsSurface('apply-page');
  return <ApplyFlow route={route} />;
}
