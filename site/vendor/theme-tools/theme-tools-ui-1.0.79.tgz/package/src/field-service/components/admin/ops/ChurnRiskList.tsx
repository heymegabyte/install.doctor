import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useMemo } from 'react';
import type { ChurnRow } from '@theme.tools/crm/field-service/admin-ops-types';

interface Props {
  rows: readonly ChurnRow[];
  title?: string;
}

/**
 * ChurnRiskList — top-N at-risk entities sorted by score desc. Renders the
 * raw signals inline so the operator can see WHY the score is high.
 */
export default function ChurnRiskList({ rows, title = 'Churn risk' }: Props) {
  useThemeToolsSurface('churn-risk-list');
  const sorted = useMemo(() => [...rows].sort((a, b) => b.score - a.score), [rows]);

  if (sorted.length === 0) {
    return (
      <div className="rounded-xl border border-zinc-800 bg-zinc-950 p-6 text-center">
        <p className="text-zinc-400">No churn predictions yet — run /run-churn first.</p>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-950 p-4">
      <h3 className="mb-3 text-sm font-medium uppercase tracking-wide text-zinc-400">{title}</h3>
      <ul className="divide-y divide-zinc-800">
        {sorted.map((row) => (
          <li
            key={row.id}
            className="flex flex-col gap-1 py-3 sm:flex-row sm:items-center sm:gap-4"
          >
            <div className="flex min-w-0 flex-1 items-center gap-3">
              <span className="text-xs uppercase tracking-wide text-zinc-500">
                {row.entity_type}
              </span>
              <span className="truncate font-mono text-sm text-zinc-200">{row.entity_id}</span>
            </div>
            <div className="flex items-center gap-3">
              <RiskBar score={row.score} />
              <span className="w-12 text-right font-mono text-sm tabular-nums text-zinc-100">
                {Math.round(row.score * 100)}%
              </span>
            </div>
            <div className="flex flex-wrap gap-1 sm:max-w-xs sm:justify-end">
              {row.signals.map((sig) => (
                <span
                  key={sig.name}
                  title={`${sig.name}: ${sig.value}`}
                  className="rounded-md border border-zinc-800 bg-zinc-900 px-2 py-0.5 text-xs text-zinc-400"
                >
                  {sig.name}
                </span>
              ))}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function RiskBar({ score }: { score: number }) {
  const pct = Math.max(0, Math.min(100, Math.round(score * 100)));
  const color =
    pct >= 75
      ? 'bg-red-500'
      : pct >= 50
        ? 'bg-orange-500'
        : pct >= 25
          ? 'bg-yellow-500'
          : 'bg-emerald-500';
  return (
    <div className="h-2 w-28 overflow-hidden rounded-full bg-zinc-800" aria-hidden="true">
      <div className={`h-full ${color}`} style={{ width: `${pct}%` }} />
    </div>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
