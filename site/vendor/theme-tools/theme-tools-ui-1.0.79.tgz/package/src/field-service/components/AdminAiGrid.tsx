import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useMemo } from 'react';
import { AgGridReact } from 'ag-grid-react';
import type { ColDef } from 'ag-grid-community';
import { ModuleRegistry, ClientSideRowModelModule, CsvExportModule } from 'ag-grid-community';


import { usd2 } from '@theme.tools/billing/field-service/money';

ModuleRegistry.registerModules([ClientSideRowModelModule, CsvExportModule]);

type Row = Record<string, unknown>;

interface AdminAiGridProps {
  rows: Row[];
  kind: 'bookings' | 'workers' | 'gigs';
}

function formatCents(v: unknown): string {
  if (typeof v !== 'number' || !Number.isFinite(v)) return '—';
  return usd2(v); // grouped — `$1,234.56`, never a commaless "$1234.56"
}

function formatDate(v: unknown): string {
  if (!v || typeof v !== 'string') return '—';
  try {
    return new Date(v).toLocaleString();
  } catch {
    return v;
  }
}

function columnsFor(kind: AdminAiGridProps['kind']): ColDef[] {
  if (kind === 'bookings') {
    return [
      { field: 'id', headerName: 'ID', width: 120, pinned: 'left' },
      {
        field: 'created_at',
        headerName: 'Created',
        valueFormatter: (p) => formatDate(p.value),
        width: 170,
      },
      { field: 'status', headerName: 'Status', width: 130, filter: true },
      { field: 'customer_name', headerName: 'Customer', width: 180, filter: true },
      { field: 'customer_email', headerName: 'Email', width: 220, filter: true },
      { field: 'customer_phone', headerName: 'Phone', width: 140 },
      { field: 'address', headerName: 'Address', width: 220 },
      { field: 'city', headerName: 'City', width: 130, filter: true },
      { field: 'zip', headerName: 'ZIP', width: 90, filter: true },
      { field: 'preferred_date', headerName: 'Date', width: 120 },
      { field: 'preferred_time', headerName: 'Time', width: 100 },
      { field: 'services_csv', headerName: 'Services', width: 180 },
      { field: 'hours', headerName: 'Hours', width: 80, type: 'numericColumn' },
      { field: 'crew', headerName: 'Crew', width: 80, type: 'numericColumn' },
      {
        field: 'total_cents',
        headerName: 'Total',
        valueFormatter: (p) => formatCents(p.value),
        width: 110,
        type: 'numericColumn',
      },
    ];
  }
  if (kind === 'workers') {
    return [
      { field: 'id', headerName: 'ID', width: 120, pinned: 'left' },
      { field: 'status', headerName: 'Status', width: 120, filter: true },
      { field: 'tier', headerName: 'Tier', width: 100, filter: true },
      { field: 'first_name', headerName: 'First', width: 130, filter: true },
      { field: 'last_name', headerName: 'Last', width: 130, filter: true },
      { field: 'phone', headerName: 'Phone', width: 140 },
      { field: 'city', headerName: 'City', width: 130, filter: true },
      { field: 'zip', headerName: 'ZIP', width: 90, filter: true },
      {
        field: 'can_drive',
        headerName: 'Drive',
        width: 90,
        valueFormatter: (p) => (p.value ? 'Yes' : 'No'),
      },
      {
        field: 'rating_avg',
        headerName: 'Rating',
        width: 100,
        type: 'numericColumn',
        valueFormatter: (p) => (typeof p.value === 'number' ? p.value.toFixed(2) : '—'),
      },
      { field: 'completed_jobs', headerName: 'Jobs', width: 90, type: 'numericColumn' },
      {
        field: 'created_at',
        headerName: 'Joined',
        valueFormatter: (p) => formatDate(p.value),
        width: 170,
      },
    ];
  }
  return [
    { field: 'id', headerName: 'ID', width: 120, pinned: 'left' },
    { field: 'booking_id', headerName: 'Booking', width: 130 },
    { field: 'status', headerName: 'Status', width: 130, filter: true },
    { field: 'crew_needed', headerName: 'Need', width: 90, type: 'numericColumn' },
    { field: 'crew_filled', headerName: 'Filled', width: 90, type: 'numericColumn' },
    {
      field: 'start_at',
      headerName: 'Start',
      valueFormatter: (p) => formatDate(p.value),
      width: 170,
    },
    { field: 'service_zip', headerName: 'ZIP', width: 90, filter: true },
    {
      field: 'worker_pay_cents_per_person',
      headerName: 'Pay/person',
      valueFormatter: (p) => formatCents(p.value),
      width: 130,
      type: 'numericColumn',
    },
  ];
}

export default function AdminAiGrid({ rows, kind }: AdminAiGridProps) {
  useThemeToolsSurface('admin-ai-grid');
  const columnDefs = useMemo<ColDef[]>(() => columnsFor(kind), [kind]);
  const defaultColDef = useMemo<ColDef>(
    () => ({ sortable: true, resizable: true, filter: 'agTextColumnFilter', floatingFilter: true }),
    [],
  );

  return (
    <div className="ag-theme-quartz-dark" style={{ width: '100%', height: 520 }}>
      <AgGridReact
        rowData={rows}
        columnDefs={columnDefs}
        defaultColDef={defaultColDef}
        animateRows
        pagination
        paginationPageSize={20}
        paginationPageSizeSelector={[20, 50, 100, 200]}
        rowSelection={{ mode: 'multiRow' }}
        suppressRowClickSelection
        enableCellTextSelection
        ensureDomOrder
      />
    </div>
  );
}
