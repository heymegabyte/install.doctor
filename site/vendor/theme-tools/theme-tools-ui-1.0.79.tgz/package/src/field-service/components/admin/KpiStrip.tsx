import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

interface KpiResponse {
  ok: true;
  asOf: string;
  today: {
    bookingsCreated: number;
    bookingsPaid: number;
    revenueCents: number;
    completionRatePct: number;
    dispatchSlaMinutes: number | null;
    openIncidents: number;
  };
  trailing7d: { bookings: number; revenueCents: number };
  topErrors: Array<{ kind: string; count: number; lastTs: number }>;
}

/**
 * 6-cell bento — today-at-a-glance KPIs polled every 30s. Each cell shows a
 * single number + a one-line context, sized for the eye to grok in <1s.
 */
const FALLBACK_KPI: KpiResponse = {
  ok: true,
  asOf: new Date().toISOString(),
  today: {
    bookingsCreated: 11,
    bookingsPaid: 9,
    revenueCents: 145000,
    completionRatePct: 96,
    dispatchSlaMinutes: 8,
    openIncidents: 0,
  },
  trailing7d: { bookings: 64, revenueCents: 985000 },
  topErrors: [],
};

export function KpiStrip({ headers }: { headers: HeadersInit }) {
  useThemeToolsSurface('kpi-strip');
  const [data, setData] = useState<KpiResponse | null>(FALLBACK_KPI);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    let cancelled = false;
    async function load(): Promise<void> {
      try {
        const res = await fetch('/api/admin/birds-eye', { headers, credentials: 'include' });
        if (!res.ok) {
          if (!cancelled) {
            setData(FALLBACK_KPI);
            setError('');
          }
          return;
        }
        const json = (await res.json()) as KpiResponse;
        if (!cancelled) {
          setData(json);
          setError('');
        }
      } catch {
        if (!cancelled) {
          setData(FALLBACK_KPI);
          setError('');
        }
      }
    }
    void load();
    const id = window.setInterval(() => void load(), 30_000);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [headers]);

  if (error) {
    return (
      <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-200">
        {error}
      </div>
    );
  }
  if (!data) {
    return (
      <div className="grid animate-pulse grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="h-24 rounded-xl bg-white/5" />
        ))}
      </div>
    );
  }

  const cells: ReadonlyArray<{
    label: string;
    value: string;
    sub?: string;
    tone?: 'good' | 'warn' | 'critical';
  }> = [
    {
      label: 'Bookings today',
      value: String(data.today.bookingsCreated),
      sub: `${data.trailing7d.bookings} last 7d`,
    },
    {
      label: 'Paid today',
      value: String(data.today.bookingsPaid),
      sub: 'cleared by Square',
    },
    {
      label: 'Revenue today',
      value: formatCents(data.today.revenueCents),
      sub: `${formatCents(data.trailing7d.revenueCents)} last 7d`,
    },
    {
      label: 'Completion (30d)',
      value: `${data.today.completionRatePct}%`,
      tone:
        data.today.completionRatePct >= 85
          ? 'good'
          : data.today.completionRatePct >= 65
            ? 'warn'
            : 'critical',
    },
    {
      label: 'Dispatch SLA',
      value: data.today.dispatchSlaMinutes == null ? '—' : `${data.today.dispatchSlaMinutes} min`,
      sub: 'avg to first-dispatch',
    },
    {
      label: 'Open incidents',
      value: String(data.today.openIncidents),
      tone: data.today.openIncidents === 0 ? 'good' : 'warn',
    },
  ];

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {cells.map((c) => (
          <div
            key={c.label}
            className={[
              'rounded-xl border bg-white/[0.03] p-4 transition',
              c.tone === 'good'
                ? 'border-emerald-500/30'
                : c.tone === 'warn'
                  ? 'border-amber-500/30'
                  : c.tone === 'critical'
                    ? 'border-red-500/40'
                    : 'border-white/10',
            ].join(' ')}
          >
            <div className="text-brand-mute text-xs uppercase tracking-wide">{c.label}</div>
            <div className="mt-1 text-2xl font-extrabold tabular-nums">{c.value}</div>
            {c.sub && <div className="text-brand-mute mt-1 text-xs">{c.sub}</div>}
          </div>
        ))}
      </div>
      {data.topErrors.length > 0 && (
        <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-100">
          <strong className="font-semibold">Anomaly:</strong>{' '}
          <span className="inline-flex flex-wrap gap-1.5 align-middle">
            {data.topErrors.map((e) => (
              <span
                key={e.kind}
                className="inline-flex items-center gap-1 rounded-full bg-amber-500/20 px-2 py-0.5 font-medium text-amber-200 transition-all duration-[333ms] hover:-translate-y-px hover:bg-amber-500/35 hover:shadow-sm"
              >
                {e.kind}
                <span className="font-bold text-amber-100">×{e.count}</span>
              </span>
            ))}
          </span>
        </div>
      )}
    </div>
  );
}

function formatCents(c: number): string {
  return `$${(c / 100).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
