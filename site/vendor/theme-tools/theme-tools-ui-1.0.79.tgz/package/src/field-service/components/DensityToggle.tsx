import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useCallback, useEffect, useState } from 'react';
import { useRovingRadio } from '../use-roving-radio.js';

export type Density = 'compact' | 'comfortable';

const STORAGE_KEY = 'bcl_density';

/**
 * Write `data-density` onto `<html>` so opt-in components can adjust their
 * row padding / spacing via plain CSS, e.g.
 *
 *   [data-density='compact'] .card-row { padding: 0.5rem }
 *
 * No global CSS resets ship with this scaffold — each consumer adds its own
 * per-component hooks incrementally.
 */
function applyDensity(d: Density): void {
  if (typeof document === 'undefined') return;
  document.documentElement.setAttribute('data-density', d);
}

function readStored(): Density {
  if (typeof window === 'undefined') return 'comfortable';
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw === 'compact' || raw === 'comfortable') return raw;
  } catch {
    /* noop */
  }
  return 'comfortable';
}

const OPTIONS: Array<{ value: Density; label: string; sub: string }> = [
  { value: 'compact', label: 'Compact', sub: 'Tight rows' },
  { value: 'comfortable', label: 'Comfortable', sub: 'Roomy rows' },
];

/**
 * Two-option density toggle (Compact / Comfortable). Default is
 * `comfortable`. Persists to `localStorage[bcl_density]` and writes
 * `<html data-density>`. Pair with per-component CSS for the actual
 * spacing change.
 *
 * @example
 *   <DensityToggle />
 */
export function DensityToggle(): JSX.Element {
  useThemeToolsSurface('density-toggle');
  const [density, setDensity] = useState<Density>(() => readStored());

  useEffect(() => {
    applyDensity(density);
    try {
      window.localStorage.setItem(STORAGE_KEY, density);
    } catch {
      /* noop */
    }
  }, [density]);

  const pick = useCallback((d: Density) => () => setDensity(d), []);
  // ARIA roving-tabindex: single tab stop + arrow/Home/End move selection (axe-blind).
  const densityRadio = useRovingRadio(OPTIONS.length, (i) => setDensity(OPTIONS[i]!.value));

  return (
    <div
      role="radiogroup"
      aria-label="Row density"
      className="inline-flex items-center gap-0.5 rounded-lg border border-brand-line bg-bg-elevated p-0.5"
    >
      {OPTIONS.map((opt, i) => {
        const active = density === opt.value;
        return (
          <button
            key={opt.value}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={pick(opt.value)}
            {...densityRadio(i, active)}
            className={`flex flex-col items-start rounded-md px-2.5 py-1 text-left transition-colors ${active ? 'bg-brand-accent/15 text-brand-accent' : 'text-brand-mute hover:text-brand-ink'}`}
          >
            <span className="text-xs font-semibold leading-tight">{opt.label}</span>
            <span className="text-[10px] leading-tight opacity-70">{opt.sub}</span>
          </button>
        );
      })}
    </div>
  );
}
