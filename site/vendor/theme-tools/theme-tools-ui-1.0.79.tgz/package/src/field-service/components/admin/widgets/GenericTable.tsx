import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { WidgetShell, tinyTable } from './WidgetShell.js';

/**
 * Generic fetch-then-table widget used by simple widgets that just render a
 * single result key. The `pickRows` function pulls the array out of the JSON
 * response (defaults to looking for common keys: rows, items, list, etc.).
 */
export function GenericTable({
  title,
  endpoint,
  adminKey,
  emptyText = 'No data yet.',
  pickRows,
}: {
  title: string;
  endpoint: string;
  adminKey: string;
  emptyText?: string;
  pickRows?: (data: Record<string, unknown>) => Array<Record<string, unknown>> | null;
}) {
  return (
    <WidgetShell
      title={title}
      endpoint={endpoint}
      adminKey={adminKey}
      render={(raw) => {
        const d = (raw ?? {}) as Record<string, unknown>;
        if (d.empty) return <p style={{ color: '#888' }}>{emptyText}</p>;
        const rows = pickRows ? pickRows(d) : autoPickRows(d);
        if (!rows || rows.length === 0) return <p style={{ color: '#888' }}>{emptyText}</p>;
        return tinyTable(rows);
      }}
    />
  );
}

function autoPickRows(d: Record<string, unknown>): Array<Record<string, unknown>> | null {
  const candidates = [
    'rows',
    'items',
    'list',
    'workers',
    'bookings',
    'reviews',
    'reviews',
    'queue',
    'samples',
    'results',
    'channels',
    'events',
    'tags',
    'segments',
    'checks',
    'certs',
    'queries',
    'mentions',
    'ranks',
    'backlinks',
    'competitors',
    'stages',
    'modules',
    'recommendations',
    'praise',
    'escalations',
    'slots',
    'requests',
    'holding',
    'funnel',
    'arms',
    'days',
    'vitals',
    'by_status',
    'errors',
    'cloud',
    'groups',
    'leads',
    'jobs',
    'sources',
    'customers',
    'cohorts',
    'replays',
    'reports',
    'breakdown',
    'cohorts',
  ];
  for (const k of candidates) {
    if (Array.isArray(d[k])) return d[k] as Array<Record<string, unknown>>;
  }
  return null;
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
