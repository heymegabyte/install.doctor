import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { GenericTable } from './GenericTable.js';
export default function LeadToQuoteLatency({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('lead-to-quote-latency');
  return (
    <GenericTable
      title="Lead → quote latency"
      endpoint="/lead-to-quote-latency"
      adminKey={adminKey}
    />
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
