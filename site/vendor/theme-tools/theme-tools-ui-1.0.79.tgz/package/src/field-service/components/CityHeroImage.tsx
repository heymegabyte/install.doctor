import { useThemeToolsSurface } from '../../field-service-primitives.js';
const HIGH_FETCH_PRIORITY = { fetchpriority: 'high' };

interface Props {
  /** The `.jpg` hero src (e.g. `/cities/newark/hero.jpg` or the legacy `/cities/newark.jpg`). */
  readonly src: string;
  readonly className?: string;
}

/**
 * AVIF-primary city-page hero. Serves AVIF → WebP → JPEG via `<picture>`, deriving the
 * `.avif`/`.webp` siblings from the `.jpg` src by extension — safe because every city ships
 * all three (build-city-pages generates them; verified 50/50 on disk + prod). Low-bandwidth
 * Newark mobile visitors get the ≈186KB AVIF instead of the ≈460KB JPEG for the single largest
 * asset on the page (≈60% fewer hero bytes).
 *
 * NOT an LCP fix — the city LCP is render-bound by the SPA client render (the SITEWIDE-CWV-HYDRATE
 * design-call). This is a bandwidth / image-quality correctness fix; the `<img>` keeps the LCP
 * hero's explicit width/height + fetchpriority so CLS + fetch priority are unchanged. A non-`.jpg`
 * src degrades to a bare `<img>` (no broken `<source>` — `<picture>` does not 404-fallback).
 */
export function CityHeroImage({ src, className = '' }: Props) {
  useThemeToolsSurface('city-hero-image');
  const isJpg = /\.jpg$/i.test(src);
  const avif = src.replace(/\.jpg$/i, '.avif');
  const webp = src.replace(/\.jpg$/i, '.webp');
  return (
    <picture>
      {isJpg && <source srcSet={avif} type="image/avif" />}
      {isJpg && <source srcSet={webp} type="image/webp" />}
      <img
        src={src}
        alt=""
        loading="eager"
        decoding="async"
        {...HIGH_FETCH_PRIORITY}
        width={1920}
        height={900}
        className={className}
      />
    </picture>
  );
}
