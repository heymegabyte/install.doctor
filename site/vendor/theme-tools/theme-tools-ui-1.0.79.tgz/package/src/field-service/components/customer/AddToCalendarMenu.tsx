import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useRovingMenu } from '../../use-roving-menu.js';
import { menuTriggerOpensOn } from '@theme.tools/i18n-a11y/field-service/menu-keynav';

/**
 * AddToCalendarMenu — dropdown button on /me/booking/<id> letting the
 * customer add their booking to Apple Calendar / Google Calendar / Outlook.
 *
 * Apple route: downloads the .ics blob from `/api/ics-calendar-invites/<id>.ics`
 *              via an `<a download>` anchor (Safari/iOS compatible — direct
 *              `window.location.assign(blob)` treats it as nav on iOS).
 * Google:      fetches `/api/ics-calendar-invites/<id>/google` for the
 *              template URL + opens in a new tab.
 * Outlook:     fetches `/api/ics-calendar-invites/<id>/outlook` for the
 *              deeplink + opens in a new tab.
 *
 * Flag: `ics_calendar_invites` — when off, every endpoint 404s and the
 * dropdown renders nothing (`useEffect` probe; component returns null).
 */

interface Props {
  bookingId: string;
  className?: string;
  /** Optional label override for the trigger. */
  label?: string;
}

type Provider = 'apple' | 'google' | 'outlook';

const PROVIDER_LABELS: Record<Provider, string> = {
  apple: 'Apple Calendar',
  google: 'Google Calendar',
  outlook: 'Outlook',
};

export function AddToCalendarMenu(props: Props): JSX.Element | null {
  useThemeToolsSurface('add-to-calendar-menu');
  const { bookingId, className = '', label = 'Add to calendar' } = props;
  const [open, setOpen] = useState(false);
  const [available, setAvailable] = useState<boolean | null>(null);
  const [busy, setBusy] = useState<Provider | null>(null);
  const [error, setError] = useState<string>('');
  const menuRef = useRef<HTMLDivElement | null>(null);
  const triggerRef = useRef<HTMLButtonElement | null>(null);

  // ARIA menu roving-tabindex: 3 providers, one tab stop, arrow/Home/End move
  // focus, first item focused on open. axe can't detect this interaction gap.
  const menuItem = useRovingMenu(3, open);

  // Probe once whether the feature is on (404 from any endpoint = flag off).
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch(
          `/api/ics-calendar-invites/${encodeURIComponent(bookingId)}/google`,
          { credentials: 'include' },
        );
        if (cancelled) return;
        // 404 = flag off (or booking not yours), hide the menu either way.
        // 401 = user not signed in but feature is on → still show the menu;
        // the actual download will retry the auth.
        setAvailable(res.status !== 404);
      } catch {
        if (!cancelled) setAvailable(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [bookingId]);

  // Close on outside click / Escape.
  useEffect(() => {
    if (!open) return;
    function onClick(e: MouseEvent): void {
      if (!menuRef.current?.contains(e.target as Node)) setOpen(false);
    }
    function onKey(e: KeyboardEvent): void {
      // APG menu-button: Escape closes the menu AND returns focus to the
      // trigger — otherwise the focused role="menuitem" unmounts and focus
      // falls to <body>, dropping a keyboard user's place (WCAG 2.4.3).
      if (e.key === 'Escape') {
        setOpen(false);
        triggerRef.current?.focus();
      }
    }
    document.addEventListener('mousedown', onClick);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onClick);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const downloadApple = useCallback(async (): Promise<void> => {
    setBusy('apple');
    setError('');
    try {
      const res = await fetch(
        `/api/ics-calendar-invites/${encodeURIComponent(bookingId)}.ics`,
        { credentials: 'include' },
      );
      if (res.status === 401) {
        setError('Sign in to download your calendar invite.');
        return;
      }
      if (!res.ok) {
        setError('Could not generate the invite. Try again.');
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `booking-${bookingId}.ics`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setOpen(false);
    } catch {
      setError('Network error. Try again.');
    } finally {
      setBusy(null);
    }
  }, [bookingId]);

  const openProviderUrl = useCallback(
    async (provider: 'google' | 'outlook'): Promise<void> => {
      setBusy(provider);
      setError('');
      try {
        const res = await fetch(
          `/api/ics-calendar-invites/${encodeURIComponent(bookingId)}/${provider}`,
          { credentials: 'include' },
        );
        if (res.status === 401) {
          setError('Sign in to add the booking to your calendar.');
          return;
        }
        if (!res.ok) {
          setError('Could not open the calendar link. Try again.');
          return;
        }
        const json = (await res.json()) as {
          ok: boolean;
          result?: { url: string };
        };
        if (!json.ok || !json.result?.url) {
          setError('Could not open the calendar link. Try again.');
          return;
        }
        window.open(json.result.url, '_blank', 'noopener,noreferrer');
        setOpen(false);
      } catch {
        setError('Network error. Try again.');
      } finally {
        setBusy(null);
      }
    },
    [bookingId],
  );

  if (available === false) return null;

  return (
    <div ref={menuRef} className={`relative inline-block ${className}`}>
      <button
        ref={triggerRef}
        type="button"
        onClick={() => setOpen((v) => !v)}
        onKeyDown={(e) => {
          // APG menu-button: ArrowDown/ArrowUp open the menu (useRovingMenu then
          // moves focus to the first item on open). Enter/Space open natively.
          if (menuTriggerOpensOn(e.key)) {
            e.preventDefault();
            setOpen(true);
          }
        }}
        className="rounded-lg bg-slate-800 px-3 py-1.5 text-sm font-medium text-slate-100 ring-1 ring-slate-700 hover:bg-slate-700"
        aria-haspopup="menu"
        aria-expanded={open}
        aria-controls={`add-to-calendar-menu-${bookingId}`}
        data-bcl-add-to-calendar={bookingId}
      >
        {label}
        <span className="ml-2 text-xs text-slate-400" aria-hidden="true">
          ▾
        </span>
      </button>

      {open && (
        <div
          id={`add-to-calendar-menu-${bookingId}`}
          role="menu"
          className="absolute right-0 z-50 mt-1 w-48 overflow-hidden rounded-lg bg-slate-900 shadow-xl ring-1 ring-slate-700"
        >
          <button
            type="button"
            role="menuitem"
            onClick={() => void downloadApple()}
            disabled={busy !== null}
            className="block w-full px-3 py-2 text-left text-sm text-slate-200 transition-all duration-[333ms] hover:bg-slate-800 focus-visible:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brand-accent disabled:opacity-50"
            data-bcl-calendar-provider="apple"
            {...menuItem(0)}
          >
            {busy === 'apple' ? 'Preparing…' : PROVIDER_LABELS.apple}
          </button>
          <button
            type="button"
            role="menuitem"
            onClick={() => void openProviderUrl('google')}
            disabled={busy !== null}
            className="block w-full px-3 py-2 text-left text-sm text-slate-200 transition-all duration-[333ms] hover:bg-slate-800 focus-visible:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brand-accent disabled:opacity-50"
            data-bcl-calendar-provider="google"
            {...menuItem(1)}
          >
            {busy === 'google' ? 'Opening…' : PROVIDER_LABELS.google}
          </button>
          <button
            type="button"
            role="menuitem"
            onClick={() => void openProviderUrl('outlook')}
            disabled={busy !== null}
            className="block w-full px-3 py-2 text-left text-sm text-slate-200 transition-all duration-[333ms] hover:bg-slate-800 focus-visible:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brand-accent disabled:opacity-50"
            data-bcl-calendar-provider="outlook"
            {...menuItem(2)}
          >
            {busy === 'outlook' ? 'Opening…' : PROVIDER_LABELS.outlook}
          </button>
        </div>
      )}

      {error && (
        <p role="alert" className="mt-1 text-xs text-red-300">
          {error}
        </p>
      )}
    </div>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
