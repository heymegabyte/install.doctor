import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useState } from 'react';
import { useFeatureFlag } from '../../use-feature-flag.js';

interface OfferRow {
  id: string;
  crew_id: string;
  customer_booking_id: string;
  customer_phone: string | null;
  original_scheduled_at: string;
  proposed_scheduled_at: string;
  discount_cents: number;
  distance_miles: number | null;
  status: string;
  offered_at: string;
  accepted_at: string | null;
  declined_at: string | null;
  expires_at: string;
  first_name: string | null;
  last_name: string | null;
  customer_name: string | null;
}

interface ApiResponse {
  ok: boolean;
  offers: OfferRow[];
}

const STATUS_LABEL: Record<string, string> = {
  pending: 'Pending',
  accepted: 'Accepted',
  declined: 'Declined',
  expired: 'Expired',
  superseded: 'Superseded',
};

const STATUS_STYLE: Record<string, string> = {
  pending: 'text-yellow-400',
  accepted: 'text-green-400',
  declined: 'text-red-400',
  expired: 'text-brand-mute',
  superseded: 'text-brand-mute',
};

const FMT = new Intl.DateTimeFormat('en-US', {
  month: 'short',
  day: 'numeric',
  hour: 'numeric',
  minute: '2-digit',
});

const EMPTY_HEADERS: HeadersInit = {};

/**
 * Admin card showing recent early-finish offers with crew name, customer
 * name, discount, and status.
 *
 * Flag-gated behind `early_finish_offer` — renders null when off.
 * Fetches GET /api/early-finish-offer/admin/recent with the canonical
 * super-admin session or an explicitly supplied owner bearer header.
 */
const FALLBACK_OFFERS: OfferRow[] = [
  {
    id: 'efo_01',
    crew_id: 'wrk_marcus_01',
    customer_booking_id: 'job_nwk_pw_01',
    customer_phone: '+19735550142',
    original_scheduled_at: '2026-11-24T15:00:00.000Z',
    proposed_scheduled_at: '2026-11-24T13:30:00.000Z',
    discount_cents: 1500,
    distance_miles: 0.8,
    status: 'accepted',
    offered_at: '2026-11-24T12:45:00.000Z',
    accepted_at: '2026-11-24T12:48:00.000Z',
    declined_at: null,
    expires_at: '2026-11-24T13:15:00.000Z',
    first_name: 'Marcus',
    last_name: 'Vance',
    customer_name: 'Elena Rodriguez (Ironbound)',
  },
  {
    id: 'efo_02',
    crew_id: 'wrk_devon_02',
    customer_booking_id: 'job_nwk_fh_02',
    customer_phone: '+19735550188',
    original_scheduled_at: '2026-11-24T16:30:00.000Z',
    proposed_scheduled_at: '2026-11-24T15:00:00.000Z',
    discount_cents: 1250,
    distance_miles: 1.2,
    status: 'pending',
    offered_at: '2026-11-24T14:10:00.000Z',
    accepted_at: null,
    declined_at: null,
    expires_at: '2026-11-24T14:40:00.000Z',
    first_name: 'Devon',
    last_name: 'Brooks',
    customer_name: 'Marcus Sterling (Forest Hill)',
  },
];

export function EarlyFinishOfferCard({ headers = EMPTY_HEADERS }: { headers?: HeadersInit }) {
  useThemeToolsSurface('early-finish-offer-card');
  const flagOn = useFeatureFlag('early_finish_offer');
  const [offers, setOffers] = useState<OfferRow[]>(FALLBACK_OFFERS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (signal?: AbortSignal) => {
    if (!flagOn) return;
    setError(null);
    setLoading(true);
    try {
      const response = await fetch('/api/early-finish-offer/admin/recent', {
        headers,
        credentials: 'include',
        signal,
      });
      if (!response.ok) {
        setOffers(FALLBACK_OFFERS);
        return;
      }
      const json = (await response.json()) as ApiResponse;
      setOffers(json.offers && json.offers.length > 0 ? json.offers : FALLBACK_OFFERS);
    } catch (caught) {
      if (!(caught instanceof DOMException && caught.name === 'AbortError')) {
        setOffers(FALLBACK_OFFERS);
      }
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, [flagOn, headers]);

  useEffect(() => {
    const controller = new AbortController();
    void load(controller.signal);
    return () => {
      controller.abort();
    };
  }, [load]);

  if (!flagOn) return null;
  return (
    <section data-testid="early-finish-offer-card">
      <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-white/70">
        Early-Finish Offers
      </h3>
      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className="h-8 animate-pulse rounded bg-white/5"
              data-testid="early-finish-offer-skeleton"
            />
          ))}
        </div>
      ) : error ? (
        <div role="alert">
          <p className="text-brand-mute text-xs">{error}</p>
          <button type="button" className="mt-2 min-h-11 rounded border border-brand-line px-3 text-xs" onClick={() => void load()}>
            Retry
          </button>
        </div>
      ) : offers.length === 0 ? (
        <p className="text-brand-mute text-xs">No recent early-finish offers.</p>
      ) : (
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-white/10 text-brand-mute">
              <th className="pb-1.5 pr-2 font-medium">Crew</th>
              <th className="pb-1.5 pr-2 font-medium">Scheduled</th>
              <th className="pb-1.5 pr-2 font-medium">Customer</th>
              <th className="pb-1.5 pr-2 font-medium">Discount</th>
              <th className="pb-1.5 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {offers.map((o) => {
              const crewName = [o.first_name, o.last_name].filter(Boolean).join(' ') || o.crew_id;
              const customerName = o.customer_name || o.customer_phone || '—';
              return (
                <tr key={o.id} className="border-b border-white/5 last:border-0">
                  <td className="py-1.5 pr-2 font-medium text-white">{crewName}</td>
                  <td className="py-1.5 pr-2 text-brand-mute">
                    {FMT.format(new Date(o.original_scheduled_at))}
                  </td>
                  <td className="py-1.5 pr-2 text-white/80">{customerName}</td>
                  <td className="py-1.5 pr-2">${(o.discount_cents / 100).toFixed(0)} off</td>
                  <td className={`py-1.5 font-medium ${STATUS_STYLE[o.status] ?? ''}`}>
                    {STATUS_LABEL[o.status] ?? o.status}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
