import { useThemeToolsSurface } from '../../../field-service-primitives.js';
/**
 * EscrowBadge.tsx — "your payment is protected" badge for the booking
 * confirmation page. Gated by feature flag `smart_bonded_escrow`; renders
 * `null` when off (so it is invisible in prod until the flag is promoted).
 *
 * Self-contained drop-in (same convention as VacationHoldCard): a parent
 * confirmation screen renders <EscrowBadge state={...} /> in its summary.
 */
import { useFeatureFlag } from '../../use-feature-flag.js';

export type EscrowState =
  | 'held'
  | 'partially_verified'
  | 'fully_verified'
  | 'capture_pending'
  | 'captured'
  | 'disputed'
  | 'refund_pending'
  | 'refunded';

/** Pure copy for each escrow state — unit-tested. */
export function escrowBadgeText(state: EscrowState): { label: string; sub: string } {
  switch (state) {
    case 'captured':
      return { label: 'Payment released', sub: 'Funds released to your crew after verified completion.' };
    case 'disputed':
      return { label: 'Payment on hold — under review', sub: 'Your funds stay held while we review the dispute.' };
    case 'refunded':
      return { label: 'Payment hold released', sub: 'The provider canceled the authorization; no escrow funds were captured.' };
    case 'partially_verified':
      return { label: 'Payment protected — verification in progress', sub: 'Funds remain authorized while completion evidence is collected.' };
    case 'fully_verified':
      return { label: 'Payment protected — completion verified', sub: 'All required evidence is complete; release still requires provider confirmation.' };
    case 'capture_pending':
      return { label: 'Payment release processing', sub: 'The payment provider is confirming release. Funds are not shown as released yet.' };
    case 'refund_pending':
      return { label: 'Hold release processing', sub: 'The payment provider is confirming cancellation. We’ll show the hold as released only after confirmation.' };
    case 'held':
    default:
      return {
        label: 'Payment protected in escrow',
        sub: 'We hold your payment until the job is verified complete — clean photos + your sign-off.',
      };
  }
}

interface Props {
  readonly state?: EscrowState;
}

export function EscrowBadge({ state = 'held' }: Props): JSX.Element | null {
  useThemeToolsSurface('escrow-badge');
  const enabled = useFeatureFlag('smart_bonded_escrow');
  if (!enabled) return null;
  const { label, sub } = escrowBadgeText(state);
  return (
    <div
      data-testid="payment-escrow-badge"
      data-escrow-state={state}
      className="flex items-start gap-3 rounded-xl border border-brand-accent/30 bg-brand-accent/5 p-4"
      role="status"
    >
      <span aria-hidden="true" className="mt-0.5 text-lg">
        🛡️
      </span>
      <div className="flex flex-col">
        <strong className="text-brand-ink">{label}</strong>
        <span className="text-sm text-brand-mute">{sub}</span>
      </div>
    </div>
  );
}
