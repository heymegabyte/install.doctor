import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { CONTAINER_SPECS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { useState } from 'react';
import { track } from '../../analytics.js';
import { SmsConsentDisclosure } from '../SmsConsentDisclosure.js';

// Idea #12 — Contact-lock before price reveal.
// We capture name + email + phone (no card) before showing the full quote
// breakdown. The form is intentionally tiny: three inputs, one button,
// no Turnstile (server-side rate limiting + Turnstile re-runs on the
// real submission later). Replaces nothing in the existing Booking.tsx
// state model — it just gates the inline price reveal until the user
// has identified themselves.

export interface ContactLockValues {
  readonly firstName: string;
  readonly lastName: string;
  readonly email: string;
  readonly phone: string;
}

export interface ContactLockProps {
  readonly initial?: Partial<ContactLockValues>;
  readonly onUnlock: (next: ContactLockValues) => void;
  readonly compact?: boolean;
  /** Preview total in cents — shown blurred behind the gate as social proof. */
  readonly previewTotalCents?: number;
}

const EMAIL_RX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_DIGIT_RX = /\D/g;

function digitsOnly(s: string): string {
  return s.replace(PHONE_DIGIT_RX, '');
}

function isValid(v: ContactLockValues): boolean {
  if (v.firstName.trim().length < 2) return false;
  if (v.lastName.trim().length < 1) return false;
  if (!EMAIL_RX.test(v.email.trim())) return false;
  if (digitsOnly(v.phone).length < 10) return false;
  return true;
}

/**
 * Renders an inline gate. When valid + submitted, calls `onUnlock`. Parent
 * stores the values and never shows this component again for the session.
 */
export function ContactLock({
  initial,
  onUnlock,
  compact = false,
  previewTotalCents,
}: ContactLockProps): JSX.Element {
  useThemeToolsSurface('contact-lock');
  const [values, setValues] = useState<ContactLockValues>({
    firstName: initial?.firstName ?? '',
    lastName: initial?.lastName ?? '',
    email: initial?.email ?? '',
    phone: initial?.phone ?? '',
  });
  const [touched, setTouched] = useState(false);
  const ok = isValid(values);

  function field<K extends keyof ContactLockValues>(key: K, next: string) {
    setValues((v) => ({ ...v, [key]: next }));
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setTouched(true);
    if (!ok) return;
    track('booking_contact_unlocked', {
      email_domain: values.email.split('@')[1] ?? '',
    });
    onUnlock(values);
  }

  const blurredTotal =
    typeof previewTotalCents === 'number' && previewTotalCents > 0
      ? `$${Math.round(previewTotalCents / 100)}`
      : null;

  return (
    <form
      onSubmit={submit}
      data-bcl-contact-lock
      className={[
        'rounded-2xl border border-brand-accent/30 bg-bg-elevated/70 backdrop-blur-sm',
        compact ? 'p-4' : 'p-5 sm:p-6',
      ].join(' ')}
      aria-labelledby="bcl-contact-lock-title"
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-widest text-brand-accent">
            One step
          </p>
          <h3 id="bcl-contact-lock-title" className="mt-1 font-display text-xl font-extrabold">
            Tell me where to send the quote.
          </h3>
          <p className="mt-1 text-sm text-brand-mute">
            No card. No spam. Your quote unlocks the moment you hit go.
          </p>
        </div>
        {blurredTotal && (
          <div className="select-none rounded-lg border border-brand-line bg-bg-primary px-3 py-2 text-right">
            <div className="text-[10px] uppercase tracking-wider text-brand-mute">Estimate</div>
            <div className="font-display text-2xl font-extrabold text-brand-accent blur-sm">
              {blurredTotal}
            </div>
          </div>
        )}
      </div>

      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
        <label className="block">
          <span className="block text-xs font-mono uppercase tracking-wider text-brand-mute mb-1">
            First name
          </span>
          <input
            type="text"
            autoComplete="given-name"
            value={values.firstName}
            onChange={(e) => field('firstName', e.target.value)}
            className="w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-brand-ink focus:border-brand-accent focus:outline-none"
            required
            minLength={2}
          />
        </label>
        <label className="block">
          <span className="block text-xs font-mono uppercase tracking-wider text-brand-mute mb-1">
            Last name
          </span>
          <input
            type="text"
            autoComplete="family-name"
            value={values.lastName}
            onChange={(e) => field('lastName', e.target.value)}
            className="w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-brand-ink focus:border-brand-accent focus:outline-none"
            required
            minLength={1}
          />
        </label>
        <label className="block">
          <span className="block text-xs font-mono uppercase tracking-wider text-brand-mute mb-1">
            Email
          </span>
          <input
            type="email"
            autoComplete="email"
            inputMode="email"
            value={values.email}
            onChange={(e) => field('email', e.target.value)}
            className="w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-brand-ink focus:border-brand-accent focus:outline-none"
            required
          />
        </label>
        <label className="block">
          <span className="block text-xs font-mono uppercase tracking-wider text-brand-mute mb-1">
            Mobile phone
          </span>
          <input
            type="tel"
            autoComplete="tel"
            inputMode="tel"
            placeholder="(555) 555-5555"
            value={values.phone}
            onChange={(e) => field('phone', e.target.value)}
            className="w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-brand-ink focus:border-brand-accent focus:outline-none"
            required
          />
        </label>
      </div>

      {touched && !ok && (
        <p
          role="alert"
          className="mt-3 rounded-md border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs text-amber-200"
        >
          Fill all four fields with a real email + 10-digit US phone.
        </p>
      )}

      <button
        type="submit"
        disabled={!ok}
        className="mt-4 w-full rounded-lg bg-brand-accent px-4 py-3 font-display text-base font-bold text-bg-primary hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50"
      >
        Show my quote →
      </button>
      <p className="mt-2 text-center text-[11px] text-brand-mute">
        Insured · We text once with your quote
      </p>
      <SmsConsentDisclosure className="mt-2 text-center" />
    </form>
  );
}
export const THEME_TOOLS_CONTAINER_SPECS_COUNT = Object.keys(CONTAINER_SPECS).length;
