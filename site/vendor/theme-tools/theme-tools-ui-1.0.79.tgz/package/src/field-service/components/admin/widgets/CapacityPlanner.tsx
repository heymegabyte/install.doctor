import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { WidgetShell, bigNumber } from './WidgetShell.js';

export default function CapacityPlanner({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('capacity-planner');
  return (
    <WidgetShell
      title="Capacity planner (30d)"
      endpoint="/capacity-planner"
      adminKey={adminKey}
      render={(raw) => {
        const d = raw as { upcoming_30d?: number; target?: number; gap?: number; note?: string };
        return bigNumber(
          'upcoming / target',
          `${d.upcoming_30d ?? 0} / ${d.target ?? 0}`,
          d.note ?? '',
        );
      }}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
