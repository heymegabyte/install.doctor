import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * §13e — full customer account editor.
 *
 * Every booking-mirrorable field is editable: first/last name, business
 * name, email, phone, primary address, latest service address, business
 * address, display name, birthday, timezone, avatar. Email + phone changes
 * route through a confirmation flow (POST /verify-start → POST
 * /verify-confirm) — the field is marked "Unverified" until confirmed.
 *
 * The card also exposes the irreversible "Delete account" flow (2-tap
 * confirm + typed phrase) and the "Transfer to a different email/phone"
 * flow (sends a code to the new contact, atomically re-points sessions +
 * bookings on confirm).
 *
 * Optimistic UI: the local `profile` state is the source of truth after
 * the first GET; PATCHes apply locally first and roll back on error.
 */
interface CustomerProfile {
  displayName: string | null;
  birthday: string | null;
  tz: string | null;
  avatarUrl: string | null;
  firstName: string | null;
  lastName: string | null;
  businessName: string | null;
  email: string | null;
  phone: string | null;
  address: string | null;
  latestAddress: string | null;
  businessAddress: string | null;
  emailVerified: boolean;
  phoneVerified: boolean;
  pendingEmail: string | null;
  pendingPhone: string | null;
  deletedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

interface ProfileResponse {
  ok: boolean;
  contact: string;
  channel: 'sms' | 'email';
  profile: CustomerProfile | null;
}

interface AvatarUploadResponse {
  ok: boolean;
  avatarUrl: string | null;
  sizeBytes?: number;
  mime?: string;
  error?: string;
}

interface PatchResponse {
  ok: boolean;
  error?: string;
}

interface VerifyStartResponse {
  ok: boolean;
  expiresAt?: string;
  pending?: string;
  error?: string;
}

interface TransferStartResponse {
  ok: boolean;
  expiresAt?: string;
  newContact?: string;
  error?: string;
}

const TZ_OPTIONS = [
  'America/New_York',
  'America/Chicago',
  'America/Denver',
  'America/Los_Angeles',
  'America/Anchorage',
  'Pacific/Honolulu',
] as const;

interface CustomerProfileCardProps {
  /** Fired after a destructive flow (delete/transfer) so the parent can log out. */
  readonly onAccountChange?: () => void;
}

export function CustomerProfileCard({
  onAccountChange,
}: CustomerProfileCardProps = {}): JSX.Element {
  useThemeToolsSurface('customer-profile-card');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');
  const [contact, setContact] = useState<string>('');
  const [channel, setChannel] = useState<'sms' | 'email'>('sms');
  const [profile, setProfile] = useState<CustomerProfile | null>(null);
  const [saving, setSaving] = useState(false);
  const [avatarUploading, setAvatarUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Verify flow state — open one drawer at a time.
  const [verifyField, setVerifyField] = useState<'email' | 'phone' | null>(null);
  const [verifyPending, setVerifyPending] = useState<string>('');
  const [verifyCode, setVerifyCode] = useState<string>('');
  const [verifyStage, setVerifyStage] = useState<'idle' | 'sent' | 'confirmed'>('idle');

  // Transfer flow state.
  const [transferOpen, setTransferOpen] = useState(false);
  const [transferNewContact, setTransferNewContact] = useState('');
  const [transferStage, setTransferStage] = useState<'idle' | 'sent'>('idle');
  const [transferCode, setTransferCode] = useState('');

  // Delete flow.
  const [deleteStage, setDeleteStage] = useState<'idle' | 'arming' | 'typing'>('idle');
  const [deletePhrase, setDeletePhrase] = useState('');

  const refresh = useCallback(async () => {
    try {
      const res = await fetch('/api/customer/profile', { credentials: 'include' });
      if (res.status === 401) {
        setError('Sign in to manage your profile.');
        setLoading(false);
        return;
      }
      if (res.status === 410) {
        // Soft-deleted while open — bounce to logout.
        onAccountChange?.();
        return;
      }
      const json = (await res.json()) as ProfileResponse;
      setContact(json.contact);
      setChannel(json.channel);
      setProfile(json.profile);
      // Auto-detect timezone if the customer hasn't set one yet — the IANA
      // string from Intl.DateTimeFormat is the same shape D1 stores.
      if (json.profile && !json.profile.tz) {
        try {
          const detected = Intl.DateTimeFormat().resolvedOptions().timeZone;
          if (detected) void updateField('tz', detected);
        } catch {
          /* older browsers without Intl tz support — skip */
        }
      }
    } catch {
      setError('Could not load your profile. Try again.');
    } finally {
      setLoading(false);
    }
  }, [onAccountChange]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const patchProfile = useCallback(async (patch: Partial<CustomerProfile>) => {
    const res = await fetch('/api/customer/profile', {
      method: 'PATCH',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    });
    const json = (await res.json().catch(() => ({}))) as PatchResponse;
    if (!res.ok || !json.ok) throw new Error(json.error ?? 'Could not save.');
  }, []);

  /**
   * Generic optimistic field updater — apply locally, PATCH in the
   * background, roll back on error. Email + phone use a different code path
   * (verify flow), so they're rejected here defensively.
   */
  const updateField = useCallback(
    async (key: keyof CustomerProfile, value: string | null) => {
      if (key === 'email' || key === 'phone') return;
      if (!profile) return;
      if ((profile[key] ?? '') === (value ?? '')) return;
      const prior = profile;
      setSaving(true);
      setError('');
      setProfile({
        ...profile,
        [key]: value,
        updatedAt: new Date().toISOString(),
      } as CustomerProfile);
      try {
        await patchProfile({ [key]: value } as Partial<CustomerProfile>);
      } catch (e) {
        setProfile(prior);
        setError((e as Error).message);
      } finally {
        setSaving(false);
      }
    },
    [profile, patchProfile],
  );

  const onAvatarChange = useCallback(async (file: File) => {
    if (file.size > 5 * 1024 * 1024) {
      setError('Avatar must be under 5 MB.');
      return;
    }
    setAvatarUploading(true);
    setError('');
    try {
      const form = new FormData();
      form.append('file', file);
      const res = await fetch('/api/customer/profile/avatar', {
        method: 'POST',
        credentials: 'include',
        body: form,
      });
      const json = (await res.json().catch(() => ({}))) as AvatarUploadResponse;
      if (!res.ok || !json.ok) throw new Error(json.error ?? 'Upload failed.');
      setProfile((p) =>
        p ? { ...p, avatarUrl: json.avatarUrl, updatedAt: new Date().toISOString() } : p,
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setAvatarUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  }, []);

  const verifyStart = useCallback(async (field: 'email' | 'phone', newValue: string) => {
    setError('');
    try {
      const res = await fetch('/api/customer/profile/verify-start', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ field, newValue }),
      });
      const json = (await res.json().catch(() => ({}))) as VerifyStartResponse;
      if (!res.ok || !json.ok) throw new Error(json.error ?? 'Could not send code.');
      setVerifyPending(json.pending ?? newValue);
      setVerifyStage('sent');
    } catch (e) {
      setError((e as Error).message);
    }
  }, []);

  const verifyConfirm = useCallback(async () => {
    if (!verifyField) return;
    setError('');
    try {
      const res = await fetch('/api/customer/profile/verify-confirm', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ field: verifyField, code: verifyCode }),
      });
      const json = (await res.json().catch(() => ({}))) as PatchResponse;
      if (!res.ok || !json.ok) throw new Error(json.error ?? 'Invalid code.');
      setVerifyStage('confirmed');
      await refresh();
      // Auto-close after a short beat so the success state is visible.
      setTimeout(() => {
        setVerifyField(null);
        setVerifyPending('');
        setVerifyCode('');
        setVerifyStage('idle');
      }, 1200);
    } catch (e) {
      setError((e as Error).message);
    }
  }, [verifyField, verifyCode, refresh]);

  const transferStart = useCallback(async () => {
    setError('');
    try {
      const res = await fetch('/api/customer/profile/transfer-start', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newContact: transferNewContact }),
      });
      const json = (await res.json().catch(() => ({}))) as TransferStartResponse;
      if (!res.ok || !json.ok) throw new Error(json.error ?? 'Could not send code.');
      setTransferNewContact(json.newContact ?? transferNewContact);
      setTransferStage('sent');
    } catch (e) {
      setError((e as Error).message);
    }
  }, [transferNewContact]);

  const transferConfirm = useCallback(async () => {
    setError('');
    try {
      const res = await fetch('/api/customer/profile/transfer-confirm', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: transferCode }),
      });
      const json = (await res.json().catch(() => ({}))) as PatchResponse;
      if (!res.ok || !json.ok) throw new Error(json.error ?? 'Invalid code.');
      // Session was re-pointed on the server — trigger a parent logout so a
      // fresh /me bootstraps under the new contact.
      onAccountChange?.();
    } catch (e) {
      setError((e as Error).message);
    }
  }, [transferCode, onAccountChange]);

  const deleteAccount = useCallback(async () => {
    setError('');
    try {
      const res = await fetch('/api/customer/account', {
        method: 'DELETE',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ confirm: 'DELETE MY ACCOUNT' }),
      });
      const json = (await res.json().catch(() => ({}))) as PatchResponse;
      if (!res.ok || !json.ok) throw new Error(json.error ?? 'Could not delete.');
      onAccountChange?.();
    } catch (e) {
      setError((e as Error).message);
    }
  }, [onAccountChange]);

  if (loading) {
    return (
      <div
        className="rounded-lg border border-brand-line bg-brand-card p-6 text-brand-mute"
        aria-busy="true"
      >
        Loading profile…
      </div>
    );
  }

  const displayInitial = (profile?.firstName || profile?.displayName || contact || '?')
    .slice(0, 1)
    .toUpperCase();
  const displayEmail = profile?.email ?? (channel === 'email' ? contact : '');
  const displayPhone = profile?.phone ?? (channel === 'sms' ? contact : '');

  return (
    <section
      className="rounded-lg border border-brand-line bg-brand-card p-6"
      aria-labelledby="customer-profile-heading"
    >
      <h2 id="customer-profile-heading" className="text-lg font-semibold text-brand-ink mb-1">
        Your account
      </h2>
      <p className="text-brand-mute text-sm mb-4">
        Edit any field. Changes to email or phone need a one-time confirmation code.
      </p>

      <div className="flex items-center gap-4 mb-6">
        {profile?.avatarUrl ? (
          <img
            src={profile.avatarUrl}
            alt={profile.displayName ?? 'Your avatar'}
            className="w-16 h-16 shrink-0 rounded-full object-cover border border-brand-line"
          />
        ) : (
          <div
            aria-hidden="true"
            className="w-16 h-16 shrink-0 rounded-full bg-brand-line/40 flex items-center justify-center text-2xl font-bold text-brand-ink"
          >
            {displayInitial}
          </div>
        )}
        <div className="min-w-0 flex-1">
          <label className="text-brand-mute text-xs font-medium block mb-1" htmlFor="avatar-input">
            Profile picture
          </label>
          <input
            id="avatar-input"
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp,image/heic"
            disabled={avatarUploading}
            onChange={(e) => {
              const f = e.currentTarget.files?.[0];
              if (f) void onAvatarChange(f);
            }}
            className="w-full max-w-full text-sm text-brand-mute"
          />
          {avatarUploading && (
            <p className="text-xs text-brand-mute mt-1" aria-live="polite">
              Uploading…
            </p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
        <DebouncedTextField
          label="First name"
          value={profile?.firstName ?? ''}
          maxLength={60}
          onCommit={(v) => void updateField('firstName', v || null)}
        />
        <DebouncedTextField
          label="Last name"
          value={profile?.lastName ?? ''}
          maxLength={60}
          onCommit={(v) => void updateField('lastName', v || null)}
        />
        <DebouncedTextField
          label="Display name"
          value={profile?.displayName ?? ''}
          maxLength={80}
          placeholder="How the crew should greet you"
          onCommit={(v) => void updateField('displayName', v || null)}
        />
        <DebouncedTextField
          label="Business name (optional)"
          value={profile?.businessName ?? ''}
          maxLength={120}
          onCommit={(v) => void updateField('businessName', v || null)}
        />
      </div>

      <fieldset className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
        <legend className="sr-only">Contact details</legend>
        <VerifiableField
          label="Email"
          value={displayEmail}
          verified={profile?.emailVerified ?? false}
          pending={profile?.pendingEmail ?? null}
          onChangeRequest={() => {
            setVerifyField('email');
            setVerifyPending('');
            setVerifyCode('');
            setVerifyStage('idle');
            setError('');
          }}
        />
        <VerifiableField
          label="Phone"
          value={displayPhone}
          verified={profile?.phoneVerified ?? false}
          pending={profile?.pendingPhone ?? null}
          onChangeRequest={() => {
            setVerifyField('phone');
            setVerifyPending('');
            setVerifyCode('');
            setVerifyStage('idle');
            setError('');
          }}
        />
      </fieldset>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
        <DebouncedTextField
          label="Primary address"
          value={profile?.address ?? ''}
          maxLength={240}
          onCommit={(v) => void updateField('address', v || null)}
        />
        <DebouncedTextField
          label="Business address (optional)"
          value={profile?.businessAddress ?? ''}
          maxLength={240}
          onCommit={(v) => void updateField('businessAddress', v || null)}
        />
        <label className="block">
          <span className="text-brand-mute text-xs font-medium block mb-1">
            Birthday (optional)
          </span>
          <input
            type="date"
            value={profile?.birthday ?? ''}
            onChange={(e) => void updateField('birthday', e.currentTarget.value || null)}
            className="w-full rounded-md border border-brand-line bg-brand-bg p-2 text-sm text-brand-ink"
          />
        </label>
      </div>

      <label className="block mb-4">
        <span className="text-brand-mute text-xs font-medium block mb-1">Timezone</span>
        <select
          value={profile?.tz ?? 'America/New_York'}
          onChange={(e) => void updateField('tz', e.currentTarget.value)}
          className="rounded-md border border-brand-line bg-brand-bg p-2 text-sm text-brand-ink"
        >
          {TZ_OPTIONS.map((tz) => (
            <option key={tz} value={tz}>
              {tz}
            </option>
          ))}
        </select>
      </label>

      {saving && (
        <p className="text-xs text-brand-mute mb-2" aria-live="polite">
          Saving…
        </p>
      )}
      {error && (
        <p className="mt-2 mb-4 text-sm text-red-300" role="alert">
          {error}
        </p>
      )}

      {/* Verify drawer */}
      {verifyField && (
        <div className="mt-6 rounded-xl border border-brand-accent/40 bg-brand-accent/5 p-4 space-y-3">
          <h3 className="font-extrabold text-brand-ink">
            {verifyStage === 'confirmed'
              ? `New ${verifyField} confirmed`
              : `Confirm new ${verifyField}`}
          </h3>
          {verifyStage === 'idle' && (
            <>
              <p className="text-xs text-brand-mute">
                Enter the new {verifyField}. We&apos;ll send a 6-digit code to it before saving.
              </p>
              <input
                type={verifyField === 'email' ? 'email' : 'tel'}
                value={verifyPending}
                onChange={(e) => setVerifyPending(e.currentTarget.value)}
                placeholder={verifyField === 'email' ? 'you@example.com' : '(555) 555-1212'}
                className="w-full rounded-md border border-brand-line bg-brand-bg p-2 text-sm text-brand-ink"
                autoFocus
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => void verifyStart(verifyField, verifyPending)}
                  disabled={verifyPending.trim().length < 3}
                  className="btn btn-primary text-sm px-4 disabled:opacity-50"
                >
                  Send code
                </button>
                <button
                  type="button"
                  onClick={() => setVerifyField(null)}
                  className="rounded-md border border-brand-line px-3 py-1.5 text-sm text-brand-mute hover:text-brand-ink"
                >
                  Cancel
                </button>
              </div>
            </>
          )}
          {verifyStage === 'sent' && (
            <>
              <p className="text-xs text-brand-mute">
                Code sent to <strong className="text-brand-ink">{verifyPending}</strong>. Expires in
                10 minutes.
              </p>
              <input
                type="text"
                inputMode="numeric"
                pattern="\d{6}"
                maxLength={6}
                value={verifyCode}
                onChange={(e) =>
                  setVerifyCode(e.currentTarget.value.replace(/\D/g, '').slice(0, 6))
                }
                placeholder="123456"
                className="w-32 rounded-md border border-brand-line bg-brand-bg p-2 text-center font-mono text-base tracking-widest text-brand-ink"
                autoFocus
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => void verifyConfirm()}
                  disabled={verifyCode.length !== 6}
                  className="btn btn-primary text-sm px-4 disabled:opacity-50"
                >
                  Confirm
                </button>
                <button
                  type="button"
                  onClick={() => void verifyStart(verifyField, verifyPending)}
                  className="rounded-md border border-brand-line px-3 py-1.5 text-sm text-brand-mute hover:text-brand-ink"
                >
                  Resend
                </button>
                <button
                  type="button"
                  onClick={() => setVerifyField(null)}
                  className="rounded-md border border-brand-line px-3 py-1.5 text-sm text-brand-mute hover:text-brand-ink"
                >
                  Cancel
                </button>
              </div>
            </>
          )}
          {verifyStage === 'confirmed' && <p className="text-sm text-emerald-300">Saved.</p>}
        </div>
      )}

      {/* Transfer + delete row */}
      <div className="mt-8 border-t border-brand-line pt-6 grid gap-4 sm:grid-cols-2">
        <section className="rounded-xl border border-brand-line bg-brand-bg/40 p-4">
          <h3 className="font-extrabold text-brand-ink mb-1">Transfer account</h3>
          <p className="text-xs text-brand-mute mb-3">
            Move every booking + session to a new email or phone. The new contact gets a 6-digit
            code; nothing changes until it&apos;s confirmed.
          </p>
          {!transferOpen ? (
            <button
              type="button"
              onClick={() => {
                setTransferOpen(true);
                setTransferStage('idle');
                setTransferNewContact('');
                setTransferCode('');
              }}
              className="rounded-md border border-brand-line px-3 py-1.5 text-sm text-brand-ink hover:border-brand-accent"
            >
              Start transfer
            </button>
          ) : transferStage === 'idle' ? (
            <div className="space-y-2">
              <input
                type="text"
                value={transferNewContact}
                onChange={(e) => setTransferNewContact(e.currentTarget.value)}
                placeholder="New email or phone"
                className="w-full rounded-md border border-brand-line bg-brand-bg p-2 text-sm text-brand-ink"
                autoFocus
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => void transferStart()}
                  disabled={transferNewContact.trim().length < 3}
                  className="btn btn-primary text-sm px-4 disabled:opacity-50"
                >
                  Send code
                </button>
                <button
                  type="button"
                  onClick={() => setTransferOpen(false)}
                  className="rounded-md border border-brand-line px-3 py-1.5 text-sm text-brand-mute hover:text-brand-ink"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <p className="text-xs text-brand-mute">
                Code sent to <strong className="text-brand-ink">{transferNewContact}</strong>.
              </p>
              <input
                type="text"
                inputMode="numeric"
                pattern="\d{6}"
                maxLength={6}
                value={transferCode}
                onChange={(e) =>
                  setTransferCode(e.currentTarget.value.replace(/\D/g, '').slice(0, 6))
                }
                placeholder="123456"
                className="w-32 rounded-md border border-brand-line bg-brand-bg p-2 text-center font-mono text-base tracking-widest text-brand-ink"
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => void transferConfirm()}
                  disabled={transferCode.length !== 6}
                  className="btn btn-primary text-sm px-4 disabled:opacity-50"
                >
                  Confirm transfer
                </button>
                <button
                  type="button"
                  onClick={() => setTransferOpen(false)}
                  className="rounded-md border border-brand-line px-3 py-1.5 text-sm text-brand-mute hover:text-brand-ink"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </section>

        <section className="rounded-xl border border-red-500/40 bg-red-500/5 p-4">
          <h3 className="font-extrabold text-red-200 mb-1">Delete account</h3>
          <p className="text-xs text-red-200/80 mb-3">
            Permanently delete your account, cancel every active booking, and clear every session.
            This cannot be undone.
          </p>
          {deleteStage === 'idle' && (
            <button
              type="button"
              onClick={() => setDeleteStage('arming')}
              className="rounded-md border border-red-500/40 bg-red-500/10 px-3 py-1.5 text-sm text-red-100 hover:bg-red-500/20"
            >
              Irreversibly delete account
            </button>
          )}
          {deleteStage === 'arming' && (
            <div className="space-y-2">
              <p className="text-xs text-red-200">
                Are you sure? Tap again to type the confirmation phrase.
              </p>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setDeleteStage('typing')}
                  className="rounded-md border border-red-500/60 bg-red-500/20 px-3 py-1.5 text-sm text-red-50 hover:bg-red-500/30"
                >
                  Yes, I&apos;m sure
                </button>
                <button
                  type="button"
                  onClick={() => setDeleteStage('idle')}
                  className="rounded-md border border-brand-line px-3 py-1.5 text-sm text-brand-mute hover:text-brand-ink"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
          {deleteStage === 'typing' && (
            <div className="space-y-2">
              <p className="text-xs text-red-200">
                Type <code className="font-mono text-red-100">DELETE MY ACCOUNT</code> to confirm.
              </p>
              <input
                type="text"
                value={deletePhrase}
                onChange={(e) => setDeletePhrase(e.currentTarget.value)}
                className="w-full rounded-md border border-red-500/40 bg-brand-bg p-2 font-mono text-sm text-brand-ink"
                autoFocus
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => void deleteAccount()}
                  disabled={deletePhrase !== 'DELETE MY ACCOUNT'}
                  className="rounded-md border border-red-500/60 bg-red-500/30 px-3 py-1.5 text-sm text-red-50 hover:bg-red-500/40 disabled:opacity-50"
                >
                  Delete forever
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setDeleteStage('idle');
                    setDeletePhrase('');
                  }}
                  className="rounded-md border border-brand-line px-3 py-1.5 text-sm text-brand-mute hover:text-brand-ink"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </section>
      </div>
    </section>
  );
}

/**
 * Text field that commits on blur (or Enter) so each keystroke doesn't fire
 * a PATCH. Pure-text fields use this; the verified ones use a different
 * pattern.
 */
function DebouncedTextField({
  label,
  value,
  maxLength,
  placeholder,
  onCommit,
}: {
  readonly label: string;
  readonly value: string;
  readonly maxLength: number;
  readonly placeholder?: string;
  readonly onCommit: (next: string) => void;
}): JSX.Element {
  const [draft, setDraft] = useState(value);
  useEffect(() => setDraft(value), [value]);
  return (
    <label className="block">
      <span className="text-brand-mute text-xs font-medium block mb-1">{label}</span>
      <input
        type="text"
        value={draft}
        maxLength={maxLength}
        placeholder={placeholder}
        onChange={(e) => setDraft(e.currentTarget.value)}
        onBlur={() => {
          if (draft.trim() !== value.trim()) onCommit(draft.trim());
        }}
        onKeyDown={(e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            (e.currentTarget as HTMLInputElement).blur();
          }
        }}
        className="w-full rounded-md border border-brand-line bg-brand-bg p-2 text-sm text-brand-ink"
      />
    </label>
  );
}

/**
 * Read-only display of a verified contact field with a "Change" button that
 * pops the verify drawer above.
 */
function VerifiableField({
  label,
  value,
  verified,
  pending,
  onChangeRequest,
}: {
  readonly label: string;
  readonly value: string;
  readonly verified: boolean;
  readonly pending: string | null;
  readonly onChangeRequest: () => void;
}): JSX.Element {
  return (
    <div className="block">
      <span className="text-brand-mute text-xs font-medium block mb-1">{label}</span>
      <div className="flex items-center gap-2">
        <div className="flex-1 rounded-md border border-brand-line bg-brand-bg/60 p-2 text-sm text-brand-ink truncate">
          {value || <span className="text-brand-mute">Not set</span>}
        </div>
        <button
          type="button"
          onClick={onChangeRequest}
          className="rounded-md border border-brand-line px-3 py-2 text-xs text-brand-ink hover:border-brand-accent"
        >
          Change
        </button>
      </div>
      <p className="text-[11px] mt-1">
        {verified ? (
          <span className="text-emerald-300">Verified ✓</span>
        ) : (
          <span className="text-yellow-300">Unverified</span>
        )}
        {pending && <span className="text-brand-mute"> · pending: {pending}</span>}
      </p>
    </div>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
