import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { evaluateHourlyLaborPricingStandard } from '@theme.tools/billing/hourly-labor-pricing';
import { useCallback, useEffect, useState } from 'react';
import { instantPayoutFeeCents } from '@theme.tools/billing/field-service/instant-payout-fee';

/**
 * Worker-initiated Instant Payout card. Wires to
 * `POST /api/work/payouts/connect/instant`. Discloses the 1.5% fee (no floor,
 * capped $1.50) up front and previews the net amount before the worker
 * confirms.
 *
 * Toggle UX:
 *   1. Worker sees their available balance + a slider/input for the amount.
 *   2. We render the fee + net side-by-side as the worker changes the amount.
 *   3. "Send now" performs the POST; on success we surface the Stripe payout
 *      id + arrival date estimate. Stripe Instant Payouts arrive within
 *      minutes for eligible debit cards.
 */

interface ConnectStatusPayload {
  ok: true;
  state: 'not_started' | 'in_progress' | 'needs_action' | 'restricted' | 'active';
  account: {
    payoutsEnabled: boolean;
  } | null;
  fees: {
    instantPct: number;
    instantMinCents: number;
    instantCapCents: number;
  };
}

interface InstantSuccess {
  payoutId: string;
  amountCents: number;
  feeCents: number;
  arrivalDate: number | null;
}

const MIN_CENTS = 1000;

/**
 * Pure helper used by both the live preview and the unit tests. Delegates to
 * the ONE canonical schedule (`shared/instant-payout-fee.ts`): 1.5%, no floor,
 * cap $1.50 — identical to the worker charge, so the previewed net == charged net.
 */
export function computeFeeForUi(amountCents: number): number {
  return instantPayoutFeeCents(amountCents);
}

export function InstantPayoutOptIn(): JSX.Element {
  useThemeToolsSurface('instant-payout-opt-in');
  const [status, setStatus] = useState<ConnectStatusPayload | null>(null);
  const [amountInput, setAmountInput] = useState<string>('');
  const [busy, setBusy] = useState(false);
  const [success, setSuccess] = useState<InstantSuccess | null>(null);
  const [err, setErr] = useState('');

  const load = useCallback(async () => {
    try {
      const res = await fetch('/api/work/payouts/connect/status', {
        credentials: 'same-origin',
      });
      if (!res.ok) return;
      const payload = (await res.json()) as ConnectStatusPayload;
      setStatus(payload);
    } catch {
      /* noop */
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const amountCents = (() => {
    const n = Number(amountInput);
    if (!Number.isFinite(n) || n <= 0) return 0;
    return Math.round(n * 100);
  })();
  const feeCents = computeFeeForUi(amountCents);
  const netCents = Math.max(0, amountCents - feeCents);
  const tooLow = amountCents > 0 && amountCents < MIN_CENTS;

  async function sendInstant(): Promise<void> {
    if (amountCents < MIN_CENTS) return;
    setBusy(true);
    setErr('');
    setSuccess(null);
    try {
      const res = await fetch('/api/work/payouts/connect/instant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amountCents }),
        credentials: 'same-origin',
      });
      const payload = (await res.json()) as InstantSuccess & {
        ok?: boolean;
        error?: string;
      };
      if (!res.ok) {
        setErr(payload.error ? labelError(payload.error) : `Failed (${res.status})`);
        return;
      }
      setSuccess({
        payoutId: payload.payoutId,
        amountCents: payload.amountCents,
        feeCents: payload.feeCents,
        arrivalDate: payload.arrivalDate ?? null,
      });
      setAmountInput('');
    } catch {
      setErr('Network error — try again.');
    } finally {
      setBusy(false);
    }
  }

  if (!status) {
    return (
      <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-white/70">
        Loading instant payout…
      </div>
    );
  }

  if (status.state !== 'active' || !status.account?.payoutsEnabled) {
    return (
      <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-white/70">
        Finish Stripe onboarding above to unlock Instant Payouts.
      </div>
    );
  }

  return (
    <section
      className="rounded-2xl border border-emerald-500/30 bg-emerald-500/5 p-6"
      aria-labelledby="instant-payout-heading"
    >
      <header className="flex items-center justify-between gap-3">
        <h3 id="instant-payout-heading" className="text-base font-semibold text-white">
          Instant Payout
        </h3>
        <span className="text-xs uppercase tracking-wide text-white/60">1.5% fee · capped $1.50</span>
      </header>

      <p className="mt-3 text-sm text-white/80">
        Cash out within minutes to your debit card. Fee is 1.5% of the amount, capped at $1.50 —
        Brick Labor absorbs it on payouts under $100. Standard payouts (free) arrive in 2 business
        days.
      </p>

      <label className="mt-4 block text-sm text-white/85">
        Amount to cash out
        <div className="mt-1 flex items-center gap-2">
          <span className="text-white/60">$</span>
          <input
            type="number"
            min={10}
            step={1}
            value={amountInput}
            onChange={(e) => setAmountInput(e.target.value)}
            placeholder="50"
            inputMode="decimal"
            className="w-32 rounded-md border border-white/10 bg-white/10 px-2 py-1 text-sm text-white outline-none focus:border-emerald-300"
            aria-describedby="instant-payout-min"
          />
        </div>
      </label>
      <p id="instant-payout-min" className="mt-1 text-xs text-white/60">
        Minimum $10.00.
      </p>

      {amountCents > 0 && (
        <dl className="mt-3 grid grid-cols-2 gap-3 text-sm text-white/85">
          <div>
            <dt className="text-xs uppercase tracking-wide text-white/60">Fee</dt>
            <dd className="mt-0.5">−${(feeCents / 100).toFixed(2)}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-white/60">Net to your card</dt>
            <dd className="mt-0.5 text-emerald-300">${(netCents / 100).toFixed(2)}</dd>
          </div>
        </dl>
      )}

      {tooLow && <p className="mt-2 text-xs text-amber-300">Minimum Instant Payout is $10.00.</p>}

      <button
        type="button"
        onClick={sendInstant}
        disabled={busy || amountCents < MIN_CENTS}
        className="mt-4 inline-flex items-center rounded-md bg-emerald-500 px-4 py-2 text-sm font-semibold text-emerald-950 hover:bg-emerald-400 disabled:opacity-60"
      >
        {busy ? 'Sending…' : `Send $${(netCents / 100).toFixed(2)} now`}
      </button>

      {success && (
        <div
          role="status"
          className="mt-3 rounded-md border border-emerald-500/40 bg-emerald-500/15 px-3 py-2 text-sm text-emerald-100"
        >
          Payout {success.payoutId.slice(0, 12)}… is on its way. Fee was $
          {(success.feeCents / 100).toFixed(2)}.{' '}
          {success.arrivalDate
            ? `Expected by ${new Date(success.arrivalDate * 1000).toLocaleTimeString()}.`
            : 'Arrives within minutes.'}
        </div>
      )}

      {err && <p className="mt-3 text-sm text-red-300">{err}</p>}
    </section>
  );
}

function labelError(code: string): string {
  switch (code) {
    case 'unauthorized':
      return 'Session expired — sign in again.';
    case 'no_account':
      return 'Finish Stripe onboarding first.';
    case 'payouts_disabled':
      return 'Your Stripe account is not active yet.';
    case 'below_minimum':
      return 'Minimum $10.00.';
    case 'rate_limited':
      return 'Hit the hourly limit. Try again in a bit.';
    case 'stripe_failed':
      return 'Stripe rejected the payout. Check your card in the dashboard.';
    case 'stripe_not_configured':
      return 'Payouts are temporarily unavailable.';
    default:
      return `Error: ${code}`;
  }
}
export const THEME_TOOLS_HOURLY_STANDARD = evaluateHourlyLaborPricingStandard({ crewSize: 1, hours: 1 });
