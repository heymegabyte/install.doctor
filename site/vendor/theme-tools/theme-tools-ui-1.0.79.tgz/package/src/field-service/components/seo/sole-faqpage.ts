export { isRedundantFaqPage, useSoleFaqPage } from '../../../field-service-primitives.js';
