import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useCallback, useEffect, useState } from 'react';
import { JsonLd } from './seo/index.js';

const TITLE = 'Refer a friend — earn $25 credit · Brick Labor';
const DESC =
  'Send a friend to Brick Labor. They get $25 off their first booking; you get $25 credit on your next move. Newark NJ hourly property crew.';

interface Referral {
  id: string;
  code: string;
  credit_cents: number;
  status: 'pending' | 'redeemed' | 'credited' | 'expired' | 'void';
  redeemed_by_booking_id: string | null;
  redeemed_at: string | null;
  credited_at: string | null;
  expires_at: string | null;
  created_at: string;
}

interface MeResponse {
  ok: boolean;
  referrals: Referral[];
  totals: {
    pending: number;
    redeemed: number;
    credited: number;
    totalCreditCents: number;
  };
}

type LoadState =
  | { kind: 'loading' }
  | { kind: 'anonymous' }
  | { kind: 'error'; message: string }
  | { kind: 'ready'; data: MeResponse };

/**
 * /refer — customer-refers-customer credit hub. Logged-in customers (cookie
 * bcl_cust_sid) see their unique code, can copy it, and watch their credit
 * accumulate as referees complete moves. Anonymous visitors get a sign-in
 * prompt that bounces to /login?next=/refer.
 *
 * On first visit for a logged-in customer we POST /api/customer-referrals/mint
 * which is idempotent — the same customer always sees the same code.
 */
/**
 * Error panel for the referral page — the message PLUS a one-click "Try again"
 * (error-recovery mandate: every error state offers a retry, not just a dead message
 * that forces a full manual reload). Pure/presentational so it's unit-testable in the
 * repo's node env via static markup (the live error state is effect-driven and never
 * reached during SSR of the whole page).
 */
export function ReferralErrorPanel({
  message,
  onRetry,
}: {
  readonly message: string;
  readonly onRetry: () => void;
}): JSX.Element {
  return (
    <div
      role="alert"
      className="mt-8 rounded-lg border border-brand-err/40 bg-brand-err/10 p-4 text-sm text-brand-err"
    >
      <p>{message}</p>
      <button
        type="button"
        onClick={onRetry}
        className="btn-secondary mt-3 inline-flex min-h-[44px] items-center"
        data-bcl-action="referral_retry"
      >
        Try again
      </button>
    </div>
  );
}

export function CustomerReferralPage(): JSX.Element {
  useThemeToolsSurface('customer-referral-page');
  useEffect(() => {
    document.title = TITLE;
    setMeta('description', DESC);
    setLink('canonical', 'https://bricklabor.com/refer');
    setMeta('robots', 'index,follow', 'name');
    setMeta('og:title', TITLE, 'property');
    setMeta('og:description', DESC, 'property');
    setMeta('og:url', 'https://bricklabor.com/refer', 'property');
  }, []);

  const [state, setState] = useState<LoadState>({ kind: 'loading' });
  const [copied, setCopied] = useState(false);

  const load = useCallback(async () => {
    try {
      const meRes = await fetch('/api/customer-referrals/me', {
        credentials: 'include',
        headers: { accept: 'application/json' },
      });
      if (meRes.status === 401) {
        setState({ kind: 'anonymous' });
        return;
      }
      if (!meRes.ok) {
        setState({ kind: 'error', message: `Couldn't load your credits (HTTP ${meRes.status}).` });
        return;
      }
      let data = (await meRes.json()) as MeResponse;
      if (data.referrals.length === 0) {
        // No code yet — mint one. Idempotent server-side.
        const mintRes = await fetch('/api/customer-referrals/mint', {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: '{}',
        });
        if (mintRes.ok) {
          const reload = await fetch('/api/customer-referrals/me', {
            credentials: 'include',
            headers: { accept: 'application/json' },
          });
          if (reload.ok) data = (await reload.json()) as MeResponse;
        }
      }
      setState({ kind: 'ready', data });
    } catch (err) {
      // Error tracked via Sentry
      setState({ kind: 'error', message: 'Network hiccup. Try again in a minute.' });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const primary =
    state.kind === 'ready'
      ? (state.data.referrals.find((r) => r.status !== 'expired' && r.status !== 'void') ??
        state.data.referrals[0])
      : undefined;
  const shareLink = primary
    ? `https://bricklabor.com/book?ref=${encodeURIComponent(primary.code)}`
    : '';

  async function copyCode() {
    if (!primary) return;
    try {
      await navigator.clipboard.writeText(primary.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  }

  return (
    <article className="section">
      <div className="container-pad max-w-4xl">
        <p className="eyebrow mb-3">Refer a friend</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold">
          Send a friend. Earn <span className="text-brand-accent">$50</span> on your next move.
        </h1>
        <p className="mt-4 text-lg text-brand-mute max-w-2xl">
          They get $25 off their first Brick Labor booking. When their move completes, $50
          lands on your account — apply it to your next move automatically at checkout.
        </p>

        {state.kind === 'loading' && (
          <p className="mt-8 text-brand-mute" role="status">
            Loading your credit hub…
          </p>
        )}

        {state.kind === 'error' && (
          <ReferralErrorPanel message={state.message} onRetry={() => void load()} />
        )}

        {state.kind === 'anonymous' && (
          <div className="mt-8 card max-w-xl">
            <h2 className="text-xl font-extrabold">Sign in to grab your code</h2>
            <p className="mt-2 text-brand-mute">
              Your referral code is tied to your account so we know who to credit. Sign in with the
              email or phone you booked with.
            </p>
            <a href="/login?next=%2Frefer" className="btn-primary mt-4 inline-block">
              Sign in →
            </a>
          </div>
        )}

        {state.kind === 'ready' && primary && (
          <>
            <section className="mt-8 grid gap-4 sm:grid-cols-3">
              <Stat
                label="Pending"
                value={String(state.data.totals.pending)}
                helper="Codes waiting to be used"
              />
              <Stat
                label="Redeemed"
                value={String(state.data.totals.redeemed)}
                helper="Friends who've booked"
              />
              <Stat
                label="Earned"
                value={formatDollars(state.data.totals.totalCreditCents)}
                helper="Lifetime credit"
                accent
              />
            </section>

            <section className="mt-8 card">
              <h2 className="text-xl font-extrabold">Your code</h2>
              <p className="mt-2 text-brand-mute">
                Share this code (or the link) anywhere — text, Slack, email. Friend enters it at
                booking; you both earn.
              </p>
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <code className="rounded-lg border border-brand-accent/40 bg-brand-accent/5 px-4 py-2 text-2xl font-extrabold tracking-wider text-brand-accent">
                  {primary.code}
                </code>
                <button type="button" onClick={copyCode} className="btn-secondary">
                  {copied ? 'Copied ✓' : 'Copy code'}
                </button>
                <a
                  href={`sms:?&body=${encodeURIComponent(
                    `Use my Brick Labor code ${primary.code} for $25 off your first move: ${shareLink}`,
                  )}`}
                  className="btn-secondary"
                >
                  Share via SMS
                </a>
                <a
                  href={`mailto:?subject=${encodeURIComponent(
                    'Try Brick Labor — $25 off',
                  )}&body=${encodeURIComponent(
                    `I used Brick Labor in Newark and they were great. Use my code ${primary.code} for $25 off your first move: ${shareLink}`,
                  )}`}
                  className="btn-secondary"
                >
                  Share via email
                </a>
              </div>
              <p className="mt-3 text-sm text-brand-mute break-all">
                Or share this link:{' '}
                <a href={shareLink} className="text-brand-accent underline-hover">
                  {shareLink}
                </a>
              </p>
              {primary.expires_at && (
                <p className="mt-2 text-[12px] text-brand-mute">
                  Code expires{' '}
                  {new Date(primary.expires_at).toLocaleDateString('en-US', {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                  })}
                  .
                </p>
              )}
            </section>

            {state.data.referrals.length > 1 && (
              <section className="mt-8">
                <h2 className="text-xl font-extrabold">History</h2>
                <ul className="mt-3 space-y-2">
                  {state.data.referrals.map((r) => (
                    <li
                      key={r.id}
                      className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-brand-line bg-bg-elevated/40 p-3 text-sm"
                    >
                      <span className="font-mono text-brand-ink">{r.code}</span>
                      <span className="text-brand-mute">
                        {r.status === 'credited'
                          ? `Credited ${formatDollars(r.credit_cents)} on ${formatDate(r.credited_at)}`
                          : r.status === 'redeemed'
                            ? `Redeemed ${formatDate(r.redeemed_at)} — pending move completion`
                            : r.status === 'pending'
                              ? 'Pending — share to earn'
                              : r.status === 'expired'
                                ? 'Expired'
                                : 'Void'}
                      </span>
                    </li>
                  ))}
                </ul>
              </section>
            )}
          </>
        )}

        <section className="mt-12 rounded-xl border border-brand-line p-6 bg-bg-elevated/40">
          <h2 className="text-xl font-extrabold">How it works</h2>
          <ol className="mt-3 space-y-2 text-brand-mute leading-relaxed">
            <li>
              <strong className="text-brand-ink">1.</strong> Share your code or link.
            </li>
            <li>
              <strong className="text-brand-ink">2.</strong> Your friend enters the code on the{' '}
              <a href="/book" className="text-brand-accent underline-hover">
                booking form
              </a>
              . They see $25 off applied.
            </li>
            <li>
              <strong className="text-brand-ink">3.</strong> When their move completes, your $25
              credit lands automatically.
            </li>
            <li>
              <strong className="text-brand-ink">4.</strong> Apply credit to your next booking —
              just check the "use my credit" box at checkout.
            </li>
          </ol>
        </section>
      </div>

      <JsonLd
        data={{
          '@context': 'https://schema.org',
          '@type': 'WebPage',
          '@id': 'https://bricklabor.com/refer',
          url: 'https://bricklabor.com/refer',
          name: TITLE,
          description: DESC,
          isPartOf: { '@id': 'https://bricklabor.com/#website' },
        }}
      />
    </article>
  );
}

function Stat({
  label,
  value,
  helper,
  accent = false,
}: {
  label: string;
  value: string;
  helper?: string;
  accent?: boolean;
}): JSX.Element {
  return (
    <div className="card">
      <p className="eyebrow">{label}</p>
      <p
        className={`mt-2 text-3xl font-extrabold ${accent ? 'text-brand-accent' : 'text-brand-ink'}`}
      >
        {value}
      </p>
      {helper && <p className="mt-1 text-xs text-brand-mute">{helper}</p>}
    </div>
  );
}

function formatDollars(cents: number): string {
  return `$${(cents / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function formatDate(iso: string | null): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  } catch {
    return '—';
  }
}

function setMeta(name: string, content: string, attr: 'name' | 'property' = 'name') {
  let el = document.querySelector<HTMLMetaElement>(`meta[${attr}="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}
