import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function HolidayImpact({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('holiday-impact');
  return (
    <GenericTable title="Holiday impact predictor" endpoint="/holiday-impact" adminKey={adminKey} />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
