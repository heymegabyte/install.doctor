import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useRef, useState } from 'react';
import { createInternalNavWatcher } from '../exit-intent-nav.js';
import { MODAL_BACKDROP_CLASS, MODAL_PANEL_CLASS, useModalMotion } from '../use-modal-motion.js';
import { useFocusManagement, useTabTrap } from '../use-dialog-a11y.js';

/**
 * Exit-intent rescue modal (Tier 1 #7).
 *
 * Fires once per session when the visitor looks like they're about to bounce.
 * Desktop: mouseleave the top of the viewport (clientY <= 0). Mobile: tab goes
 * hidden OR a fast upward scroll (velocity heuristic). Hits POST
 * /api/ai/exit-rescue for an AI-generated offer (with a hand-curated fallback
 * inside the worker if the AI binding is missing).
 *
 * Dedup via sessionStorage so reloads inside one session don't re-fire. Hidden
 * on /login*, /admin*, /work*, /me*, /track* — these are not bounce-recovery
 * surfaces, they're authenticated/transactional flows where a popup would feel
 * abusive.
 */

type Offer = {
  body: string;
  ctaLabel: string;
  intent: 'book' | 'bundle' | 'sms' | 'call';
  deeplink: string;
  expiresMinutes: number;
};

const SESSION_KEY = 'bcl_exit_shown';
const SUPPRESSED_PREFIXES = ['/login', '/admin', '/work', '/me', '/track'];
const MIN_DWELL_MS = 8_000;

function isSuppressed(): boolean {
  if (typeof window === 'undefined') return true;
  const path = window.location.pathname;
  return SUPPRESSED_PREFIXES.some((p) => path === p || path.startsWith(`${p}/`));
}

export function ExitIntentRescue() {
  useThemeToolsSurface('exit-intent-rescue');
  const [offer, setOffer] = useState<Offer | null>(null);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const triggeredRef = useRef(false);
  const mountedAtRef = useRef<number>(Date.now());
  const lastScrollYRef = useRef<number>(0);
  const lastScrollAtRef = useRef<number>(Date.now());
  const dialogRef = useRef<HTMLDivElement>(null);
  const lastFocusRef = useRef<HTMLElement | null>(null);
  // Shared A7 modal motion: backdrop fade + panel slide/scale on open, animated
  // exit on every dismiss path (Esc, backdrop, decline). Reduced-motion closes
  // instantly. Single-sourced with SurgeExplainerModal via use-modal-motion.
  const { closing, requestClose } = useModalMotion(() => setOpen(false));

  // SCAN-21 — reuse the canonical shared dialog a11y kit instead of a bespoke
  // trap: focus moves INTO the panel on open + restores to the trigger on close
  // (useFocusManagement); Tab / Shift+Tab stay contained, wrapping first↔last
  // (useTabTrap). Extends the same primitive SosButton + AiChat use — no dup.
  useFocusManagement(open, dialogRef, lastFocusRef);
  const onDialogKeyDown = useTabTrap(dialogRef);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (isSuppressed()) return;
    try {
      if (sessionStorage.getItem(SESSION_KEY)) return;
    } catch {
      // Privacy-mode browsers throw on sessionStorage; just bail.
      return;
    }

    // Records internal forward-navigation clicks so onVisibility can tell a
    // conversion (clicking deeper) apart from a genuine bounce.
    const navWatcher = createInternalNavWatcher();

    function trigger() {
      if (triggeredRef.current) return;
      if (Date.now() - mountedAtRef.current < MIN_DWELL_MS) return;
      triggeredRef.current = true;
      try {
        sessionStorage.setItem(SESSION_KEY, '1');
      } catch {
        /* ignore */
      }
      void fetchOffer();
    }

    async function fetchOffer() {
      setLoading(true);
      try {
        const res = await fetch('/api/ai/exit-rescue', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          // The offer is worthless if it lands after the visitor's gone; the
          // worker caps the AI at 2.5s, so 4s here is pure backstop, not the
          // budget. A timeout/abort falls through to the silent catch below.
          signal: AbortSignal.timeout(4_000),
          body: JSON.stringify({
            url: window.location.pathname + window.location.search,
            scrollPct: Math.min(
              100,
              Math.round(
                ((window.scrollY + window.innerHeight) /
                  Math.max(1, document.documentElement.scrollHeight)) *
                  100,
              ),
            ),
            sessionMinutes: Math.round((Date.now() - mountedAtRef.current) / 60_000),
            referrer: document.referrer || '',
          }),
        });
        if (!res.ok) throw new Error(`status ${res.status}`);
        const json = (await res.json()) as { ok: boolean; offer?: Offer };
        if (json.ok && json.offer) {
          setOffer(json.offer);
          setOpen(true);
        }
      } catch {
        // Network/AI fail = stay silent. Bouncing visitor doesn't see an error toast.
      } finally {
        setLoading(false);
      }
    }

    function onMouseOut(e: MouseEvent) {
      // Real exit-intent: cursor crossed the TOP edge headed for the browser chrome.
      if (e.clientY <= 0 && !e.relatedTarget) trigger();
    }

    function onVisibility() {
      // A `hidden` event that follows an internal link/submit click is a
      // forward navigation (a conversion), NOT a bounce — don't burn the
      // one-per-session rescue on a visitor who's advancing into the funnel.
      if (document.visibilityState === 'hidden' && !navWatcher.recentlyNavigated()) trigger();
    }

    function onScroll() {
      const y = window.scrollY;
      const dt = Math.max(1, Date.now() - lastScrollAtRef.current);
      const dy = y - lastScrollYRef.current;
      // Fast upward scroll on mobile = looking for tabs / back button.
      if (dy < -200 && dt < 300) trigger();
      lastScrollYRef.current = y;
      lastScrollAtRef.current = Date.now();
    }

    document.addEventListener('mouseout', onMouseOut);
    document.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      document.removeEventListener('mouseout', onMouseOut);
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('scroll', onScroll);
      navWatcher.cleanup();
    };
  }, []);

  // Esc → animated close (Tab-containment + focus into/out is owned by the
  // shared kit above; this only routes Esc through the exit-animation path).
  useEffect(() => {
    if (!open) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        e.preventDefault();
        requestClose();
      }
    }
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, requestClose]);

  if (!open || !offer) return null;

  return (
    <div
      className={`${MODAL_BACKDROP_CLASS} fixed inset-0 z-[120] flex items-end justify-center bg-black/65 px-4 pb-6 pt-12 sm:items-center sm:p-6`}
      role="presentation"
      data-closing={closing || undefined}
      onClick={requestClose}
    >
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="exit-rescue-title"
        aria-describedby="exit-rescue-body"
        className={`${MODAL_PANEL_CLASS} relative w-full max-w-md overflow-hidden rounded-2xl border border-brand-line bg-bg-elevated p-6 shadow-2xl`}
        data-closing={closing || undefined}
        onClick={(e) => e.stopPropagation()}
        onKeyDown={onDialogKeyDown}
      >
        <div className="absolute inset-x-0 top-0 h-1 bg-brand-accent" aria-hidden />
        <p
          id="exit-rescue-title"
          className="mb-2 font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent"
        >
          Before you go
        </p>
        <p id="exit-rescue-body" className="mb-5 text-base leading-snug text-brand-ink">
          {offer.body}
        </p>
        <div className="flex flex-col gap-2">
          <a
            href={offer.deeplink}
            data-bcl-action={`exit_rescue_${offer.intent}`}
            data-bcl-intent={offer.intent}
            className="inline-flex items-center justify-center rounded-md bg-brand-accent px-4 py-3 text-sm font-semibold text-black transition hover:brightness-110 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-accent"
            onClick={() => {
              setOpen(false);
            }}
          >
            {offer.ctaLabel}
          </a>
          <button
            type="button"
            onClick={requestClose}
            className="inline-flex items-center justify-center rounded-md border border-brand-line bg-transparent px-4 py-2 text-xs text-brand-mute transition hover:text-brand-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-line"
          >
            No thanks
          </button>
        </div>
        {loading && (
          <p className="mt-3 text-[11px] text-brand-mute" aria-live="polite">
            Loading offer…
          </p>
        )}
      </div>
    </div>
  );
}
