import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useMemo, useState } from 'react';

/**
 * Wave 3A — pre-accept transparency card.
 *
 * Renders BEFORE the worker commits to a gig:
 *  - Pay (cents/hr + estimated total)
 *  - City-level location (no street until accept)
 *  - Hours
 *  - Scope summary (dispatcher notes)
 *  - Customer rating + prior-job count
 *  - Crew filled vs needed
 *  - 60–120 second "Accept" countdown
 *  - Idempotent web-accept link fallback for SMS-filtered carriers
 *
 * Per HRW Gig Trap 2025 — workers cite "I accepted blind" as the single
 * biggest gig-economy complaint. This card eliminates that by-design.
 */

export interface Transparency {
  gigId: string;
  claimStatus: string;
  pay: {
    centsPerHour: number;
    estimatedTotalCents: number;
    rushBonusCents: number;
    shiftLeadBonusCents: number;
    hoursEstimated: number;
  };
  location: {
    cityLevel: string;
    streetAddress: string | null;
    zip: string | null;
  };
  scopeSummary: string | null;
  customerNotes: string | null;
  crewFilled: number;
  crewNeeded: number;
  needsDriver: boolean;
  needsHauling: boolean;
  startAt: string;
  customer: {
    ratingAvg: number | null;
    priorJobCount: number;
  };
}

export interface JobAcceptCardProps {
  gigId: string;
  countdownSeconds?: number;
  onAccepted?: () => void;
  onDeclined?: () => void;
}

const DEFAULT_COUNTDOWN = 90;

function dollars(cents: number): string {
  return `$${(cents / 100).toFixed(0)}`;
}

function ratingLabel(avg: number | null, count: number): string {
  if (avg === null || count === 0) return 'New customer · no rating yet';
  return `${avg.toFixed(1)} stars · ${count} prior job${count === 1 ? '' : 's'}`;
}

export function JobAcceptCard({
  gigId,
  countdownSeconds = DEFAULT_COUNTDOWN,
  onAccepted,
  onDeclined,
}: JobAcceptCardProps) {
  useThemeToolsSurface('job-accept-card');
  const [data, setData] = useState<Transparency | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(countdownSeconds);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`/api/work/gigs/${encodeURIComponent(gigId)}`, {
          headers: { Accept: 'application/json' },
        });
        if (cancelled) return;
        if (!res.ok) {
          setError(`Couldn't load gig details (${res.status})`);
          return;
        }
        const body = (await res.json()) as { transparency: Transparency };
        setData(body.transparency);
      } catch (err) {
        if (!cancelled) setError(`Network: ${(err as Error).message}`);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [gigId]);

  useEffect(() => {
    if (!data) return;
    if (data.claimStatus !== 'invited') return;
    if (secondsLeft <= 0) return;
    const t = window.setInterval(() => setSecondsLeft((s) => Math.max(0, s - 1)), 1000);
    return () => window.clearInterval(t);
  }, [data, secondsLeft]);

  const fallbackUrl = useMemo(
    () =>
      typeof window === 'undefined'
        ? `/work/dashboard?gig=${encodeURIComponent(gigId)}`
        : `${window.location.origin}/work/dashboard?gig=${encodeURIComponent(gigId)}`,
    [gigId],
  );

  const accept = useCallback(async () => {
    setBusy(true);
    setError('');
    try {
      const res = await fetch(`/api/work/gigs/${encodeURIComponent(gigId)}/accept`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: '{}',
      });
      if (!res.ok) {
        const body = (await res.json().catch(() => ({}))) as { code?: string };
        setError(body.code ? `Couldn't accept: ${body.code}` : `Couldn't accept (${res.status})`);
        return;
      }
      onAccepted?.();
    } catch (err) {
      setError(`Network: ${(err as Error).message}`);
    } finally {
      setBusy(false);
    }
  }, [gigId, onAccepted]);

  const decline = useCallback(async () => {
    setBusy(true);
    setError('');
    try {
      const res = await fetch(`/api/work/gigs/${encodeURIComponent(gigId)}/decline`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: '{}',
      });
      if (res.ok) onDeclined?.();
    } catch {
      /* swallow */
    } finally {
      setBusy(false);
    }
  }, [gigId, onDeclined]);

  if (error && !data) {
    return (
      <div
        role="alert"
        className="rounded-2xl border border-red-500/40 bg-red-500/10 p-5 text-red-200"
      >
        {error}
      </div>
    );
  }
  if (!data) {
    return (
      <div className="rounded-2xl border border-brand-line bg-brand-card p-5 text-brand-mute">
        Loading gig details…
      </div>
    );
  }

  const accepted = data.claimStatus !== 'invited';
  const countdownDone = secondsLeft <= 0;

  return (
    <article
      className="rounded-2xl border border-brand-line bg-brand-card p-5 space-y-4"
      data-testid="job-accept-card"
    >
      <header className="flex flex-wrap items-baseline justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-wider text-brand-mute mb-1">
            Pre-accept transparency
          </p>
          <h2 className="text-xl font-extrabold text-brand-ink">
            {data.pay.hoursEstimated}h gig · {data.location.cityLevel}
          </h2>
        </div>
        <p className="text-2xl font-extrabold text-brand-accent">
          {dollars(data.pay.estimatedTotalCents)}
        </p>
      </header>

      <dl className="grid grid-cols-2 gap-3 text-sm">
        <div>
          <dt className="text-brand-mute text-xs uppercase tracking-wider">Hourly</dt>
          <dd className="font-extrabold text-brand-ink">
            {dollars(data.pay.centsPerHour)}/hr · {data.pay.hoursEstimated}h
          </dd>
        </div>
        <div>
          <dt className="text-brand-mute text-xs uppercase tracking-wider">Crew</dt>
          <dd className="font-extrabold text-brand-ink">
            {data.crewFilled} of {data.crewNeeded} filled
          </dd>
        </div>
        <div>
          <dt className="text-brand-mute text-xs uppercase tracking-wider">Customer</dt>
          <dd className="font-extrabold text-brand-ink">
            {ratingLabel(data.customer.ratingAvg, data.customer.priorJobCount)}
          </dd>
        </div>
        <div>
          <dt className="text-brand-mute text-xs uppercase tracking-wider">Bonuses</dt>
          <dd className="font-extrabold text-brand-ink">
            {data.pay.rushBonusCents > 0 ? `${dollars(data.pay.rushBonusCents)} rush` : '—'}
            {data.pay.shiftLeadBonusCents > 0
              ? ` · ${dollars(data.pay.shiftLeadBonusCents)} lead`
              : ''}
          </dd>
        </div>
      </dl>

      {(data.needsDriver || data.needsHauling) && (
        <p className="text-xs font-bold text-amber-300">
          {data.needsDriver ? 'Driving required (U-Haul or worker vehicle). ' : ''}
          {data.needsHauling ? 'Hauling required.' : ''}
        </p>
      )}

      {data.scopeSummary && (
        <div>
          <p className="text-xs uppercase tracking-wider text-brand-mute mb-1">Scope</p>
          <p className="text-sm text-brand-ink italic">"{data.scopeSummary}"</p>
        </div>
      )}

      <div className="rounded-xl border border-brand-line bg-brand-bg/40 p-3 text-xs text-brand-mute">
        Street address is shown <strong className="text-brand-ink">after</strong> accept. Pre-accept
        view is city + ZIP only — your safety and the customer's privacy both.
      </div>

      {accepted ? (
        <p className="text-sm font-bold text-emerald-300">
          Already {data.claimStatus}. Open the gig from your dashboard.
        </p>
      ) : (
        <>
          {!countdownDone && (
            <p
              aria-live="polite"
              className="text-xs uppercase tracking-wider text-brand-accent font-extrabold"
            >
              Accept window: {secondsLeft}s remaining
            </p>
          )}
          {countdownDone && (
            <p className="text-xs uppercase tracking-wider text-amber-300 font-extrabold">
              Countdown finished. You can still accept — first Y wins.
            </p>
          )}
          {error && (
            <p role="alert" className="text-sm text-red-300">
              {error}
            </p>
          )}
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => void accept()}
              disabled={busy}
              className="btn-primary flex-1 min-w-[140px]"
            >
              {busy ? '…' : `Accept ${dollars(data.pay.estimatedTotalCents)}`}
            </button>
            <button
              type="button"
              onClick={() => void decline()}
              disabled={busy}
              className="rounded-xl border border-brand-line bg-transparent px-4 py-2 text-sm font-bold text-brand-mute hover:text-brand-ink transition-colors"
            >
              Decline
            </button>
          </div>
          <p className="text-[11px] text-brand-mute">
            SMS link filtered by your carrier? Use the web-accept fallback:{' '}
            <a className="underline-hover text-brand-accent" href={fallbackUrl}>
              {fallbackUrl}
            </a>
          </p>
        </>
      )}
    </article>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
