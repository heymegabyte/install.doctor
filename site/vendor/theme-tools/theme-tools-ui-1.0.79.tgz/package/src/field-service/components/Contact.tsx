import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useState } from 'react';
import { localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { contactCopy } from '@theme.tools/i18n-a11y/field-service/contact-copy';
import { TurnstileWidget } from './TurnstileWidget.js';
import { PHONE_TEL_HREF } from '@theme.tools/i18n-a11y/field-service/contact-phone';

export function Contact() {
  useThemeToolsSurface('contact');
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<{ ok: boolean; message: string } | null>(null);
  const [turnstileToken, setTurnstileToken] = useState('');

  // SSR/prerender is locale-stamped per route; on the client we read the URL so
  // the `/es` + `/pt` mirrors render in-language post-hydration. EN default.
  const locale =
    typeof window === 'undefined' ? 'en' : stripLocalePrefix(window.location.pathname).locale;
  const copy = contactCopy(locale);
  // Keep a mirror-locale visitor in /es · /pt: localize internal `/` hrefs
  // (incl. `/#pricing` homepage anchors); leave mailto:/tel:/external bare.
  const lp = (path: string) => (path.startsWith('/') ? localizedPath(locale, path) : path);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    setSubmitting(true);
    setResult(null);
    const fd = new FormData(form);
    const payload = {
      name: String(fd.get('name') || '').trim(),
      email: String(fd.get('email') || '').trim(),
      phone: String(fd.get('phone') || '').trim(),
      subject: String(fd.get('subject') || '').trim(),
      message: String(fd.get('message') || '').trim(),
      turnstileToken,
    };

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as { ok: boolean; message: string };
      if (res.ok && data.ok) {
        setResult({ ok: true, message: data.message || copy.successMsg });
        form.reset();
      } else {
        setResult({ ok: false, message: data.message || copy.errorMsg });
      }
    } catch (err) {
      // Error tracked via Sentry
      setResult({ ok: false, message: copy.networkErrMsg });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <section id="contact" className="section bg-bg-elevated/40 border-y border-brand-line" data-animate="cta-cinematic">
      <div className="container-pad">
        {/* Reveal via the production animate.ts runtime (shared global IO) —
            VERTICAL fade-up only. A prior pass removed slide-in because sideways
            motion was jarring; fade-up is IO-gated, reduced-motion-safe, and
            html.js-gated (degrades to visible without JS), so no CLS. */}
        <div className="grid lg:grid-cols-2 gap-10">
          <div data-animate="fade-up">
            <p className="eyebrow mb-3">{copy.eyebrow}</p>
            <h2 className="text-4xl sm:text-5xl font-extrabold">
              {copy.titlePre}
              <span className="text-gradient">{copy.titleAccent}</span>
            </h2>
            <p className="mt-4 text-lg text-brand-mute">
              {copy.intro.pre}
              <a href={lp('/book')} className="text-brand-accent underline-hover">
                {copy.intro.bookLink}
              </a>
              {copy.intro.mid}
              <a href={lp('/#pricing')} className="text-brand-accent underline-hover">
                {copy.intro.priceLink}
              </a>
              {copy.intro.post}
            </p>
            <p className="mt-3 text-sm text-brand-mute">
              {copy.commonAsks.pre}
              <a href={lp('/services/power-washing')} className="text-brand-accent underline-hover">
                {copy.commonAsks.powerWashLink}
              </a>
              {copy.commonAsks.sep1}
              <a href={lp('/services/lawn-care')} className="text-brand-accent underline-hover">
                {copy.commonAsks.lawnLink}
              </a>
              {copy.commonAsks.sep2}
              <a href={lp('/services/hauling')} className="text-brand-accent underline-hover">
                {copy.commonAsks.haulLink}
              </a>
              {copy.commonAsks.mid}
              <a href={lp('/services/light-repairs')} className="text-brand-accent underline-hover">
                {copy.commonAsks.repairsLink}
              </a>
              {copy.commonAsks.post}
            </p>
            <div className="mt-5 rounded-lg border border-brand-accent/40 bg-brand-accent/5 p-4 text-sm leading-relaxed text-brand-mute">
              <strong className="text-brand-ink">{copy.dayRates.strong}</strong>
              {copy.dayRates.pre}
              <a href={lp('/book')} className="text-brand-accent underline-hover">
                {copy.dayRates.widgetLink}
              </a>
              {copy.dayRates.mid}
              <a href={lp('/c/newark')} className="text-brand-accent underline-hover">
                {copy.dayRates.newarkLink}
              </a>
              {copy.dayRates.sep1}
              <a href={lp('/c/jersey-city')} className="text-brand-accent underline-hover">
                {copy.dayRates.jerseyCityLink}
              </a>
              {copy.dayRates.sep2}
              <a href={lp('/c/hoboken')} className="text-brand-accent underline-hover">
                {copy.dayRates.hobokenLink}
              </a>
              {copy.dayRates.post}
            </div>
            <ul className="mt-8 space-y-4 text-sm" data-stagger="90">
              <li className="flex items-center gap-3" data-animate="fade-up">
                <span
                  className="grid h-10 w-10 place-items-center rounded-lg bg-brand-accent/15 text-brand-accent"
                  aria-hidden
                >
                  <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={1.8}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5"
                  >
                    <path d="M3 8l9 6 9-6M5 19h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2z" />
                  </svg>
                </span>
                <a href="mailto:hey@bricklabor.com" className="underline-hover text-brand-ink">
                  hey@bricklabor.com
                </a>
              </li>
              <li className="flex items-center gap-3" data-animate="fade-up">
                <span
                  className="grid h-10 w-10 place-items-center rounded-lg bg-brand-accent/15 text-brand-accent"
                  aria-hidden
                >
                  <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={1.8}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5"
                  >
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z" />
                  </svg>
                </span>
                <a href={PHONE_TEL_HREF} className="underline-hover text-brand-ink">
                  (855) 82LABOR
                </a>
              </li>
              <li className="flex items-center gap-3" data-animate="fade-up">
                <span
                  className="grid h-10 w-10 place-items-center rounded-lg bg-brand-accent/15 text-brand-accent"
                  aria-hidden
                >
                  <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={1.8}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5"
                  >
                    <path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z" />
                    <circle cx="12" cy="10" r="3" />
                  </svg>
                </span>
                <a
                  href="https://www.google.com/maps/dir/?api=1&destination=Newark%2C%20NJ"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline-hover text-brand-ink"
                >
                  {copy.addressLine}
                </a>
              </li>
            </ul>
          </div>

          <form
            onSubmit={onSubmit}
            className="card space-y-3"
            aria-label={copy.formLabel}
            data-animate="fade-up"
            data-delay="120"
          >
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="label" htmlFor="ct-name">
                  {copy.nameLabel}
                </label>
                <input id="ct-name" name="name" required autoComplete="name" className="tt-input" />
              </div>
              <div>
                <label className="label" htmlFor="ct-email">
                  {copy.emailLabel}
                </label>
                <input
                  id="ct-email"
                  name="email"
                  type="email"
                  required
                  autoComplete="email"
                  className="tt-input"
                />
              </div>
            </div>
            <div>
              <label className="label" htmlFor="ct-phone">
                {copy.phoneLabel}
              </label>
              <input id="ct-phone" name="phone" type="tel" autoComplete="tel" className="tt-input" />
            </div>
            <div>
              <label className="label" htmlFor="ct-subject">
                {copy.subjectLabel}
              </label>
              <input
                id="ct-subject"
                name="subject"
                className="tt-input"
                placeholder={copy.subjectPlaceholder}
              />
            </div>
            <div>
              <label className="label" htmlFor="ct-message">
                {copy.messageLabel}
              </label>
              <textarea
                id="ct-message"
                name="message"
                required
                rows={5}
                className="tt-input resize-y"
                placeholder={copy.messagePlaceholder}
              />
            </div>
            <TurnstileWidget onToken={setTurnstileToken} action="contact" />
            <button
              type="submit"
              disabled={submitting}
              aria-busy={submitting}
              className="tt-btn tt-btn--primary w-full"
            >
              {submitting ? copy.sending : copy.submit}
            </button>
            {result && (
              <div
                role={result.ok ? 'status' : 'alert'}
                aria-live={result.ok ? 'polite' : 'assertive'}
                className={`rounded-lg border p-3 text-sm ${
                  result.ok
                    ? 'border-brand-ok/40 bg-brand-ok/10 text-brand-ok'
                    : 'border-brand-err/40 bg-brand-err/10 text-brand-err'
                }`}
              >
                {result.message}
              </div>
            )}
            <p className="text-[11px] text-brand-mute">
              {copy.footerNote.pre}
              <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
                hey@bricklabor.com
              </a>
              {copy.footerNote.post}
            </p>
            <p className="border-t border-brand-line pt-3 text-[11px] leading-relaxed text-brand-mute">
              {copy.whileWait.pre}
              <a href={lp('/blog')} className="text-brand-accent underline-hover">
                {copy.whileWait.blogLink}
              </a>
              {copy.whileWait.sep1}
              <a href={lp('/#testimonials')} className="text-brand-accent underline-hover">
                {copy.whileWait.reviewsLink}
              </a>
              {copy.whileWait.sep2}
              <a href={lp('/sources')} className="text-brand-accent underline-hover">
                {copy.whileWait.citationsLink}
              </a>
              {copy.whileWait.mid}
              <a href={lp('/book')} className="text-brand-accent underline-hover">
                {copy.whileWait.bookLink}
              </a>
              {copy.whileWait.post}
            </p>
          </form>
        </div>
      </div>
    </section>
  );
}
