import { useThemeToolsSurface } from '../../../field-service-primitives.js';
/**
 * EscrowDispute.tsx — dispute control + status for a held escrow job on the
 * /me job-detail surface. Gated by feature flag `smart_bonded_escrow`; renders
 * `null` when off. Self-contained drop-in.
 *
 * Posts to the id-first alias `POST /api/escrow/:id/dispute` (which delegates
 * to the canonical smart-bonded-escrow handler). The button is hidden once the
 * escrow is in a terminal state (captured/refunded) — you can only dispute a
 * held job.
 */
import { useState } from 'react';
import { useFeatureFlag } from '../../use-feature-flag.js';
import type { EscrowState } from './EscrowBadge.js';

/** Human dispute-status line — unit-tested. */
export function disputeStatusText(state: EscrowState): string {
  switch (state) {
    case 'disputed':
      return 'Dispute opened — under review';
    case 'refunded':
      return 'Resolved — refunded';
    case 'captured':
      return 'Closed — payment released';
    case 'held':
    case 'partially_verified':
    case 'fully_verified':
    default:
      return 'No dispute';
  }
}

/** Whether the dispute button can be shown (only a held job is disputable). */
export function canDispute(state: EscrowState): boolean {
  return state === 'held' || state === 'partially_verified' || state === 'fully_verified';
}

interface Props {
  /** The escrow row id (or booking id the alias resolves) to dispute. */
  readonly escrowId: string;
  readonly state?: EscrowState;
  readonly onDisputed?: () => void;
}

export function EscrowDispute({ escrowId, state = 'held', onDisputed }: Props): JSX.Element | null {
  useThemeToolsSurface('escrow-dispute');
  const enabled = useFeatureFlag('smart_bonded_escrow');
  const [busy, setBusy] = useState(false);
  const [localState, setLocalState] = useState<EscrowState>(state);
  const [error, setError] = useState('');

  if (!enabled) return null;

  async function openDispute() {
    setBusy(true);
    setError('');
    try {
      const res = await fetch(`/api/escrow/${encodeURIComponent(escrowId)}/dispute`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ reason: 'customer_dispute' }),
      });
      if (!res.ok) {
        setError('Could not open a dispute. Call (855) 82LABOR and we’ll sort it out.');
        return;
      }
      setLocalState('disputed');
      onDisputed?.();
    } catch {
      setError('Network hiccup — try again, or call (855) 82LABOR.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-2" data-escrow-state={localState}>
      <span data-testid="escrow-dispute-status" className="text-sm text-brand-mute">
        {disputeStatusText(localState)}
      </span>
      {canDispute(localState) && (
        <button
          type="button"
          data-testid="escrow-dispute-btn"
          onClick={openDispute}
          disabled={busy}
          aria-busy={busy}
          className="inline-flex min-h-[44px] items-center justify-center rounded-lg border border-white/15 px-4 font-semibold text-brand-ink disabled:opacity-60"
        >
          {busy ? 'Opening…' : 'Open a dispute'}
        </button>
      )}
      {error && (
        <span role="alert" className="text-xs text-red-400">
          {error}
        </span>
      )}
    </div>
  );
}
