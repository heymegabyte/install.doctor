import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useMemo, useState } from 'react';

const TITLE = 'Brick Labor API — REST v1 Docs · Bookings, Availability, Webhooks';
const DESC =
  'Public REST API v1 for Brick Labor. Issue keys, book crews, query availability, subscribe to webhooks. Curl + Node + Python examples, sandbox builder, signed payloads.';

const BASE_URL = 'https://bricklabor.com/api/v1';

const SECTIONS = [
  { id: 'quickstart', label: 'Quickstart' },
  { id: 'auth', label: 'Authentication' },
  { id: 'bookings', label: 'Bookings' },
  { id: 'availability', label: 'Availability' },
  { id: 'cities', label: 'Cities' },
  { id: 'webhooks', label: 'Webhooks' },
  { id: 'errors', label: 'Errors' },
  { id: 'rate-limits', label: 'Rate limits' },
  { id: 'sdks', label: 'SDKs' },
  { id: 'sandbox', label: 'Sandbox' },
] as const;

const FAQ_ITEMS = [
  {
    q: 'How do I get an API key?',
    a: 'Email hey@bricklabor.com or call (855) 82LABOR. Live keys (bcl_live_*) ship within one business day. Test keys (bcl_test_*) are free and provisioned instantly for prototyping.',
  },
  {
    q: 'Which environments exist?',
    a: 'A single base URL: https://bricklabor.com/api/v1. Test-mode keys (bcl_test_*) and live keys hit the same endpoints — only behavior differs (test bookings stay in pending_confirmation and do not dispatch a crew).',
  },
  {
    q: 'Is the API stable?',
    a: 'Yes. v1 endpoints are versioned and additive. Breaking changes ship as v2; v1 stays online for at least 18 months after v2 reaches GA.',
  },
  {
    q: 'Do you support webhooks?',
    a: 'Yes. Subscribe via POST /api/v1/webhooks with the events you care about. Each delivery is signed HMAC-SHA256 in the X-Bcl-Signature header. Retries: 3 attempts with exponential backoff.',
  },
  {
    q: 'How do I test idempotency?',
    a: 'Send the same Idempotency-Key header within 24 hours on a duplicate POST /api/v1/bookings — you get the original response back, same booking id, same total.',
  },
] as const;

export function ApiDocsPage() {
  useThemeToolsSurface('api-docs-page');
  useEffect(() => {
    document.title = TITLE;
    setMeta('description', DESC);
    setLink('canonical', 'https://bricklabor.com/api');
    setMeta('robots', 'index,follow', 'name');
    setMeta('og:title', TITLE, 'property');
    setMeta('og:description', DESC, 'property');
    setMeta('og:url', 'https://bricklabor.com/api', 'property');
    setMeta('og:type', 'article', 'property');
  }, []);

  return (
    <article className="section">
      <div className="container-pad max-w-5xl">
        <header className="mb-12">
          <p className="eyebrow mb-3">REST API · v1</p>
          <h1 className="text-4xl sm:text-5xl font-extrabold mb-3">Brick Labor API</h1>
          <p className="text-brand-mute max-w-2xl leading-relaxed">
            Book crews, query availability, subscribe to webhooks. Same API the bricklabor.com site
            uses — battle-tested in production, versioned, signed. Curl + Node + Python examples
            below, plus a live sandbox builder.
          </p>
          <div className="mt-6 flex flex-wrap gap-3 text-sm">
            <a
              href="#quickstart"
              className="rounded-full border border-brand-line bg-bg-elevated px-4 py-2 text-brand-ink hover:bg-bg-elevated/80"
            >
              Get started in 60 seconds
            </a>
            <a
              href="mailto:hey@bricklabor.com?subject=API%20key%20request"
              className="rounded-full bg-brand-accent px-4 py-2 font-semibold text-bg hover:opacity-90"
            >
              Request a live key
            </a>
          </div>
        </header>

        <nav
          aria-label="API docs sections"
          className="mb-12 flex flex-wrap gap-2 text-xs font-mono uppercase tracking-wider text-brand-mute"
        >
          {SECTIONS.map((s) => (
            <a
              key={s.id}
              href={`#${s.id}`}
              className="rounded-md border border-brand-line bg-bg-elevated/40 px-3 py-1.5 hover:border-brand-accent hover:text-brand-ink"
            >
              {s.label}
            </a>
          ))}
        </nav>

        <Quickstart />
        <Authentication />
        <Bookings />
        <Availability />
        <Cities />
        <Webhooks />
        <ErrorsSection />
        <RateLimits />
        <SdksSection />
        <Sandbox />

        <FaqSection items={FAQ_ITEMS} />
      </div>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'TechArticle',
            '@id': 'https://bricklabor.com/api',
            url: 'https://bricklabor.com/api',
            name: TITLE,
            headline: 'Brick Labor REST API v1',
            description: DESC,
            dependencies: 'HTTPS, JSON, HMAC-SHA256',
            proficiencyLevel: 'Beginner',
            inLanguage: 'en-US',
            isPartOf: { '@id': 'https://bricklabor.com/#website' },
            datePublished: '2026-05-20',
            dateModified: '2026-05-20',
            author: {
              '@type': 'Organization',
              name: 'Brick Labor',
              url: 'https://bricklabor.com',
            },
            publisher: {
              '@type': 'Organization',
              name: 'Brick Labor',
              url: 'https://bricklabor.com',
            },
          }),
        }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'FAQPage',
            mainEntity: FAQ_ITEMS.map((item) => ({
              '@type': 'Question',
              name: item.q,
              acceptedAnswer: { '@type': 'Answer', text: item.a },
            })),
          }),
        }}
      />
    </article>
  );
}

// ─── Sections ──────────────────────────────────────────────────────────

function Quickstart() {
  const sample = `# 1. Set your key (request one at hey@bricklabor.com)
export BCL_KEY="bcl_live_..."

# 2. Confirm the key works
curl -H "Authorization: Bearer $BCL_KEY" ${BASE_URL}/me

# 3. Check availability
curl -H "Authorization: Bearer $BCL_KEY" \\
  "${BASE_URL}/availability?date=2026-06-01&hours=2"

# 4. Create a booking
curl -X POST -H "Authorization: Bearer $BCL_KEY" \\
  -H "Content-Type: application/json" \\
  -H "Idempotency-Key: my-unique-id-123" \\
  -d '{
    "name": "Jordan Vargas",
    "email": "jordan@example.com",
    "phone": "555-867-5309",
    "address": "123 Main St",
    "city": "Newark",
    "zip": "07102",
    "preferredDate": "2026-06-01",
    "preferredTime": "10:00 AM",
    "services": ["power-wash"],
    "hours": 2,
    "crew": 2
  }' ${BASE_URL}/bookings`;
  return (
    <Section id="quickstart" title="Quickstart">
      <p>
        Four <code className="font-mono text-brand-accent">curl</code> commands. Real responses, no
        SDK required.
      </p>
      <Code language="sh" code={sample} />
      <p className="text-sm text-brand-mute">
        Test keys (<code className="font-mono text-brand-accent">bcl_test_*</code>) follow the same
        shape — bookings stay in{' '}
        <code className="font-mono text-brand-accent">pending_confirmation</code> and no crew is
        dispatched.
      </p>
    </Section>
  );
}

function Authentication() {
  return (
    <Section id="auth" title="Authentication">
      <p>
        Every endpoint accepts a bearer token in the{' '}
        <code className="font-mono text-brand-accent">Authorization</code> header:
      </p>
      <Code
        language="http"
        code={`Authorization: Bearer bcl_live_abcdef0123456789abcdef0123456789`}
      />
      <ul className="list-disc pl-6 space-y-2 text-brand-mute">
        <li>
          Keys are <strong>32 hex chars</strong> after the prefix. 128 bits of entropy. Format
          regex:{' '}
          <code className="font-mono text-brand-accent">^bcl_(live|test)_[0-9a-f]{`{32}`}$</code>.
        </li>
        <li>
          Only the SHA-256 hash is stored. <strong>Lose your key, request a new one</strong> — we
          can't recover it.
        </li>
        <li>
          Scopes are enforced per route. Default scopes for new keys:{' '}
          <code className="font-mono text-brand-accent">bookings:read</code>,{' '}
          <code className="font-mono text-brand-accent">bookings:write</code>,{' '}
          <code className="font-mono text-brand-accent">availability:read</code>,{' '}
          <code className="font-mono text-brand-accent">cities:read</code>,{' '}
          <code className="font-mono text-brand-accent">me:read</code>. Webhook subscribers need{' '}
          <code className="font-mono text-brand-accent">webhooks:write</code>.
        </li>
        <li>
          Missing or wrong scope → 403 with{' '}
          <code className="font-mono text-brand-accent">requiredScope</code> in the response body.
        </li>
      </ul>
    </Section>
  );
}

function Bookings() {
  const createBody = `{
  "name": "Jordan Vargas",
  "email": "jordan@example.com",
  "phone": "555-867-5309",
  "address": "123 Main St",
  "city": "Newark",
  "zip": "07102",
  "preferredDate": "2026-06-01",
  "preferredTime": "10:00 AM",
  "services": ["power-wash", "lawn"],
  "hours": 3,
  "crew": 2,
  "paymentMode": "deposit",
  "smsOptIn": true,
  "emailOptIn": true,
  "notes": "Side gate code: 4242",
  "origin": "api"
}`;
  const createResp = `{
  "ok": true,
  "booking": {
    "id": "5a7c...",
    "status": "pending_payment",
    "totalCents": 30000,
    "surgeMultiplier": 1.0,
    "checkoutUrl": "https://square.link/u/...",
    "preferredDate": "2026-06-01",
    "preferredTime": "10:00 AM",
    "services": ["power-wash", "lawn"],
    "hours": 3,
    "crew": 2
  }
}`;
  return (
    <Section id="bookings" title="Bookings">
      <Endpoint
        method="POST"
        path="/api/v1/bookings"
        scope="bookings:write"
        description="Create a booking. Returns 201 with the booking id and a Square checkout URL (when paymentMode is 'deposit' or 'full'). Pass an Idempotency-Key header to safely retry."
      />
      <h4 className="font-semibold text-brand-ink mt-4 mb-2">Request body</h4>
      <Code language="json" code={createBody} />
      <h4 className="font-semibold text-brand-ink mt-4 mb-2">Response (201)</h4>
      <Code language="json" code={createResp} />
      <Endpoint
        method="GET"
        path="/api/v1/bookings/:id"
        scope="bookings:read"
        description="Fetch a single booking. Customer-scoped keys can only read their own bookings; partner keys can read any booking they created."
      />
    </Section>
  );
}

function Availability() {
  return (
    <Section id="availability" title="Availability">
      <Endpoint
        method="GET"
        path="/api/v1/availability"
        scope="availability:read"
        description="Returns hourly slot suggestions for a date. Query params: date (YYYY-MM-DD, required), hours (1-8, default 2), zip (optional), crew (optional)."
      />
      <Code
        language="sh"
        code={`curl -H "Authorization: Bearer $BCL_KEY" \\
  "${BASE_URL}/availability?date=2026-06-01&hours=2&zip=07102&crew=2"`}
      />
      <Code
        language="json"
        code={`{
  "ok": true,
  "date": "2026-06-01",
  "slots": [
    { "startAt": "2026-06-01T06:00:00-04:00", "localTime": "6:00 AM", "premium": true },
    { "startAt": "2026-06-01T07:00:00-04:00", "localTime": "7:00 AM", "premium": false },
    { "startAt": "2026-06-01T08:00:00-04:00", "localTime": "8:00 AM", "premium": false }
  ]
}`}
      />
    </Section>
  );
}

function Cities() {
  return (
    <Section id="cities" title="Cities">
      <Endpoint
        method="GET"
        path="/api/v1/cities"
        scope="cities:read"
        description="Service-area list. Returns the canonical slug, display name, county, population, and centroid for every covered city."
      />
      <Code language="sh" code={`curl -H "Authorization: Bearer $BCL_KEY" ${BASE_URL}/cities`} />
    </Section>
  );
}

function Webhooks() {
  return (
    <Section id="webhooks" title="Webhooks">
      <p>
        Subscribe a URL to receive signed JSON payloads when events fire. Five supported events:
      </p>
      <ul className="list-disc pl-6 space-y-1 text-brand-mute">
        <li>
          <code className="font-mono text-brand-accent">booking.created</code> — a new booking
          landed (web/SMS/API)
        </li>
        <li>
          <code className="font-mono text-brand-accent">booking.paid</code> — Square confirmed
          payment
        </li>
        <li>
          <code className="font-mono text-brand-accent">booking.completed</code> — crew marked the
          job done
        </li>
        <li>
          <code className="font-mono text-brand-accent">dispatch.assigned</code> — crew assigned to
          a booking
        </li>
        <li>
          <code className="font-mono text-brand-accent">review.submitted</code> — customer left a
          rating
        </li>
      </ul>
      <Endpoint
        method="POST"
        path="/api/v1/webhooks"
        scope="webhooks:write"
        description="Subscribe. Response includes signingSecret (shown ONCE — store it). Sign every received payload with HMAC-SHA256 to verify origin."
      />
      <Endpoint
        method="GET"
        path="/api/v1/webhooks"
        scope="webhooks:write"
        description="List your active subscriptions and their last-delivery state."
      />
      <Endpoint
        method="DELETE"
        path="/api/v1/webhooks/:id"
        scope="webhooks:write"
        description="Revoke a subscription. Idempotent."
      />

      <h4 className="font-semibold text-brand-ink mt-4 mb-2">Signature verification</h4>
      <p>
        Each delivery includes{' '}
        <code className="font-mono text-brand-accent">X-Bcl-Signature: sha256=&lt;hex&gt;</code>.
        Compute <code className="font-mono text-brand-accent">HMAC-SHA256(secret, body)</code> and
        compare with constant-time equality.
      </p>
      <Code
        language="js"
        code={`import crypto from 'node:crypto';

function verify(req, secret) {
  const sig = req.headers['x-bcl-signature'] || '';
  const expected =
    'sha256=' + crypto.createHmac('sha256', secret).update(req.rawBody).digest('hex');
  return crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
}`}
      />
      <h4 className="font-semibold text-brand-ink mt-4 mb-2">Retry policy</h4>
      <p>
        Three attempts. Exponential backoff (0.5s, 1s, 2s). 2xx = success. 4xx (except 429) = give
        up. 5xx + 429 = retry.
      </p>
    </Section>
  );
}

function ErrorsSection() {
  const example = `{
  "ok": false,
  "error": "This key is missing the \`bookings:write\` scope.",
  "code": "forbidden",
  "requiredScope": "bookings:write"
}`;
  return (
    <Section id="errors" title="Errors">
      <p>Every error response is the same flat envelope:</p>
      <Code language="json" code={example} />
      <table className="my-4 w-full text-sm border-collapse">
        <thead>
          <tr className="text-left text-brand-mute border-b border-brand-line">
            <th className="py-2 pr-4 font-semibold">Status</th>
            <th className="py-2 pr-4 font-semibold">code</th>
            <th className="py-2 font-semibold">Meaning</th>
          </tr>
        </thead>
        <tbody className="font-mono text-xs text-brand-mute">
          <tr className="border-b border-brand-line/60">
            <td className="py-2 pr-4">400</td>
            <td className="py-2 pr-4">invalid_input</td>
            <td className="py-2 font-sans">
              Zod validation failed; check `error` for the first failing path.
            </td>
          </tr>
          <tr className="border-b border-brand-line/60">
            <td className="py-2 pr-4">401</td>
            <td className="py-2 pr-4">unauthenticated</td>
            <td className="py-2 font-sans">Missing or unknown API key.</td>
          </tr>
          <tr className="border-b border-brand-line/60">
            <td className="py-2 pr-4">403</td>
            <td className="py-2 pr-4">forbidden</td>
            <td className="py-2 font-sans">Key is valid but the scope check failed.</td>
          </tr>
          <tr className="border-b border-brand-line/60">
            <td className="py-2 pr-4">404</td>
            <td className="py-2 pr-4">not_found</td>
            <td className="py-2 font-sans">Resource doesn't exist or you don't own it.</td>
          </tr>
          <tr className="border-b border-brand-line/60">
            <td className="py-2 pr-4">429</td>
            <td className="py-2 pr-4">rate_limit</td>
            <td className="py-2 font-sans">Slow down. Respect Retry-After.</td>
          </tr>
          <tr>
            <td className="py-2 pr-4">5xx</td>
            <td className="py-2 pr-4">internal</td>
            <td className="py-2 font-sans">Our problem. Retry with the same Idempotency-Key.</td>
          </tr>
        </tbody>
      </table>
    </Section>
  );
}

function RateLimits() {
  return (
    <Section id="rate-limits" title="Rate limits">
      <p>
        Per-key minute bucket. Default 60 requests/minute. Bursts beyond the budget return{' '}
        <code className="font-mono text-brand-accent">429</code> with a{' '}
        <code className="font-mono text-brand-accent">Retry-After</code> header.
      </p>
      <ul className="list-disc pl-6 space-y-2 text-brand-mute">
        <li>
          Every response includes{' '}
          <code className="font-mono text-brand-accent">X-RateLimit-Limit</code> +{' '}
          <code className="font-mono text-brand-accent">X-RateLimit-Remaining</code>.
        </li>
        <li>
          Need more? Email{' '}
          <a href="mailto:hey@bricklabor.com" className="text-brand-accent underline-hover">
            hey@bricklabor.com
          </a>{' '}
          with a use-case. Most integrations get bumped to 600/min in 24 hours.
        </li>
        <li>Webhooks are not subject to the per-key budget — deliveries fire per event.</li>
      </ul>
    </Section>
  );
}

function SdksSection() {
  return (
    <Section id="sdks" title="SDKs">
      <p>
        No language-specific SDK yet — the API is small enough to call directly. Battle-tested
        snippets:
      </p>
      <h4 className="font-semibold text-brand-ink mt-4 mb-2">Node 22 (native fetch)</h4>
      <Code
        language="js"
        code={`async function createBooking(input) {
  const res = await fetch('${BASE_URL}/bookings', {
    method: 'POST',
    headers: {
      'Authorization': \`Bearer \${process.env.BCL_KEY}\`,
      'Content-Type': 'application/json',
      'Idempotency-Key': crypto.randomUUID(),
    },
    body: JSON.stringify(input),
  });
  if (!res.ok) throw new Error(\`booking failed: \${res.status}\`);
  return res.json();
}`}
      />
      <h4 className="font-semibold text-brand-ink mt-4 mb-2">Python 3.12 (urllib3)</h4>
      <Code
        language="py"
        code={`import os, json, urllib.request, uuid

def create_booking(payload: dict) -> dict:
    req = urllib.request.Request(
        '${BASE_URL}/bookings',
        method='POST',
        headers={
            'Authorization': f'Bearer {os.environ["BCL_KEY"]}',
            'Content-Type': 'application/json',
            'Idempotency-Key': str(uuid.uuid4()),
        },
        data=json.dumps(payload).encode('utf-8'),
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read())`}
      />
      <h4 className="font-semibold text-brand-ink mt-4 mb-2">Curl</h4>
      <Code
        language="sh"
        code={`curl -X POST -H "Authorization: Bearer $BCL_KEY" \\
  -H "Content-Type: application/json" \\
  -H "Idempotency-Key: $(uuidgen)" \\
  -d '{"name":"...", "email":"...", "preferredDate":"2026-06-01", "services":["power-wash"], "hours":2}' \\
  ${BASE_URL}/bookings`}
      />
    </Section>
  );
}

function Sandbox() {
  return (
    <Section id="sandbox" title="Sandbox · Live request builder">
      <p>
        Paste a test key (<code className="font-mono text-brand-accent">bcl_test_*</code>), pick an
        endpoint, tweak the JSON, and fire. Responses round-trip live against our API.
      </p>
      <RequestBuilder />
    </Section>
  );
}

function FaqSection({ items }: { items: ReadonlyArray<{ q: string; a: string }> }) {
  return (
    <section id="faq" className="mt-16 border-t border-brand-line pt-10">
      <h2 className="text-2xl font-extrabold mb-6">FAQ</h2>
      <dl className="space-y-6">
        {items.map((item) => (
          <div key={item.q}>
            <dt className="font-semibold text-brand-ink mb-1">{item.q}</dt>
            <dd className="text-brand-mute leading-relaxed">{item.a}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}

// ─── Primitives ────────────────────────────────────────────────────────

function Section(props: { id: string; title: string; children: React.ReactNode }) {
  return (
    <section id={props.id} className="mb-14 scroll-mt-24">
      <h2 className="text-2xl font-extrabold mb-4">{props.title}</h2>
      <div className="space-y-4 text-brand-mute leading-relaxed">{props.children}</div>
    </section>
  );
}

function Endpoint(props: {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  path: string;
  scope: string;
  description: string;
}) {
  const colorByMethod: Record<string, string> = {
    GET: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
    POST: 'bg-brand-accent/15 text-brand-accent border-brand-accent/30',
    PUT: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
    DELETE: 'bg-rose-500/15 text-rose-300 border-rose-500/30',
  };
  return (
    <div className="mt-6 rounded-lg border border-brand-line bg-bg-elevated/40 p-5">
      <div className="flex flex-wrap items-center gap-3 font-mono text-sm">
        <span
          className={`rounded border px-2 py-1 text-xs font-bold uppercase ${colorByMethod[props.method] || ''}`}
        >
          {props.method}
        </span>
        <code className="text-brand-ink">{props.path}</code>
        <span className="ml-auto text-xs text-brand-mute">
          scope · <code className="text-brand-accent">{props.scope}</code>
        </span>
      </div>
      <p className="mt-3 text-sm text-brand-mute">{props.description}</p>
    </div>
  );
}

function Code(props: { language: string; code: string }) {
  const [copied, setCopied] = useState(false);
  async function copy() {
    try {
      await navigator.clipboard.writeText(props.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    } catch {
      // Clipboard blocked — no-op
    }
  }
  return (
    <div className="my-3 rounded-lg border border-brand-line bg-bg-primary overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2 border-b border-brand-line text-xs font-mono uppercase tracking-wider text-brand-mute">
        <span>{props.language}</span>
        <button
          type="button"
          onClick={copy}
          className="text-brand-mute hover:text-brand-accent focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent rounded px-2 py-0.5"
          aria-label="Copy code"
        >
          {copied ? 'Copied!' : 'Copy'}
        </button>
      </div>
      <pre className="m-0 px-4 py-4 overflow-x-auto text-sm font-mono text-brand-ink whitespace-pre">
        <code>{props.code}</code>
      </pre>
      {/* WCAG 4.1.3 — announce the copy to screen readers (the button label flip
          to "Copied!" is otherwise silent). */}
      <span className="sr-only" role="status" aria-live="polite">
        {copied ? `${props.language} code copied to clipboard` : ''}
      </span>
    </div>
  );
}

// ─── Sandbox builder ───────────────────────────────────────────────────

type EndpointKey = 'me' | 'cities' | 'availability' | 'bookings-create' | 'bookings-get';

interface EndpointSpec {
  readonly key: EndpointKey;
  readonly label: string;
  readonly method: 'GET' | 'POST';
  readonly path: (params: Record<string, string>) => string;
  readonly defaultBody?: string;
  readonly params: ReadonlyArray<{ name: string; placeholder: string }>;
}

const ENDPOINTS: ReadonlyArray<EndpointSpec> = [
  { key: 'me', label: 'GET /me', method: 'GET', path: () => '/me', params: [] },
  { key: 'cities', label: 'GET /cities', method: 'GET', path: () => '/cities', params: [] },
  {
    key: 'availability',
    label: 'GET /availability',
    method: 'GET',
    path: (p) =>
      `/availability?date=${encodeURIComponent(p.date || '2026-06-01')}&hours=${p.hours || '2'}`,
    params: [
      { name: 'date', placeholder: '2026-06-01' },
      { name: 'hours', placeholder: '2' },
    ],
  },
  {
    key: 'bookings-create',
    label: 'POST /bookings',
    method: 'POST',
    path: () => '/bookings',
    defaultBody: JSON.stringify(
      {
        name: 'Sandbox Tester',
        email: 'sandbox@example.com',
        phone: '555-867-5309',
        address: '123 Test St',
        city: 'Newark',
        zip: '07102',
        preferredDate: '2026-06-01',
        preferredTime: '10:00 AM',
        services: ['power-wash'],
        hours: 2,
        crew: 1,
        paymentMode: 'none',
        origin: 'api',
      },
      null,
      2,
    ),
    params: [],
  },
  {
    key: 'bookings-get',
    label: 'GET /bookings/:id',
    method: 'GET',
    path: (p) => `/bookings/${encodeURIComponent(p.id || '')}`,
    params: [{ name: 'id', placeholder: 'booking id' }],
  },
];

function RequestBuilder() {
  const [key, setKey] = useState('');
  const [endpointKey, setEndpointKey] = useState<EndpointKey>('me');
  const endpoint = useMemo(
    () => ENDPOINTS.find((e) => e.key === endpointKey) ?? ENDPOINTS[0]!,
    [endpointKey],
  );
  const [params, setParams] = useState<Record<string, string>>({});
  const [body, setBody] = useState(endpoint.defaultBody ?? '');
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<string>('');
  const [status, setStatus] = useState<number | null>(null);

  useEffect(() => {
    setBody(endpoint.defaultBody ?? '');
    setParams({});
    setResponse('');
    setStatus(null);
  }, [endpoint]);

  async function fire() {
    setLoading(true);
    setResponse('');
    setStatus(null);
    try {
      const url = `${BASE_URL}${endpoint.path(params)}`;
      const headers: Record<string, string> = {
        Authorization: `Bearer ${key.trim()}`,
        'Content-Type': 'application/json',
      };
      const init: RequestInit = { method: endpoint.method, headers };
      if (endpoint.method === 'POST') {
        headers['Idempotency-Key'] = `sandbox-${Date.now()}`;
        init.body = body;
      }
      const res = await fetch(url, init);
      setStatus(res.status);
      const text = await res.text();
      try {
        setResponse(JSON.stringify(JSON.parse(text), null, 2));
      } catch {
        setResponse(text);
      }
    } catch (err) {
      setResponse(`Network error: ${(err as Error).message}`);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="rounded-lg border border-brand-line bg-bg-elevated/40 p-5 space-y-4">
      <div className="grid sm:grid-cols-2 gap-3">
        <label className="block text-sm">
          <span className="block mb-1 text-brand-mute">Test key</span>
          <input
            type="text"
            value={key}
            onChange={(e) => setKey(e.target.value)}
            placeholder="bcl_test_..."
            className="w-full rounded border border-brand-line bg-bg px-3 py-2 font-mono text-sm text-brand-ink focus:border-brand-accent focus:outline-none"
            autoComplete="off"
            spellCheck={false}
          />
        </label>
        <label className="block text-sm">
          <span className="block mb-1 text-brand-mute">Endpoint</span>
          <select
            value={endpointKey}
            onChange={(e) => setEndpointKey(e.target.value as EndpointKey)}
            className="w-full rounded border border-brand-line bg-bg px-3 py-2 text-sm text-brand-ink focus:border-brand-accent focus:outline-none"
          >
            {ENDPOINTS.map((ep) => (
              <option key={ep.key} value={ep.key}>
                {ep.label}
              </option>
            ))}
          </select>
        </label>
      </div>
      {endpoint.params.length > 0 && (
        <div className="grid sm:grid-cols-2 gap-3">
          {endpoint.params.map((p) => (
            <label key={p.name} className="block text-sm">
              <span className="block mb-1 text-brand-mute">{p.name}</span>
              <input
                type="text"
                value={params[p.name] ?? ''}
                onChange={(e) => setParams((prev) => ({ ...prev, [p.name]: e.target.value }))}
                placeholder={p.placeholder}
                className="w-full rounded border border-brand-line bg-bg px-3 py-2 font-mono text-sm text-brand-ink focus:border-brand-accent focus:outline-none"
                autoComplete="off"
                spellCheck={false}
              />
            </label>
          ))}
        </div>
      )}
      {endpoint.method === 'POST' && (
        <label className="block text-sm">
          <span className="block mb-1 text-brand-mute">Body (JSON)</span>
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={12}
            className="w-full rounded border border-brand-line bg-bg px-3 py-2 font-mono text-xs text-brand-ink focus:border-brand-accent focus:outline-none"
            spellCheck={false}
          />
        </label>
      )}
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={fire}
          disabled={loading || !key.trim()}
          className="rounded bg-brand-accent px-4 py-2 text-sm font-semibold text-bg hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          {loading ? 'Sending…' : `Send ${endpoint.method} ${endpoint.path(params)}`}
        </button>
        {status !== null && (
          <span
            className={`font-mono text-sm ${
              status >= 200 && status < 300 ? 'text-emerald-300' : 'text-rose-300'
            }`}
          >
            HTTP {status}
          </span>
        )}
      </div>
      {response && (
        <pre className="m-0 rounded border border-brand-line bg-bg-primary px-4 py-4 overflow-x-auto text-xs font-mono text-brand-ink whitespace-pre">
          <code>{response}</code>
        </pre>
      )}
      <p className="text-xs text-brand-mute">
        Tip: use a <code className="font-mono text-brand-accent">bcl_test_*</code> key — live keys
        will create real bookings and dispatch a real crew.
      </p>
    </div>
  );
}

function setMeta(name: string, content: string, attr: 'name' | 'property' = 'name') {
  let el = document.querySelector<HTMLMetaElement>(`meta[${attr}="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}
