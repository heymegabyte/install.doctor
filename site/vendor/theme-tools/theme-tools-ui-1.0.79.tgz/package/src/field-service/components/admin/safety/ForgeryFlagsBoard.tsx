import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

/**
 * License forgery flags board. Lists every pending review (forgery score
 * descending), with a "Rescan" action that hits /api/admin/safety/forgery-scan/:docId.
 */

interface ForgeryRow {
  id: string;
  document_id: string;
  score: number;
  signals: string;
  reviewed_at: string | null;
  created_at: string;
}

export function ForgeryFlagsBoard({ auth }: { readonly auth: HeadersInit }) {
  useThemeToolsSurface('forgery-flags-board');
  const [rows, setRows] = useState<ForgeryRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);

  async function reload() {
    setError('');
    try {
      const res = await fetch('/api/admin/safety/forgery-flags', { headers: auth });
      if (res.status === 404) {
        setRows([]);
        return;
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as { rows?: ForgeryRow[] };
      setRows(data.rows ?? []);
    } catch (err) {
      setError((err as Error).message);
    }
  }

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    (async () => {
      await reload();
      if (!cancelled) setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auth]);

  async function rescan(docId: string) {
    setBusyId(docId);
    try {
      await fetch(`/api/admin/safety/forgery-scan/${docId}`, {
        method: 'POST',
        headers: auth,
      });
      await reload();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusyId(null);
    }
  }

  return (
    <section aria-labelledby="forgery-h" className="space-y-3">
      <header>
        <h2 id="forgery-h" className="text-xl font-bold">
          License forgery flags
        </h2>
        <p className="text-brand-mute text-sm">
          AI Vision (EXIF + visual). Sort by score; rescan after re-upload.
        </p>
      </header>

      {error && <p className="text-rose-400 text-sm">{error}</p>}
      {loading && <p className="text-brand-mute text-sm">Loading…</p>}
      {!loading && rows.length === 0 && <p className="text-brand-mute text-sm">No active flags.</p>}

      {rows.length > 0 && (
        <ul className="space-y-2">
          {rows.map((row) => {
            const signals = safeJson(row.signals);
            return (
              <li
                key={row.id}
                className="rounded-md border border-brand-line bg-brand-ink/40 p-3 text-sm"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-mono text-xs">doc {row.document_id.slice(0, 8)}</span>
                  <span
                    className={
                      'rounded-full px-2 py-0.5 text-xs ' +
                      (row.score >= 0.6
                        ? 'bg-rose-900/40 text-rose-200'
                        : row.score >= 0.3
                          ? 'bg-amber-900/40 text-amber-200'
                          : 'bg-emerald-900/30 text-emerald-200')
                    }
                  >
                    score {row.score.toFixed(2)}
                  </span>
                  <button
                    type="button"
                    onClick={() => rescan(row.document_id)}
                    disabled={busyId === row.document_id}
                    className="btn btn-secondary text-xs disabled:opacity-60"
                  >
                    {busyId === row.document_id ? 'Rescanning…' : 'Rescan'}
                  </button>
                </div>
                {Array.isArray(signals) && signals.length > 0 && (
                  <ul className="mt-2 list-disc pl-5 text-xs text-brand-mute">
                    {signals.map((s, i) => (
                      <li key={i}>{describeSignal(s)}</li>
                    ))}
                  </ul>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

function safeJson(s: string | null | undefined): unknown {
  if (!s) return null;
  try {
    return JSON.parse(s);
  } catch {
    return null;
  }
}

function describeSignal(s: unknown): string {
  if (!s || typeof s !== 'object') return String(s);
  const obj = s as { kind?: string; weight?: number; detail?: string };
  return `${obj.kind ?? '?'} (${(obj.weight ?? 0).toFixed(2)})${obj.detail ? ' — ' + obj.detail : ''}`;
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
