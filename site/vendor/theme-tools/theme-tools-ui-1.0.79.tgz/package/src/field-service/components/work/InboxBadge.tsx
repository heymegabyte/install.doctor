import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useState } from 'react';
import { InboxPanel } from './InboxPanel.js';

// Wave 21B — bell-icon button + unread count badge mounted in the dashboard
// header. Clicking opens the slide-out InboxPanel.
//
// Polls /api/work/inbox?unread=1 every 60s for live counts and re-fetches on
// `focus`/`visibilitychange` so a worker who tabs away and back gets fresh
// state without a manual refresh.

interface InboxApiResponse {
  unread: number;
  items: unknown[];
}

export function InboxBadge(): JSX.Element {
  useThemeToolsSurface('inbox-badge');
  const [unread, setUnread] = useState<number>(0);
  const [open, setOpen] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await fetch('/api/work/inbox?unread=1', {
        credentials: 'include',
        headers: { Accept: 'application/json' },
      });
      if (!res.ok) return;
      const j = (await res.json()) as InboxApiResponse;
      setUnread(Number(j.unread ?? 0));
    } catch {
      // Best-effort — badge stays at last known value.
    }
  }, []);

  useEffect(() => {
    void load();
    const t = window.setInterval(() => void load(), 60_000);
    const onFocus = (): void => void load();
    window.addEventListener('focus', onFocus);
    document.addEventListener('visibilitychange', onFocus);
    return () => {
      window.clearInterval(t);
      window.removeEventListener('focus', onFocus);
      document.removeEventListener('visibilitychange', onFocus);
    };
  }, [load]);

  return (
    <>
      <button
        type="button"
        aria-label={unread > 0 ? `Inbox — ${unread} unread` : 'Inbox'}
        aria-expanded={open}
        aria-controls="worker-inbox-panel"
        onClick={() => setOpen((v) => !v)}
        className="relative inline-flex items-center justify-center h-9 w-9 rounded-xl border border-brand-line text-brand-ink hover:bg-brand-card transition-colors"
      >
        <span aria-hidden="true" className="text-lg leading-none">
          {/* bell glyph — kept inline so we don't need an icon dep */}
          <svg
            viewBox="0 0 24 24"
            width="20"
            height="20"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
            <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
          </svg>
        </span>
        {unread > 0 && (
          <span
            aria-hidden="true"
            className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 inline-flex items-center justify-center rounded-full bg-red-500 text-[10px] font-extrabold text-white"
          >
            {unread > 99 ? '99+' : unread}
          </span>
        )}
      </button>
      <InboxPanel
        open={open}
        onClose={() => {
          setOpen(false);
          void load();
        }}
      />
    </>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
