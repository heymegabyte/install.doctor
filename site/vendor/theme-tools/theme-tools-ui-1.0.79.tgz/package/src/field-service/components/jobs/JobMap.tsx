import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { useEffect, useRef, useState } from 'react';
import {
  DARK_MAP_STYLES,
  fetchMapsConfig,
  formatDistance,
  formatEta,
  loadGoogleMaps,
} from '../../google-maps.js';

export interface LatLng {
  readonly lat: number;
  readonly lng: number;
}

interface Props {
  /** Job destination (the customer's address). */
  readonly destination: LatLng | null;
  /** Live position of the moving party (crew truck on customer view; "you" on crew view). */
  readonly crewPosition?: (LatLng & { heading?: number | null }) | null;
  /** Straight-line ETA + distance from crewPosition → destination. */
  readonly etaSeconds?: number | null;
  readonly distanceMeters?: number | null;
  /** Label for the moving marker. */
  readonly moverLabel?: string;
  /** Visual height. */
  readonly heightClass?: string;
}

// Orange dest pin + cyan moving marker, drawn as inline SVG dataURIs so they
// render without a Cloud Map ID (matches MapInner's classic-marker fallback).
function pinSvg(color: string, stroke: string): string {
  return (
    'data:image/svg+xml;charset=UTF-8,' +
    encodeURIComponent(
      `<svg xmlns="http://www.w3.org/2000/svg" width="28" height="36" viewBox="0 0 28 36">` +
        `<path d="M14 0C6.8 0 1 5.8 1 13c0 9.2 13 23 13 23s13-13.8 13-23C27 5.8 21.2 0 14 0z" fill="${color}" stroke="${stroke}" stroke-width="1.5"/>` +
        `<circle cx="14" cy="13" r="5" fill="#0a0e14"/>` +
        `</svg>`,
    )
  );
}
function truckSvg(): string {
  return (
    'data:image/svg+xml;charset=UTF-8,' +
    encodeURIComponent(
      `<svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34">` +
        `<circle cx="17" cy="17" r="15" fill="#22D3EE" stroke="#0a0e14" stroke-width="2"/>` +
        `<path d="M8 20v-7h9v7M17 16h5l3 3v1h-8M11 22.5a1.7 1.7 0 1 1-3.4 0 1.7 1.7 0 0 1 3.4 0zM23 22.5a1.7 1.7 0 1 1-3.4 0 1.7 1.7 0 0 1 3.4 0z" fill="none" stroke="#0a0e14" stroke-width="1.6" stroke-linejoin="round"/>` +
        `</svg>`,
    )
  );
}

export function JobMap({
  destination,
  crewPosition,
  etaSeconds,
  distanceMeters,
  moverLabel = 'Crew',
  heightClass = 'h-64 sm:h-80',
}: Props) {
  useThemeToolsSurface('job-map');
  const ref = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<google.maps.Map | null>(null);
  const destMarkerRef = useRef<google.maps.Marker | null>(null);
  const moverMarkerRef = useRef<google.maps.Marker | null>(null);
  const lineRef = useRef<google.maps.Polyline | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error' | 'disabled'>('loading');

  // Boot the SDK + base map once.
  useEffect(() => {
    if (!ref.current || !destination) return;
    let cancelled = false;
    (async () => {
      try {
        const cfg = await fetchMapsConfig();
        if (cancelled) return;
        if (!cfg.ok || !cfg.apiKey) {
          setStatus('disabled');
          return;
        }
        await loadGoogleMaps(cfg.apiKey);
        if (cancelled || !ref.current) return;
        const { Map: GMap } = (await google.maps.importLibrary('maps')) as google.maps.MapsLibrary;
        if (cancelled || !ref.current) return;
        const options: google.maps.MapOptions = {
          center: destination,
          zoom: 13,
          gestureHandling: 'cooperative',
          streetViewControl: false,
          mapTypeControl: false,
          fullscreenControl: false,
          clickableIcons: false,
          zoomControl: true,
          backgroundColor: '#0a0e14',
        };
        if (cfg.mapId) options.mapId = cfg.mapId;
        else options.styles = DARK_MAP_STYLES;
        mapRef.current = new GMap(ref.current, options);
        setStatus('ready');
      } catch {
        if (!cancelled) setStatus('error');
      }
    })();
    return () => {
      cancelled = true;
      destMarkerRef.current?.setMap(null);
      moverMarkerRef.current?.setMap(null);
      lineRef.current?.setMap(null);
      mapRef.current = null;
    };
    // Re-boot only if the destination identity changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [destination?.lat, destination?.lng]);

  // Draw / update the destination pin.
  useEffect(() => {
    if (status !== 'ready' || !mapRef.current || !destination) return;
    if (!destMarkerRef.current) {
      destMarkerRef.current = new google.maps.Marker({
        map: mapRef.current,
        title: 'Job location',
        icon: {
          url: pinSvg('#FF6B1A', '#0A0E14'),
          scaledSize: new google.maps.Size(28, 36),
          anchor: new google.maps.Point(14, 36),
        },
        zIndex: 10,
      });
    }
    destMarkerRef.current.setPosition(destination);
  }, [status, destination?.lat, destination?.lng]);

  // Draw / update the live moving marker + route hint + viewport fit.
  useEffect(() => {
    if (status !== 'ready' || !mapRef.current) return;
    const map = mapRef.current;
    if (crewPosition) {
      if (!moverMarkerRef.current) {
        moverMarkerRef.current = new google.maps.Marker({
          map,
          title: moverLabel,
          icon: {
            url: truckSvg(),
            scaledSize: new google.maps.Size(34, 34),
            anchor: new google.maps.Point(17, 17),
          },
          zIndex: 20,
        });
      }
      moverMarkerRef.current.setPosition(crewPosition);

      // Lightweight straight-line "route hint" (Directions API is paid; the
      // geofence DO owns precise arrival, so a dashed geodesic is enough).
      if (destination) {
        if (!lineRef.current) {
          lineRef.current = new google.maps.Polyline({
            map,
            geodesic: true,
            strokeOpacity: 0,
            icons: [
              {
                icon: { path: 'M 0,-1 0,1', strokeOpacity: 0.7, scale: 3, strokeColor: '#22D3EE' },
                offset: '0',
                repeat: '12px',
              },
            ],
          });
        }
        lineRef.current.setPath([crewPosition, destination]);
        const bounds = new google.maps.LatLngBounds();
        bounds.extend(crewPosition);
        bounds.extend(destination);
        map.fitBounds(bounds, 64);
      }
    } else if (destination) {
      map.setCenter(destination);
      map.setZoom(14);
    }
  }, [status, crewPosition?.lat, crewPosition?.lng, destination?.lat, destination?.lng, moverLabel]);

  if (!destination) return null;

  return (
    <div className={`relative w-full overflow-hidden rounded-xl ${heightClass}`} data-testid="job-map">
      <div ref={ref} className="h-full w-full" />
      {(status === 'loading' || status === 'error' || status === 'disabled') && (
        <div className="absolute inset-0 flex items-center justify-center bg-bg-elevated/70 font-mono text-sm text-brand-mute">
          <div className="flex items-center gap-3">
            {status === 'loading' && (
              <span className="inline-block h-2 w-2 animate-pulse rounded-full bg-brand-accent" />
            )}
            {status === 'loading'
              ? 'Loading live map…'
              : status === 'disabled'
                ? 'Map offline — call (855) 82LABOR'
                : 'Map unavailable'}
          </div>
        </div>
      )}
      {status === 'ready' && etaSeconds != null && (
        <div
          className="pointer-events-none absolute left-3 top-3 flex items-center gap-2 rounded-full bg-bg-base/85 px-3 py-1.5 font-mono text-sm text-brand-ink shadow-lg backdrop-blur"
          aria-live="polite"
          data-testid="job-map-eta"
        >
          <span className="inline-block h-2 w-2 animate-pulse rounded-full bg-[#22D3EE]" />
          <span>
            ETA <strong>{formatEta(etaSeconds)}</strong>
            {distanceMeters != null ? (
              <span className="text-brand-mute"> · {formatDistance(distanceMeters)} out</span>
            ) : null}
          </span>
        </div>
      )}
    </div>
  );
}
