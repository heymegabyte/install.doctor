import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useState } from 'react';

/**
 * CrewScoreboard — AI-driven crew quality leaderboard.
 *
 * 1. Loads active workers from `/admin/entities/workers?active=true`.
 * 2. Caps the list at 20 (don't blast AI on a 200-worker account).
 * 3. For each worker, fires `POST /api/ai/crew-quality` with `{workerId}` and
 *    collects the returned score + tier + coaching points.
 * 4. Renders an ordered table: rank · name · tier · score · 1st coaching point.
 * 5. Click a row to expand and show the full coaching plan.
 *
 * Bearer-gated via the standard owner key. Calls are run with bounded
 * parallelism (5 at a time) to keep the AI gateway happy.
 */

interface WorkerRow {
  id: string;
  first_name: string;
  last_name: string;
  tier: string;
  city: string | null;
  jobs_completed: number;
  rating_avg: number | null;
}

interface Score {
  qualityScore: number;
  tier: 'rookie' | 'reliable' | 'top_25' | 'top_10';
  strengths: string[];
  coachingPoints: string[];
  rationale: string;
}

interface ScoredWorker extends WorkerRow {
  score: Score | null;
  failed: boolean;
}

const MAX_WORKERS = 20;
const CONCURRENCY = 5;

const TIER_COLOR: Record<Score['tier'], string> = {
  rookie: 'text-brand-mute',
  reliable: 'text-brand-ink',
  top_25: 'text-brand-accent',
  top_10: 'text-brand-accent font-semibold',
};

export function CrewScoreboard({ bearer }: { bearer: string }) {
  useThemeToolsSurface('crew-scoreboard');
  const [workers, setWorkers] = useState<ScoredWorker[]>([]);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('');
  const [openId, setOpenId] = useState<string | null>(null);
  const [progress, setProgress] = useState<{ done: number; total: number }>({
    done: 0,
    total: 0,
  });

  const headers = useCallback(
    (): HeadersInit => ({
      'content-type': 'application/json',
      authorization: `Bearer ${bearer}`,
    }),
    [bearer],
  );

  const run = useCallback(async () => {
    if (!bearer) return;
    setLoading(true);
    setStatus('');
    setWorkers([]);
    setOpenId(null);
    try {
      const res = await fetch(`/admin/entities/workers?active=true&limit=${MAX_WORKERS}`, {
        headers: headers(),
      });
      const json = (await res.json()) as { ok: boolean; workers?: WorkerRow[]; error?: string };
      if (!res.ok || !json.ok) {
        setStatus(json.error ?? `HTTP ${res.status}`);
        setLoading(false);
        return;
      }
      const base = (json.workers ?? []).slice(0, MAX_WORKERS);
      if (base.length === 0) {
        setLoading(false);
        return;
      }
      setProgress({ done: 0, total: base.length });

      const scored: ScoredWorker[] = base.map((w) => ({ ...w, score: null, failed: false }));
      setWorkers(scored);

      // Bounded parallel runner — `CONCURRENCY` workers in flight at a time.
      let next = 0;
      const advance = async (): Promise<void> => {
        while (next < base.length) {
          const i = next++;
          const w = base[i]!;
          try {
            const r = await fetch('/api/ai/crew-quality', {
              method: 'POST',
              headers: headers(),
              body: JSON.stringify({ workerId: w.id }),
            });
            const j = (await r.json()) as { ok: boolean; score?: Score };
            if (r.ok && j.ok && j.score) {
              scored[i] = { ...scored[i]!, score: j.score };
            } else {
              scored[i] = { ...scored[i]!, failed: true };
            }
          } catch {
            scored[i] = { ...scored[i]!, failed: true };
          }
          setWorkers([...scored]);
          setProgress((p) => ({ done: p.done + 1, total: p.total }));
        }
      };

      await Promise.all(
        Array.from({ length: Math.min(CONCURRENCY, base.length) }, () => advance()),
      );
    } catch (err) {
      setStatus((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, [bearer, headers]);

  useEffect(() => {
    void run();
  }, [run]);

  const ranked = [...workers]
    .filter((w) => w.score)
    .sort((a, b) => b.score!.qualityScore - a.score!.qualityScore);

  if (!bearer) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
        <h2 className="text-xl font-bold text-brand-ink">Crew scoreboard</h2>
        <p className="mt-2 text-sm text-brand-mute">
          Add the owner key above to load the AI quality leaderboard.
        </p>
      </section>
    );
  }

  return (
    <section className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-brand-ink">Crew scoreboard</h2>
          <p className="mt-1 text-sm text-brand-mute">
            AI quality score per active crew · top {MAX_WORKERS}
          </p>
        </div>
        <button
          type="button"
          onClick={() => void run()}
          disabled={loading}
          className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-xs text-brand-ink hover:border-brand-accent disabled:opacity-50"
        >
          {loading ? `Scoring ${progress.done}/${progress.total}…` : 'Refresh'}
        </button>
      </div>

      {status && <p className="mt-3 text-xs text-red-400">{status}</p>}

      {workers.length === 0 && !loading ? (
        <p className="mt-4 rounded-md border border-dashed border-brand-line p-4 text-sm text-brand-mute">
          No active crew. Onboard a worker first.
        </p>
      ) : (
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-brand-line text-left">
                <th className="px-2 py-2 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                  #
                </th>
                <th className="px-2 py-2 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                  Crew
                </th>
                <th className="px-2 py-2 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                  Tier
                </th>
                <th className="px-2 py-2 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                  Score
                </th>
                <th className="px-2 py-2 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
                  Coaching
                </th>
              </tr>
            </thead>
            <tbody>
              {ranked.map((w, idx) => {
                const open = openId === w.id;
                const coach0 = w.score!.coachingPoints[0] ?? '—';
                return (
                  <>
                    <tr
                      key={w.id}
                      onClick={() => setOpenId(open ? null : w.id)}
                      className="cursor-pointer border-b border-brand-line/60 hover:bg-bg-primary"
                    >
                      <td className="px-2 py-2 font-mono text-xs text-brand-mute">{idx + 1}</td>
                      <td className="px-2 py-2 text-brand-ink">
                        <span className="font-semibold">
                          {w.first_name} {w.last_name}
                        </span>
                        <span className="ml-2 font-mono text-[10px] text-brand-mute">
                          {w.id.slice(0, 8)}
                        </span>
                      </td>
                      <td
                        className={`px-2 py-2 font-mono text-xs uppercase ${TIER_COLOR[w.score!.tier]}`}
                      >
                        {w.score!.tier.replace('_', ' ')}
                      </td>
                      <td className="px-2 py-2 font-mono text-base text-brand-ink">
                        {w.score!.qualityScore}
                      </td>
                      <td className="px-2 py-2 text-xs text-brand-mute">
                        <span className="line-clamp-1">{coach0}</span>
                      </td>
                    </tr>
                    {open && (
                      <tr
                        key={`${w.id}-detail`}
                        className="border-b border-brand-line/60 bg-bg-primary"
                      >
                        <td colSpan={5} className="px-3 py-3 text-sm">
                          <p className="mb-2 text-brand-ink">{w.score!.rationale}</p>
                          {w.score!.strengths.length > 0 && (
                            <>
                              <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">
                                Strengths
                              </p>
                              <ul className="mb-2 ml-4 list-disc text-brand-mute">
                                {w.score!.strengths.map((s, i) => (
                                  <li key={i}>{s}</li>
                                ))}
                              </ul>
                            </>
                          )}
                          {w.score!.coachingPoints.length > 0 && (
                            <>
                              <p className="font-mono text-[10px] uppercase tracking-widest text-brand-accent">
                                Coaching points
                              </p>
                              <ul className="ml-4 list-disc text-brand-mute">
                                {w.score!.coachingPoints.map((c, i) => (
                                  <li key={i}>{c}</li>
                                ))}
                              </ul>
                            </>
                          )}
                        </td>
                      </tr>
                    )}
                  </>
                );
              })}
              {workers
                .filter((w) => w.failed)
                .map((w) => (
                  <tr key={`fail-${w.id}`} className="border-b border-brand-line/40 text-xs">
                    <td className="px-2 py-1 text-brand-mute">—</td>
                    <td className="px-2 py-1 text-brand-mute">
                      {w.first_name} {w.last_name}
                    </td>
                    <td colSpan={3} className="px-2 py-1 text-brand-mute">
                      AI scoring failed for this crew member.
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
