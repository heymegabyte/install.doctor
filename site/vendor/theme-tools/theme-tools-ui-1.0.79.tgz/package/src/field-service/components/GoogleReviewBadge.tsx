import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect, useState } from 'react';

interface ReviewsResponse {
  ok?: boolean;
  disabled?: boolean;
  rating?: number | null;
  ratingCount?: number | null;
}

/**
 * Google Review Badge — inline trust element showing the live rating + count.
 *
 * Reads the SERVER-PROXIED `/api/reviews` endpoint (same-origin → no CORS, and the Places API key
 * stays on the worker, never in the client bundle). The worker calls Places API (New) server-side
 * with `GOOGLE_MAPS_API_KEY` + `GOOGLE_PLACE_ID`, KV-caches 24h, and returns `{ ok:true,
 * disabled:true, rating:null }` when unkeyed. This badge falls back to a static branded estimate
 * whenever the live rating is absent — a broken/empty call must never show a broken UI, and must
 * never log a console error. (The old client-side `places.googleapis.com` fetch was CORS-blocked on
 * EVERY page — Places API New has no browser CORS — and leaked the API key into the bundle.)
 */
export function GoogleReviewBadge(): JSX.Element {
  useThemeToolsSurface('google-review-badge');
  const [rating, setRating] = useState<number | null>(null);
  const [total, setTotal] = useState<number | null>(null);

  useEffect(() => {
    let cancelled = false;
    // Same-origin → no CORS; the endpoint is keyless-safe (always 200), so a failed/empty response
    // never logs a console error — the badge simply keeps its static fallback.
    fetch('/api/reviews', { headers: { accept: 'application/json' } })
      .then((res) => (res.ok ? (res.json() as Promise<ReviewsResponse>) : Promise.reject(res.status)))
      .then((data) => {
        if (cancelled || !data.ok || data.disabled) return;
        if (typeof data.rating === 'number') setRating(data.rating);
        if (typeof data.ratingCount === 'number') setTotal(data.ratingCount);
      })
      .catch(() => {
        /* remain on static fallback — same-origin, no console noise */
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const displayRating = rating ?? 5.0;
  const displayTotal = total ?? 50;

  return (
    <a
      href="https://g.page/r/Cfkhxm5cS2DZEBM/review"
      target="_blank"
      rel="noopener noreferrer"
      data-testid="google-review-badge"
      data-theme-tools-component="GoogleReviewBadge"
      className="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full border border-black/85 bg-[#0c1017] px-3.5 py-2 text-xs shadow-[0_14px_34px_rgba(0,0,0,0.88),0_0_0_1px_rgba(0,0,0,0.85),inset_0_1px_0_rgba(255,255,255,0.04)] hover:border-brand-accent transition-all duration-[333ms]"
    >
      {/* Google G icon — inline SVG for zero network dependency */}
      <svg viewBox="0 0 24 24" className="w-4 h-4 flex-shrink-0" aria-hidden="true">
        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" />
        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
      </svg>
      <span className="flex items-baseline gap-1.5">
        <strong className="text-xs font-bold text-brand-ink">{displayRating.toFixed(1)}</strong>
        <span className="text-[11px] tracking-wide text-brand-mute">
          ★★★★★ · {displayTotal}+ reviews
        </span>
      </span>
    </a>
  );
}
