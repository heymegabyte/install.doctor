import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import type { JSX, ReactNode } from 'react';
import { Logo } from '../Logo.js';

// Shared shell used by every auth/system surface (customer login, crew login,
// admin login, password reset, magic-link verify, etc). Keeps the visual
// system identical so any new auth page picks up:
//   • orange-rail top gradient on the elevated card
//   • BRICKLABOR wordmark + audience badge
//   • eyebrow → headline → body pattern matching the booking confirmation
//   • consistent stage dots when the form is multi-step
//
// Slot the form inside as children. Background, padding, and max-width are
// all handled here so individual pages stay small.

export type AuthStage = 'contact' | 'code' | 'success';

interface AuthShellProps {
  readonly eyebrow: string;
  readonly headline: string;
  readonly body: ReactNode;
  readonly badge?: string;
  readonly stage?: AuthStage;
  readonly stageLabels?: Readonly<Record<AuthStage, string>>;
  readonly footer?: ReactNode;
  readonly children: ReactNode;
  /** Doubles the container to `max-w-4xl` (896px ≈ 2× the default `max-w-md`). */
  readonly wide?: boolean;
  /** Optional side panel rendered beside the auth card (2-col on desktop). */
  readonly aside?: ReactNode;
  /**
   * Suppresses the in-card header row (secondary wordmark + audience badge).
   * Used on `/login`, where the global `<Header>` already shows the primary
   * Brick Labor logo, so the duplicate small logo + "Sign in" pill are noise.
   */
  readonly hideChrome?: boolean;
}

const DEFAULT_STAGE_LABELS: Readonly<Record<AuthStage, string>> = {
  contact: 'Contact',
  code: 'Verify',
  success: 'Done',
};

export function AuthShell({
  eyebrow,
  headline,
  body,
  badge,
  stage,
  stageLabels = DEFAULT_STAGE_LABELS,
  footer,
  children,
  wide,
  aside,
  hideChrome,
}: AuthShellProps): JSX.Element {
  useThemeToolsSurface('auth-shell');
  return (
    <article className="section">
      <div className={`container-pad ${wide || aside ? 'max-w-4xl' : 'max-w-md'}`}>
        {!hideChrome && (
          <div className="mb-7 flex items-center justify-between gap-4">
            <a
              href="/"
              aria-label="Brick Labor home"
              className="inline-flex items-center gap-2.5 rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:ring-offset-2 focus-visible:ring-offset-bg-primary"
            >
              <Logo className="h-7 w-auto" />
              <span className="sr-only">Brick Labor</span>
            </a>
            {badge && (
              <span className="rounded-full border border-brand-line bg-bg-elevated px-3 py-1 font-mono text-[10px] uppercase tracking-[0.18em] text-brand-mute">
                {badge}
              </span>
            )}
          </div>
        )}

        <div className={aside ? 'grid items-start gap-6 md:grid-cols-2' : undefined}>
          <div className="auth-card">
            <p className="eyebrow mb-3">{eyebrow}</p>
            <h1 className="font-display text-3xl sm:text-4xl font-extrabold leading-tight tracking-tight text-brand-ink">
              {headline}
            </h1>
            <div className="mt-3 text-sm sm:text-base text-brand-mute leading-relaxed">{body}</div>

            {stage && <StageDots stage={stage} labels={stageLabels} />}

            <div className="mt-5">{children}</div>
          </div>
          {aside}
        </div>

        {footer && (
          <div className="mt-6 text-center text-xs text-brand-mute leading-relaxed">{footer}</div>
        )}
      </div>
    </article>
  );
}

function StageDots({
  stage,
  labels,
}: {
  readonly stage: AuthStage;
  readonly labels: Readonly<Record<AuthStage, string>>;
}): JSX.Element {
  const order: ReadonlyArray<AuthStage> = ['contact', 'code', 'success'];
  const idx = order.indexOf(stage);
  return (
    <ol
      aria-label="Login progress"
      className="mt-6 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.16em] text-brand-mute"
    >
      {order.map((s, i) => {
        const reached = i <= idx;
        const isCurrent = i === idx;
        return (
          <li key={s} className="flex items-center gap-2">
            <span
              aria-current={isCurrent ? 'step' : undefined}
              className={`inline-flex h-5 w-5 items-center justify-center rounded-full border text-[10px] font-semibold transition-colors ${
                reached
                  ? 'border-brand-accent bg-brand-accent text-bg-primary'
                  : 'border-brand-line bg-bg-primary text-brand-mute'
              }`}
            >
              {i + 1}
            </span>
            <span className={isCurrent ? 'text-brand-ink' : ''}>{labels[s]}</span>
            {i < order.length - 1 && (
              <span aria-hidden className="text-brand-line">
                /
              </span>
            )}
          </li>
        );
      })}
    </ol>
  );
}

export function AuthError({ error }: { readonly error: string }): JSX.Element | null {
  if (!error) return null;
  return (
    <div
      role="alert"
      className="mt-4 rounded-md border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-200"
    >
      {error}
    </div>
  );
}
