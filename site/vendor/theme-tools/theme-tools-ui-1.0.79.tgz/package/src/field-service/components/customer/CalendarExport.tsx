import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useState } from 'react';

/**
 * CalendarExport — three CTAs for adding the customer's upcoming services
 * to their device calendar:
 *
 *   1. One-time .ics download (next confirmed booking) via
 *      GET /api/customer/bookings/:id/calendar.ics (cookie-gated).
 *   2. webcal:// subscription link for the whole feed
 *      (/api/customer/jobs/calendar — exposed via customer-jobs.ts).
 *   3. Apple Wallet pass (/api/customer-ics/wallet-pass) — gated on a live
 *      HEAD probe: the CTA renders ONLY when the endpoint exists (200/non-404).
 *      Until the signed-.pkpass backend ships, the button is simply absent —
 *      no unfinished "coming soon" affordance is shown to customers.
 *
 * Mirrors NextServiceCard's pattern of fetching the upcoming list itself so
 * the component is drop-in mountable without a parent passing in a bookingId.
 */

interface JobListItem {
  id: string;
  service: string;
  preferredDate: string;
  status: string;
  paymentStatus: 'pending' | 'confirmed' | 'paid' | 'completed' | 'canceled' | 'defunct';
}

const SOON_STATUSES = new Set(['paid', 'paid_in_full', 'confirmed', 'in_progress', 'en_route']);

export function CalendarExport({ customerEmail: _customerEmail }: { customerEmail: string }) {
  useThemeToolsSurface('calendar-export');
  const [nextId, setNextId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [unauth, setUnauth] = useState(false);
  const [busy, setBusy] = useState<'ics' | 'sub' | 'wallet' | null>(null);
  const [toast, setToast] = useState('');
  const [walletAvailable, setWalletAvailable] = useState<boolean | null>(null);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch('/api/customer/jobs?filter=upcoming&limit=20', {
          credentials: 'same-origin',
        });
        if (res.status === 401) {
          if (!cancelled) {
            setUnauth(true);
            setLoading(false);
          }
          return;
        }
        const json = (await res.json()) as { ok: boolean; items?: JobListItem[] };
        const items = json.ok ? (json.items ?? []) : [];
        const upcoming = items
          .filter(
            (b) =>
              SOON_STATUSES.has(b.status) ||
              b.paymentStatus === 'paid' ||
              b.paymentStatus === 'confirmed',
          )
          .sort((a, b) => (a.preferredDate ?? '').localeCompare(b.preferredDate ?? ''))[0];
        if (!cancelled) {
          setNextId(upcoming?.id ?? null);
          setLoading(false);
        }
        // Probe wallet endpoint quietly.
        try {
          const probe = await fetch('/api/customer-ics/wallet-pass', {
            method: 'HEAD',
            credentials: 'same-origin',
          });
          if (!cancelled) setWalletAvailable(probe.status !== 404);
        } catch {
          if (!cancelled) setWalletAvailable(false);
        }
      } catch {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  function showToast(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(''), 2500);
  }

  async function downloadIcs() {
    if (!nextId) return;
    setBusy('ics');
    try {
      const res = await fetch(`/api/customer/bookings/${encodeURIComponent(nextId)}/calendar.ics`, {
        credentials: 'same-origin',
      });
      if (!res.ok) {
        showToast('Download failed — try signing in again.');
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `brickcitylabor-${nextId}.ics`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      showToast('Calendar invite downloaded.');
    } finally {
      setBusy(null);
    }
  }

  async function copyWebcal() {
    setBusy('sub');
    try {
      const httpsUrl = `${window.location.origin}/api/customer/jobs/calendar`;
      const webcalUrl = httpsUrl.replace(/^https?:/, 'webcal:');
      await navigator.clipboard.writeText(webcalUrl);
      showToast('Subscribe link copied — paste into your calendar.');
    } catch {
      showToast('Copy failed — see browser settings.');
    } finally {
      setBusy(null);
    }
  }

  function openWallet() {
    setBusy('wallet');
    try {
      window.open('/api/customer-ics/wallet-pass', '_blank', 'noopener,noreferrer');
    } finally {
      setBusy(null);
    }
  }

  if (loading) {
    return (
      <section
        className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
        aria-live="polite"
      >
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">Calendar</p>
        <p className="mt-2 text-sm text-brand-mute">Loading…</p>
      </section>
    );
  }

  if (unauth) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-4">
        <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">Calendar</p>
        <p className="mt-2 text-sm text-brand-mute">Sign in to export your schedule.</p>
      </section>
    );
  }

  return (
    <section
      className="rounded-2xl border border-brand-line bg-bg-elevated p-4"
      aria-labelledby="calendar-export-title"
    >
      <p
        id="calendar-export-title"
        className="font-mono text-[10px] uppercase tracking-widest text-brand-accent"
      >
        Calendar
      </p>
      <p className="mt-1 text-xs text-brand-mute">
        {nextId
          ? 'Add your next service to any calendar app.'
          : 'No upcoming services to export yet.'}
      </p>
      <div className="mt-3 flex flex-col gap-2">
        <button
          type="button"
          data-bcl-action="calendar-export-ics"
          onClick={() => void downloadIcs()}
          disabled={!nextId || busy === 'ics'}
          className="inline-flex items-center justify-center rounded-md bg-brand-accent px-3 py-2 text-sm font-semibold text-black hover:brightness-110 disabled:opacity-40"
        >
          {busy === 'ics' ? 'Preparing…' : 'Add to Apple / Google Calendar (.ics)'}
        </button>
        <button
          type="button"
          data-bcl-action="calendar-export-webcal"
          onClick={() => void copyWebcal()}
          disabled={busy === 'sub'}
          className="inline-flex items-center justify-center rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink hover:border-brand-accent hover:bg-brand-accent/5 disabled:opacity-40"
        >
          {busy === 'sub' ? 'Copying…' : 'Subscribe to my schedule (webcal://)'}
        </button>
        {walletAvailable === true && (
          <button
            type="button"
            data-bcl-action="calendar-export-wallet"
            onClick={openWallet}
            disabled={busy === 'wallet'}
            className="inline-flex items-center justify-center rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink hover:border-brand-accent hover:bg-brand-accent/5 disabled:opacity-40"
          >
            Add to Apple Wallet
          </button>
        )}
      </div>
      {toast && (
        <p
          role="status"
          aria-live="polite"
          className="mt-3 rounded-md border border-brand-accent/40 bg-brand-accent/5 px-3 py-1.5 text-xs text-brand-accent"
        >
          {toast}
        </p>
      )}
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
