import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useCallback, useEffect, useState } from 'react';

/**
 * Wave 21C — global impersonation banner.
 *
 * Reads the non-HttpOnly `bcl_admin_impersonate` cookie set by
 * /api/admin/impersonate/start and renders a sticky orange bar across the top
 * of every page so the operator can never forget they're masquerading. Clicking
 * "Exit" hits /api/admin/impersonate/stop which clears both the marker cookie
 * and the underlying `bcl_cust_sid` session.
 *
 * Renders nothing when no marker present (the common case) — zero footprint on
 * normal pages.
 */

interface Marker {
  contact: string;
  channel: 'email' | 'sms';
  startedAt: string;
}

function readMarker(): Marker | null {
  if (typeof document === 'undefined') return null;
  const raw = document.cookie.match(/(?:^|;\s*)bcl_admin_impersonate=([^;]+)/);
  if (!raw || !raw[1]) return null;
  try {
    const decoded = decodeURIComponent(raw[1]);
    const parsed = JSON.parse(decoded) as Marker;
    if (!parsed?.contact) return null;
    return parsed;
  } catch {
    return null;
  }
}

function getAdminBearer(): string {
  try {
    return localStorage.getItem('bcl-admin-key-v1') || '';
  } catch {
    return '';
  }
}

export function ImpersonationBanner() {
  useThemeToolsSurface('impersonation-banner');
  const [marker, setMarker] = useState<Marker | null>(null);
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    setMarker(readMarker());
    // Re-read on focus — marker may have been set in another tab.
    const onFocus = () => setMarker(readMarker());
    window.addEventListener('focus', onFocus);
    return () => window.removeEventListener('focus', onFocus);
  }, []);

  const exit = useCallback(async () => {
    setExiting(true);
    const token = getAdminBearer();
    try {
      await fetch('/api/admin/impersonate/stop', {
        method: 'POST',
        headers: token ? { authorization: `Bearer ${token}` } : {},
      });
    } catch {
      /* ignore — we still clear client-side */
    }
    // Belt + braces: explicitly expire the marker locally even if the API
    // didn't get a chance to.
    document.cookie = 'bcl_admin_impersonate=; Max-Age=0; Path=/';
    setMarker(null);
    window.location.href = '/admin/customers';
  }, []);

  if (!marker) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="sticky top-0 z-[60] flex flex-wrap items-center justify-between gap-2 border-b border-fuchsia-500/40 bg-fuchsia-950/80 px-4 py-2 text-sm text-fuchsia-100 backdrop-blur"
    >
      <span>
        <strong className="font-bold">Impersonating</strong> {marker.contact} ({marker.channel}) —
        every action is logged and the customer cannot see this view.
      </span>
      <button
        type="button"
        onClick={() => void exit()}
        disabled={exiting}
        className="rounded border border-fuchsia-300 px-3 py-0.5 text-xs font-semibold text-white hover:bg-fuchsia-700 disabled:opacity-50"
      >
        {exiting ? 'Exiting…' : 'Exit impersonation'}
      </button>
    </div>
  );
}

export default ImpersonationBanner;
