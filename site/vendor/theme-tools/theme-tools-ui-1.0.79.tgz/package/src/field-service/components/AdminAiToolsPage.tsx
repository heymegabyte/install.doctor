import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useState } from 'react';
import { usd0 } from '@theme.tools/billing/field-service/money';
import { getAdminToken, setAdminToken } from '@theme.tools/crm/field-service/admin-api';

function getKey(): string {
  return getAdminToken();
}
function setKey(v: string): void {
  setAdminToken(v);
}

type Prediction = {
  reEstimatedHours: number;
  riskScore: number;
  riskFactors: string[];
  upsellOps: string[];
  skillsNeeded: string[];
  rationale: string;
};

type RouteResult = {
  totalKm: number;
  explanation: string;
  order: Array<{ sequence: number; id: string; label: string; lat: number; lng: number }>;
  mapsUrl: string;
};

type DigestPreview = {
  data: {
    bookings: number;
    revenueCents: number;
    completedJobs: number;
    cancellations: number;
    newCustomers: number;
    repeatCustomers: number;
    pendingReviews: number;
    topService: string;
    topCity: string;
  };
  commentary: { headline: string; insights: string[]; actions: string[] };
};

export function AdminAiToolsPage() {
  useThemeToolsSurface('admin-ai-tools-page');
  const [authKey, setAuthKeyState] = useState<string>(getKey());

  const persistKey = (v: string) => {
    setKey(v);
    setAuthKeyState(v);
  };

  const headers = (): HeadersInit => ({
    'content-type': 'application/json',
    authorization: `Bearer ${authKey}`,
  });

  return (
    <main className="bg-bg-primary min-h-screen pb-24">
      <section className="mx-auto max-w-4xl px-4 pt-12 space-y-8">
        <header>
          <p className="mb-2 font-mono text-[11px] uppercase tracking-[0.18em] text-brand-accent">
            Operator console
          </p>
          <h1 className="text-3xl font-bold text-brand-ink">AI tools</h1>
          <p className="mt-2 max-w-xl text-brand-mute">
            Tier 1 dispatcher console — weekly digest, job-value predictor, route optimizer.
          </p>
        </header>

        <div className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
          <label className="block text-sm">
            <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
              Owner invoice key
            </span>
            <input
              type="password"
              value={authKey}
              onChange={(e) => persistKey(e.target.value.trim())}
              placeholder="paste once — stored in this browser only"
              className="mt-1 w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink focus:outline focus:outline-2 focus:outline-brand-accent"
            />
          </label>
          {authKey && (
            <button
              type="button"
              onClick={() => persistKey('')}
              className="mt-3 text-xs text-brand-mute hover:text-brand-ink"
            >
              Clear stored key
            </button>
          )}
        </div>

        <WeeklyDigestPanel headers={headers} authed={Boolean(authKey)} />
        <JobValuePanel headers={headers} authed={Boolean(authKey)} />
        <RouteOptimizerPanel headers={headers} authed={Boolean(authKey)} />
        <AiSuiteRunner headers={headers} authed={Boolean(authKey)} />
      </section>
    </main>
  );
}

// ──────────────────────────────────────────────────────────────────────────
// AiSuiteRunner — generic JSON-in / JSON-out runner for the 11 AI routes
// shipped in the Tier 2/3 wave. Operator picks a tool, fills the example
// body, hits Run. Renders the response. Saves trips to curl / Postman for
// the operator while a dedicated UI per tool gets built out.
// ──────────────────────────────────────────────────────────────────────────

interface ToolSpec {
  id: string;
  label: string;
  path: string;
  method: 'GET' | 'POST';
  blurb: string;
  defaultBody?: string;
  bearerRequired: boolean;
}

const AI_SUITE: ToolSpec[] = [
  {
    id: 'eta',
    label: 'ETA predictor',
    path: '/api/ai/eta',
    method: 'POST',
    blurb: 'Realistic finish-time window for a scheduled gig.',
    bearerRequired: false,
    defaultBody:
      '{\n  "services": ["junk-removal","cleanout"],\n  "crewSize": 2,\n  "estimatedHours": 4,\n  "startIso": "2026-06-01T14:00:00.000Z",\n  "city": "Newark"\n}',
  },
  {
    id: 'fair-market',
    label: 'Fair-market quote',
    path: '/api/ai/fair-market',
    method: 'POST',
    blurb: 'Honest market range vs our flat $50/hr/person.',
    bearerRequired: false,
    defaultBody:
      '{\n  "description": "3BR move Newark to Hoboken, one flight of stairs",\n  "city": "Newark"\n}',
  },
  {
    id: 'complaint-mediator',
    label: 'Complaint mediator',
    path: '/api/ai/complaint-mediator',
    method: 'POST',
    blurb: 'Drafts a measured reply + concession recommendation.',
    bearerRequired: true,
    defaultBody:
      '{\n  "complaintText": "Crew was 90 min late and the customer\'s planter is chipped.",\n  "customerName": "Maria"\n}',
  },
  {
    id: 'winback',
    label: 'Customer winback',
    path: '/api/ai/winback',
    method: 'POST',
    blurb: 'Reads booking history + drafts SMS + email + offer.',
    bearerRequired: true,
    defaultBody: '{\n  "customerEmail": "past-customer@example.com"\n}',
  },
  {
    id: 'inbox-triage',
    label: 'Inbox triage',
    path: '/api/ai/inbox-triage',
    method: 'POST',
    blurb: 'Classifies + drafts reply for one inbound email.',
    bearerRequired: true,
    defaultBody:
      '{\n  "subject": "Quote please",\n  "body": "Hi — can I get a quote for power-wash on my driveway in Newark next week?",\n  "fromEmail": "lead@example.com"\n}',
  },
  {
    id: 'invoice-itemize',
    label: 'Invoice itemizer',
    path: '/api/ai/invoice-itemize',
    method: 'POST',
    blurb: 'Crew freeform note → line-item invoice JSON.',
    bearerRequired: true,
    defaultBody:
      '{\n  "note": "2 person crew, 3 hours, 1 dump trip $45, 2 bags fill $24, $20 tip cash",\n  "hourlyRateCents": 5000\n}',
  },
  {
    id: 'no-show',
    label: 'No-show predictor',
    path: '/api/ai/no-show',
    method: 'POST',
    blurb: 'Risk 0-100 + draft confirm SMS for one booking.',
    bearerRequired: true,
    defaultBody: '{\n  "bookingId": "PASTE_BOOKING_ID"\n}',
  },
  {
    id: 'crew-quality',
    label: 'Crew quality score',
    path: '/api/ai/crew-quality',
    method: 'POST',
    blurb: '60-day quality score + coaching plan for one worker.',
    bearerRequired: true,
    defaultBody: '{\n  "workerId": "PASTE_WORKER_ID"\n}',
  },
  {
    id: 'scope-creep',
    label: 'Scope-creep detector',
    path: '/api/ai/scope-creep',
    method: 'POST',
    blurb: 'On-site note vs original booking → upcharge proposal.',
    bearerRequired: true,
    defaultBody:
      '{\n  "bookingId": "PASTE_BOOKING_ID",\n  "onSiteNote": "Customer added the garage and a backyard pile after we arrived. Easily 3x what was booked."\n}',
  },
  {
    id: 'damage-detector',
    label: 'Damage detector',
    path: '/api/ai/damage-detector',
    method: 'POST',
    blurb: 'Before/after photo diff → flag NEW damage. (base64 ≤2MB each)',
    bearerRequired: true,
    defaultBody:
      '{\n  "beforeBase64": "PASTE_BEFORE_B64",\n  "afterBase64": "PASTE_AFTER_B64",\n  "bookingId": "PASTE_BOOKING_ID"\n}',
  },
  {
    id: 'weather-reschedule',
    label: 'Weather reschedule',
    path: '/api/ai/weather-reschedule',
    method: 'POST',
    blurb: 'Walks outdoor gigs on a date, flags weather-at-risk + drafts SMS.',
    bearerRequired: true,
    defaultBody: '{\n  "date": "2026-06-15"\n}',
  },
  {
    id: 'marketing-scheduler',
    label: 'Marketing scheduler',
    path: '/api/ai/marketing-scheduler',
    method: 'POST',
    blurb: '7-day social content calendar from a brief.',
    bearerRequired: true,
    defaultBody: '{\n  "city": "Newark",\n  "servicesFocus": ["cleanout","power-wash"]\n}',
  },
  {
    id: 'tax-draft',
    label: 'Quarterly tax draft',
    path: '/api/ai/tax-draft',
    method: 'POST',
    blurb: 'Q estimate from D1 revenue + 1099 payouts. NOT tax advice.',
    bearerRequired: true,
    defaultBody: '{\n  "year": 2026,\n  "quarter": 2,\n  "filingStatus": "single"\n}',
  },
  {
    id: 'call-summarize',
    label: 'Call summarizer',
    path: '/api/ai/call-summarize',
    method: 'POST',
    blurb: 'Twilio recording URL OR transcript → intent + actions.',
    bearerRequired: true,
    defaultBody:
      '{\n  "transcript": "Hi this is John I am looking to book a moving crew for next Saturday in Hoboken about a 2 bedroom apartment thanks",\n  "fromPhone": "+15551234567"\n}',
  },
  {
    id: 'photo-estimate',
    label: 'Photo estimate',
    path: '/api/ai/photo-estimate',
    method: 'POST',
    blurb: 'Public photo→rough quote. base64 ≤2MB.',
    bearerRequired: false,
    defaultBody:
      '{\n  "imageBase64": "PASTE_B64",\n  "mime": "image/jpeg",\n  "serviceHint": "cleanout"\n}',
  },
];

function AiSuiteRunner({ headers, authed }: { headers: () => HeadersInit; authed: boolean }) {
  const [toolId, setToolId] = useState<string>(AI_SUITE[0]!.id);
  const [body, setBody] = useState<string>(AI_SUITE[0]!.defaultBody ?? '{}');
  const [response, setResponse] = useState<string>('');
  const [status, setStatus] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const tool = AI_SUITE.find((t) => t.id === toolId) ?? AI_SUITE[0]!;

  function switchTool(id: string) {
    const next = AI_SUITE.find((t) => t.id === id);
    if (!next) return;
    setToolId(id);
    setBody(next.defaultBody ?? '{}');
    setResponse('');
    setStatus('');
  }

  async function run() {
    setLoading(true);
    setStatus('');
    setResponse('');
    if (tool.bearerRequired && !authed) {
      setStatus('Add the owner key first (this tool is bearer-gated).');
      setLoading(false);
      return;
    }
    let parsed: unknown;
    try {
      parsed = JSON.parse(body);
    } catch {
      setStatus('Request body is not valid JSON.');
      setLoading(false);
      return;
    }
    try {
      const res = await fetch(tool.path, {
        method: tool.method,
        headers: tool.bearerRequired ? headers() : { 'content-type': 'application/json' },
        body: tool.method === 'POST' ? JSON.stringify(parsed) : undefined,
      });
      const text = await res.text();
      setStatus(`HTTP ${res.status}`);
      try {
        setResponse(JSON.stringify(JSON.parse(text), null, 2));
      } catch {
        setResponse(text);
      }
    } catch (err) {
      setStatus((err as Error).message || 'Network error');
    } finally {
      setLoading(false);
    }
  }

  return (
    <Panel
      title="AI Tool Suite"
      blurb="Generic JSON-in / JSON-out runner for every Tier 2 AI route. Pick a tool, edit the example body, hit Run."
    >
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <label className="block text-sm sm:col-span-1">
          <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
            Tool
          </span>
          <select
            value={toolId}
            onChange={(e) => switchTool(e.target.value)}
            className="mt-1 w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink"
          >
            {AI_SUITE.map((t) => (
              <option key={t.id} value={t.id}>
                {t.label}
                {t.bearerRequired ? ' (bearer)' : ' (public)'}
              </option>
            ))}
          </select>
        </label>
        <div className="sm:col-span-2">
          <p className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
            What it does
          </p>
          <p className="mt-1 text-sm text-brand-ink">{tool.blurb}</p>
          <p className="mt-1 font-mono text-[10px] text-brand-mute">
            {tool.method} {tool.path}
          </p>
        </div>
      </div>
      <label className="block text-sm">
        <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Request body (JSON)
        </span>
        <textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          rows={8}
          spellCheck={false}
          className="mt-1 w-full rounded-md border border-brand-line bg-bg-primary p-3 font-mono text-xs text-brand-ink"
        />
      </label>
      <div className="flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={run}
          disabled={loading}
          className="rounded-md bg-brand-accent px-3 py-2 text-sm font-semibold text-black hover:brightness-110 disabled:opacity-50"
        >
          {loading ? 'Running…' : 'Run'}
        </button>
        {status && <span className="text-xs text-brand-mute">{status}</span>}
      </div>
      {response && (
        <pre className="max-h-96 overflow-auto rounded-lg border border-brand-line bg-bg-primary p-3 font-mono text-xs text-brand-ink">
          {response}
        </pre>
      )}
    </Panel>
  );
}

function Panel({
  title,
  blurb,
  children,
}: {
  title: string;
  blurb: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
      <h2 className="text-xl font-bold text-brand-ink">{title}</h2>
      <p className="mt-1 mb-4 text-sm text-brand-mute">{blurb}</p>
      <div className="space-y-4">{children}</div>
    </section>
  );
}

function WeeklyDigestPanel({ headers, authed }: { headers: () => HeadersInit; authed: boolean }) {
  const [preview, setPreview] = useState<DigestPreview | null>(null);
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(false);

  async function loadPreview() {
    if (!authed) return setStatus('Add the owner key first.');
    setLoading(true);
    setStatus('');
    try {
      const res = await fetch('/api/admin/weekly-digest/preview', { headers: headers() });
      const json = (await res.json()) as { ok: boolean; preview?: DigestPreview; error?: string };
      if (!res.ok || !json.ok || !json.preview) {
        setStatus(json.error ?? `Failed: ${res.status}`);
      } else {
        setPreview(json.preview);
      }
    } finally {
      setLoading(false);
    }
  }

  async function send() {
    if (!authed) return setStatus('Add the owner key first.');
    setLoading(true);
    setStatus('');
    try {
      const res = await fetch('/api/admin/weekly-digest/send', {
        method: 'POST',
        headers: headers(),
      });
      const json = (await res.json()) as { ok: boolean; error?: string };
      setStatus(json.ok ? 'Sent.' : (json.error ?? `Failed: ${res.status}`));
    } finally {
      setLoading(false);
    }
  }

  return (
    <Panel
      title="Weekly digest"
      blurb="7-day rollup with AI commentary. Preview first, then send to operator email."
    >
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={loadPreview}
          disabled={loading}
          className="rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink hover:border-brand-accent disabled:opacity-50"
        >
          Preview
        </button>
        <button
          type="button"
          onClick={send}
          disabled={loading}
          className="rounded-md bg-brand-accent px-3 py-2 text-sm font-semibold text-black hover:brightness-110 disabled:opacity-50"
        >
          Send to operator email
        </button>
      </div>
      {status && (
        <p className="text-sm text-brand-mute" aria-live="polite">
          {status}
        </p>
      )}
      {preview && (
        <div className="rounded-lg border border-brand-line bg-bg-primary p-4 text-sm">
          <p className="mb-2 text-base font-semibold text-brand-ink">
            {preview.commentary.headline}
          </p>
          <ul className="mb-3 list-disc space-y-1 pl-5 text-brand-mute">
            {preview.commentary.insights.map((i, idx) => (
              <li key={idx}>{i}</li>
            ))}
          </ul>
          <p className="mb-1 font-mono text-[10px] uppercase tracking-widest text-brand-accent">
            Actions
          </p>
          <ul className="list-disc space-y-1 pl-5 text-brand-mute">
            {preview.commentary.actions.map((a, idx) => (
              <li key={idx}>{a}</li>
            ))}
          </ul>
          <dl className="mt-4 grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
            <Stat label="Bookings" value={preview.data.bookings.toString()} />
            <Stat label="Revenue" value={usd0(preview.data.revenueCents)} />
            <Stat label="Completed" value={preview.data.completedJobs.toString()} />
            <Stat label="Pending reviews" value={preview.data.pendingReviews.toString()} />
          </dl>
        </div>
      )}
    </Panel>
  );
}

function JobValuePanel({ headers, authed }: { headers: () => HeadersInit; authed: boolean }) {
  const [bookingId, setBookingId] = useState('');
  const [pred, setPred] = useState<Prediction | null>(null);
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(false);

  async function predict() {
    if (!authed) return setStatus('Add the owner key first.');
    if (bookingId.length < 8) return setStatus('Booking id looks too short.');
    setLoading(true);
    setStatus('');
    setPred(null);
    try {
      const res = await fetch('/api/ai/job-value', {
        method: 'POST',
        headers: headers(),
        body: JSON.stringify({ bookingId }),
      });
      const json = (await res.json()) as { ok: boolean; prediction?: Prediction; error?: string };
      if (!res.ok || !json.ok || !json.prediction) {
        setStatus(json.error ?? `Failed: ${res.status}`);
      } else {
        setPred(json.prediction);
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <Panel
      title="Job-value predictor"
      blurb="Paste a booking_id; AI returns risk + upsell + re-estimated hours."
    >
      <div className="flex flex-col gap-2 sm:flex-row">
        <input
          value={bookingId}
          onChange={(e) => setBookingId(e.target.value.trim())}
          placeholder="booking_id"
          className="flex-1 rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink"
        />
        <button
          type="button"
          onClick={predict}
          disabled={loading}
          className="rounded-md bg-brand-accent px-3 py-2 text-sm font-semibold text-black hover:brightness-110 disabled:opacity-50"
        >
          Predict
        </button>
      </div>
      {status && <p className="text-sm text-brand-mute">{status}</p>}
      {pred && (
        <div className="rounded-lg border border-brand-line bg-bg-primary p-4 text-sm space-y-3">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            <Stat label="Re-est hours" value={`${pred.reEstimatedHours}h`} />
            <Stat label="Risk score" value={`${pred.riskScore}/100`} />
            <Stat label="Upsell ideas" value={pred.upsellOps.length.toString()} />
          </div>
          <p className="text-brand-ink">{pred.rationale}</p>
          {pred.riskFactors.length > 0 && (
            <TagList label="Risk factors" tags={pred.riskFactors} tone="warn" />
          )}
          {pred.upsellOps.length > 0 && <TagList label="Upsells" tags={pred.upsellOps} />}
          {pred.skillsNeeded.length > 0 && (
            <TagList label="Skills needed" tags={pred.skillsNeeded} />
          )}
        </div>
      )}
    </Panel>
  );
}

function RouteOptimizerPanel({ headers, authed }: { headers: () => HeadersInit; authed: boolean }) {
  const [stopsText, setStopsText] = useState(
    '[\n  { "id": "a", "label": "11 Park Ave Newark", "address": "11 Park Ave, Newark NJ" },\n  { "id": "b", "label": "75 Halsey Newark", "address": "75 Halsey St, Newark NJ" },\n  { "id": "c", "label": "Hoboken move", "address": "1 Newark St, Hoboken NJ" }\n]',
  );
  const [startAddr, setStartAddr] = useState('Newark NJ 07102');
  const [result, setResult] = useState<RouteResult | null>(null);
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(false);

  async function optimize() {
    if (!authed) return setStatus('Add the owner key first.');
    let stops: unknown;
    try {
      stops = JSON.parse(stopsText);
    } catch {
      setStatus('Stops JSON is malformed.');
      return;
    }
    setLoading(true);
    setStatus('');
    setResult(null);
    try {
      const res = await fetch('/api/ai/route-optimizer', {
        method: 'POST',
        headers: headers(),
        body: JSON.stringify({
          start: { address: startAddr, label: 'Depot' },
          stops,
        }),
      });
      const json = (await res.json()) as { ok: boolean; error?: string } & Partial<RouteResult>;
      if (!res.ok || !json.ok || !json.order) {
        setStatus(json.error ?? `Failed: ${res.status}`);
      } else {
        setResult({
          totalKm: json.totalKm ?? 0,
          explanation: json.explanation ?? '',
          order: json.order,
          mapsUrl: json.mapsUrl ?? '',
        });
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <Panel
      title="Route optimizer"
      blurb="Up to 10 stops. Greedy + 2-opt order, one-click Google Maps deeplink."
    >
      <label className="block text-sm">
        <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Start address
        </span>
        <input
          value={startAddr}
          onChange={(e) => setStartAddr(e.target.value)}
          className="mt-1 w-full rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink"
        />
      </label>
      <label className="block text-sm">
        <span className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">
          Stops (JSON array)
        </span>
        <textarea
          value={stopsText}
          onChange={(e) => setStopsText(e.target.value)}
          rows={8}
          spellCheck={false}
          className="mt-1 w-full rounded-md border border-brand-line bg-bg-primary p-3 font-mono text-xs text-brand-ink"
        />
      </label>
      <button
        type="button"
        onClick={optimize}
        disabled={loading}
        className="rounded-md bg-brand-accent px-3 py-2 text-sm font-semibold text-black hover:brightness-110 disabled:opacity-50"
      >
        Optimize
      </button>
      {status && <p className="text-sm text-brand-mute">{status}</p>}
      {result && (
        <div className="rounded-lg border border-brand-line bg-bg-primary p-4 text-sm space-y-3">
          <p className="text-base text-brand-ink">{result.explanation}</p>
          <ol className="list-decimal space-y-1 pl-5 text-brand-mute">
            {result.order.map((s) => (
              <li key={s.id}>{s.label}</li>
            ))}
          </ol>
          <p className="text-xs text-brand-mute">Total ~{result.totalKm} km</p>
          {result.mapsUrl && (
            <a
              href={result.mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center rounded-md bg-brand-accent px-3 py-2 text-sm font-semibold text-black hover:brightness-110"
            >
              Open in Google Maps →
            </a>
          )}
        </div>
      )}
    </Panel>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-brand-line bg-bg-elevated px-3 py-2">
      <dt className="font-mono text-[10px] uppercase tracking-widest text-brand-mute">{label}</dt>
      <dd className="text-base text-brand-ink">{value}</dd>
    </div>
  );
}

function TagList({
  label,
  tags,
  tone = 'neutral',
}: {
  label: string;
  tags: string[];
  tone?: 'neutral' | 'warn';
}) {
  return (
    <div>
      <p className="mb-1 font-mono text-[10px] uppercase tracking-widest text-brand-mute">
        {label}
      </p>
      <ul className="flex flex-wrap gap-1.5">
        {tags.map((t, idx) => (
          <li
            key={`${t}-${idx}`}
            className={`rounded-md border px-2 py-0.5 text-xs ${
              tone === 'warn'
                ? 'border-red-500/50 bg-red-500/10 text-red-300'
                : 'border-brand-line bg-bg-elevated text-brand-mute'
            }`}
          >
            {t}
          </li>
        ))}
      </ul>
    </div>
  );
}
