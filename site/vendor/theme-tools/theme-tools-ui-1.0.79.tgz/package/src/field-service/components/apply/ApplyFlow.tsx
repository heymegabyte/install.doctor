import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { useCallback, useEffect, useMemo, useRef, useState, type JSX, type ReactNode } from 'react';
import { QUESTIONS, FREE_TEXT_QUESTION, type RawAnswers } from '@theme.tools/crm/field-service/crew-questions';

/**
 * ApplyFlow — the multi-step "Apply to Work / Join the Crew" gig-labor intake.
 *
 * Mobile-first, autosaved, resumable (the `bcl_apply_sid` cookie carries the
 * application across reloads — on mount we GET /api/apply/me and resume at the
 * right step). Steps: intro → account → verify (email+phone OTP) → profile
 * (emergency contact + 12-question questionnaire) → driver (conditional) →
 * review (AI dispatch profile + submit) → status (checklist dashboard).
 *
 * Talks to the flag-gated /api/apply/* worker. When a provider key is unset the
 * server returns a `devCode` so the flow is fully testable offline; in prod the
 * keys are set and no code is ever returned to the browser.
 */

type Step = 'intro' | 'account' | 'verify' | 'profile' | 'driver' | 'review' | 'status';

const STEP_ORDER: readonly Step[] = ['account', 'verify', 'profile', 'driver', 'review', 'status'];
const STEP_LABELS: Record<Step, string> = {
  intro: 'Start',
  account: 'Account',
  verify: 'Verify',
  profile: 'Profile',
  driver: 'Driver',
  review: 'Review',
  status: 'Status',
};

interface DriverDto {
  licenseState: string | null;
  frontUploaded: boolean;
  backUploaded: boolean;
  isAdult: boolean;
  consentMvr: boolean;
  identityStatus: string | null;
  mvrStatus: string | null;
}
interface ChecklistItem {
  key: string;
  label: string;
  done: boolean;
  applicable: boolean;
}
interface AppDto {
  id: string;
  status: string;
  legalFirstName: string;
  legalLastName: string;
  email: string;
  phone: string;
  city: string;
  zip: string;
  emailVerified: boolean;
  phoneVerified: boolean;
  emergencyContactName: string | null;
  emergencyContactPhone: string | null;
  answers: RawAnswers;
  freeText: string | null;
  questionnaireComplete: boolean;
  wantsDriver: boolean;
  driver: DriverDto;
  aiDispatchProfile: string | null;
  aiGenerated: boolean;
  ssnOnFile: boolean;
  ssnLast4: string | null;
  submittedAt: string | null;
  checklist: ChecklistItem[];
  dispatchReady: boolean;
}

function stepFromPath(path: string): Step {
  const seg = path.replace(/\/$/, '').split('/')[2];
  if (seg && (STEP_ORDER as readonly string[]).includes(seg)) return seg as Step;
  return 'intro';
}

/**
 * Format a US phone number progressively as the user types: `(973) 555-1234`.
 * Keeps only digits, drops a leading country `1`, and never exceeds 10 digits —
 * so the field self-corrects while staying friendly on mobile.
 */
function formatUsPhone(raw: string): string {
  let d = raw.replace(/\D/g, '');
  if (d.length === 11 && d.startsWith('1')) d = d.slice(1);
  d = d.slice(0, 10);
  if (d.length === 0) return '';
  if (d.length < 4) return `(${d}`;
  if (d.length < 7) return `(${d.slice(0, 3)}) ${d.slice(3)}`;
  return `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}`;
}

/**
 * Read the referral from `/apply?ref=<email|code>` once, at module load. Blank /
 * missing / oversized falls back to the default referrer so the "Referred by …"
 * line + the `/start` attribution are always populated (mirrors the worker's
 * `normalizeReferrer`). Kept lightweight — the worker is the source of truth and
 * re-normalizes whatever we send.
 */
const DEFAULT_REFERRER = 'brian@megabyte.space';
function readReferralFromUrl(): string {
  try {
    const raw = new URLSearchParams(window.location.search).get('ref');
    const cleaned = (raw ?? '').trim();
    if (cleaned.length === 0 || cleaned.length > 200) return DEFAULT_REFERRER;
    return cleaned;
  } catch {
    return DEFAULT_REFERRER;
  }
}

/**
 * A subtle "Referred by …" chip shown on the intro + account steps so the
 * applicant can see who's bringing them in (or the default). Purely
 * informational — the attribution is enforced server-side.
 */
function ReferralNote({ referrer }: { referrer: string }): JSX.Element {
  return (
    <p
      className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-brand-line bg-bg-primary/60 px-2.5 py-1 text-[11px] text-brand-mute"
      data-testid="apply-referral-note"
    >
      <svg width="12" height="12" viewBox="0 0 20 20" fill="none" aria-hidden="true">
        <path
          d="M7 10a3 3 0 100-6 3 3 0 000 6zm7 6a4 4 0 00-4-4H8a4 4 0 00-4 4M14 8h4m-2-2v4"
          stroke="currentColor"
          strokeWidth="1.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
      Referred by <span className="font-semibold text-brand-ink">{referrer}</span>
    </p>
  );
}

async function api<T = unknown>(
  path: string,
  method: 'GET' | 'POST' | 'PUT',
  body?: unknown,
): Promise<{ ok: boolean; status: number; data: T }> {
  const res = await fetch(`/api/apply${path}`, {
    method,
    credentials: 'include',
    headers: body ? { 'content-type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = (await res.json().catch(() => ({}))) as T;
  return { ok: res.ok, status: res.status, data };
}

export function ApplyFlow({
  route = '/apply',
  embedded = false,
}: {
  route?: string;
  /**
   * When rendered inside a dialog (e.g. the `/login` "Work at Brick Labor"
   * CTA) the flow drives its own step state without touching the URL, the
   * document title, or the full-page `<section>` wrapper.
   */
  embedded?: boolean;
}): JSX.Element {
  const [step, setStepState] = useState<Step>(() => (embedded ? 'intro' : stepFromPath(route)));
  const [app, setApp] = useState<AppDto | null>(null);
  const [loading, setLoading] = useState(true);
  const [paused, setPaused] = useState(false);
  const [resumeError, setResumeError] = useState(false);
  // Referral attribution from `?ref=` — captured once, threaded into the /start
  // call + shown as a subtle "Referred by …" line. Defaults to brian@megabyte.space.
  const [referrer] = useState<string>(() => readReferralFromUrl());

  const navigate = useCallback(
    (next: Step) => {
      setStepState(next);
      if (embedded) {
        // Scroll the dialog's own scroll container, not the page.
        document.querySelector('[data-apply-scroll]')?.scrollTo({ top: 0 });
        return;
      }
      const path = next === 'intro' ? '/apply' : `/apply/${next}`;
      window.history.pushState({}, '', path);
      window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
    },
    [embedded],
  );

  useEffect(() => {
    if (embedded) return;
    document.title = 'Apply to Work — Brick Labor';
    const onPop = () => setStepState(stepFromPath(window.location.pathname));
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, [embedded]);

  // Resume on mount — load the in-progress application if the cookie is present.
  // A network/server failure is distinct from the intentional flag-off paused
  // state and must remain retryable instead of leaving the applicant on an
  // infinite loading screen.
  const loadApplication = useCallback(async (isCancelled?: () => boolean) => {
    setLoading(true);
    setResumeError(false);
    try {
      const r = await api<{ ok: boolean; application?: AppDto; code?: string }>('/me', 'GET');
      if (isCancelled?.()) return;
      // Flag off → /api/apply/* 404s. Show the paused notice.
      if (r.status === 404) {
        setPaused(true);
        return;
      }
      if (!r.ok && r.status >= 500) throw new Error(`status ${r.status}`);
      setPaused(false);
      if (r.ok && r.data.application) setApp(r.data.application);
    } catch {
      if (!isCancelled?.()) setResumeError(true);
    } finally {
      if (!isCancelled?.()) setLoading(false);
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    void loadApplication(() => cancelled);
    return () => {
      cancelled = true;
    };
  }, [loadApplication]);

  const refresh = useCallback((next: AppDto | null | undefined) => {
    if (next) setApp(next);
  }, []);

  // Focus management + screen-reader announcement on step change. Moving focus
  // to the new step's heading means keyboard + SR users land on the fresh
  // content instead of the top of the page; the polite live region narrates it.
  const cardRef = useRef<HTMLDivElement>(null);
  const [announce, setAnnounce] = useState('');
  const firstStepRender = useRef(true);
  useEffect(() => {
    if (embedded) return;
    if (firstStepRender.current) {
      firstStepRender.current = false;
      return;
    }
    const heading = cardRef.current?.querySelector<HTMLElement>('h1, h2');
    if (heading) {
      heading.setAttribute('tabindex', '-1');
      heading.focus({ preventScroll: true });
      setAnnounce(
        `${heading.textContent ?? STEP_LABELS[step]}. Step ${STEP_ORDER.indexOf(step) + 1}.`,
      );
    }
  }, [step, embedded]);

  if (loading) {
    return (
      <Shell embedded={embedded}>
        <p className="text-sm text-brand-mute" role="status">
          Loading your application…
        </p>
      </Shell>
    );
  }

  if (resumeError) {
    return (
      <Shell embedded={embedded} hideFootnote>
        <div data-testid="apply-resume-error" role="alert">
          <h1 className="font-display text-2xl font-extrabold text-brand-ink">
            We couldn't load your application
          </h1>
          <p className="mt-2 text-sm text-brand-mute">
            Check your connection and try again. Your saved progress is still here.
          </p>
          <button
            type="button"
            data-testid="apply-resume-retry"
            className="btn-primary mt-5 min-h-11"
            onClick={() => void loadApplication()}
          >
            Try again
          </button>
        </div>
      </Shell>
    );
  }

  if (paused) {
    return (
      <Shell embedded={embedded} hideFootnote>
        <PausedPitch />
      </Shell>
    );
  }

  return (
    <Shell
      embedded={embedded}
      stepper={step !== 'intro' ? <Stepper current={step} app={app} /> : undefined}
      cardRef={cardRef}
      announce={announce}
    >
      {step === 'intro' && (
        <IntroStep
          onStart={() => navigate(app ? 'verify' : 'account')}
          resuming={!!app}
          referrer={referrer}
        />
      )}
      {step === 'account' && (
        <AccountStep
          app={app}
          referrer={referrer}
          onSaved={(a) => {
            refresh(a);
            navigate('verify');
          }}
        />
      )}
      {step === 'verify' && (
        <VerifyStep
          app={app}
          refresh={refresh}
          onNext={() => navigate('profile')}
          requireAccount={() => navigate('account')}
        />
      )}
      {step === 'profile' && (
        <ProfileStep
          app={app}
          refresh={refresh}
          onNext={() => navigate(app?.wantsDriver ? 'driver' : 'review')}
        />
      )}
      {step === 'driver' && (
        <DriverStep
          app={app}
          refresh={refresh}
          onNext={() => navigate('review')}
          onSkip={() => navigate('review')}
        />
      )}
      {step === 'review' && (
        <ReviewStep app={app} refresh={refresh} onSubmitted={() => navigate('status')} />
      )}
      {step === 'status' && <StatusStep app={app} refresh={refresh} />}
    </Shell>
  );
}

// ── Paused pitch ─────────────────────────────────────────────────────────────
// When the hiring flag is off, /api/apply/* 404s. Instead of a bare "paused"
// line, sell the role anyway: what the work is, the flat $50/hr promise, the
// real perks, and a waitlist path — so a motivated candidate leaves warm, not
// cold. Keeps the two live actions honest: notify-me + "I already work here".
function PausedPitch(): JSX.Element {
  const PERKS: ReadonlyArray<readonly ['cash' | 'clock' | 'truck' | 'pin', string, string]> = [
    ['cash', '$50/hr', 'Per person, paid per job — 1-hour minimum, weekly pay.'],
    ['clock', 'Your hours', 'Pick the jobs and days that fit. No shifts forced on you.'],
    ['truck', 'Drive & earn more', 'Optional U-Haul / driver track unlocks the bigger jobs.'],
    ['pin', 'Local work', 'Newark and nearby — short trips, home every night.'],
  ];
  return (
    <div data-testid="apply-paused">
      <span className="inline-flex items-center gap-2 rounded-full border border-brand-accent/40 bg-brand-accent/10 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.16em] text-brand-accent">
        <span className="apply-pulse-dot" aria-hidden="true" />
        Hiring soon
      </span>
      <h1 className="mt-3 font-display text-3xl font-extrabold leading-tight text-brand-ink text-balance">
        Get paid to move Newark.
      </h1>
      <p className="mt-3 text-brand-mute leading-relaxed text-pretty">
        We're not taking new crew applications this exact minute — but Brick Labor is growing fast.
        Join the waitlist and you're first in line the moment a spot opens.
      </p>

      <ul className="mt-6 grid gap-3 sm:grid-cols-2">
        {PERKS.map(([icon, stat, label]) => (
          <li
            key={stat}
            className="flex items-start gap-3 rounded-xl border border-brand-line bg-bg-primary/60 p-4 transition-colors hover:border-brand-accent/50"
          >
            <span className="mt-0.5 flex h-9 w-9 flex-none items-center justify-center rounded-lg bg-brand-accent/12 text-brand-accent">
              <PerkIcon name={icon} />
            </span>
            <span className="min-w-0">
              <span className="block font-display text-base font-extrabold text-brand-accent">
                {stat}
              </span>
              <span className="mt-0.5 block text-sm leading-snug text-brand-mute">{label}</span>
            </span>
          </li>
        ))}
      </ul>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <a
          href="/careers"
          data-bcl-cta="apply-paused-waitlist"
          className="btn-primary btn-arrow flex-1 text-center"
        >
          Join the waitlist{' '}
          <span data-btn-arrow aria-hidden="true">
            →
          </span>
        </a>
        <a
          href="/login/crew"
          data-bcl-cta="apply-paused-crew-login"
          className="flex flex-1 items-center justify-center rounded-lg border border-brand-line px-4 py-3 text-sm font-semibold text-brand-ink transition-colors hover:border-brand-accent hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
        >
          I already work here
        </a>
      </div>

      <p className="mt-3 text-center text-xs text-brand-mute">
        <span className="font-semibold text-brand-ink">Newark crew are hired weekly</span> —
        waitlist first, then a quick 5-minute application when spots open.
      </p>

      <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-xs text-brand-mute">
        <svg width="13" height="13" viewBox="0 0 20 20" fill="none" aria-hidden="true">
          <path
            d="M10 1.5l6.5 2.5v5c0 4-2.8 7.4-6.5 8.5-3.7-1.1-6.5-4.5-6.5-8.5V4L10 1.5z"
            stroke="#9ca3af"
            strokeWidth="1.4"
            strokeLinejoin="round"
          />
        </svg>
        Licensed, insured, and background-checked. Real crews, real pay.
      </p>
    </div>
  );
}

// ── Layout ───────────────────────────────────────────────────────────────────
function Shell({
  children,
  stepper,
  embedded = false,
  hideFootnote = false,
  cardRef,
  announce,
}: {
  children: ReactNode;
  stepper?: ReactNode;
  embedded?: boolean;
  /** Suppress the "progress saves automatically" note (e.g. the paused view,
   * where there is no in-progress application to save). */
  hideFootnote?: boolean;
  /** Card element the step-change focus effect targets its heading within. */
  cardRef?: React.Ref<HTMLDivElement>;
  /** Polite screen-reader announcement of the current step. */
  announce?: string;
}): JSX.Element {
  // Inside the dialog the host panel owns the scroll + padding, so we render
  // the stepper + card bare; standalone `/apply` keeps the full-page wrapper.
  const body = (
    <div className="apply-flow-root">
      <p className="sr-only" role="status" aria-live="polite">
        {announce}
      </p>
      {stepper}
      <div
        ref={cardRef}
        className={`auth-card ${stepper || embedded ? 'mt-5' : ''}`}
        data-testid="apply-flow"
      >
        {children}
      </div>
      {!hideFootnote && (
        <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-xs text-brand-mute">
          <svg width="13" height="13" viewBox="0 0 20 20" fill="none" aria-hidden="true">
            <path
              d="M10 2.5a7.5 7.5 0 100 15 7.5 7.5 0 000-15zM10 6v4l2.5 1.5"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          Progress saves automatically — close this and pick up right where you left off.
        </p>
      )}
    </div>
  );
  if (embedded) return body;
  return (
    <article className="section">
      <div className="container-pad max-w-2xl">{body}</div>
    </article>
  );
}

function Stepper({ current, app }: { current: Step; app: AppDto | null }): JSX.Element {
  const steps = STEP_ORDER.filter((s) => s !== 'driver' || app?.wantsDriver);
  const idx = steps.indexOf(current);
  // Progress fill runs from the first node to the current one (0 at step 1).
  const onStatus = current === 'status';
  const progress = onStatus ? 1 : steps.length > 1 ? idx / (steps.length - 1) : 0;
  // Rough per-step time hint so "2 minutes left" shrinks as they advance instead
  // of lying at every step. Never shown on the final (status) step.
  const minsLeft = Math.max(1, steps.length - 1 - idx);
  return (
    <div>
      <p
        className="mb-2 font-mono text-[10px] uppercase tracking-[0.16em] text-brand-mute"
        aria-live="polite"
      >
        {onStatus
          ? 'All steps complete'
          : `Step ${idx + 1} of ${steps.length} · about ${minsLeft} min${minsLeft === 1 ? '' : 's'} left`}
      </p>
      <nav
        aria-label="Application progress"
        className="apply-steps"
        style={{ ['--apply-progress' as string]: String(progress) }}
      >
        <div className="apply-steps-track" aria-hidden="true">
          <div className="apply-steps-fill" />
        </div>
        <ol className="apply-steps-nodes">
          {steps.map((s, i) => {
            const state = i < idx ? 'done' : i === idx ? 'current' : 'todo';
            return (
              <li key={s} className="apply-step-node" data-state={state}>
                <span
                  className="apply-step-dot"
                  aria-current={i === idx ? 'step' : undefined}
                  aria-hidden="true"
                >
                  {state === 'done' ? '✓' : i + 1}
                </span>
                <span className="apply-step-label">{STEP_LABELS[s]}</span>
              </li>
            );
          })}
        </ol>
      </nav>
    </div>
  );
}

function Saving({ on }: { on: boolean }): JSX.Element | null {
  if (!on) return null;
  return (
    <span className="ml-2 text-xs text-brand-mute" role="status" aria-live="polite">
      Saving…
    </span>
  );
}

/**
 * SegmentedCode — a premium 6-cell one-time-code field. A single offscreen
 * <input> owns paste / SMS autofill (`autocomplete="one-time-code"`) / keyboard;
 * the six cells are the visual layer with an active caret. Fires `onComplete`
 * the moment all six digits are present so the user never hunts for a button.
 */
function SegmentedCode({
  value,
  onChange,
  onComplete,
  invalid,
  verified,
  label,
  testid,
}: {
  value: string;
  onChange: (v: string) => void;
  onComplete?: (v: string) => void;
  invalid?: boolean;
  verified?: boolean;
  label: string;
  testid?: string;
}): JSX.Element {
  const cells = [0, 1, 2, 3, 4, 5];
  const activeIdx = Math.min(value.length, 5);
  const handle = (raw: string) => {
    const next = raw.replace(/\D/g, '').slice(0, 6);
    onChange(next);
    if (next.length === 6) onComplete?.(next);
  };
  return (
    <div
      className="apply-otp"
      data-invalid={invalid ? 'true' : undefined}
      data-verified={verified ? 'true' : undefined}
    >
      <input
        className="apply-otp-input"
        type="text"
        inputMode="numeric"
        autoComplete="one-time-code"
        maxLength={6}
        value={value}
        onChange={(e) => handle(e.target.value)}
        aria-label={label}
        data-testid={testid}
      />
      <div className="apply-otp-cells" aria-hidden="true">
        {cells.map((i) => (
          <div
            key={i}
            className="apply-otp-cell"
            data-filled={value[i] ? 'true' : 'false'}
            data-active={i === activeIdx && !verified ? 'true' : 'false'}
          >
            {value[i] ?? ''}
          </div>
        ))}
      </div>
    </div>
  );
}

// Envelope / phone glyph for the verify-step channel cards.
function ChannelIcon({ channel }: { channel: 'email' | 'phone' }): JSX.Element {
  const common = {
    width: 14,
    height: 14,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 1.7,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
    'aria-hidden': true,
  };
  if (channel === 'email')
    return (
      <svg {...common}>
        <rect x="3" y="5" width="18" height="14" rx="2" />
        <path d="M3.5 6.5l8.5 6 8.5-6" />
      </svg>
    );
  return (
    <svg {...common}>
      <path d="M6.5 3h4l1.5 4-2 1.5a11 11 0 005.5 5.5l1.5-2 4 1.5v4a1.5 1.5 0 01-1.6 1.5A16 16 0 015 5.6 1.5 1.5 0 016.5 3z" />
    </svg>
  );
}

// A tiny inline-SVG icon set for the intro perk list + section headers. Stroke
// inherits `currentColor` so each icon takes the brand-accent from its wrapper.
function PerkIcon({ name }: { name: 'cash' | 'clock' | 'truck' | 'pin' }): JSX.Element {
  const common = {
    width: 18,
    height: 18,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 1.7,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
    'aria-hidden': true,
  };
  if (name === 'cash')
    return (
      <svg {...common}>
        <rect x="2.5" y="6" width="19" height="12" rx="2" />
        <circle cx="12" cy="12" r="2.6" />
        <path d="M6 9v6M18 9v6" />
      </svg>
    );
  if (name === 'clock')
    return (
      <svg {...common}>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7.5V12l3 2" />
      </svg>
    );
  if (name === 'pin')
    return (
      <svg {...common}>
        <path d="M12 21s7-5.5 7-11a7 7 0 10-14 0c0 5.5 7 11 7 11z" />
        <circle cx="12" cy="10" r="2.5" />
      </svg>
    );
  return (
    <svg {...common}>
      <path d="M2.5 6.5h11v9h-11z" />
      <path d="M13.5 10h4l3 3v2.5h-7z" />
      <circle cx="6.5" cy="17" r="1.6" />
      <circle cx="17" cy="17" r="1.6" />
    </svg>
  );
}

// ── Intro ────────────────────────────────────────────────────────────────────
function IntroStep({
  onStart,
  resuming,
  referrer,
}: {
  onStart: () => void;
  resuming: boolean;
  referrer: string;
}): JSX.Element {
  const PERKS: ReadonlyArray<readonly [ReactNode, string, string]> = [
    [
      <PerkIcon key="pay" name="cash" />,
      '$50/hour, per crew member',
      'Paid per job, weekly — 1-hour minimum.',
    ],
    [
      <PerkIcon key="hrs" name="clock" />,
      'Pick your own hours',
      'Take the jobs and days that fit your life.',
    ],
    [
      <PerkIcon key="drv" name="truck" />,
      'Drive and earn more',
      'Optional U-Haul / driver track unlocks bigger jobs.',
    ],
  ];
  return (
    <>
      {resuming && (
        <div className="mb-4 flex items-center gap-3 rounded-xl border border-brand-accent/30 bg-brand-accent/[0.07] p-3">
          <span className="flex h-8 w-8 flex-none items-center justify-center rounded-lg bg-brand-accent/15 text-brand-accent">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path
                d="M4 12a8 8 0 108-8"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
              />
              <path
                d="M4 4v4h4"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </span>
          <span className="text-sm text-brand-ink">
            <strong className="font-semibold">Welcome back.</strong>{' '}
            <span className="text-brand-mute">
              We saved your spot — pick up where you left off.
            </span>
          </span>
        </div>
      )}
      <div className="flex items-center justify-between gap-3">
        <p className="eyebrow text-brand-accent">Join the crew</p>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-brand-line bg-bg-primary/60 px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.14em] text-brand-mute">
          <svg width="12" height="12" viewBox="0 0 20 20" fill="none" aria-hidden="true">
            <path
              d="M10 2.5a7.5 7.5 0 100 15 7.5 7.5 0 000-15zM10 6v4l2.5 1.5"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          About 5 min
        </span>
      </div>
      <h1 className="mt-3 font-display text-3xl sm:text-4xl font-extrabold leading-tight text-brand-ink text-balance">
        Apply to work with Brick Labor
      </h1>
      <p className="mt-3 text-brand-mute leading-relaxed text-pretty">
        Moving, labor, hauling, power washing, cleaning, and driver jobs across Newark and nearby.
        Fast signup, a quick verify, and we get you dispatch-ready — your progress saves as you go.
      </p>
      <ReferralNote referrer={referrer} />
      <ul className="mt-5 grid gap-2.5">
        {PERKS.map(([icon, title, sub]) => (
          <li
            key={title}
            className="flex items-start gap-3 rounded-xl border border-brand-line bg-bg-primary/50 p-3 transition-colors hover:border-brand-accent/50"
          >
            <span className="mt-0.5 flex h-8 w-8 flex-none items-center justify-center rounded-lg bg-brand-accent/12 text-brand-accent">
              {icon}
            </span>
            <span className="min-w-0">
              <span className="block text-sm font-semibold text-brand-ink">{title}</span>
              <span className="block text-xs leading-snug text-brand-mute">{sub}</span>
            </span>
          </li>
        ))}
      </ul>
      <button
        type="button"
        onClick={onStart}
        data-testid="apply-start"
        className="btn-primary btn-arrow mt-6 w-full"
      >
        {resuming ? 'Resume my application' : 'Start my application'}{' '}
        <span data-btn-arrow aria-hidden="true">
          →
        </span>
      </button>
      <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-xs text-brand-mute">
        <svg width="13" height="13" viewBox="0 0 20 20" fill="none" aria-hidden="true">
          <path
            d="M10 1.5l6.5 2.5v5c0 4-2.8 7.4-6.5 8.5-3.7-1.1-6.5-4.5-6.5-8.5V4L10 1.5z"
            stroke="currentColor"
            strokeWidth="1.4"
            strokeLinejoin="round"
          />
        </svg>
        Your info is encrypted and only used to get you hired.
      </p>
    </>
  );
}

// ── Account ──────────────────────────────────────────────────────────────────
function AccountStep({
  app,
  referrer,
  onSaved,
}: {
  app: AppDto | null;
  referrer: string;
  onSaved: (a: AppDto) => void;
}): JSX.Element {
  const [f, setF] = useState({
    legalFirstName: app?.legalFirstName ?? '',
    legalLastName: app?.legalLastName ?? '',
    preferredName: '',
    email: app?.email ?? '',
    phone: app?.phone ?? '',
    zip: app?.zip ?? '',
    city: app?.city ?? '',
  });
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    // Format phone as the user types: (973) 555-1234; ZIP stays 5 digits.
    const value =
      k === 'phone' ? formatUsPhone(raw) : k === 'zip' ? raw.replace(/\D/g, '').slice(0, 5) : raw;
    setF((p) => ({ ...p, [k]: value }));
  };
  const markTouched = (k: keyof typeof f) => () => setTouched((p) => ({ ...p, [k]: true }));

  // Per-field validity → drives the inline check/× affordance (only once touched).
  const fieldOk = {
    legalFirstName: f.legalFirstName.trim().length > 0,
    legalLastName: f.legalLastName.trim().length > 0,
    email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email),
    phone: f.phone.replace(/\D/g, '').length >= 10,
    zip: /^\d{5}$/.test(f.zip.trim()),
    city: f.city.trim().length > 0,
  };
  // Show the check/× once a field is valid, OR once the user has engaged it
  // (blurred, or typed something into it) — so a wrong email flags red while
  // it's being fixed, not only after leaving the field.
  const vOf = (k: keyof typeof fieldOk): boolean | undefined => {
    const engaged = touched[k] || String(f[k as keyof typeof f]).length > 0;
    return engaged || fieldOk[k] ? fieldOk[k] : undefined;
  };

  const valid =
    fieldOk.legalFirstName &&
    fieldOk.legalLastName &&
    fieldOk.email &&
    fieldOk.phone &&
    fieldOk.zip &&
    fieldOk.city;

  // If the application already exists, account is done — skip straight ahead.
  if (app) {
    return (
      <>
        <h2 className="font-display text-2xl font-extrabold text-brand-ink">Account created</h2>
        <p className="mt-2 text-brand-mute">
          You're signed in as {app.email}. Next: verify your contact info.
        </p>
        <button type="button" className="btn-primary mt-5 w-full" onClick={() => onSaved(app)}>
          Continue →
        </button>
      </>
    );
  }

  const submit = async () => {
    if (!valid) {
      setError('Fill in every field — name, a valid email, US phone, ZIP, and city.');
      return;
    }
    setBusy(true);
    setError('');
    // Thread the referral through to the worker, which re-normalizes it
    // (blank/invalid → default) and persists it with the application.
    const r = await api<{ ok: boolean; application?: AppDto; error?: string }>('/start', 'POST', {
      ...f,
      ref: referrer,
    });
    setBusy(false);
    if (r.status === 404) {
      setError('Applications are paused right now. Check back soon.');
      return;
    }
    if (!r.ok || !r.data.application) {
      setError(
        r.data.error || 'Could not start your application. Check your details and try again.',
      );
      return;
    }
    onSaved(r.data.application);
  };

  return (
    <>
      <h2 className="font-display text-2xl font-extrabold text-brand-ink">Create your account</h2>
      <p className="mt-2 text-sm text-brand-mute">
        Legal name matches your ID — you can add a preferred name too.
      </p>
      <ReferralNote referrer={referrer} />
      <div className="mt-5 grid gap-4">
        <div className="grid grid-cols-2 gap-3">
          <Field
            label="Legal first name"
            id="ap-first"
            value={f.legalFirstName}
            onChange={set('legalFirstName')}
            onBlur={markTouched('legalFirstName')}
            valid={vOf('legalFirstName')}
            autoComplete="given-name"
          />
          <Field
            label="Legal last name"
            id="ap-last"
            value={f.legalLastName}
            onChange={set('legalLastName')}
            onBlur={markTouched('legalLastName')}
            valid={vOf('legalLastName')}
            autoComplete="family-name"
          />
        </div>
        <Field
          label="Preferred name (optional)"
          id="ap-pref"
          value={f.preferredName}
          onChange={set('preferredName')}
          autoComplete="nickname"
          hint="What the crew should call you — leave blank to use your first name."
        />
        <Field
          label="Email"
          id="ap-email"
          type="email"
          value={f.email}
          onChange={set('email')}
          onBlur={markTouched('email')}
          valid={vOf('email')}
          autoComplete="email"
          hint="We email you job offers and your application status."
        />
        <Field
          label="Mobile phone"
          id="ap-phone"
          type="tel"
          value={f.phone}
          onChange={set('phone')}
          onBlur={markTouched('phone')}
          valid={vOf('phone')}
          autoComplete="tel"
          hint="Texts you when a job is ready — standard rates apply."
        />
        <div className="grid grid-cols-2 gap-3">
          <Field
            label="ZIP code"
            id="ap-zip"
            value={f.zip}
            onChange={set('zip')}
            onBlur={markTouched('zip')}
            valid={vOf('zip')}
            inputMode="numeric"
            autoComplete="postal-code"
          />
          <Field
            label="City"
            id="ap-city"
            value={f.city}
            onChange={set('city')}
            onBlur={markTouched('city')}
            valid={vOf('city')}
            autoComplete="address-level2"
          />
        </div>
      </div>
      <button
        type="button"
        onClick={submit}
        disabled={busy || !valid}
        aria-busy={busy}
        data-testid="account-submit"
        className="btn-primary mt-6 w-full"
      >
        {busy ? 'Creating…' : 'Create account →'}
      </button>
      {error && <Err msg={error} />}
    </>
  );
}

// ── Verify (email + phone OTP) ────────────────────────────────────────────────
function VerifyStep({
  app,
  refresh,
  onNext,
  requireAccount,
}: {
  app: AppDto | null;
  refresh: (a: AppDto | undefined) => void;
  onNext: () => void;
  requireAccount: () => void;
}): JSX.Element {
  if (!app) {
    return (
      <>
        <h2 className="font-display text-2xl font-extrabold text-brand-ink">
          Start your account first
        </h2>
        <button type="button" className="btn-primary mt-5 w-full" onClick={requireAccount}>
          Back to account →
        </button>
      </>
    );
  }
  const bothVerified = app.emailVerified && app.phoneVerified;
  return (
    <>
      <h2 className="font-display text-2xl font-extrabold text-brand-ink">
        Verify your contact info
      </h2>
      <p className="mt-2 text-sm text-brand-mute">
        We text + email you about jobs, so both must be verified. A field is invalid until you
        confirm the code.
      </p>
      <div className="mt-5 grid gap-4">
        <OtpField channel="email" app={app} refresh={refresh} />
        <OtpField channel="phone" app={app} refresh={refresh} />
      </div>
      <button
        type="button"
        onClick={onNext}
        disabled={!bothVerified}
        data-testid="verify-next"
        className="btn-primary mt-6 w-full"
      >
        {bothVerified ? 'Continue →' : 'Verify both to continue'}
      </button>
    </>
  );
}

function OtpField({
  channel,
  app,
  refresh,
}: {
  channel: 'email' | 'phone';
  app: AppDto;
  refresh: (a: AppDto | undefined) => void;
}): JSX.Element {
  const verified = channel === 'email' ? app.emailVerified : app.phoneVerified;
  const current = channel === 'email' ? app.email : app.phone;
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(current);
  const [sent, setSent] = useState(false);
  const [code, setCode] = useState('');
  const [invalid, setInvalid] = useState(false);
  const [devCode, setDevCode] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const label = channel === 'email' ? 'Email' : 'Phone';
  const stateLabel = verified ? 'Verified' : sent ? 'Code sent' : 'Not verified yet';

  const saveContact = async () => {
    setBusy(true);
    setError('');
    const r = await api<{ ok: boolean; application?: AppDto }>('/contact/change', 'POST', {
      [channel]: value,
    });
    setBusy(false);
    setEditing(false);
    setSent(false);
    setCode('');
    refresh(r.data.application); // verified flag now cleared server-side
  };

  const send = async () => {
    setBusy(true);
    setError('');
    const r = await api<{ ok: boolean; devCode?: string; error?: string }>(
      `/${channel}/send`,
      'POST',
      {},
    );
    setBusy(false);
    if (!r.ok) {
      setError(r.data.error || 'Could not send the code. Try again in a minute.');
      return;
    }
    setSent(true);
    if (r.data.devCode) setDevCode(r.data.devCode);
  };

  const confirm = async (submitted?: string) => {
    const c = submitted ?? code;
    if (c.length !== 6) return;
    setBusy(true);
    setError('');
    setInvalid(false);
    const r = await api<{ ok: boolean; code?: string; application?: AppDto }>(
      `/${channel}/confirm`,
      'POST',
      { code: c },
    );
    setBusy(false);
    if (!r.ok) {
      setInvalid(true);
      setCode('');
      setError(
        r.data.code === 'expired'
          ? 'That code expired — send a new one.'
          : 'That code did not match. Try again.',
      );
      return;
    }
    setSent(false);
    setDevCode(null);
    setInvalid(false);
    refresh(r.data.application);
  };

  return (
    <div
      className="rounded-xl border border-brand-line bg-bg-primary p-4"
      data-testid={`otp-${channel}`}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="flex items-center gap-2">
          <span
            className={`flex h-6 w-6 flex-none items-center justify-center rounded-md ${verified ? 'bg-emerald-500/15 text-emerald-400' : 'bg-brand-accent/12 text-brand-accent'}`}
          >
            <ChannelIcon channel={channel} />
          </span>
          <span className="field-label mb-0">{label}</span>
        </span>
        <span
          data-testid={`otp-${channel}-state`}
          className={`inline-flex items-center gap-1 font-mono text-[10px] uppercase tracking-wider ${verified ? 'text-emerald-400' : 'text-brand-mute'}`}
        >
          {verified && (
            <svg width="12" height="12" viewBox="0 0 20 20" fill="none" aria-hidden="true">
              <path
                d="M4 10.5l4 4 8-9"
                stroke="currentColor"
                strokeWidth="2.4"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          )}
          {stateLabel}
        </span>
      </div>

      {verified && !editing ? (
        <div className="mt-2 flex items-center justify-between gap-2">
          <span className="text-sm text-brand-ink">{current}</span>
          <button
            type="button"
            onClick={() => setEditing(true)}
            className="text-xs text-brand-accent underline-hover"
          >
            Change
          </button>
        </div>
      ) : (
        <div className="mt-2 grid gap-2">
          <input
            className="field-input"
            type={channel === 'email' ? 'email' : 'tel'}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            aria-label={`${label} address`}
            data-testid={`otp-${channel}-input`}
          />
          {value !== current ? (
            <button
              type="button"
              onClick={saveContact}
              disabled={busy}
              aria-busy={busy}
              className="btn-primary"
            >
              Update {label.toLowerCase()}
            </button>
          ) : !sent ? (
            <button
              type="button"
              onClick={send}
              disabled={busy}
              aria-busy={busy}
              data-testid={`otp-${channel}-send`}
              className="btn-primary"
            >
              {busy ? 'Sending…' : `Send code by ${channel === 'email' ? 'email' : 'text'}`}
            </button>
          ) : (
            <div className="grid gap-2.5">
              <p className="text-xs text-brand-mute">
                Enter the 6-digit code we sent to your {channel === 'email' ? 'email' : 'phone'}.
              </p>
              {devCode && (
                <p
                  className="rounded bg-amber-500/10 px-2 py-1 text-xs text-amber-300"
                  data-testid={`otp-${channel}-devcode`}
                >
                  Dev mode (no provider key set): your code is <strong>{devCode}</strong>
                </p>
              )}
              <SegmentedCode
                value={code}
                onChange={(v) => {
                  setCode(v);
                  if (invalid) setInvalid(false);
                }}
                onComplete={(v) => confirm(v)}
                invalid={invalid}
                label={`${label} verification code`}
                testid={`otp-${channel}-code`}
              />
              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => confirm()}
                  disabled={busy || code.length !== 6}
                  aria-busy={busy}
                  data-testid={`otp-${channel}-confirm`}
                  className="btn-primary flex-1"
                >
                  {busy ? 'Verifying…' : 'Verify code'}
                </button>
                <button
                  type="button"
                  onClick={send}
                  disabled={busy}
                  aria-busy={busy}
                  className="whitespace-nowrap px-2 text-xs text-brand-accent underline-hover"
                >
                  Resend
                </button>
              </div>
            </div>
          )}
        </div>
      )}
      {error && <Err msg={error} />}
    </div>
  );
}

// ── Profile + questionnaire ───────────────────────────────────────────────────
function ProfileStep({
  app,
  refresh,
  onNext,
}: {
  app: AppDto | null;
  refresh: (a: AppDto | undefined) => void;
  onNext: () => void;
}): JSX.Element {
  const [ecName, setEcName] = useState(app?.emergencyContactName ?? '');
  const [ecPhone, setEcPhone] = useState(app?.emergencyContactPhone ?? '');
  const [ecTouched, setEcTouched] = useState<{ name?: boolean; phone?: boolean }>({});
  const [answers, setAnswers] = useState<RawAnswers>(app?.answers ?? {});
  const [freeText, setFreeText] = useState(app?.freeText ?? '');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const toggle = (qid: string, opt: string, multi: boolean) => {
    setAnswers((prev) => {
      if (!multi) return { ...prev, [qid]: opt };
      const cur = Array.isArray(prev[qid]) ? (prev[qid] as string[]) : [];
      const next = cur.includes(opt) ? cur.filter((o) => o !== opt) : [...cur, opt];
      return { ...prev, [qid]: next };
    });
  };

  const isAnswered = (qid: string): boolean => {
    const v = answers[qid];
    const q = QUESTIONS.find((x) => x.id === qid);
    return q?.multi ? Array.isArray(v) && v.length > 0 : typeof v === 'string' && v.length > 0;
  };
  const ecNameOk = ecName.trim().length > 0;
  const ecPhoneOk = ecPhone.replace(/\D/g, '').length >= 10;
  // Progress across the whole step: emergency contact (1 unit) + every question.
  const answeredQ = QUESTIONS.filter((q) => isAnswered(q.id)).length;
  const ecDone = ecNameOk && ecPhoneOk;
  const totalUnits = QUESTIONS.length + 1;
  const doneUnits = answeredQ + (ecDone ? 1 : 0);
  const pct = Math.round((doneUnits / totalUnits) * 100);

  const complete = useMemo(
    () =>
      QUESTIONS.every((q) => {
        const v = answers[q.id];
        return q.multi ? Array.isArray(v) && v.length > 0 : typeof v === 'string' && v.length > 0;
      }) &&
      ecName.trim().length > 0 &&
      ecPhone.replace(/\D/g, '').length >= 10,
    [answers, ecName, ecPhone],
  );

  const saveAll = async () => {
    setSaving(true);
    setError('');
    await api('/profile', 'PUT', {
      emergencyContactName: ecName.trim(),
      emergencyContactPhone: ecPhone.trim(),
    });
    const r = await api<{ ok: boolean; application?: AppDto }>('/questionnaire', 'PUT', {
      answers: { ...answers, [FREE_TEXT_QUESTION.id]: freeText },
    });
    setSaving(false);
    if (!r.ok) {
      setError('Could not save your answers. Try again.');
      return;
    }
    refresh(r.data.application);
    onNext();
  };

  if (!app) return <NeedAccount />;

  return (
    <>
      <h2 className="font-display text-2xl font-extrabold text-brand-ink">
        Your worker profile <Saving on={saving} />
      </h2>
      <p className="mt-2 text-sm text-brand-mute">
        Tap the answers that fit. This is how dispatch matches you to jobs.
      </p>

      {/* Completion meter — turns a long questionnaire into visible momentum. */}
      <div className="apply-meter mt-4" aria-hidden="true">
        <div className="apply-meter-track">
          <div className="apply-meter-fill" style={{ width: `${pct}%` }} />
        </div>
        <span className="apply-meter-label">
          {doneUnits}/{totalUnits} done
        </span>
      </div>

      <div className="mt-5 grid gap-3 rounded-xl border border-brand-line bg-bg-primary p-4">
        <p className="field-label mb-0">Emergency contact</p>
        <p className="-mt-1 text-xs text-brand-mute">Who we call if something happens on a job.</p>
        <Field
          label="Name"
          id="ec-name"
          value={ecName}
          onChange={(e) => setEcName(e.target.value)}
          onBlur={() => setEcTouched((p) => ({ ...p, name: true }))}
          valid={ecTouched.name || ecName.length > 0 ? ecNameOk : undefined}
          autoComplete="name"
        />
        <Field
          label="Phone"
          id="ec-phone"
          type="tel"
          value={ecPhone}
          onChange={(e) => setEcPhone(formatUsPhone(e.target.value))}
          onBlur={() => setEcTouched((p) => ({ ...p, phone: true }))}
          valid={ecTouched.phone || ecPhone.length > 0 ? ecPhoneOk : undefined}
          autoComplete="tel"
        />
      </div>

      <div className="mt-5 grid gap-5">
        {QUESTIONS.map((q) => (
          <fieldset key={q.id} data-testid={`q-${q.id}`}>
            <legend className="field-label flex items-center gap-1.5">
              <span
                className={`apply-q-tick ${isAnswered(q.id) ? 'is-done' : ''}`}
                aria-hidden="true"
              >
                {isAnswered(q.id) ? (
                  <svg width="10" height="10" viewBox="0 0 20 20" fill="none">
                    <path
                      d="M4 10.5l4 4 8-9"
                      stroke="currentColor"
                      strokeWidth="2.6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                ) : null}
              </span>
              {q.prompt}
            </legend>
            <div className="mt-2 flex flex-wrap gap-2">
              {q.options.map((opt) => {
                const cur = answers[q.id];
                const active = q.multi ? Array.isArray(cur) && cur.includes(opt) : cur === opt;
                return (
                  <button
                    key={opt}
                    type="button"
                    aria-pressed={active}
                    onClick={() => toggle(q.id, opt, q.multi)}
                    className={`apply-chip min-h-[44px] rounded-full border px-4 py-2 text-sm transition ${
                      active
                        ? 'border-brand-accent bg-brand-accent text-bg-primary font-semibold'
                        : 'border-brand-line bg-bg-elevated text-brand-mute hover:border-brand-accent hover:text-brand-ink'
                    }`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
          </fieldset>
        ))}
        <div>
          <label htmlFor="q-free" className="field-label">
            {FREE_TEXT_QUESTION.prompt}
          </label>
          <textarea
            id="q-free"
            data-testid="q-free-text"
            value={freeText}
            onChange={(e) => setFreeText(e.target.value.slice(0, 2000))}
            rows={3}
            className="field-input"
            placeholder="Tell us anything that helps us place you well."
          />
        </div>
      </div>

      <button
        type="button"
        onClick={saveAll}
        disabled={saving || !complete}
        aria-busy={saving}
        data-testid="profile-next"
        className="btn-primary mt-6 w-full"
      >
        {complete ? 'Save + continue →' : 'Answer every question to continue'}
      </button>
      {error && <Err msg={error} />}
    </>
  );
}

// ── Driver track (conditional) ────────────────────────────────────────────────
function DriverStep({
  app,
  refresh,
  onNext,
  onSkip,
}: {
  app: AppDto | null;
  refresh: (a: AppDto | undefined) => void;
  onNext: () => void;
  onSkip: () => void;
}): JSX.Element {
  const [licenseState, setLicenseState] = useState(app?.driver.licenseState ?? '');
  const [licenseExpiration, setLicenseExpiration] = useState('');
  const [isAdult, setIsAdult] = useState(app?.driver.isAdult ?? false);
  const [hasSecondId, setHasSecondId] = useState(false);
  const [consentMvr, setConsentMvr] = useState(app?.driver.consentMvr ?? false);
  const [truck, setTruck] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [front, setFront] = useState(app?.driver.frontUploaded ?? false);
  const [back, setBack] = useState(app?.driver.backUploaded ?? false);

  if (!app) return <NeedAccount />;
  if (!app.wantsDriver) {
    return (
      <>
        <h2 className="font-display text-2xl font-extrabold text-brand-ink">
          No driver track needed
        </h2>
        <p className="mt-2 text-brand-mute">
          You didn't pick driver/U-Haul jobs, so you can skip this step.
        </p>
        <button type="button" className="btn-primary mt-5 w-full" onClick={onSkip}>
          Continue →
        </button>
      </>
    );
  }

  const upload = (slot: 'license_front' | 'license_back') => async (file: File) => {
    if (file.size > 10 * 1024 * 1024) {
      setError('That image is over 10 MB — pick a smaller JPG, PNG, or WebP.');
      return;
    }
    setBusy(true);
    setError('');
    const res = await fetch(`/api/apply/upload/${slot}`, {
      method: 'POST',
      credentials: 'include',
      headers: { 'content-type': file.type },
      body: file,
    });
    setBusy(false);
    if (!res.ok) {
      setError('Upload failed — use a JPG/PNG/WebP under 10 MB.');
      return;
    }
    if (slot === 'license_front') setFront(true);
    else setBack(true);
  };

  const TRUCKS = ['Cargo van', 'Pickup', '10 ft', '15 ft', '20 ft', '26 ft'];
  const valid =
    /^[A-Za-z]{2}$/.test(licenseState) &&
    /^\d{4}-\d{2}-\d{2}$/.test(licenseExpiration) &&
    isAdult &&
    front &&
    back;

  const save = async () => {
    if (!valid) {
      setError(
        'License state, expiration (YYYY-MM-DD), 18+ confirmation, and BOTH license photos are required.',
      );
      return;
    }
    setBusy(true);
    setError('');
    const r = await api<{ ok: boolean; application?: AppDto }>('/driver', 'PUT', {
      licenseState: licenseState.toUpperCase(),
      licenseExpiration,
      isAdult: true,
      hasSecondId,
      truckExperience: truck,
      consentMvr,
    });
    if (consentMvr) await api('/identity/start', 'POST', {});
    setBusy(false);
    if (!r.ok) {
      setError('Could not save your driver details.');
      return;
    }
    refresh(r.data.application);
    onNext();
  };

  return (
    <>
      <h2 className="font-display text-2xl font-extrabold text-brand-ink">Driver / U-Haul track</h2>
      <p className="mt-2 text-sm text-brand-mute">
        You're not driver-approved automatically — our team reviews your license + driving record
        first.
      </p>
      <div className="mt-5 grid gap-4">
        <div className="grid grid-cols-2 gap-3">
          <Field
            label="License state"
            id="dl-state"
            value={licenseState}
            onChange={(e) => setLicenseState(e.target.value.toUpperCase().slice(0, 2))}
            valid={licenseState.length > 0 ? /^[A-Za-z]{2}$/.test(licenseState) : undefined}
            placeholder="NJ"
            hint="2-letter state on your license."
            maxLength={2}
          />
          <div>
            <label htmlFor="dl-exp" className="field-label">
              Expiration date
            </label>
            <input
              id="dl-exp"
              type="date"
              value={licenseExpiration}
              onChange={(e) => setLicenseExpiration(e.target.value)}
              className="field-input"
              aria-label="License expiration date"
            />
            <p className="mt-1 text-[11px] leading-snug text-brand-mute">
              Must be a valid, unexpired license.
            </p>
          </div>
        </div>
        <div>
          <p className="field-label">Driver&apos;s license photos</p>
          <p className="-mt-1 mb-2 text-xs text-brand-mute">
            Clear, well-lit photos of both sides. Used only to verify your license — encrypted at
            rest.
          </p>
          <div className="grid grid-cols-2 gap-3">
            <UploadTile
              label="License front"
              done={front}
              onFile={upload('license_front')}
              testid="upload-front"
            />
            <UploadTile
              label="License back"
              done={back}
              onFile={upload('license_back')}
              testid="upload-back"
            />
          </div>
        </div>
        <fieldset>
          <legend className="field-label">Truck experience</legend>
          <div className="mt-2 flex flex-wrap gap-2">
            {TRUCKS.map((t) => {
              const active = truck.includes(t);
              return (
                <button
                  key={t}
                  type="button"
                  aria-pressed={active}
                  onClick={() =>
                    setTruck((p) => (p.includes(t) ? p.filter((x) => x !== t) : [...p, t]))
                  }
                  className={`apply-chip min-h-[44px] rounded-full border px-4 py-2 text-sm ${active ? 'border-brand-accent bg-brand-accent text-bg-primary font-semibold' : 'border-brand-line bg-bg-elevated text-brand-mute hover:border-brand-accent hover:text-brand-ink'}`}
                >
                  {t}
                </button>
              );
            })}
          </div>
        </fieldset>
        <Check
          label="I confirm I am 18 or older"
          checked={isAdult}
          onChange={setIsAdult}
          testid="dl-adult"
        />
        <Check label="I have a second form of ID" checked={hasSecondId} onChange={setHasSecondId} />
        <Check
          label="I consent to a motor-vehicle record (MVR) check"
          checked={consentMvr}
          onChange={setConsentMvr}
          testid="dl-mvr"
        />
      </div>
      <button
        type="button"
        onClick={save}
        disabled={busy || !valid}
        aria-busy={busy}
        data-testid="driver-next"
        className="btn-primary mt-6 w-full"
      >
        {busy ? 'Saving…' : 'Save driver info →'}
      </button>
      {error && <Err msg={error} />}
    </>
  );
}

// ── Review + submit ───────────────────────────────────────────────────────────
function ReviewStep({
  app,
  refresh,
  onSubmitted,
}: {
  app: AppDto | null;
  refresh: (a: AppDto | undefined) => void;
  onSubmitted: () => void;
}): JSX.Element {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [profile, setProfile] = useState<string | null>(app?.aiDispatchProfile ?? null);
  const [regenerating, setRegenerating] = useState(false);
  const [ssn, setSsn] = useState('');
  const [ssnLast4, setSsnLast4] = useState<string | null>(app?.ssnLast4 ?? null);
  const [ssnBusy, setSsnBusy] = useState(false);

  const regenerate = async () => {
    setRegenerating(true);
    const r = await api<{ ok: boolean; profile?: { dispatchProfile: string } }>(
      '/dispatch-profile',
      'POST',
      {},
    );
    setRegenerating(false);
    if (r.ok && r.data.profile) setProfile(r.data.profile.dispatchProfile);
  };

  const saveSsn = async () => {
    if (!/^\d{3}-?\d{2}-?\d{4}$/.test(ssn.trim())) {
      setError('Enter a valid 9-digit SSN.');
      return;
    }
    setSsnBusy(true);
    setError('');
    const r = await api<{ ok: boolean; last4?: string }>('/ssn', 'POST', { ssn: ssn.trim() });
    setSsnBusy(false);
    if (!r.ok || !r.data.last4) {
      setError('Could not save your SSN. Try again.');
      return;
    }
    setSsnLast4(r.data.last4);
    setSsn('');
  };

  // Generate the AI dispatch profile on entry (idempotent — regenerates safely).
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const r = await api<{ ok: boolean; profile?: { dispatchProfile: string } }>(
        '/dispatch-profile',
        'POST',
        {},
      );
      if (!cancelled && r.ok && r.data.profile) setProfile(r.data.profile.dispatchProfile);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (!app) return <NeedAccount />;

  const submit = async () => {
    setBusy(true);
    setError('');
    const r = await api<{ ok: boolean; code?: string; application?: AppDto }>(
      '/submit',
      'POST',
      {},
    );
    setBusy(false);
    if (!r.ok) {
      setError(
        r.data.code === 'verification_incomplete'
          ? 'Verify your email + phone first.'
          : r.data.code === 'questionnaire_incomplete'
            ? 'Finish your worker profile first.'
            : 'Could not submit — please review your steps.',
      );
      return;
    }
    refresh(r.data.application);
    onSubmitted();
  };

  const ssnDone = !!ssnLast4 || app.ssnOnFile;
  // What still blocks a successful submit — drives the "what's left" hint so the
  // applicant never taps a doomed button and wonders why it failed.
  const remaining: string[] = [];
  if (!app.emailVerified) remaining.push('verify your email');
  if (!app.phoneVerified) remaining.push('verify your phone');
  if (!app.questionnaireComplete) remaining.push('finish your worker profile');
  if (!ssnDone) remaining.push('add your SSN');
  const readyToSubmit = remaining.length === 0;

  return (
    <>
      <h2 className="font-display text-2xl font-extrabold text-brand-ink">Review + submit</h2>
      <p className="mt-2 text-sm text-brand-mute">
        Here's the dispatch profile we generated from your answers.
      </p>
      <div className="apply-ai-card mt-4" data-testid="ai-dispatch-profile">
        <div className="flex items-center justify-between gap-2">
          <span className="apply-ai-badge">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path
                d="M12 3l1.8 4.9L18.7 9l-4.9 1.8L12 15l-1.8-4.2L5.3 9l4.9-1.1L12 3z"
                fill="currentColor"
              />
              <path
                d="M18.5 14l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8.8-2.2z"
                fill="currentColor"
              />
            </svg>
            AI dispatch profile
          </span>
          <button
            type="button"
            onClick={regenerate}
            disabled={regenerating}
            className="inline-flex items-center gap-1 text-[11px] font-semibold text-brand-accent underline-hover disabled:opacity-60"
            data-testid="regenerate-profile"
          >
            <svg
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              aria-hidden="true"
              className={regenerating ? 'apply-spin' : ''}
            >
              <path
                d="M4 12a8 8 0 0113.7-5.7L20 8m0 0V3m0 5h-5M20 12a8 8 0 01-13.7 5.7L4 16m0 0v5m0-5h5"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            {regenerating ? 'Regenerating…' : 'Regenerate'}
          </button>
        </div>
        <p className="mt-2 text-sm leading-relaxed text-brand-ink">
          {profile ?? 'Generating your dispatch profile…'}
        </p>
      </div>

      <ul className="mt-4 grid gap-2" data-testid="review-checklist">
        <ReviewRow label="Email verified" ok={app.emailVerified} />
        <ReviewRow label="Phone verified" ok={app.phoneVerified} />
        <ReviewRow label="Worker profile complete" ok={app.questionnaireComplete} />
        {app.wantsDriver && (
          <ReviewRow
            label="Driver documents uploaded"
            ok={app.driver.frontUploaded && app.driver.backUploaded}
          />
        )}
        <ReviewRow label="SSN on file for payroll" ok={ssnDone} />
      </ul>

      <div
        className="mt-4 rounded-xl border border-brand-line bg-bg-primary p-4"
        data-testid="ssn-block"
      >
        <div className="flex items-center gap-2">
          <span className="flex h-6 w-6 flex-none items-center justify-center rounded-md bg-brand-accent/12 text-brand-accent">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <rect
                x="4"
                y="10"
                width="16"
                height="10"
                rx="2"
                stroke="currentColor"
                strokeWidth="1.7"
              />
              <path
                d="M8 10V7a4 4 0 018 0v3"
                stroke="currentColor"
                strokeWidth="1.7"
                strokeLinecap="round"
              />
            </svg>
          </span>
          <label htmlFor="ssn-input" className="field-label mb-0">
            Social Security Number
          </label>
        </div>
        <p className="mb-2 mt-2 text-xs text-brand-mute">
          Required for your background check and payroll. Encrypted at rest — we never display or
          log the full number, only the last 4.
        </p>
        {ssnDone ? (
          <p
            className="inline-flex items-center gap-1.5 text-sm text-emerald-400"
            data-testid="ssn-onfile"
          >
            <svg width="15" height="15" viewBox="0 0 20 20" fill="none" aria-hidden="true">
              <path
                d="M4 10.5l4 4 8-9"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            SSN on file (ending {ssnLast4 ?? app.ssnLast4})
          </p>
        ) : (
          <div className="flex gap-2">
            <input
              type="password"
              inputMode="numeric"
              autoComplete="off"
              value={ssn}
              onChange={(e) => setSsn(e.target.value)}
              placeholder="123-45-6789"
              id="ssn-input"
              data-testid="ssn-input"
              className="field-input flex-1"
            />
            <button
              type="button"
              onClick={saveSsn}
              disabled={ssnBusy}
              data-testid="ssn-save"
              className="btn-primary"
            >
              {ssnBusy ? 'Saving…' : 'Save'}
            </button>
          </div>
        )}
      </div>

      <button
        type="button"
        onClick={submit}
        disabled={busy || !readyToSubmit}
        aria-busy={busy}
        data-testid="submit-application"
        className="btn-primary mt-6 w-full"
      >
        {busy ? 'Submitting…' : readyToSubmit ? 'Submit application →' : 'A few steps left'}
      </button>
      {!readyToSubmit && !error && (
        <p className="mt-2 text-center text-xs text-brand-mute">
          Still to do: {remaining.join(', ')}.
        </p>
      )}
      {error && <Err msg={error} />}
      <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-xs text-brand-mute">
        <svg width="13" height="13" viewBox="0 0 20 20" fill="none" aria-hidden="true">
          <path
            d="M10 1.5l6.5 2.5v5c0 4-2.8 7.4-6.5 8.5-3.7-1.1-6.5-4.5-6.5-8.5V4L10 1.5z"
            stroke="currentColor"
            strokeWidth="1.4"
            strokeLinejoin="round"
          />
        </svg>
        Submitting doesn&apos;t lock anything in — our team reviews every application by hand.
      </p>
    </>
  );
}

// ── Status dashboard ──────────────────────────────────────────────────────────
function StatusStep({
  app,
  refresh,
}: {
  app: AppDto | null;
  refresh: (a: AppDto | undefined) => void;
}): JSX.Element {
  useEffect(() => {
    (async () => {
      const r = await api<{ ok: boolean; application?: AppDto }>('/status', 'GET');
      if (r.ok) refresh(r.data.application);
    })();
  }, []);

  if (!app) return <NeedAccount />;
  const items = app.checklist.filter((i) => i.applicable);
  const done = items.filter((i) => i.done).length;
  const submitted = !!app.submittedAt;

  // What happens after they hit submit — kills the "now what?" anxiety with a
  // concrete 3-beat timeline so the applicant knows exactly what's coming.
  const NEXT_STEPS: ReadonlyArray<readonly [string, string]> = [
    [
      'We review your application',
      'A real person checks your details — usually within 1 business day.',
    ],
    [
      'Quick background + license check',
      'Standard for every crew member. We text you if we need anything.',
    ],
    [
      'Your first job offer',
      'Once cleared, jobs come straight to your phone — accept the ones that fit.',
    ],
  ];

  return (
    <>
      <div className="apply-success-hero" data-testid="apply-success-hero">
        <span
          className={`apply-success-badge ${submitted ? 'is-celebrate' : ''}`}
          aria-hidden="true"
        >
          <svg width="34" height="34" viewBox="0 0 24 24" fill="none">
            <path
              d="M4 12.5l5 5 11-12"
              stroke="currentColor"
              strokeWidth="2.4"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </span>
        <h2 className="mt-4 font-display text-2xl sm:text-3xl font-extrabold leading-tight text-brand-ink text-balance">
          {submitted ? "Application in! You're on the crew list." : "You're almost done"}
        </h2>
        <p className="mt-2 text-sm text-brand-mute">
          {done}/{items.length} steps complete · Status:{' '}
          <strong className="text-brand-ink">{humanStatus(app.status)}</strong>
        </p>
      </div>

      {submitted && (
        <div className="mt-6">
          <p className="eyebrow mb-3 text-brand-accent">What happens next</p>
          <ol className="apply-next grid gap-0">
            {NEXT_STEPS.map(([title, sub], i) => (
              <li key={title} className="apply-next-step">
                <span className="apply-next-marker" aria-hidden="true">
                  {i + 1}
                </span>
                <span className="apply-next-body">
                  <span className="block text-sm font-semibold text-brand-ink">{title}</span>
                  <span className="block text-xs leading-snug text-brand-mute">{sub}</span>
                </span>
              </li>
            ))}
          </ol>
        </div>
      )}

      <details className="apply-status-details mt-6" data-testid="status-checklist">
        <summary className="flex cursor-pointer items-center justify-between gap-2 text-sm font-semibold text-brand-ink">
          <span>Your checklist</span>
          <span className="font-mono text-[10px] uppercase tracking-wider text-brand-mute">
            {done}/{items.length} done
          </span>
        </summary>
        <ul className="mt-3 grid gap-2">
          {items.map((i) => (
            <li
              key={i.key}
              className="flex items-center gap-3 rounded-lg border border-brand-line bg-bg-primary px-3 py-2.5"
            >
              <span
                aria-hidden
                className={`inline-flex h-5 w-5 flex-none items-center justify-center rounded-full text-xs ${
                  i.done
                    ? 'bg-emerald-500 text-bg-primary'
                    : 'border border-brand-line text-brand-mute'
                }`}
              >
                {i.done ? '✓' : ''}
              </span>
              <span className={i.done ? 'text-brand-ink' : 'text-brand-mute'}>{i.label}</span>
            </li>
          ))}
        </ul>
      </details>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <a
          href="/login/crew"
          data-bcl-cta="apply-status-login"
          className="btn-primary btn-arrow flex-1 text-center"
        >
          Go to my crew account{' '}
          <span data-btn-arrow aria-hidden="true">
            →
          </span>
        </a>
        <a
          href="/"
          className="flex flex-1 items-center justify-center rounded-lg border border-brand-line px-4 py-3 text-sm font-semibold text-brand-ink transition-colors hover:border-brand-accent hover:text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
        >
          Back to home
        </a>
      </div>
      <p className="mt-3 text-center text-xs text-brand-mute">
        We&apos;ll text and email you as each step clears — no need to wait here.
      </p>
    </>
  );
}

// ── Small shared bits ─────────────────────────────────────────────────────────
function Field({
  label,
  id,
  value,
  onChange,
  onBlur,
  type = 'text',
  inputMode,
  placeholder,
  hint,
  valid,
  autoComplete,
  maxLength,
}: {
  label: string;
  id: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onBlur?: () => void;
  type?: string;
  inputMode?: 'numeric' | 'tel' | 'email' | 'text';
  placeholder?: string;
  /** Small helper line under the label (format hint, reassurance). */
  hint?: string;
  /**
   * Inline validity affordance. `undefined` = pristine (no icon);
   * `true`/`false` render a green check / red × trailing the input and colour
   * the border. Only pass once the user has interacted (touched) the field.
   */
  valid?: boolean;
  autoComplete?: string;
  maxLength?: number;
}): JSX.Element {
  const hintId = hint ? `${id}-hint` : undefined;
  return (
    <div className="apply-field" data-valid={valid === undefined ? undefined : String(valid)}>
      <label htmlFor={id} className="field-label">
        {label}
      </label>
      <input
        id={id}
        type={type}
        inputMode={inputMode}
        value={value}
        onChange={onChange}
        onBlur={onBlur}
        placeholder={placeholder}
        className="field-input"
        aria-invalid={valid === false ? true : undefined}
        aria-describedby={hintId}
        autoComplete={autoComplete}
        maxLength={maxLength}
      />
      {valid !== undefined && (
        <span className="apply-field-validity" aria-hidden="true">
          {valid ? (
            <svg width="15" height="15" viewBox="0 0 20 20" fill="none">
              <path
                d="M4 10.5l4 4 8-9"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          ) : (
            <svg width="14" height="14" viewBox="0 0 20 20" fill="none">
              <path
                d="M5 5l10 10M15 5L5 15"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
              />
            </svg>
          )}
        </span>
      )}
      {hint && (
        <p id={hintId} className="mt-1 text-[11px] leading-snug text-brand-mute">
          {hint}
        </p>
      )}
    </div>
  );
}

function Check({
  label,
  checked,
  onChange,
  testid,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  testid?: string;
}): JSX.Element {
  // Branded custom checkbox: the native input drives state + keyboard + focus,
  // the styled box (≥24px, WCAG 2.5.8) is the visual. Whole row is a tap target.
  return (
    <label className="apply-check flex min-h-[44px] cursor-pointer items-center gap-3 rounded-lg text-sm text-brand-ink focus-within:outline-none focus-within:ring-2 focus-within:ring-brand-accent focus-within:ring-offset-2 focus-within:ring-offset-bg-primary">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        data-testid={testid}
        className="sr-only"
      />
      <span className="apply-check-box" aria-hidden="true">
        <svg width="14" height="14" viewBox="0 0 20 20" fill="none">
          <path
            d="M4 10.5l4 4 8-9"
            stroke="currentColor"
            strokeWidth="2.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </span>
      <span>{label}</span>
    </label>
  );
}

function UploadTile({
  label,
  done,
  onFile,
  testid,
}: {
  label: string;
  done: boolean;
  onFile: (file: File) => void | Promise<void>;
  testid: string;
}): JSX.Element {
  const [preview, setPreview] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);

  // Local object-URL preview so the applicant sees the exact photo they picked;
  // revoked on unmount / replace to avoid leaks.
  const take = (file: File | undefined) => {
    if (!file) return;
    setPreview((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return URL.createObjectURL(file);
    });
    void onFile(file);
  };
  useEffect(
    () => () => {
      if (preview) URL.revokeObjectURL(preview);
    },
    [preview],
  );

  return (
    <label
      className={`apply-upload ${done ? 'is-done' : ''} ${dragOver ? 'is-dragover' : ''}`}
      onDragOver={(e) => {
        e.preventDefault();
        setDragOver(true);
      }}
      onDragLeave={() => setDragOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragOver(false);
        take(e.dataTransfer.files?.[0]);
      }}
    >
      {preview ? (
        <img src={preview} alt={`${label} preview`} className="apply-upload-thumb" />
      ) : null}
      <span className="apply-upload-body">
        <span className="apply-upload-icon" aria-hidden="true">
          {done ? (
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path
                d="M4 12.5l5 5 11-12"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          ) : (
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path
                d="M12 15V4m0 0L8 8m4-4l4 4M5 15v3a2 2 0 002 2h10a2 2 0 002-2v-3"
                stroke="currentColor"
                strokeWidth="1.7"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          )}
        </span>
        <span className="apply-upload-title">{done ? 'Uploaded' : label}</span>
        <span className="apply-upload-hint">
          {done ? 'Tap or drop to replace' : 'Tap or drop · JPG / PNG / WebP'}
        </span>
      </span>
      <input
        type="file"
        accept="image/jpeg,image/png,image/webp"
        onChange={(e) => take(e.target.files?.[0])}
        data-testid={testid}
        className="sr-only"
      />
    </label>
  );
}

function ReviewRow({ label, ok }: { label: string; ok: boolean }): JSX.Element {
  return (
    <li
      className={`flex items-center gap-3 rounded-lg border px-3 py-2 text-sm ${
        ok
          ? 'border-emerald-500/30 bg-emerald-500/[0.06]'
          : 'border-amber-400/30 bg-amber-400/[0.05]'
      }`}
    >
      <span
        aria-hidden="true"
        className={`inline-flex h-5 w-5 flex-none items-center justify-center rounded-full ${
          ok ? 'bg-emerald-500 text-bg-primary' : 'border border-amber-400/60 text-amber-300'
        }`}
      >
        {ok ? (
          <svg width="12" height="12" viewBox="0 0 20 20" fill="none">
            <path
              d="M4 10.5l4 4 8-9"
              stroke="currentColor"
              strokeWidth="2.6"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        ) : (
          <svg width="11" height="11" viewBox="0 0 20 20" fill="none">
            <path d="M10 5v6" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
            <circle cx="10" cy="14.5" r="1" fill="currentColor" />
          </svg>
        )}
      </span>
      <span className={ok ? 'text-brand-ink' : 'text-brand-mute'}>{label}</span>
      <span
        className={`ml-auto font-mono text-[10px] uppercase tracking-wider ${
          ok ? 'text-emerald-400' : 'text-amber-300'
        }`}
      >
        {ok ? 'Done' : 'To do'}
      </span>
    </li>
  );
}

function Err({ msg }: { msg: string }): JSX.Element {
  return (
    <div
      role="alert"
      className="mt-4 rounded-md border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-200"
    >
      {msg}
    </div>
  );
}

function NeedAccount(): JSX.Element {
  return (
    <>
      <h2 className="font-display text-2xl font-extrabold text-brand-ink">
        Start your application first
      </h2>
      <a
        href="/apply/account"
        className="btn-primary mt-5 inline-flex w-full items-center justify-center"
      >
        Back to start →
      </a>
    </>
  );
}

function humanStatus(s: string): string {
  return s.replace(/_/g, ' ').replace(/\b\w/g, (m) => m.toUpperCase());
}
