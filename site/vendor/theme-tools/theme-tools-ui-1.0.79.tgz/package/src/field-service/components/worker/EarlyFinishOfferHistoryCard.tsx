import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { useCallback, useEffect, useState } from 'react';
import { useFeatureFlag } from '../../use-feature-flag.js';

interface OfferRow {
  id: string;
  original_scheduled_at: string;
  proposed_scheduled_at: string;
  discount_cents: number;
  distance_miles: number | null;
  status: string;
  expires_at: string;
}

const STATUS_LABEL: Record<string, string> = {
  pending: 'Waiting for customer',
  accepted: 'Customer accepted',
  declined: 'Customer declined',
  expired: 'Offer expired',
  superseded: 'Replaced by a newer offer',
};

const DATE = new Intl.DateTimeFormat('en-US', {
  month: 'short',
  day: 'numeric',
  hour: 'numeric',
  minute: '2-digit',
});

export function EarlyFinishOfferHistoryCard(): JSX.Element | null {
  useThemeToolsSurface('early-finish-offer-history-card');
  const enabled = useFeatureFlag('early_finish_offer');
  const [offers, setOffers] = useState<OfferRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    if (!enabled) return;
    setLoading(true);
    setError('');
    try {
      const profileRes = await fetch('/api/work/profile', { credentials: 'same-origin' });
      const profile = (await profileRes.json().catch(() => null)) as {
        worker?: { id?: string };
      } | null;
      const workerId = profile?.worker?.id;
      if (!profileRes.ok || !workerId) throw new Error('profile_unavailable');
      const offersRes = await fetch(
        `/api/early-finish-offer/log/${encodeURIComponent(workerId)}`,
        { credentials: 'same-origin' },
      );
      const body = (await offersRes.json().catch(() => null)) as {
        ok?: boolean;
        offers?: OfferRow[];
      } | null;
      if (!offersRes.ok || !body?.ok || !body.offers) throw new Error('offers_unavailable');
      setOffers(body.offers);
    } catch {
      setError("We couldn't load your early-finish offers. Your jobs are unchanged.");
    } finally {
      setLoading(false);
    }
  }, [enabled]);

  useEffect(() => {
    void load();
  }, [load]);

  if (!enabled) return null;

  return (
    <section
      className="rounded-2xl border border-brand-line bg-brand-card p-4"
      data-testid="crew-early-finish-offers"
      aria-labelledby="crew-early-finish-heading"
    >
      <h2 id="crew-early-finish-heading" className="text-lg font-bold text-brand-ink">
        Early-finish offers
      </h2>
      <p className="mt-1 text-sm text-brand-mute">
        When your schedule opens up, we may offer a nearby customer an earlier arrival.
      </p>

      {loading ? (
        <p className="mt-4 text-sm text-brand-mute" role="status">
          Loading offers…
        </p>
      ) : error ? (
        <div className="mt-4" role="alert">
          <p className="text-sm text-brand-mute">{error}</p>
          <button type="button" className="btn-secondary mt-3 min-h-11" onClick={() => void load()}>
            Try again
          </button>
        </div>
      ) : offers.length === 0 ? (
        <p className="mt-4 text-sm text-brand-mute">No early-finish offers yet.</p>
      ) : (
        <ul className="mt-4 grid gap-3">
          {offers.map((offer) => (
            <li key={offer.id} className="rounded-xl border border-brand-line p-3">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <p className="font-semibold text-brand-ink">
                    {DATE.format(new Date(offer.proposed_scheduled_at))}
                  </p>
                  <p className="text-xs text-brand-mute">
                    Originally {DATE.format(new Date(offer.original_scheduled_at))}
                  </p>
                </div>
                <span className="rounded-full bg-brand-accent/10 px-2.5 py-1 text-xs font-semibold text-brand-accent">
                  ${(offer.discount_cents / 100).toFixed(0)} customer savings
                </span>
              </div>
              <p className="mt-2 text-sm font-medium text-brand-ink">
                {STATUS_LABEL[offer.status] ?? offer.status.replace(/_/g, ' ')}
              </p>
              {offer.distance_miles != null && (
                <p className="mt-1 text-xs text-brand-mute">
                  {offer.distance_miles.toFixed(1)} miles from your last job
                </p>
              )}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
