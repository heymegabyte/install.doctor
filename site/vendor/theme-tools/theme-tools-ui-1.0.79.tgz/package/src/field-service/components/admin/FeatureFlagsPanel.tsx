import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useEffect, useState } from 'react';

/**
 * Feature flags + kill switch panel. Super-admin only.
 * Optimistic toggle, audit-logged server-side.
 */

interface Flag {
  key: string;
  enabled: number;
  description: string;
  updated_at: string;
}

const KILL_SCOPES = ['all', 'booking_form', 'ai_routes', 'admin'] as const;

const FALLBACK_FLAGS: Flag[] = [
  { key: 'early_finish_offer', enabled: 1, description: 'SMS nearby homeowners a discount when a crew finishes early', updated_at: '2026-11-23' },
  { key: 'crew_sentiment_rotation', enabled: 1, description: 'Monitor per-crew sentiment & auto-pause above 40% negative ratio', updated_at: '2026-11-23' },
  { key: 'competitor_intel', enabled: 1, description: 'Weekly competitor pricing & review digest', updated_at: '2026-11-23' },
  { key: 'edge_search', enabled: 1, description: 'Edge-native Orama site search at /search', updated_at: '2026-11-23' },
];

export function FeatureFlagsPanel({ bearer }: { bearer: string }) {
  useThemeToolsSurface('feature-flags-panel');
  const [flags, setFlags] = useState<Flag[]>(FALLBACK_FLAGS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [pending, setPending] = useState<Set<string>>(new Set());
  const [query, setQuery] = useState('');
  const [enabledOnly, setEnabledOnly] = useState(false);

  useEffect(() => {
    void (async () => {
      try {
        const res = await fetch('/api/super-admin/feature-flags/list', {
          credentials: 'include',
          headers: bearer ? { authorization: `Bearer ${bearer}` } : undefined,
        });
        const json = (await res.json()) as { ok: boolean; flags?: Flag[]; error?: string };
        if (json.ok && json.flags && json.flags.length > 0) setFlags(json.flags);
        else setFlags(FALLBACK_FLAGS);
      } catch {
        setFlags(FALLBACK_FLAGS);
      } finally {
        setLoading(false);
      }
    })();
  }, [bearer]);

  async function toggle(key: string, next: boolean) {
    // Optimistic flip + revert on failure.
    setPending((p) => new Set(p).add(key));
    setFlags((prev) => prev.map((f) => (f.key === key ? { ...f, enabled: next ? 1 : 0 } : f)));
    try {
      const res = await fetch('/api/super-admin/feature-flags/set', {
        method: 'POST',
        credentials: 'include',
        headers: {
          ...(bearer ? { authorization: `Bearer ${bearer}` } : {}),
          'content-type': 'application/json',
        },
        body: JSON.stringify({ key, enabled: next }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
    } catch (err) {
      // Roll back.
      setFlags((prev) => prev.map((f) => (f.key === key ? { ...f, enabled: next ? 0 : 1 } : f)));
      setError(`Toggle failed: ${(err as Error).message}`);
    } finally {
      setPending((p) => {
        const n = new Set(p);
        n.delete(key);
        return n;
      });
    }
  }

  async function killSwitch(scope: (typeof KILL_SCOPES)[number], enabled: boolean) {
    const reason = prompt(
      `Confirm KILL SWITCH (${scope}) → ${enabled ? 'ENABLE (block traffic)' : 'DISABLE (resume traffic)'}.\nReason (optional):`,
    );
    if (reason === null) return; // user cancelled
    try {
      const res = await fetch('/api/super-admin/feature-flags/kill-switch', {
        method: 'POST',
        credentials: 'include',
        headers: {
          ...(bearer ? { authorization: `Bearer ${bearer}` } : {}),
          'content-type': 'application/json',
        },
        body: JSON.stringify({ scope, enabled, reason }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      // Re-fetch flags to surface the new kill_switch_* row.
      const r = await fetch('/api/super-admin/feature-flags/list', {
        credentials: 'include',
        headers: bearer ? { authorization: `Bearer ${bearer}` } : undefined,
      });
      const j = (await r.json()) as { ok: boolean; flags?: Flag[] };
      if (j.ok && j.flags) setFlags(j.flags);
    } catch (err) {
      setError(`Kill switch failed: ${(err as Error).message}`);
    }
  }

  if (loading) return <p className="text-sm text-brand-mute">Loading flags…</p>;
  if (error && flags.length === 0) return <p className="text-sm text-red-400">{error}</p>;

  const regular = flags.filter((f) => !f.key.startsWith('kill_switch_'));
  const killSwitches = flags.filter((f) => f.key.startsWith('kill_switch_'));
  const q = query.trim().toLowerCase();
  const visible = regular.filter((f) => {
    if (enabledOnly && f.enabled !== 1) return false;
    if (!q) return true;
    return f.key.toLowerCase().includes(q) || (f.description || '').toLowerCase().includes(q);
  });
  const enabledCount = regular.filter((f) => f.enabled === 1).length;

  return (
    <div className="space-y-4">
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-5" data-enter>
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-xl font-bold text-brand-ink">
            Feature flags{' '}
            <span className="text-sm font-normal text-brand-mute">
              · {visible.length} of {regular.length} · {enabledCount} on
            </span>
          </h2>
          <div className="flex items-center gap-2">
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search flags…"
              aria-label="Search feature flags"
              data-testid="flag-search"
              className="field-input h-9 w-44 text-sm"
            />
            <button
              type="button"
              onClick={() => setEnabledOnly((v) => !v)}
              aria-pressed={enabledOnly}
              data-testid="flag-enabled-only"
              className={`rounded-full border px-3 py-1.5 text-xs transition ${
                enabledOnly
                  ? 'border-brand-accent bg-brand-accent/10 text-brand-ink'
                  : 'border-brand-line text-brand-mute hover:text-brand-ink'
              }`}
            >
              Enabled only
            </button>
          </div>
        </div>
        <ul className="space-y-2">
          {visible.length === 0 && (
            <li className="rounded-lg border border-brand-line bg-bg-primary p-3 text-center text-sm text-brand-mute">
              No flags match “{query}”{enabledOnly ? ' (enabled only)' : ''}.
            </li>
          )}
          {visible.map((f) => (
            <li
              key={f.key}
              className="flex items-start justify-between gap-3 rounded-lg border border-brand-line bg-bg-primary p-3"
            >
              <div className="min-w-0 flex-1">
                <p className="font-mono text-xs text-brand-ink">{f.key}</p>
                <p className="mt-0.5 text-xs text-brand-mute">
                  {f.description || '(no description)'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => void toggle(f.key, f.enabled !== 1)}
                disabled={pending.has(f.key)}
                aria-pressed={f.enabled === 1}
                data-bcl-action="feature_flag_toggle"
                data-bcl-flag={f.key}
                className={`inline-flex h-6 w-11 shrink-0 items-center rounded-full border transition ${
                  f.enabled === 1
                    ? 'border-brand-accent bg-brand-accent'
                    : 'border-brand-line bg-bg-elevated'
                } ${pending.has(f.key) ? 'opacity-50' : ''}`}
              >
                <span
                  className={`inline-block h-5 w-5 transform rounded-full bg-bg-primary transition ${
                    f.enabled === 1 ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                  aria-hidden
                />
                <span className="sr-only">{f.enabled === 1 ? 'enabled' : 'disabled'}</span>
              </button>
            </li>
          ))}
        </ul>
      </section>

      <section
        className="rounded-2xl border border-red-500/30 bg-red-500/5 p-5"
        aria-labelledby="kill-switches-title"
      >
        <h2 id="kill-switches-title" className="mb-3 text-xl font-bold text-red-300">
          Kill switches
        </h2>
        <p className="mb-3 text-xs text-brand-mute">
          Block traffic to a scope in an outage. Re-toggle to resume.
        </p>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {KILL_SCOPES.map((scope) => {
            const flag = killSwitches.find((k) => k.key === `kill_switch_${scope}`);
            const active = flag?.enabled === 1;
            return (
              <button
                key={scope}
                type="button"
                onClick={() => void killSwitch(scope, !active)}
                className={`rounded-md border px-3 py-2 text-sm font-semibold transition ${
                  active
                    ? 'border-red-500 bg-red-500/20 text-red-200'
                    : 'border-brand-line bg-bg-primary text-brand-mute hover:border-red-500/50'
                }`}
              >
                {scope.replace('_', ' ')}
                {active ? ' · ENABLED' : ''}
              </button>
            );
          })}
        </div>
      </section>
      {error && <p className="text-sm text-red-400">{error}</p>}
    </div>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
