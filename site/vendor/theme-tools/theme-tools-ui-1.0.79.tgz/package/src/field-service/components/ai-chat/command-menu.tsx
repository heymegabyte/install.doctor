import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { useEffect, useMemo, useRef, type JSX } from 'react';
import type { AiChatCommandSpec } from '@theme.tools/agent-ui/field-service/ai-chat';
import { matchChatCommands } from '@theme.tools/agent-ui/field-service/ai-chat';

/**
 * Fuzzy slash-command palette anchored above the composer. Renders the popup
 * half of a WCAG APG editable-combobox: `role="listbox"` with a stable id
 * ({@link COMMAND_LISTBOX_ID}) and one `role="option"` per command, each
 * carrying a derived id ({@link commandOptionId}). The composer textarea owns
 * the combobox half (`role="combobox"` + `aria-expanded` + `aria-controls` +
 * `aria-activedescendant`) and points `aria-activedescendant` at the active
 * option's id so a screen reader announces the highlighted command as the user
 * arrows through — the wiring this module exists to make possible.
 */

/** Stable DOM id of the slash-command listbox — shared by the composer's `aria-controls`. */
export const COMMAND_LISTBOX_ID = 'ai-chat-command-listbox';

/**
 * Derive the stable DOM id for the command option at `idx`.
 *
 * The composer's `aria-activedescendant` is set to `commandOptionId(activeIndex)`
 * so the active `<option>` is announced without moving focus off the textarea.
 *
 * @param idx - Zero-based option index within the current match set.
 * @returns A stable, collision-free element id (e.g. `ai-chat-command-option-2`).
 * @example
 * commandOptionId(2) // → 'ai-chat-command-option-2'
 */
export function commandOptionId(idx: number): string {
  return `ai-chat-command-option-${idx}`;
}

interface CommandMenuProps {
  query: string;
  activeIndex: number;
  onActiveIndexChange: (idx: number) => void;
  onSelect: (cmd: AiChatCommandSpec) => void;
}

export function CommandMenu({
  query,
  activeIndex,
  onActiveIndexChange,
  onSelect,
}: CommandMenuProps): JSX.Element | null {
  useThemeToolsSurface('command-menu');
  const matches = useMemo(() => matchChatCommands(query, 8), [query]);
  const listRef = useRef<HTMLUListElement>(null);

  useEffect(() => {
    const item = listRef.current?.querySelector<HTMLElement>(`[data-cmd-idx="${activeIndex}"]`);
    if (item) item.scrollIntoView({ block: 'nearest' });
  }, [activeIndex]);

  if (matches.length === 0) return null;

  return (
    // roving-exempt: this is the LISTBOX half of a split WCAG editable-combobox.
    // The combobox owner (the AiChat composer: role="combobox" + aria-expanded +
    // aria-controls={COMMAND_LISTBOX_ID} + aria-activedescendant=commandOptionId)
    // lives in a SEPARATE file, so focus stays on the composer input and arrows
    // move the activedescendant pointer cross-file — the gate can't resolve that
    // ownership locally. Keyboard nav is real; it just isn't provable in one file.
    <div
      id={COMMAND_LISTBOX_ID}
      role="listbox"
      aria-label="Slash commands"
      className="absolute bottom-full left-3 right-3 mb-2 max-h-72 overflow-y-auto rounded-xl border border-brand-line bg-bg-elevated/95 shadow-2xl backdrop-blur"
    >
      <ul ref={listRef} className="py-1">
        {matches.map((cmd, idx) => {
          const active = idx === activeIndex;
          return (
            <li key={cmd.name} data-cmd-idx={idx}>
              <button
                type="button"
                id={commandOptionId(idx)}
                role="option"
                aria-selected={active}
                onMouseEnter={() => onActiveIndexChange(idx)}
                onClick={() => onSelect(cmd)}
                className={`flex w-full items-center gap-3 px-3 py-2 text-left transition-colors ${
                  active
                    ? 'bg-brand-accent/15 text-brand-ink'
                    : 'text-brand-ink/85 hover:bg-brand-line/30'
                }`}
              >
                <span className="font-mono text-xs text-brand-accent">/{cmd.name}</span>
                <span className="flex-1 truncate text-xs text-brand-mute">{cmd.description}</span>
                <span className="rounded-full bg-brand-line/40 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-brand-mute">
                  {cmd.category}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

export function commandMatches(query: string): AiChatCommandSpec[] {
  return matchChatCommands(query, 8);
}
