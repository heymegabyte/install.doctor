import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { GenericTable } from './GenericTable.js';
export default function ChannelAttribution({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('channel-attribution');
  return (
    <GenericTable
      title="Channel attribution (90d)"
      endpoint="/channel-attribution"
      adminKey={adminKey}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
