import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { useEffect, useState, type JSX, type ReactNode } from 'react';
import { Logo } from '../Logo.js';
import { Header } from '../Header.js';
import type { UserAvatarMenuGroup } from './UserAvatarMenu.js';

/**
 * DashboardShell — shared full-width chrome for every authenticated surface:
 *   - /me (customer dashboard)
 *   - /work/dashboard (crew dashboard)
 *   - /admin/* (operations dashboard)
 *
 * Layout:
 *   ┌────────────────────────────────────────────────────────┐
 *   │ TOP NAVBAR — Logo LEFT · breadcrumb · UserAvatar RIGHT │
 *   ├──────┬─────────────────────────────────────────────────┤
 *   │ SIDE │                                                 │
 *   │ MENU │           full-width main canvas                │
 *   │      │                                                 │
 *   └──────┴─────────────────────────────────────────────────┘
 *
 * Public Header + Footer are suppressed on every route that mounts this
 * shell (handled at the App.tsx level — see `hidePublicChrome`).
 */

export interface DashboardBreadcrumb {
  readonly label: string;
  readonly href?: string;
}

export interface DashboardNavItem {
  readonly key: string;
  readonly label: string;
  readonly href: string;
  readonly icon: string;
  readonly badge?: number;
  readonly danger?: boolean;
}

export interface DashboardNavGroup {
  readonly label?: string;
  readonly items: ReadonlyArray<DashboardNavItem>;
}

export interface DashboardShellProps {
  /** Which side-menu item is currently active (matches `nav[*].items[*].key`). */
  readonly active: string;
  /** Page title shown in the top-bar (large, bold). */
  readonly title: string;
  readonly breadcrumb?: ReadonlyArray<DashboardBreadcrumb>;
  /** Side-menu groups, rendered top→bottom in the left rail. */
  readonly nav: ReadonlyArray<DashboardNavGroup>;
  /** User-avatar dropdown payload — shown top-right. */
  readonly userDisplayName: string;
  readonly userSubtitle?: string;
  readonly userAvatarUrl?: string | null;
  readonly userMenu: ReadonlyArray<UserAvatarMenuGroup>;
  /** Optional inline header actions left of the avatar (e.g. "+ New" button). */
  readonly headerActions?: ReactNode;
  /** Optional brand badge under the logo (e.g. "ADMIN", "CREW", "ACCOUNT"). */
  readonly brandBadge?: string;
  /**
   * Collapse the desktop sidebar to icon-only (60px) — gives the main canvas
   * full-bleed feel for calendar / kanban / map surfaces. Persisted by the
   * caller (e.g. /me persists in localStorage `bcl_me_shell_compact_v1`).
   * Default false → 240px sidebar.
   */
  readonly compact?: boolean;
  /** Toggle handler — pairs with `compact`. When omitted the toggle button is hidden. */
  readonly onToggleCompact?: (next: boolean) => void;
  /**
   * Render the main canvas as full-bleed (no padding, no PageTitle strip).
   * Use for calendar / canvas surfaces that own their own internal chrome.
   * Default false → preserves the existing px-4 py-6 + PageTitle behavior.
   */
  readonly fullBleed?: boolean;
  readonly children: ReactNode;
}

export function DashboardShell({
  active,
  title,
  breadcrumb,
  nav,
  userDisplayName,
  userSubtitle,
  userAvatarUrl,
  userMenu,
  headerActions,
  brandBadge,
  compact = false,
  onToggleCompact,
  fullBleed = false,
  children,
}: DashboardShellProps): JSX.Element {
  useThemeToolsSurface('dashboard-shell');
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    if (typeof document === 'undefined') return;
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileOpen]);

  void userMenu;

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* ── Universal Top Navbar (Shared Across Marketing, Blog, Guides & Admin/Customer/Crew Dashboards) ── */}
      <Header
        ctaHref="/book"
        brandBadge={brandBadge ?? 'DASHBOARD'}
        overrideUser={{
          displayName: userDisplayName,
          subtitle: userSubtitle,
          avatarUrl: userAvatarUrl,
          role:
            brandBadge === 'ADMIN'
              ? 'super_admin'
              : brandBadge === 'CREW'
                ? 'worker'
                : 'customer',
        }}
        onMobileSidebarToggle={() => setMobileOpen(true)}
        headerActions={
          <>
            {headerActions}
            {onToggleCompact && (
              <button
                type="button"
                onClick={() => onToggleCompact(!compact)}
                aria-pressed={compact}
                aria-label={compact ? 'Expand sidebar' : 'Collapse sidebar to icons'}
                title={compact ? 'Expand sidebar' : 'Collapse sidebar to icons'}
                className="hidden lg:inline-flex rounded-md border border-black/85 bg-[#0c1017] px-2 py-1.5 text-xs text-brand-mute hover:text-brand-ink hover:border-brand-accent min-h-[36px] min-w-[36px] items-center justify-center shadow-sm"
              >
                {compact ? '⇥' : '⇤'}
              </button>
            )}
          </>
        }
      />

      <div className="flex">
        {/* ── Sidebar (desktop) ─────────────────────────────────────── */}
        <aside
          className={`hidden lg:flex flex-col shrink-0 border-r border-black/85 bg-[#0a0d13]/95 shadow-[4px_0_28px_rgba(0,0,0,0.85)] min-h-[calc(100vh-72px)] sticky top-[72px] transition-[width] duration-200 ${
            compact ? 'w-[60px]' : 'w-60'
          }`}
        >
          <SidebarNav nav={nav} active={active} compact={compact} />
        </aside>

        {/* ── Sidebar (mobile drawer) ───────────────────────────────── */}
        {mobileOpen && (
          <div className="lg:hidden fixed inset-0 z-50">
            <div
              className="absolute inset-0 bg-black/75 backdrop-blur-sm"
              onClick={() => setMobileOpen(false)}
              aria-hidden
            />
            <aside className="absolute left-0 top-0 bottom-0 w-72 bg-[#0a0d13] border-r border-black/85 shadow-[8px_0_36px_rgba(0,0,0,0.92)] flex flex-col">
              <div className="flex items-center justify-between p-4 border-b border-black/85">
                <a href="/" className="flex items-center gap-2" aria-label="Home">
                  <Logo className="h-7 w-auto" />
                </a>
                <button
                  type="button"
                  onClick={() => setMobileOpen(false)}
                  className="text-brand-mute hover:text-brand-ink min-h-[40px] min-w-[40px]"
                  aria-label="Close menu"
                >
                  ✕
                </button>
              </div>
              <SidebarNav nav={nav} active={active} onNavigate={() => setMobileOpen(false)} />
            </aside>
          </div>
        )}

        {/* ── Main canvas — full-width, page-title strip + content ──── */}
        <div className="flex-1 min-w-0">
          {fullBleed ? (
            <main className="min-h-[calc(100vh-72px)] flex flex-col">{children}</main>
          ) : (
            <>
              <PageTitle title={title} breadcrumb={breadcrumb} />
              <main className="px-4 py-6 lg:px-8 lg:py-8">{children}</main>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function SidebarNav({
  nav,
  active,
  onNavigate,
  compact = false,
}: {
  nav: ReadonlyArray<DashboardNavGroup>;
  active: string;
  onNavigate?: () => void;
  compact?: boolean;
}): JSX.Element {
  return (
    <nav
      className={`flex-1 overflow-y-auto py-5 space-y-5 ${compact ? 'px-1.5' : 'px-3'}`}
      aria-label="Dashboard sections"
    >
      {nav.map((group, gi) => (
        <div key={gi}>
          {group.label && !compact && (
            <p className="px-3 mb-1.5 font-mono text-[10px] uppercase tracking-wider text-brand-mute">
              {group.label}
            </p>
          )}
          <ul className="space-y-0.5">
            {group.items.map((item) => {
              const isActive = item.key === active;
              return (
                <li key={item.key}>
                  <a
                    href={item.href}
                    onClick={onNavigate}
                    aria-current={isActive ? 'page' : undefined}
                    aria-label={compact ? item.label : undefined}
                    title={compact ? item.label : undefined}
                    className={`flex items-center rounded-md text-sm transition-colors ${
                      compact ? 'justify-center px-2 py-2 min-h-[40px]' : 'gap-3 px-3 py-2'
                    } ${
                      isActive
                        ? compact
                          ? 'bg-brand-accent/15 text-brand-accent border border-brand-accent/30'
                          : 'bg-brand-accent/10 text-brand-accent border-l-2 border-brand-accent pl-[10px] font-semibold'
                        : item.danger
                          ? 'text-red-300 hover:bg-red-500/10'
                          : 'text-brand-ink hover:bg-bg-elevated hover:text-brand-accent'
                    }`}
                  >
                    <span
                      className={`w-5 text-center font-mono text-base ${
                        isActive ? 'text-brand-accent' : 'text-brand-mute'
                      }`}
                      aria-hidden
                    >
                      {item.icon}
                    </span>
                    {!compact && <span className="flex-1 truncate">{item.label}</span>}
                    {!compact && typeof item.badge === 'number' && item.badge > 0 && (
                      <span
                        className={`px-1.5 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                          item.danger
                            ? 'bg-red-500/20 text-red-300'
                            : 'bg-brand-accent/15 text-brand-accent'
                        }`}
                      >
                        {item.badge > 99 ? '99+' : item.badge}
                      </span>
                    )}
                  </a>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </nav>
  );
}

function PageTitle({
  title,
  breadcrumb,
}: {
  title: string;
  breadcrumb?: ReadonlyArray<DashboardBreadcrumb>;
}): JSX.Element {
  return (
    <div className="border-b border-black/85 bg-[#0a0d13]/85 px-4 py-3.5 lg:px-8 lg:py-4 shadow-[0_8px_24px_rgba(0,0,0,0.65)]">
      {breadcrumb && breadcrumb.length > 0 && (
        <nav
          className="text-[11px] font-mono uppercase tracking-wider text-brand-mute mb-1.5 truncate"
          aria-label="Breadcrumb"
        >
          {breadcrumb.map((b, i) => (
            <span key={i}>
              {i > 0 && <span className="mx-1.5 text-brand-mute">/</span>}
              {b.href ? (
                <a href={b.href} className="hover:text-brand-accent">
                  {b.label}
                </a>
              ) : (
                <span className="text-brand-ink">{b.label}</span>
              )}
            </span>
          ))}
        </nav>
      )}
      <h1 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight leading-none truncate">
        {title}
      </h1>
    </div>
  );
}
