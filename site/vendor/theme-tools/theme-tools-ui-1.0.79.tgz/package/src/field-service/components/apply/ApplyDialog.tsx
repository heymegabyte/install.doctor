import { Suspense, lazy, useRef, type JSX, type KeyboardEvent } from 'react';
import { useBodyScrollLock, useFocusManagement, useTabTrap } from '../../use-dialog-a11y.js';
import {
  MODAL_BACKDROP_CLASS,
  MODAL_PANEL_CLASS,
  useModalMotion,
} from '../../use-modal-motion.js';

const ApplyFlow = lazy(() => import('./ApplyFlow.js').then((module) => ({ default: module.ApplyFlow })));

export interface ApplyDialogProps {
  readonly open: boolean;
  readonly onClose: () => void;
}

export function ApplyDialog({ open, onClose }: ApplyDialogProps): JSX.Element | null {
  const panelRef = useRef<HTMLDivElement | null>(null);
  const restoreRef = useRef<HTMLElement | null>(null);
  const { closing, requestClose } = useModalMotion(onClose);

  useFocusManagement(open, panelRef, restoreRef);
  useBodyScrollLock(open, 99_999);
  const onTabTrap = useTabTrap(panelRef);

  if (!open) return null;

  const onKeyDown = (event: KeyboardEvent<HTMLElement>) => {
    if (event.key === 'Escape') {
      event.preventDefault();
      requestClose();
      return;
    }
    onTabTrap(event);
  };

  return (
    <div
      className={`${MODAL_BACKDROP_CLASS} fixed inset-0 z-[60] flex items-start justify-center overflow-y-auto bg-black/70 p-4 backdrop-blur-sm sm:p-6`}
      data-apply-scroll
      data-closing={closing || undefined}
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) requestClose();
      }}
    >
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-label="Apply to work at Brick Labor"
        data-testid="apply-dialog"
        data-closing={closing || undefined}
        onKeyDown={onKeyDown}
        className={`${MODAL_PANEL_CLASS} relative my-6 w-full max-w-2xl rounded-2xl border border-brand-line bg-bg-elevated shadow-2xl`}
      >
        <button
          type="button"
          onClick={requestClose}
          aria-label="Close application"
          data-testid="apply-dialog-close"
          className="absolute right-3 top-3 z-10 inline-flex h-9 w-9 items-center justify-center rounded-full border border-brand-line bg-bg-primary text-brand-mute transition-all duration-[333ms] hover:-translate-y-0.5 hover:border-brand-accent hover:text-brand-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accent"
        >
          <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" fill="none">
            <path
              d="M3 3l10 10M13 3L3 13"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
            />
          </svg>
        </button>
        <div className="px-1 py-2 sm:px-2">
          <Suspense
            fallback={
              <p className="p-8 text-center text-sm text-brand-mute" role="status">
                Loading the application…
              </p>
            }
          >
            <ApplyFlow embedded />
          </Suspense>
        </div>
      </div>
    </div>
  );
}
