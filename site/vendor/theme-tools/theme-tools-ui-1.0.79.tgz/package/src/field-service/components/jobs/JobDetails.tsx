import { useThemeToolsSurface } from '../../../field-service-primitives.js';
// Shared details panel for the live Job view — renders on BOTH the customer
// /track/:id surface and the crew active-job surface. Customer sees the crew
// roster + price breakdown; crew sees the customer + address + a Navigate CTA.

export interface PriceLine {
  readonly label: string;
  readonly cents: number;
}

export interface JobCrewMember {
  readonly workerId: string;
  readonly firstName: string;
  readonly lastInitial: string;
  readonly avatarUrl: string | null;
  readonly ratingAvg: number | null;
  readonly ratingCount: number | null;
  readonly isLead: boolean;
  readonly claimStatus: string;
}

interface Props {
  readonly variant: 'customer' | 'crew';
  readonly schedule: { date: string; time: string; hours: number; crewCount?: number };
  readonly services: readonly string[];
  readonly breakdown?: readonly PriceLine[];
  readonly crew?: readonly JobCrewMember[];
  /** Crew variant: the customer-facing details. */
  readonly customerName?: string;
  readonly address?: string | null;
  readonly destination?: { lat: number; lng: number } | null;
  /** CTA handlers/links. */
  readonly onChat?: () => void;
  readonly callHref?: string;
}

function money(cents: number): string {
  const neg = cents < 0;
  const v = Math.abs(cents) / 100;
  return `${neg ? '−' : ''}$${v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function claimLabel(s: string): string {
  switch (s) {
    case 'accepted':
      return 'Accepted';
    case 'confirmed':
      return 'Confirmed';
    case 'checked_in':
      return 'On site';
    case 'completed':
      return 'Done';
    default:
      return s;
  }
}

function navHref(address: string | null | undefined, dest: { lat: number; lng: number } | null | undefined): string {
  if (dest) return `https://www.google.com/maps/dir/?api=1&destination=${dest.lat},${dest.lng}`;
  if (address) return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(address)}`;
  return 'https://www.google.com/maps';
}

export function JobDetails({
  variant,
  schedule,
  services,
  breakdown,
  crew,
  customerName,
  address,
  destination,
  onChat,
  callHref,
}: Props) {
  useThemeToolsSurface('job-details');
  return (
    <section
      className="flex flex-col gap-4 rounded-xl border border-white/10 bg-bg-elevated/60 p-4 sm:p-5"
      aria-label="Job details"
      data-testid="job-details"
    >
      {/* Schedule strip */}
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-sm text-brand-mute">
        <span className="text-brand-ink">{schedule.date}</span>
        <span aria-hidden="true">·</span>
        <span>{schedule.time}</span>
        <span aria-hidden="true">·</span>
        <span>{schedule.hours} hr</span>
        {schedule.crewCount ? (
          <>
            <span aria-hidden="true">·</span>
            <span>
              {schedule.crewCount} crew
            </span>
          </>
        ) : null}
      </div>

      {/* Services */}
      {services.length > 0 && (
        <div className="flex flex-wrap gap-2" aria-label="Services">
          {services.map((s) => (
            <span
              key={s}
              className="rounded-full border border-white/10 bg-bg-base/60 px-2.5 py-1 text-xs text-brand-ink"
            >
              {s}
            </span>
          ))}
        </div>
      )}

      {/* Crew variant: customer + address + Navigate */}
      {variant === 'crew' && (
        <div className="flex flex-col gap-3 border-t border-white/10 pt-4">
          {customerName && (
            <div>
              <div className="text-xs uppercase tracking-wide text-brand-mute">Customer</div>
              <div className="text-brand-ink">{customerName}</div>
            </div>
          )}
          {address && (
            <div>
              <div className="text-xs uppercase tracking-wide text-brand-mute">Address</div>
              <div className="text-brand-ink">{address}</div>
            </div>
          )}
          <div className="flex flex-wrap gap-2">
            <a
              href={navHref(address, destination)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-brand-accent px-4 font-semibold text-bg-primary"
              data-testid="job-navigate"
            >
              Navigate →
            </a>
            {onChat && (
              <button
                type="button"
                onClick={onChat}
                className="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-white/15 px-4 font-semibold text-brand-ink"
              >
                Message customer
              </button>
            )}
            {callHref && (
              <a
                href={callHref}
                className="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-white/15 px-4 font-semibold text-brand-ink"
              >
                Call
              </a>
            )}
          </div>
        </div>
      )}

      {/* Customer variant: crew roster */}
      {variant === 'customer' && crew && crew.length > 0 && (
        <ul className="flex flex-col gap-3 border-t border-white/10 pt-4" aria-label="Crew">
          {crew.map((c) => (
            <li key={c.workerId} className="flex items-center gap-3">
              <div className="h-10 w-10 shrink-0 overflow-hidden rounded-full bg-bg-base/70" aria-hidden="true">
                {c.avatarUrl ? (
                  <img src={c.avatarUrl} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover" />
                ) : (
                  <span className="flex h-full w-full items-center justify-center font-mono text-sm text-brand-mute">
                    {c.firstName.charAt(0)}
                    {c.lastInitial}
                  </span>
                )}
              </div>
              <div className="flex min-w-0 flex-col">
                <span className="text-brand-ink">
                  <strong>
                    {c.firstName} {c.lastInitial}.
                  </strong>
                  {c.isLead ? (
                    <span className="ml-2 rounded bg-brand-accent/15 px-1.5 py-0.5 text-xs text-brand-accent">Lead</span>
                  ) : null}
                </span>
                <span className="flex items-center gap-2 text-xs text-brand-mute">
                  {c.ratingAvg != null ? (
                    <span aria-label={`${c.ratingAvg.toFixed(1)} stars`}>
                      ★ {c.ratingAvg.toFixed(1)}
                      {c.ratingCount ? ` (${c.ratingCount})` : ''}
                    </span>
                  ) : null}
                  <span>{claimLabel(c.claimStatus)}</span>
                </span>
              </div>
            </li>
          ))}
        </ul>
      )}

      {/* Price breakdown */}
      {breakdown && breakdown.length > 0 && (
        <div className="border-t border-white/10 pt-4" aria-label="Price breakdown" data-testid="job-breakdown">
          <div className="mb-2 text-xs uppercase tracking-wide text-brand-mute">
            {variant === 'crew' ? 'Job value' : 'Price'}
          </div>
          <dl className="flex flex-col gap-1.5 font-mono text-sm">
            {breakdown.map((line, i) => {
              const isTotal = i === breakdown.length - 1;
              return (
                <div
                  key={`${line.label}-${i}`}
                  className={`flex items-baseline justify-between ${
                    isTotal ? 'mt-1 border-t border-white/10 pt-2 text-brand-ink' : 'text-brand-mute'
                  }`}
                >
                  <dt className={isTotal ? 'font-semibold' : ''}>{line.label}</dt>
                  <dd className={isTotal ? 'font-semibold tabular-nums' : 'tabular-nums'}>{money(line.cents)}</dd>
                </div>
              );
            })}
          </dl>
        </div>
      )}

      {/* Customer variant: chat / call CTAs */}
      {variant === 'customer' && (onChat || callHref) && (
        <div className="flex flex-wrap gap-2 border-t border-white/10 pt-4">
          {onChat && (
            <button
              type="button"
              onClick={onChat}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-white/15 px-4 font-semibold text-brand-ink"
            >
              Message crew
            </button>
          )}
          {callHref && (
            <a
              href={callHref}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-white/15 px-4 font-semibold text-brand-ink"
            >
              Call dispatch
            </a>
          )}
        </div>
      )}
    </section>
  );
}
