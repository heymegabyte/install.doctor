import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { Booking, CalendarView, StatusFilter } from '@theme.tools/scheduling/field-service/customer-types';
import { colorForService, SERVICE_COLORS, statusKey } from '@theme.tools/scheduling/field-service/customer-types';
import {
  HOUR_ROW_PX,
  SNAP_MINUTES,
  SNAP_ROW_PX,
  VISIBLE_HOURS,
  addDays,
  addMonths,
  bookingEnd,
  bookingStart,
  clamp,
  detectTimezone,
  endOfMonth,
  formatTime12,
  isSameDay,
  isToday,
  longDate,
  minutesFromGridTop,
  minutesFromPx,
  monthGrid,
  parseTime,
  pad2,
  pxFromMinutes,
  rangeLabel,
  snapTo,
  startOfMonth,
  startOfWeek,
  toIsoDate,
} from '@theme.tools/scheduling/field-service/customer-date-utils';
import { MiniCalendar } from './calendar/MiniCalendar.js';
import { KeyboardShortcutsModal } from './calendar/KeyboardShortcutsModal.js';
import { EventHoverPreview } from './calendar/EventHoverPreview.js';
import { AiScheduleOptimizer } from './calendar/AiScheduleOptimizer.js';
import { InstallBanner, OfflineIndicator } from './calendar/InstallBanner.js';
import { SmsActions } from './calendar/SmsActions.js';
import {
  QuickSchedulePopover,
  type QuickScheduleDraft,
  type QuickScheduleMode,
} from './QuickSchedulePopover.js';
import { useDragCreate, type DragRect } from '../../use-drag-create.js';
import { extractErrorMessage } from '../../api-error.js';
import { startSafeViewTransition } from '../../../field-service-primitives.js';

interface CalendarWorkspaceProps {
  bookings: Booking[];
  contact: string;
  channel: 'sms' | 'email';
  /** Re-fetch /api/auth/client/me — called after save/delete. */
  onRefresh: () => Promise<void> | void;
  /** Forwarded so the toolbar slot can render alongside the view switcher. */
  toolbar?: React.ReactNode;
}

type StatusToggles = Record<StatusFilter, boolean>;

const DEFAULT_TOGGLES: StatusToggles = {
  upcoming: true,
  in_progress: true,
  completed: true,
  cancelled: false,
};

const VIEW_LABELS: Record<CalendarView, string> = {
  month: 'Month',
  week: 'Week',
  day: 'Day',
  agenda: 'Agenda',
};

const WEEKDAY_HEADERS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] as const;

interface PopoverState {
  mode: QuickScheduleMode;
  draft: QuickScheduleDraft;
  booking?: Booking;
  anchor?: { x: number; y: number };
  error: string | null;
  saving: boolean;
}

/**
 * Full-bleed calendar workspace mounted inside DashboardShell on /me. Owns:
 *  - view + anchor date state
 *  - search query + status filter toggles
 *  - QuickSchedulePopover lifecycle (create + edit + cancel)
 *  - drag-to-create on Week/Day grids
 *  - keyboard shortcuts (d/w/m/a, t, j/k, n, /, ?, Esc)
 *  - View Transitions API for the view swap (no-op if unsupported)
 */
export function CalendarWorkspace({
  bookings,
  contact: _contact,
  channel: _channel,
  onRefresh,
  toolbar,
}: CalendarWorkspaceProps) {
  useThemeToolsSurface('calendar-workspace');
  const [view, setView] = useState<CalendarView>('week');
  const [anchor, setAnchor] = useState<Date>(() => new Date());
  const [selected, setSelected] = useState<Date>(() => new Date());
  const [query, setQuery] = useState('');
  const [toggles, setToggles] = useState<StatusToggles>(DEFAULT_TOGGLES);
  const [popover, setPopover] = useState<PopoverState | null>(null);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const [hoverPreview, setHoverPreview] = useState<{ b: Booking; x: number; y: number } | null>(
    null,
  );
  const searchRef = useRef<HTMLInputElement | null>(null);
  const [now, setNow] = useState<Date>(() => new Date());

  // Tick "today" indicator every 30s.
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30_000);
    return () => clearInterval(t);
  }, []);

  // View-transition wrapped setter — animates the view swap on supported browsers.
  const switchView = useCallback(
    (next: CalendarView) => {
      if (next === view) return;
      if (
        'startViewTransition' in document &&
        !window.matchMedia('(prefers-reduced-motion: reduce)').matches
      ) {
        if (!startSafeViewTransition(document, () => setView(next))) setView(next);
      } else {
        setView(next);
      }
    },
    [view],
  );

  const shift = useCallback(
    (delta: number) => {
      setAnchor((prev) => {
        if (view === 'month') return addMonths(prev, delta);
        if (view === 'week') return addDays(prev, delta * 7);
        return addDays(prev, delta);
      });
    },
    [view],
  );

  const jumpToday = useCallback(() => {
    const t = new Date();
    setAnchor(t);
    setSelected(t);
  }, []);

  const openCreate = useCallback(
    (draft: Partial<QuickScheduleDraft>, anchorPos?: { x: number; y: number }) => {
      const today = new Date();
      const startDate = draft.date ?? toIsoDate(selected);
      const startTime = draft.startTime ?? '09:00';
      setPopover({
        mode: 'create',
        anchor: anchorPos,
        booking: undefined,
        error: null,
        saving: false,
        draft: {
          date: startDate >= toIsoDate(today) ? startDate : toIsoDate(today),
          startTime,
          hours: draft.hours ?? 2,
          crew: draft.crew ?? 2,
          service: draft.service ?? 'lawn',
        },
      });
    },
    [selected],
  );

  const openEdit = useCallback((b: Booking, anchorPos: { x: number; y: number }) => {
    const t = parseTime(b.preferred_time) ?? { hour: 9, minute: 0 };
    const primary = (b.service || 'other').split(',')[0]?.trim();
    setPopover({
      mode: 'edit',
      anchor: anchorPos,
      booking: b,
      error: null,
      saving: false,
      draft: {
        date: b.preferred_date,
        startTime: `${pad2(t.hour)}:${pad2(t.minute)}`,
        hours: b.hours,
        crew: b.crew_size,
        service:
          (SERVICE_COLORS[primary ?? ''] ? (primary as QuickScheduleDraft['service']) : 'other') ||
          'other',
      },
    });
  }, []);

  // Filter pipeline shared by every view.
  const visibleBookings = useMemo(() => {
    const q = query.trim().toLowerCase();
    return bookings.filter((b) => {
      if (!toggles[statusKey(b.status)]) return false;
      if (q) {
        const hay = [b.service, b.customer_address, b.customer_name, b.id, b.status, b.notes]
          .filter(Boolean)
          .join(' ')
          .toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [bookings, query, toggles]);

  // Keyboard shortcuts.
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const tag = (e.target as HTMLElement | null)?.tagName?.toLowerCase();
      const inField =
        tag === 'input' ||
        tag === 'textarea' ||
        tag === 'select' ||
        (e.target as HTMLElement)?.isContentEditable;
      if (e.key === 'Escape') {
        if (popover) setPopover(null);
        else if (shortcutsOpen) setShortcutsOpen(false);
        return;
      }
      if (inField) return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (e.key === '?') {
        e.preventDefault();
        setShortcutsOpen(true);
      } else if (e.key === '/') {
        e.preventDefault();
        searchRef.current?.focus();
      } else if (e.key === 'd') switchView('day');
      else if (e.key === 'w') switchView('week');
      else if (e.key === 'm') switchView('month');
      else if (e.key === 'a') switchView('agenda');
      else if (e.key === 't') jumpToday();
      else if (e.key === 'j') shift(-1);
      else if (e.key === 'k') shift(1);
      else if (e.key === 'n') openCreate({});
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [popover, shortcutsOpen, switchView, jumpToday, shift, openCreate]);

  async function savePopover(draft: QuickScheduleDraft) {
    if (!popover) return;
    setPopover((p) => (p ? { ...p, saving: true, error: null } : p));
    try {
      if (popover.mode === 'edit' && popover.booking) {
        const res = await fetch(`/api/booking/${popover.booking.id}`, {
          method: 'PATCH',
          credentials: 'same-origin',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            preferredDate: draft.date,
            preferredTime: draft.startTime,
            hours: draft.hours,
            crew: draft.crew,
            service: draft.service,
          }),
        });
        const json = (await res.json().catch(() => ({}))) as {
          ok?: boolean;
          error?: unknown;
          message?: unknown;
          details?: unknown;
        };
        if (!res.ok || json.ok === false) {
          const friendly = extractErrorMessage(json) || `Save failed (${res.status})`;
          setPopover((p) => (p ? { ...p, saving: false, error: friendly } : p));
          return;
        }
        await onRefresh();
        setPopover(null);
      } else {
        // Create flow: kick the user into the full booking form with the slot
        // pre-filled. The /api/booking POST requires Turnstile + a full address;
        // we do NOT pretend to satisfy that from a 5-field popover.
        const params = new URLSearchParams({
          service: draft.service,
          date: draft.date,
          time: draft.startTime,
          hours: String(draft.hours),
          crew: String(draft.crew),
        });
        window.location.href = `/book?${params.toString()}`;
      }
    } catch {
      setPopover((p) => (p ? { ...p, saving: false, error: 'Network error' } : p));
    }
  }

  async function deletePopover() {
    if (!popover?.booking) return;
    setPopover((p) => (p ? { ...p, saving: true, error: null } : p));
    try {
      const res = await fetch(`/api/booking/${popover.booking.id}`, {
        method: 'DELETE',
        credentials: 'same-origin',
      });
      const json = (await res.json().catch(() => ({}))) as {
        ok?: boolean;
        error?: unknown;
        message?: unknown;
        details?: unknown;
      };
      if (!res.ok || json.ok === false) {
        const friendly = extractErrorMessage(json) || `Cancel failed (${res.status})`;
        setPopover((p) => (p ? { ...p, saving: false, error: friendly } : p));
        return;
      }
      await onRefresh();
      setPopover(null);
    } catch {
      setPopover((p) => (p ? { ...p, saving: false, error: 'Network error' } : p));
    }
  }

  const tz = useMemo(() => detectTimezone(), []);

  return (
    <div className="flex flex-1 min-h-0 flex-col lg:flex-row">
      {/* Left rail */}
      <aside
        aria-label="Calendar sidebar"
        className="hidden lg:flex flex-col w-[260px] shrink-0 border-r border-brand-line bg-bg-elevated/60 p-4 gap-4 overflow-y-auto"
      >
        <button
          type="button"
          onClick={() => openCreate({})}
          className="rounded-xl bg-brand-accent px-4 py-3 text-sm font-extrabold text-bg-primary hover:bg-brand-accentHover shadow-glow min-h-[44px] flex items-center justify-center gap-2"
        >
          <span aria-hidden>＋</span> New booking
        </button>
        <MiniCalendar
          anchor={anchor}
          selected={selected}
          bookings={bookings}
          onPick={(d) => {
            setSelected(d);
            setAnchor(d);
            if (view === 'month') switchView('day');
          }}
          onMonthShift={(delta) => setAnchor((a) => addMonths(a, delta))}
        />
        <section aria-label="Other calendars" className="space-y-2">
          <p className="text-[10px] uppercase tracking-wider text-brand-mute font-bold">Show</p>
          <ul className="space-y-1.5">
            {(Object.keys(DEFAULT_TOGGLES) as StatusFilter[]).map((s) => (
              <li key={s}>
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input
                    type="checkbox"
                    checked={toggles[s]}
                    onChange={(e) => setToggles((prev) => ({ ...prev, [s]: e.target.checked }))}
                    className="accent-brand-accent"
                  />
                  <span className="text-brand-ink capitalize">{s.replace('_', ' ')}</span>
                  <span className="ml-auto text-xs text-brand-mute">
                    {bookings.filter((b) => statusKey(b.status) === s).length}
                  </span>
                </label>
              </li>
            ))}
          </ul>
        </section>
        <section aria-label="Service colors" className="space-y-2">
          <p className="text-[10px] uppercase tracking-wider text-brand-mute font-bold">Services</p>
          <ul className="grid grid-cols-2 gap-1.5">
            {Object.entries(SERVICE_COLORS).map(([id, c]) => (
              <li key={id} className="flex items-center gap-2 text-xs text-brand-ink">
                <span
                  aria-hidden
                  className="h-2.5 w-2.5 rounded-full"
                  style={{ background: c.dot }}
                />
                <span className="truncate">{c.label}</span>
              </li>
            ))}
          </ul>
        </section>
      </aside>

      {/* Main canvas */}
      <section className="flex-1 min-w-0 min-h-0 flex flex-col">
        {/* Toolbar */}
        <div className="flex items-center gap-2 border-b border-brand-line bg-bg-elevated/50 px-3 py-2 flex-wrap">
          <button
            type="button"
            onClick={jumpToday}
            className="rounded-md border border-brand-line bg-bg-elevated px-3 py-1.5 text-xs font-bold text-brand-ink hover:border-brand-accent min-h-[36px]"
          >
            Today
          </button>
          <button
            type="button"
            onClick={() => shift(-1)}
            aria-label="Previous period"
            className="rounded-md border border-brand-line bg-bg-elevated px-2 py-1.5 text-brand-mute hover:text-brand-ink hover:border-brand-accent min-h-[36px] min-w-[36px]"
          >
            ‹
          </button>
          <button
            type="button"
            onClick={() => shift(1)}
            aria-label="Next period"
            className="rounded-md border border-brand-line bg-bg-elevated px-2 py-1.5 text-brand-mute hover:text-brand-ink hover:border-brand-accent min-h-[36px] min-w-[36px]"
          >
            ›
          </button>
          <h2 className="text-sm sm:text-base font-extrabold text-brand-ink ml-1">
            {rangeLabel(view, anchor)}
          </h2>
          <span
            className="hidden md:inline text-[10px] uppercase tracking-wider text-brand-mute"
            title={`Time zone: ${tz}`}
          >
            {tz}
          </span>

          <div className="ml-auto flex items-center gap-2 flex-wrap">
            <label className="relative">
              <input
                ref={searchRef}
                type="search"
                placeholder="Search bookings ( / )"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                aria-label="Search bookings"
                className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 pl-7 text-xs text-brand-ink placeholder:text-brand-mute focus:border-brand-accent focus:outline-none min-h-[36px] w-[160px] sm:w-[220px]"
              />
              <span
                aria-hidden
                className="absolute left-2 top-1/2 -translate-y-1/2 text-brand-mute text-xs"
              >
                ⌕
              </span>
            </label>
            <AiScheduleOptimizer
              bookings={bookings}
              onAccept={(s) => {
                const d = new Date();
                const diff = (s.weekday - d.getDay() + 7) % 7 || 7;
                const target = addDays(d, diff);
                openCreate({
                  date: toIsoDate(target),
                  startTime: `${pad2(s.hour)}:00`,
                  service: (SERVICE_COLORS[s.service]
                    ? s.service
                    : 'other') as QuickScheduleDraft['service'],
                });
              }}
            />
            <div
              role="group"
              aria-label="Calendar view"
              className="inline-flex rounded-md border border-brand-line bg-bg-elevated overflow-hidden"
            >
              {(Object.keys(VIEW_LABELS) as CalendarView[]).map((v) => (
                <button
                  key={v}
                  type="button"
                  onClick={() => switchView(v)}
                  aria-pressed={view === v}
                  className={[
                    'px-3 py-1.5 text-xs font-bold min-h-[36px]',
                    view === v
                      ? 'bg-brand-accent text-bg-primary'
                      : 'text-brand-mute hover:text-brand-ink hover:bg-brand-line',
                  ].join(' ')}
                >
                  {VIEW_LABELS[v]}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => setShortcutsOpen(true)}
              aria-label="Keyboard shortcuts"
              className="rounded-md border border-brand-line bg-bg-elevated px-2 py-1.5 text-xs text-brand-mute hover:text-brand-ink hover:border-brand-accent min-h-[36px]"
            >
              ?
            </button>
            {toolbar}
          </div>
        </div>

        {/* Top banner row */}
        <div className="px-3 pt-3">
          <InstallBanner />
        </div>

        {/* View body */}
        <div
          className="flex-1 min-h-0 overflow-auto px-3 py-3"
          style={{ viewTransitionName: 'calendar-canvas' as unknown as string }}
        >
          {view === 'month' && (
            <MonthView
              anchor={anchor}
              bookings={visibleBookings}
              onPickDay={(d) => {
                setSelected(d);
                setAnchor(d);
                switchView('day');
              }}
              onEvent={(b, pos) => openEdit(b, pos)}
            />
          )}
          {view === 'week' && (
            <TimeGridView
              days={Array.from({ length: 7 }, (_, i) => addDays(startOfWeek(anchor), i))}
              bookings={visibleBookings}
              now={now}
              onCreate={(draft, pos) => openCreate(draft, pos)}
              onEvent={(b, pos) => openEdit(b, pos)}
              onHover={setHoverPreview}
            />
          )}
          {view === 'day' && (
            <TimeGridView
              days={[anchor]}
              bookings={visibleBookings}
              now={now}
              onCreate={(draft, pos) => openCreate(draft, pos)}
              onEvent={(b, pos) => openEdit(b, pos)}
              onHover={setHoverPreview}
            />
          )}
          {view === 'agenda' && (
            <AgendaView
              anchor={anchor}
              bookings={visibleBookings}
              onEvent={(b, pos) => openEdit(b, pos)}
            />
          )}
        </div>
      </section>

      {popover && (
        <QuickSchedulePopover
          mode={popover.mode}
          booking={popover.booking}
          initial={popover.draft}
          anchor={popover.anchor}
          onClose={() => setPopover(null)}
          onSave={savePopover}
          onDelete={popover.mode === 'edit' ? deletePopover : undefined}
          error={popover.error}
          saving={popover.saving}
        />
      )}
      {shortcutsOpen && <KeyboardShortcutsModal onClose={() => setShortcutsOpen(false)} />}
      {hoverPreview && (
        <EventHoverPreview
          booking={hoverPreview.b}
          anchor={{ x: hoverPreview.x, y: hoverPreview.y }}
        />
      )}
      <OfflineIndicator />
    </div>
  );
}

/* ------------------------ Month view ------------------------ */

function MonthView({
  anchor,
  bookings,
  onPickDay,
  onEvent,
}: {
  anchor: Date;
  bookings: Booking[];
  onPickDay: (d: Date) => void;
  onEvent: (b: Booking, pos: { x: number; y: number }) => void;
}) {
  const cells = useMemo(() => monthGrid(anchor), [anchor]);
  const byDay = useMemo(() => {
    const m = new Map<string, Booking[]>();
    for (const b of bookings) {
      const k = b.preferred_date;
      const list = m.get(k) ?? [];
      list.push(b);
      m.set(k, list);
    }
    for (const list of m.values()) {
      list.sort((a, b) => (a.preferred_time || '').localeCompare(b.preferred_time || ''));
    }
    return m;
  }, [bookings]);

  return (
    <div className="rounded-xl border border-brand-line bg-bg-elevated overflow-hidden">
      <ol className="grid grid-cols-7 border-b border-brand-line bg-bg-primary/40">
        {WEEKDAY_HEADERS.map((d) => (
          <li
            key={d}
            className="px-2 py-2 text-[10px] uppercase tracking-wider text-brand-mute text-center font-bold"
          >
            {d}
          </li>
        ))}
      </ol>
      <ol className="grid grid-cols-7 grid-rows-6 min-h-[60dvh]">
        {cells.map((d) => {
          const inMonth = d.getMonth() === anchor.getMonth();
          const day = byDay.get(toIsoDate(d)) ?? [];
          return (
            <li
              key={toIsoDate(d)}
              className={[
                'border-b border-r border-brand-line p-1.5 flex flex-col gap-1 overflow-hidden cursor-pointer transition-colors',
                inMonth ? 'bg-bg-elevated' : 'bg-bg-primary/60',
                'hover:bg-brand-line/40',
              ].join(' ')}
              onClick={() => onPickDay(d)}
            >
              <div className="flex items-center justify-between">
                <span
                  className={[
                    'inline-flex h-6 w-6 items-center justify-center rounded-md text-xs',
                    isToday(d)
                      ? 'bg-brand-accent text-bg-primary font-extrabold'
                      : inMonth
                        ? 'text-brand-ink'
                        : 'text-brand-mute',
                  ].join(' ')}
                >
                  {d.getDate()}
                </span>
                {day.length > 3 && (
                  <span className="text-[10px] text-brand-mute">+{day.length - 3}</span>
                )}
              </div>
              <ul className="flex flex-col gap-0.5">
                {day.slice(0, 3).map((b) => {
                  const palette = colorForService(b.service);
                  return (
                    <li key={b.id}>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onEvent(b, { x: e.clientX, y: e.clientY });
                        }}
                        className="w-full text-left truncate rounded-sm px-1.5 py-0.5 text-[11px] font-semibold min-h-[18px] hover:brightness-125 transition"
                        style={{
                          background: palette.fill,
                          color: palette.text,
                          borderLeft: `2px solid ${palette.dot}`,
                        }}
                      >
                        <span className="text-[9px] mr-1 opacity-75">{b.preferred_time}</span>
                        {palette.label}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

/* ------------------------ Time grid (week/day) ------------------------ */

function TimeGridView({
  days,
  bookings,
  now,
  onCreate,
  onEvent,
  onHover,
}: {
  days: Date[];
  bookings: Booking[];
  now: Date;
  onCreate: (draft: Partial<QuickScheduleDraft>, pos: { x: number; y: number }) => void;
  onEvent: (b: Booking, pos: { x: number; y: number }) => void;
  onHover: (state: { b: Booking; x: number; y: number } | null) => void;
}) {
  const gridRef = useRef<HTMLDivElement | null>(null);
  const dayIso = useMemo(() => days.map((d) => toIsoDate(d)), [days]);

  const byDay = useMemo(() => {
    const m = new Map<string, Booking[]>();
    for (const b of bookings) {
      const k = b.preferred_date;
      const list = m.get(k) ?? [];
      list.push(b);
      m.set(k, list);
    }
    return m;
  }, [bookings]);

  const snap = useCallback((clientY: number, gridTop: number) => {
    const px = clientY - gridTop;
    return clamp(Math.round(px / SNAP_ROW_PX) * SNAP_ROW_PX, 0, VISIBLE_HOURS.length * HOUR_ROW_PX);
  }, []);

  const dayFromX = useCallback(
    (clientX: number, gridLeft: number, gridWidth: number) => {
      const colWidth = gridWidth / days.length;
      const idx = Math.floor((clientX - gridLeft) / colWidth);
      return clamp(idx, 0, days.length - 1);
    },
    [days.length],
  );

  const { rect, pointerHandlers } = useDragCreate({
    snap,
    dayFromX,
    onComplete: (r: DragRect, anchorPos) => {
      const dayDate = days[r.dayIndex];
      if (!dayDate) return;
      const minutes = minutesFromPx(r.top);
      const hour = Math.floor(minutes / 60) + (VISIBLE_HOURS[0] ?? 6);
      const min = snapTo(minutes % 60, SNAP_MINUTES);
      const dur = Math.max(1, Math.round(minutesFromPx(r.height) / 60));
      onCreate(
        {
          date: toIsoDate(dayDate),
          startTime: `${pad2(hour)}:${pad2(min)}`,
          hours: dur,
        },
        anchorPos,
      );
    },
  });

  const todayCol = days.findIndex((d) => isSameDay(d, now));

  return (
    <div className="rounded-xl border border-brand-line bg-bg-elevated">
      {/* Column headers */}
      <ol
        className="grid border-b border-brand-line"
        style={{ gridTemplateColumns: `60px repeat(${days.length}, minmax(0, 1fr))` }}
      >
        <li className="px-2 py-2" />
        {days.map((d) => (
          <li
            key={toIsoDate(d)}
            className={[
              'px-2 py-2 text-center border-l border-brand-line',
              isToday(d) ? 'bg-brand-accent/10' : '',
            ].join(' ')}
          >
            <p className="text-[10px] uppercase tracking-wider text-brand-mute">
              {d.toLocaleDateString(undefined, { weekday: 'short' })}
            </p>
            <p
              className={[
                'text-lg font-extrabold',
                isToday(d) ? 'text-brand-accent' : 'text-brand-ink',
              ].join(' ')}
            >
              {d.getDate()}
            </p>
          </li>
        ))}
      </ol>

      <div className="flex">
        {/* Hour column */}
        <ol className="w-[60px] shrink-0">
          {VISIBLE_HOURS.map((h) => (
            <li
              key={h}
              className="text-right pr-2 text-[10px] uppercase tracking-wider text-brand-mute"
              style={{ height: HOUR_ROW_PX }}
            >
              {h % 12 === 0 ? 12 : h % 12}
              {h >= 12 ? 'p' : 'a'}
            </li>
          ))}
        </ol>

        {/* Day grid */}
        <div
          ref={gridRef}
          className="relative flex-1 grid select-none touch-none"
          style={{ gridTemplateColumns: `repeat(${days.length}, minmax(0, 1fr))` }}
          {...pointerHandlers}
        >
          {/* Hour gridlines per column */}
          {days.map((d, dayIdx) => (
            <div
              key={toIsoDate(d)}
              className={[
                'relative border-l border-brand-line',
                dayIdx === todayCol ? 'bg-brand-accent/[0.04]' : '',
              ].join(' ')}
              style={{ height: VISIBLE_HOURS.length * HOUR_ROW_PX }}
            >
              {VISIBLE_HOURS.map((_, i) => (
                <div
                  key={i}
                  className="border-t border-brand-line/40"
                  style={{ height: HOUR_ROW_PX }}
                />
              ))}

              {/* Today indicator */}
              {dayIdx === todayCol && (
                <div
                  aria-hidden
                  className="absolute left-0 right-0 z-10 pointer-events-none"
                  style={{ top: pxFromMinutes(minutesFromGridTop(now)) }}
                >
                  <div className="h-px bg-brand-accent" />
                  <span
                    className="absolute -left-1 -top-1 h-2 w-2 rounded-full"
                    style={{ background: 'var(--brand-accent)' }}
                  />
                </div>
              )}

              {/* Drag-create ghost */}
              {rect && rect.dayIndex === dayIdx && rect.height > 0 && (
                <div
                  aria-hidden
                  className="absolute left-1 right-1 rounded-md border-2 border-dashed border-brand-accent bg-brand-accent/15 pointer-events-none"
                  style={{ top: rect.top, height: Math.max(rect.height, 18) }}
                />
              )}

              {/* Events for this day */}
              {(byDay.get(dayIso[dayIdx]!) ?? []).map((b) => (
                <EventBlock
                  key={b.id}
                  booking={b}
                  onClick={(pos) => onEvent(b, pos)}
                  onHover={(pos) => onHover(pos ? { b, x: pos.x, y: pos.y } : null)}
                />
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function EventBlock({
  booking: b,
  onClick,
  onHover,
}: {
  booking: Booking;
  onClick: (pos: { x: number; y: number }) => void;
  onHover: (pos: { x: number; y: number } | null) => void;
}) {
  const start = bookingStart(b);
  const end = bookingEnd(b);
  const startMin = minutesFromGridTop(start);
  const durationMin = Math.max(30, (end.getTime() - start.getTime()) / 60000);
  const palette = colorForService(b.service);
  const hoverTimer = useRef<number | null>(null);

  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        onClick({ x: e.clientX, y: e.clientY });
      }}
      onPointerEnter={(e) => {
        const x = e.clientX;
        const y = e.clientY;
        if (hoverTimer.current) window.clearTimeout(hoverTimer.current);
        hoverTimer.current = window.setTimeout(() => onHover({ x, y }), 320);
      }}
      onPointerLeave={() => {
        if (hoverTimer.current) window.clearTimeout(hoverTimer.current);
        onHover(null);
      }}
      className="absolute left-1 right-1 rounded-md p-1.5 text-left text-xs leading-tight overflow-hidden hover:brightness-125 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-accent transition"
      style={{
        top: pxFromMinutes(startMin),
        height: pxFromMinutes(durationMin) - 2,
        background: palette.fill,
        borderLeft: `3px solid ${palette.dot}`,
        color: palette.text,
        // CSS view-transitions hook — per-event animation when the data refreshes.
        viewTransitionName: `evt-${b.id.slice(0, 8)}` as unknown as string,
        ['startingStyle' as keyof React.CSSProperties as string]: 'opacity:0',
      }}
    >
      <p className="font-extrabold truncate">{palette.label}</p>
      <p className="opacity-80 truncate">
        {formatTime12(start.getHours(), start.getMinutes())} · {b.crew_size} crew · {b.hours}h
      </p>
      {b.customer_address && (
        <p className="opacity-60 truncate text-[10px]">{b.customer_address}</p>
      )}
    </button>
  );
}

/* ------------------------ Agenda view ------------------------ */

function AgendaView({
  anchor,
  bookings,
  onEvent,
}: {
  anchor: Date;
  bookings: Booking[];
  onEvent: (b: Booking, pos: { x: number; y: number }) => void;
}) {
  const start = startOfMonth(anchor);
  const end = endOfMonth(anchor);
  const filtered = useMemo(() => {
    return bookings
      .filter((b) => {
        const d = bookingStart(b);
        return d >= start && d < end;
      })
      .sort((a, b) => bookingStart(a).getTime() - bookingStart(b).getTime());
  }, [bookings, start, end]);

  const groups = useMemo(() => {
    const map = new Map<string, Booking[]>();
    for (const b of filtered) {
      const k = b.preferred_date;
      const list = map.get(k) ?? [];
      list.push(b);
      map.set(k, list);
    }
    return [...map.entries()];
  }, [filtered]);

  if (groups.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-brand-line bg-bg-elevated p-10 text-center text-brand-mute">
        Nothing this month. Press{' '}
        <kbd className="rounded border border-brand-line px-1 text-xs">n</kbd> to book a crew.
      </div>
    );
  }

  return (
    <ol className="space-y-4">
      {groups.map(([day, list]) => {
        const d = new Date(`${day}T12:00:00`);
        return (
          <li
            key={day}
            className="rounded-xl border border-brand-line bg-bg-elevated overflow-hidden"
          >
            <header
              className={[
                'flex items-center justify-between border-b border-brand-line px-4 py-2',
                isToday(d) ? 'bg-brand-accent/10' : 'bg-bg-primary/30',
              ].join(' ')}
            >
              <p className="font-extrabold text-brand-ink">{longDate(d)}</p>
              <p className="text-xs text-brand-mute">
                {list.length} booking{list.length === 1 ? '' : 's'}
              </p>
            </header>
            <ul className="divide-y divide-brand-line">
              {list.map((b) => {
                const palette = colorForService(b.service);
                return (
                  <li key={b.id} className="p-4 flex flex-col sm:flex-row sm:items-center gap-3">
                    <span
                      aria-hidden
                      className="h-3 w-3 rounded-full shrink-0"
                      style={{ background: palette.dot }}
                    />
                    <div className="min-w-0 flex-1">
                      <p className="font-extrabold text-brand-ink capitalize">
                        {palette.label}{' '}
                        <span className="text-brand-mute font-normal">· {b.preferred_time}</span>
                      </p>
                      {b.customer_address && (
                        <p className="text-xs text-brand-mute truncate">📍 {b.customer_address}</p>
                      )}
                    </div>
                    <p className="text-sm text-brand-ink">
                      {b.crew_size} crew · {b.hours}h · ${(b.total_cents / 100).toFixed(2)}
                    </p>
                    <div className="flex flex-wrap items-center gap-2">
                      <SmsActions booking={b} />
                      <button
                        type="button"
                        onClick={(e) => onEvent(b, { x: e.clientX, y: e.clientY })}
                        className="rounded-md border border-brand-line bg-bg-elevated px-3 py-1.5 text-xs text-brand-ink hover:border-brand-accent min-h-[32px]"
                      >
                        Edit
                      </button>
                      <a
                        href={`/track/${b.id}`}
                        className="rounded-md bg-brand-accent px-3 py-1.5 text-xs font-extrabold text-bg-primary hover:bg-brand-accentHover min-h-[32px] inline-flex items-center"
                      >
                        Track →
                      </a>
                    </div>
                  </li>
                );
              })}
            </ul>
          </li>
        );
      })}
    </ol>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
