import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useState } from 'react';

/**
 * Background-check renewal calendar. Lists every scheduled / due renewal,
 * grouped by month, with a "Run sweep" button that POSTs the admin route.
 *
 * The list source is a thin server endpoint we don't strictly own here —
 * the integrator wires `/api/admin/safety/bg-renewals` (or similar) into
 * the worker. Until then we render an empty-state with a manual sweep
 * action so the page is functional.
 */

interface RenewalRow {
  id: string;
  worker_id: string;
  kind: 'criminal' | 'mvr' | 'identity';
  next_check_at: string | null;
  expires_at: string | null;
  status: string;
  vendor: string | null;
}

export function BgCheckRenewalCalendar({ auth }: { readonly auth: HeadersInit }) {
  useThemeToolsSurface('bg-check-renewal-calendar');
  const [rows, setRows] = useState<RenewalRow[]>([]);
  const [error, setError] = useState('');
  const [sweeping, setSweeping] = useState(false);
  const [sweepResult, setSweepResult] = useState('');

  const reload = useCallback(async () => {
    setError('');
    try {
      // Conventional path — integrator wires it. Tolerate 404 cleanly.
      const res = await fetch('/api/admin/safety/bg-renewals', { headers: auth });
      if (res.status === 404) {
        setRows([]);
        return;
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as { rows?: RenewalRow[] };
      setRows(data.rows ?? []);
    } catch (err) {
      setError((err as Error).message);
    }
  }, [auth]);

  useEffect(() => {
    void reload();
  }, [reload]);

  async function onSweep() {
    setSweeping(true);
    setSweepResult('');
    try {
      const res = await fetch('/api/admin/safety/renew-bg-checks', {
        method: 'POST',
        headers: { ...auth, 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      const data = (await res.json()) as { ran?: string[] };
      setSweepResult(`Processed ${(data.ran ?? []).length} renewals.`);
      await reload();
    } catch (err) {
      setSweepResult(`Error: ${(err as Error).message}`);
    } finally {
      setSweeping(false);
    }
  }

  const grouped = groupByMonth(rows);

  return (
    <section aria-labelledby="bg-h" className="space-y-4">
      <header className="flex items-end justify-between gap-3">
        <div>
          <h2 id="bg-h" className="text-xl font-bold">
            BG check renewals
          </h2>
          <p className="text-brand-mute text-sm">
            Annual criminal + MVR, biennial identity. Runs via Checkr / Yardstik / Persona.
          </p>
        </div>
        <button
          type="button"
          onClick={onSweep}
          disabled={sweeping}
          className="btn btn-primary text-sm disabled:opacity-60"
        >
          {sweeping ? 'Running…' : 'Run sweep'}
        </button>
      </header>

      {sweepResult && <p className="text-brand-accent text-sm">{sweepResult}</p>}
      {error && <p className="text-rose-400 text-sm">{error}</p>}

      {rows.length === 0 && (
        <p className="text-brand-mute text-sm">
          No scheduled renewals on file (or endpoint not wired). Use the sweep to seed.
        </p>
      )}

      {rows.length > 0 && (
        <div className="space-y-4">
          {Object.entries(grouped).map(([month, items]) => (
            <div key={month}>
              <h3 className="mb-2 text-sm font-semibold uppercase tracking-wider text-brand-mute">
                {month}
              </h3>
              <ul className="space-y-1">
                {items.map((r) => (
                  <li
                    key={r.id}
                    className="flex items-center justify-between rounded-md border border-brand-line bg-brand-ink/40 px-3 py-2 text-sm"
                  >
                    <span className="font-mono text-xs">{r.next_check_at}</span>
                    <span>{r.kind}</span>
                    <span className="text-brand-mute">{r.vendor ?? '—'}</span>
                    <span
                      className={
                        r.status === 'clear'
                          ? 'text-emerald-400'
                          : r.status === 'consider' || r.status === 'adverse'
                            ? 'text-amber-400'
                            : 'text-brand-mute'
                      }
                    >
                      {r.status}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

function groupByMonth(rows: RenewalRow[]): Record<string, RenewalRow[]> {
  const out: Record<string, RenewalRow[]> = {};
  for (const r of rows) {
    const key = (r.next_check_at ?? 'unscheduled').slice(0, 7);
    if (!out[key]) out[key] = [];
    out[key]!.push(r);
  }
  return out;
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
