import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { POWER_WASH_PROTOCOLS } from '@theme.tools/scheduling/field-service-domain-advisors';
import { type MouseEvent, useEffect, useMemo, useState } from 'react';
import {
  CONTAMINANTS,
  CUSTOMER_EXPECTATIONS_LIMITS,
  CUSTOMER_EXPECTATIONS_PROMISE,
  CUSTOMER_PREP,
  DRY_SWEEP_REASONS,
  DRY_SWEEP_TARGETS,
  DRY_SWEEP_TOOLS,
  EQUIPMENT,
  FAQ_ITEMS,
  FIELD_CHECKLIST,
  MACHINES,
  MASTER_WORKFLOW,
  SEQUENCES,
  STOP_WORK_CONDITIONS,
  SURFACES,
  TOC,
  TROUBLESHOOTING,
  type CleaningSequence,
  type SurfaceId,
} from '../data/power-washing-sop.js';
import { ResponsivePicture } from '../picture.js';

const ORIGIN = 'https://bricklabor.com';
const TITLE = 'Power Washing SOP · Brick Labor — Newark NJ Property Crew';
const DESC =
  'How Brick Labor power washes property in Newark NJ — machine selection, cleaning sequences, chemistry, stop-work rules, and customer expectations.';
const LAST_UPDATED = '2026-08-28';
const CANONICAL = `${ORIGIN}/guides/power-washing`;
const SERVICE_URL = '/services/power-washing';
const BOOK_URL = '/book';
const OG_IMAGE = `${ORIGIN}/og-image.jpg`;

/**
 * schema.org structured data. Injected client-side (this page renders fully on
 * the client), so it never duplicates the prerendered shell's WebPage/Breadcrumb
 * singletons in dist/. Google renders JS and picks these up.
 */
const HOWTO_LD = {
  '@context': 'https://schema.org',
  '@type': 'HowTo',
  name: 'How Brick Labor power washes property',
  description: DESC,
  inLanguage: 'en-US',
  totalTime: 'PT1H',
  step: MASTER_WORKFLOW.map((s) => ({
    '@type': 'HowToStep',
    position: s.n,
    name: s.title,
    text: s.detail,
  })),
};

const FAQ_LD = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  inLanguage: 'en-US',
  mainEntity: FAQ_ITEMS.map((f) => ({
    '@type': 'Question',
    name: f.q,
    acceptedAnswer: { '@type': 'Answer', text: f.a },
  })),
};

const BREADCRUMB_LD = {
  '@context': 'https://schema.org',
  '@type': 'BreadcrumbList',
  inLanguage: 'en-US',
  itemListElement: [
    { '@type': 'ListItem', position: 1, name: 'Home', item: `${ORIGIN}/` },
    { '@type': 'ListItem', position: 2, name: 'Power Washing', item: `${ORIGIN}${SERVICE_URL}` },
    { '@type': 'ListItem', position: 3, name: 'Power Washing SOP', item: CANONICAL },
  ],
};

const CRUMBS: readonly { label: string; href?: string }[] = [
  { label: 'Home', href: '/' },
  { label: 'Power Washing', href: SERVICE_URL },
  { label: 'SOP Guide' },
];

/** Custom imagery generated for this guide (public/guides/power-washing/). */
const IMG_BASE = '/guides/power-washing';

const MACHINE_MEDIA: Record<string, { slug: string; alt: string }> = {
  'gas-4000': {
    slug: 'machine-gas',
    alt: 'A gas-powered pressure washer with a coiled high-pressure hose on a residential concrete driveway',
  },
  'electric-1900': {
    slug: 'machine-electric',
    alt: 'A compact electric pressure washer with its hose and lance on a residential front porch',
  },
};

const AUDIENCE_CARDS: readonly { id: string; who: string; whatYouGet: string }[] = [
  {
    id: 'customer',
    who: 'If you are a customer',
    whatYouGet:
      'This is the exact workflow our crew will use on your property. No mystery, no surprises, no wall of pressure-washer jargon.',
  },
  {
    id: 'crew',
    who: 'If you are on the crew',
    whatYouGet:
      'This is the field SOP. Print the quick-reference card at the bottom. When in doubt, use the least aggressive method that will do the job.',
  },
];

export function GuidePowerWashing() {
  useThemeToolsSurface('guide-power-washing');
  const [surfaceFilter, setSurfaceFilter] = useState<SurfaceId | 'all'>('all');
  const [activeId, setActiveId] = useState<string>(TOC[0]?.id ?? '');
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    document.title = TITLE;
    setMeta('description', DESC);
    setLink('canonical', CANONICAL);
    setMeta('robots', 'index,follow', 'name');
    setMeta('og:title', TITLE, 'property');
    setMeta('og:description', DESC, 'property');
    setMeta('og:type', 'article', 'property');
    setMeta('og:url', CANONICAL, 'property');
    setMeta('og:image', OG_IMAGE, 'property');
    setMeta('twitter:card', 'summary_large_image', 'name');
    setMeta('twitter:title', TITLE, 'name');
    setMeta('twitter:description', DESC, 'name');
  }, []);

  // Reading-progress bar — reflects document scroll fraction. Passive listener,
  // no animation loop, so it is inherently reduced-motion friendly.
  useEffect(() => {
    const onScroll = () => {
      const doc = document.documentElement;
      const max = doc.scrollHeight - doc.clientHeight;
      setProgress(max > 0 ? Math.min(1, Math.max(0, doc.scrollTop / max)) : 0);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
    };
  }, []);

  // Scrollspy — highlight the TOC entry whose section is currently in view.
  useEffect(() => {
    const els = TOC.map((t) => document.getElementById(t.id)).filter(
      (el): el is HTMLElement => el !== null,
    );
    if (els.length === 0) return;
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (visible[0]?.target.id) setActiveId(visible[0].target.id);
      },
      { rootMargin: '-96px 0px -60% 0px', threshold: 0 },
    );
    for (const el of els) observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // Structured data. The prerendered SPA shell carries the HOMEPAGE's generic
  // FAQPage + BreadcrumbList on every route, so we strip those stale singletons
  // on this route (avoiding the 2×-block conflict the jsonld-singletons gate
  // forbids) and inject this page's accurate HowTo + FAQPage + BreadcrumbList
  // into <head>. Injected client-side because this route renders client-side.
  useEffect(() => {
    for (const s of Array.from(
      document.querySelectorAll<HTMLScriptElement>('script[type="application/ld+json"]'),
    )) {
      if (s.dataset.guideLd) continue;
      try {
        const type = (JSON.parse(s.textContent || '{}') as { '@type'?: string })['@type'];
        if (type === 'FAQPage' || type === 'BreadcrumbList') s.remove();
      } catch {
        /* leave unparseable blocks alone */
      }
    }
    const injected = [HOWTO_LD, FAQ_LD, BREADCRUMB_LD].map((data) => {
      const el = document.createElement('script');
      el.type = 'application/ld+json';
      el.dataset.guideLd = '1';
      el.textContent = JSON.stringify(data);
      document.head.appendChild(el);
      return el;
    });
    return () => {
      for (const el of injected) el.remove();
    };
  }, []);

  const gasMachine = MACHINES.find((m) => m.id === 'gas-4000')!;
  const electricMachine = MACHINES.find((m) => m.id === 'electric-1900')!;

  const filteredSequences = useMemo(() => {
    if (surfaceFilter === 'all') return SEQUENCES;
    return SEQUENCES.filter((s) => s.surfaceId === surfaceFilter);
  }, [surfaceFilter]);

  return (
    <>
      <div
        aria-hidden="true"
        className="fixed inset-x-0 top-0 z-50 h-1 origin-left bg-brand-accent transition-transform duration-150 print:hidden"
        style={{ transform: `scaleX(${progress})` }}
        data-testid="reading-progress"
      />
      <article
        className="section docs-power-washing [&_section[id]]:scroll-mt-24"
        data-testid="guide-power-washing"
      >
        <div className="container-pad max-w-4xl">
          <Breadcrumb />
          <p className="eyebrow mb-3">Field Guide · Property Cleaning</p>
          <h1 className="text-4xl sm:text-5xl font-extrabold mb-3 text-brand-ink">
            Power Washing SOP
          </h1>
          <p className="text-brand-mute mb-6 max-w-2xl leading-relaxed">
            The Brick Labor operating manual for pressure washing residential and commercial
            property. Written once for two audiences — customers who want to know exactly what will
            happen on their driveway, and crew who need a systematic field guide.
          </p>
          <p className="text-xs text-brand-mute/70 mb-6">Last updated: {LAST_UPDATED}</p>

          <figure className="mb-10 overflow-hidden rounded-2xl border border-brand-line">
            <ResponsivePicture
              src={`${IMG_BASE}/hero.jpg`}
              alt="A Brick Labor worker power washing a Newark sidewalk, a bright clean stripe of concrete beside the untouched dirty section"
              width={1280}
              height={720}
              loading="eager"
              decoding="sync"
              fetchPriority="high"
              className="w-full h-auto"
            />
          </figure>

          <div className="mb-10 grid gap-4 sm:grid-cols-2">
            {AUDIENCE_CARDS.map((c) => (
              <div key={c.id} className="rounded-xl border border-brand-line bg-bg-elevated/40 p-5">
                <p className="eyebrow mb-2 text-brand-accent">{c.who}</p>
                <p className="text-sm text-brand-mute leading-relaxed">{c.whatYouGet}</p>
              </div>
            ))}
          </div>

          <aside
            role="note"
            aria-label="What this page will not tell you"
            className="mb-10 rounded-md border border-amber-400/40 bg-amber-400/10 p-4 text-amber-100"
          >
            <p className="text-sm leading-relaxed">
              <strong className="font-bold">One line up front:</strong> the machine that says 4,000
              PSI on the side does not clean at 4,000 PSI. Actual cleaning force is set by nozzle,
              distance, fan width, chemistry, dwell time, and movement speed. More pressure is not
              better. The professional move is the least aggressive method that produces the result.
            </p>
          </aside>

          <CtaBand testid="cta-top" />

          <nav
            aria-label="On this page"
            className="mb-14 rounded-md border border-brand-line bg-bg-elevated/40 p-5 text-sm"
          >
            <p className="eyebrow mb-3">On this page</p>
            <ol className="grid gap-1 sm:grid-cols-2">
              {TOC.map((t) => {
                const active = activeId === t.id;
                return (
                  <li key={t.id}>
                    <a
                      href={`#${t.id}`}
                      onClick={(e) => scrollToId(e, t.id)}
                      aria-current={active ? 'true' : undefined}
                      className={
                        active
                          ? 'font-semibold text-brand-accent'
                          : 'text-brand-mute underline-hover hover:text-brand-accent'
                      }
                    >
                      {t.label}
                    </a>
                  </li>
                );
              })}
            </ol>
          </nav>

          {/* ────────────────────────────  1. PHILOSOPHY  ──────────────────────────── */}
          <section id="philosophy" className="mb-16">
            <h2 className="mt-4 mb-4 text-2xl sm:text-3xl font-extrabold text-brand-ink">
              1. Least Aggressive Effective Method
            </h2>
            <p className="text-brand-mute leading-relaxed mb-4">
              Professional power washing is not about using the highest pressure available. It is
              about producing a clean, safe result on the customer&apos;s surface without damaging
              it. We compensate for a stubborn stain with chemistry and dwell time, not by driving a
              concentrated nozzle two inches from the substrate.
            </p>
            <div className="rounded-xl border border-brand-line bg-bg-elevated/40 p-5 sm:p-6 mb-4">
              <p className="eyebrow mb-2">Preferred hierarchy</p>
              <p className="font-mono text-sm text-brand-ink leading-relaxed">
                Dry removal → Chemistry → Dwell → Agitation → Water flow → Controlled mechanical
                cleaning → Final rinse
              </p>
            </div>
            <div className="rounded-xl border border-brand-line bg-bg-elevated/40 p-5 sm:p-6">
              <p className="eyebrow mb-2">Selection hierarchy</p>
              <p className="font-mono text-sm text-brand-ink leading-relaxed">
                Correct machine → Correct chemistry → Correct tool → Minimum effective pressure
              </p>
            </div>
          </section>

          {/* ────────────────────────────  2. RIGHT-SIZE  ──────────────────────────── */}
          <section id="right-size" className="mb-16">
            <h2 className="mt-4 mb-4 text-2xl sm:text-3xl font-extrabold text-brand-ink">
              2. Right-size the machine to the job
            </h2>
            <p className="text-brand-mute leading-relaxed mb-6">
              We carry two classes of pressure washer, and the choice between them is deliberate.
              More PSI is not automatically better. Choosing the smaller machine is often the
              professional call.
            </p>

            <div className="grid gap-4 sm:grid-cols-2 mb-6">
              <div className="rounded-xl border border-brand-line bg-bg-elevated/40 p-5">
                <p className="eyebrow mb-2 text-brand-accent">Choose the electric</p>
                <ul className="list-disc space-y-1 pl-5 text-sm text-brand-mute">
                  <li>Area is small</li>
                  <li>Contamination is light</li>
                  <li>Surface is delicate</li>
                  <li>Surface cleaner would be overkill</li>
                  <li>Low water demand is desirable</li>
                  <li>Setup speed matters more than production rate</li>
                </ul>
              </div>
              <div className="rounded-xl border border-brand-line bg-bg-elevated/40 p-5">
                <p className="eyebrow mb-2 text-brand-accent">Choose the gas</p>
                <ul className="list-disc space-y-1 pl-5 text-sm text-brand-mute">
                  <li>Surface cleaner will be used</li>
                  <li>Large concrete area, commercial sidewalk, driveway, parking</li>
                  <li>Heavy soil after proper chemistry</li>
                  <li>Long hose runs or extension wand needed</li>
                  <li>Significant rinsing volume required</li>
                </ul>
              </div>
            </div>

            <p className="text-sm text-brand-mute leading-relaxed">
              Even when we use the gas washer, we use conservative effective pressure. The
              productivity advantage is GPM — the ability to move water fast enough to run the
              24-inch surface cleaner — not the peak PSI headline number.
            </p>
          </section>

          {/* ────────────────────────────  3. MACHINES  ──────────────────────────── */}
          <section id="machines" className="mb-16">
            <h2 className="mt-4 mb-4 text-2xl sm:text-3xl font-extrabold text-brand-ink">
              3. The two machines
            </h2>
            <div className="grid gap-5 md:grid-cols-2">
              {[gasMachine, electricMachine].map((m) => (
                <div
                  key={m.id}
                  className="rounded-xl border border-brand-line bg-bg-elevated/40 p-5 sm:p-6"
                >
                  {MACHINE_MEDIA[m.id] && (
                    <ResponsivePicture
                      src={`${IMG_BASE}/${MACHINE_MEDIA[m.id]!.slug}.jpg`}
                      alt={MACHINE_MEDIA[m.id]!.alt}
                      width={1000}
                      height={750}
                      loading="lazy"
                      decoding="async"
                      className="mb-4 w-full h-auto rounded-lg border border-brand-line"
                    />
                  )}
                  <p className="eyebrow mb-1 text-brand-accent">{m.shortName}</p>
                  <h3 className="text-lg font-bold text-brand-ink mb-1">{m.displayName}</h3>
                  <p className="font-mono text-xs text-brand-mute mb-4">{m.power}</p>
                  <p className="text-sm text-brand-mute leading-relaxed mb-4">{m.summary}</p>
                  <p className="eyebrow mb-2">Best for</p>
                  <ul className="list-disc space-y-1 pl-5 text-sm text-brand-mute mb-4">
                    {m.bestFor.map((b) => (
                      <li key={b}>{b}</li>
                    ))}
                  </ul>
                  <p className="eyebrow mb-2">Avoid when</p>
                  <ul className="list-disc space-y-1 pl-5 text-sm text-brand-mute mb-4">
                    {m.avoidWhen.map((b) => (
                      <li key={b}>{b}</li>
                    ))}
                  </ul>
                  <p className="eyebrow mb-2">Examples</p>
                  <ul className="list-disc space-y-1 pl-5 text-sm text-brand-mute">
                    {m.examples.map((b) => (
                      <li key={b}>{b}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            <div className="mt-8">
              <p className="eyebrow mb-3">Additional equipment carried on every job</p>
              <div className="grid gap-4 sm:grid-cols-2">
                {EQUIPMENT.map((g) => (
                  <div
                    key={g.heading}
                    className="rounded-xl border border-brand-line bg-bg-elevated/40 p-4"
                  >
                    <p className="text-sm font-semibold text-brand-ink mb-2">{g.heading}</p>
                    <ul className="list-disc space-y-1 pl-5 text-sm text-brand-mute">
                      {g.items.map((it) => (
                        <li key={it}>{it}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* ────────────────────────────  4. WORKFLOW  ──────────────────────────── */}
          <section id="workflow" className="mb-16">
            <h2 className="mt-4 mb-4 text-2xl sm:text-3xl font-extrabold text-brand-ink">
              4. Master workflow — every job, every time
            </h2>
            <p className="text-brand-mute leading-relaxed mb-6">
              Every Brick Labor power-washing job follows the same 29 steps. Some steps take
              seconds, some take longer, but the order does not change. The order is what keeps the
              work systematic instead of aggressive.
            </p>
            <ol className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {MASTER_WORKFLOW.map((s) => (
                <li
                  key={s.n}
                  className="rounded-lg border border-brand-line bg-bg-elevated/30 p-3 text-sm"
                >
                  <div className="flex items-baseline gap-2 mb-1">
                    <span className="font-mono text-xs text-brand-accent">{s.n}</span>
                    <span className="font-semibold text-brand-ink">{s.title}</span>
                  </div>
                  <p className="text-xs text-brand-mute leading-relaxed">{s.detail}</p>
                </li>
              ))}
            </ol>
          </section>

          {/* ────────────────────────────  5. DRY SWEEP  ──────────────────────────── */}
          <section id="dry-sweep" className="mb-16">
            <h2 className="mt-4 mb-4 text-2xl sm:text-3xl font-extrabold text-brand-ink">
              5. Dry sweeping — water is not the first tool
            </h2>
            <p className="text-brand-mute leading-relaxed mb-6">
              Water should not be the first tool used against loose debris. Before any wet cleaning
              begins, we remove as much loose material as reasonably possible with brooms, blowers,
              and hand pickup. The customer sees this as our crew looking prepared. The reason is
              more concrete than that.
            </p>
            <ResponsivePicture
              src={`${IMG_BASE}/dry-sweep.jpg`}
              alt="A worker sweeping leaves and debris off a concrete patio with a push broom before any water is used"
              width={1200}
              height={800}
              loading="lazy"
              decoding="async"
              className="mb-6 w-full h-auto rounded-2xl border border-brand-line"
            />
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="rounded-xl border border-brand-line bg-bg-elevated/40 p-4">
                <p className="eyebrow mb-2">Tools</p>
                <ul className="list-disc space-y-1 pl-5 text-sm text-brand-mute">
                  {DRY_SWEEP_TOOLS.map((t) => (
                    <li key={t}>{t}</li>
                  ))}
                </ul>
              </div>
              <div className="rounded-xl border border-brand-line bg-bg-elevated/40 p-4">
                <p className="eyebrow mb-2">Targets</p>
                <ul className="list-disc space-y-1 pl-5 text-sm text-brand-mute">
                  {DRY_SWEEP_TARGETS.map((t) => (
                    <li key={t}>{t}</li>
                  ))}
                </ul>
              </div>
              <div className="rounded-xl border border-brand-line bg-bg-elevated/40 p-4">
                <p className="eyebrow mb-2">Why</p>
                <ul className="list-disc space-y-1 pl-5 text-sm text-brand-mute">
                  {DRY_SWEEP_REASONS.map((t) => (
                    <li key={t}>{t}</li>
                  ))}
                </ul>
              </div>
            </div>
            <p className="font-mono text-sm text-brand-ink mt-6 rounded-lg border border-brand-line bg-bg-elevated/40 p-4">
              Dry debris removal → chemistry if needed → wet cleaning
            </p>
          </section>

          {/* ────────────────────────────  6. CHEMISTRY ORDER  ──────────────────────────── */}
          <section id="chemistry-order" className="mb-16">
            <h2 className="mt-4 mb-4 text-2xl sm:text-3xl font-extrabold text-brand-ink">
              6. When chemistry goes first, and when it does not
            </h2>
            <p className="text-brand-mute leading-relaxed mb-6">
              The order of chemistry and mechanical cleaning is not a preference. It is dictated by
              the contamination.
            </p>

            <div className="rounded-xl border border-brand-line bg-bg-elevated/40 p-5 sm:p-6 mb-4">
              <p className="eyebrow mb-2 text-brand-accent">Chemistry BEFORE surface cleaning</p>
              <p className="text-sm text-brand-mute mb-3">
                When the contamination requires chemistry — algae, oil, grease — we pretreat first,
                let it dwell, agitate where useful, and only then bring the mechanical tools in.
              </p>
              <p className="font-mono text-xs text-brand-ink">
                Sweep → protect surroundings → apply treatment → dwell → surface clean → edge detail
                → rinse → water broom → inspect
              </p>
            </div>

            <div className="rounded-xl border border-brand-line bg-bg-elevated/40 p-5 sm:p-6 mb-4">
              <p className="eyebrow mb-2 text-brand-accent">No chemistry at all</p>
              <p className="text-sm text-brand-mute mb-3">
                If plain water and the surface cleaner will produce the result, we skip chemistry
                entirely. Not every dirty slab needs a chemical.
              </p>
              <p className="font-mono text-xs text-brand-ink">
                Sweep → test → surface cleaner → edge detail → rinse → water broom → inspect
              </p>
            </div>

            <div className="rounded-xl border border-brand-line bg-bg-elevated/40 p-5 sm:p-6">
              <p className="eyebrow mb-2 text-brand-accent">Chemistry AFTER initial cleaning</p>
              <p className="text-sm text-brand-mute mb-3">
                Sometimes stains only become visible after the general dirt is gone. In that case
                spot treatment is more efficient than treating the whole property up front.
              </p>
              <p className="font-mono text-xs text-brand-ink">
                Sweep → general clean → inspect remaining stains → spot-treat specific stains →
                dwell → spot clean → final rinse
              </p>
            </div>
          </section>

          {/* ────────────────────────────  7. SEQUENCE PLAYBOOK  ──────────────────────────── */}
          <section id="sequences" className="mb-16">
            <h2 className="mt-4 mb-4 text-2xl sm:text-3xl font-extrabold text-brand-ink">
              7. Sequence playbook by surface
            </h2>
            <p className="text-brand-mute leading-relaxed mb-6">
              For every common surface and contamination combination, here is the exact order of
              operations, the machine we would default to, and the expected result. This is the
              section our crew consults in the field — and the section customers can point to before
              we start.
            </p>
            <ResponsivePicture
              src={`${IMG_BASE}/surface-cleaner.jpg`}
              alt="A pressure-washer surface cleaner spraying water and cutting a bright clean arc into dirty concrete"
              width={1280}
              height={720}
              loading="lazy"
              decoding="async"
              className="mb-6 w-full h-auto rounded-2xl border border-brand-line"
            />

            <div
              className="mb-6 flex flex-wrap items-center gap-2"
              role="group"
              aria-label="Filter sequences by surface"
              data-testid="sequence-filter"
            >
              <span className="text-xs uppercase tracking-wider text-brand-mute">
                Filter by surface:
              </span>
              <button
                type="button"
                onClick={() => setSurfaceFilter('all')}
                aria-pressed={surfaceFilter === 'all'}
                className={filterButtonClasses(surfaceFilter === 'all')}
              >
                All
              </button>
              {SURFACES.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setSurfaceFilter(s.id)}
                  aria-pressed={surfaceFilter === s.id}
                  className={filterButtonClasses(surfaceFilter === s.id)}
                >
                  {s.name}
                </button>
              ))}
            </div>

            <div className="grid gap-4">
              {filteredSequences.map((seq) => (
                <SequenceCard key={seq.id} seq={seq} />
              ))}
              {filteredSequences.length === 0 && (
                <p className="text-sm text-brand-mute">
                  No sequences documented for that surface yet. Reach out and we will write one.
                </p>
              )}
            </div>
          </section>

          {/* ────────────────────────────  8. CHEMICAL MATRIX  ──────────────────────────── */}
          <section id="chemical-matrix" className="mb-16">
            <h2 className="mt-4 mb-4 text-2xl sm:text-3xl font-extrabold text-brand-ink">
              8. Chemical decision matrix
            </h2>
            <p className="text-brand-mute leading-relaxed mb-6">
              A quick reference for which chemistry family to reach for on each contamination
              category, and the typical order.
            </p>
            <div className="overflow-x-auto rounded-xl border border-brand-line bg-bg-elevated/40">
              <table className="w-full text-sm">
                <thead className="bg-bg-elevated/60 text-left text-xs uppercase tracking-wider text-brand-mute">
                  <tr>
                    <th className="px-4 py-3">Contamination</th>
                    <th className="px-4 py-3">First choice</th>
                    <th className="px-4 py-3">Typical order</th>
                  </tr>
                </thead>
                <tbody className="text-brand-mute">
                  {CONTAMINANTS.map((c) => (
                    <tr key={c.id} className="border-t border-brand-line align-top">
                      <td className="px-4 py-3">
                        <p className="text-brand-ink font-semibold">{c.name}</p>
                        {c.note && <p className="mt-1 text-xs opacity-80">{c.note}</p>}
                      </td>
                      <td className="px-4 py-3">{c.firstChoice}</td>
                      <td className="px-4 py-3 font-mono text-xs">{c.typicalOrder}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* ────────────────────────────  9. TECHNIQUE  ──────────────────────────── */}
          <section id="technique" className="mb-16">
            <h2 className="mt-4 mb-4 text-2xl sm:text-3xl font-extrabold text-brand-ink">
              9. Tool technique
            </h2>

            <TechniqueCard
              title="Surface cleaner"
              body="For compatible durable flatwork. Pretreat first if chemistry is needed, wait the required dwell, chemical feed OFF unless explicitly required. Place the cleaner flat, establish stable rotation before the production pass, walk at a consistent speed, overlap passes, do not hover stationary, inspect behind as you go, and hand-clean any boundary the cleaner cannot safely reach."
            />
            <TechniqueCard
              title="Water broom"
              body="A rinse, flush, and productivity tool — not a scrubber. Primary cleaning complete → chemical feed OFF → loosened dirt rinsed → water broom pushes dirty water in the intended direction → inspect → final spot rinse. We never intentionally push contaminated runoff into storm drains."
            />
            <TechniqueCard
              title="Spray wand"
              body="Wide fan first. Greater distance first. Controlled approach. Continuous movement. Overlap. Test area. No hovering. No casual zero-degree nozzle use. The wand is for edges, corners, vertical surfaces, details, spot stains, and areas the surface cleaner cannot safely reach."
            />
            <TechniqueCard
              title="24-foot extension wand"
              body="For high walls, elevated siding, and other appropriate surfaces reachable from the ground. Respect the lowest-rated component in the assembly. Use two-handed control. Anticipate leverage and reaction force. Wide fan, conservative distance, keep away from power lines and fragile materials. We do not pressure wash roofs simply because the extension reaches them."
            />
            <TechniqueCard
              title="Downstream chemical injector"
              body="Connect approved chemical → select low-pressure soap mode → apply → dwell → stop chemical draw → flush the injector → switch to clean-water mode → mechanical clean or rinse. Chemical feed must NOT remain unintentionally active during surface-cleaner work, plain-water rinsing, water brooming, or the final rinse."
            />
          </section>

          {/* ────────────────────────────  10. WATER SUPPLY  ──────────────────────────── */}
          <section id="water-supply" className="mb-16">
            <h2 className="mt-4 mb-4 text-2xl sm:text-3xl font-extrabold text-brand-ink">
              10. Water supply and startup
            </h2>
            <p className="text-brand-mute leading-relaxed mb-6">
              The gas washer requires roughly 3.5 GPM continuous. Some customer supplies read around
              4.6 GPM static but drop under continuous demand. A static-looking flow is not the same
              as an adequate supply. If the machine starts starving, we stop.
            </p>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="rounded-xl border border-brand-line bg-bg-elevated/40 p-5">
                <p className="eyebrow mb-2 text-brand-accent">Gas washer startup</p>
                <p className="font-mono text-xs text-brand-ink leading-relaxed">
                  Inspect oil/fuel/equipment → connect water → water fully ON → purge trigger with
                  engine OFF → confirm stable stream → connect / test accessories → start machine →
                  test in safe area → begin work
                </p>
                <p className="mt-3 text-xs text-brand-mute">Never run the pump dry.</p>
              </div>
              <div className="rounded-xl border border-brand-line bg-bg-elevated/40 p-5">
                <p className="eyebrow mb-2 text-brand-accent">Electric washer startup</p>
                <p className="font-mono text-xs text-brand-ink leading-relaxed">
                  Inspect cord / GFCI / environment → connect water → purge air → connect power per
                  manufacturer requirements → test → clean
                </p>
                <p className="mt-3 text-xs text-brand-mute">
                  Keep electrical connections out of standing water.
                </p>
              </div>
            </div>
          </section>

          {/* ────────────────────────────  11. TROUBLESHOOTING  ──────────────────────────── */}
          <section id="troubleshooting" className="mb-16">
            <h2 className="mt-4 mb-4 text-2xl sm:text-3xl font-extrabold text-brand-ink">
              11. Troubleshooting
            </h2>
            <div className="overflow-x-auto rounded-xl border border-brand-line bg-bg-elevated/40">
              <table className="w-full text-sm">
                <thead className="bg-bg-elevated/60 text-left text-xs uppercase tracking-wider text-brand-mute">
                  <tr>
                    <th className="px-4 py-3">Symptom</th>
                    <th className="px-4 py-3">Likely cause</th>
                    <th className="px-4 py-3">Action</th>
                  </tr>
                </thead>
                <tbody className="text-brand-mute">
                  {TROUBLESHOOTING.map((t) => (
                    <tr key={t.id} className="border-t border-brand-line align-top">
                      <td className="px-4 py-3 text-brand-ink font-semibold">{t.issue}</td>
                      <td className="px-4 py-3">{t.likely}</td>
                      <td className="px-4 py-3">{t.action}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* ────────────────────────────  12. STOP-WORK  ──────────────────────────── */}
          <section id="stop-work" className="mb-16">
            <h2 className="mt-4 mb-4 text-2xl sm:text-3xl font-extrabold text-brand-ink">
              12. Stop-work conditions
            </h2>
            <aside
              role="note"
              className="mb-6 rounded-md border border-red-500/40 bg-red-500/10 p-4 text-red-100"
            >
              <p className="text-sm leading-relaxed">
                <strong className="font-bold">Stop immediately</strong> when any of these appear.
                Reassess before continuing. Nothing about a paid job overrides these — a damaged
                surface is worse than a delayed one.
              </p>
            </aside>
            <ul className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {STOP_WORK_CONDITIONS.map((c) => (
                <li
                  key={c}
                  className="rounded-lg border border-brand-line bg-bg-elevated/30 p-3 text-sm text-brand-mute"
                >
                  {c}
                </li>
              ))}
            </ul>
          </section>

          {/* ────────────────────────────  13. CUSTOMER PREP  ──────────────────────────── */}
          <section id="customer-prep" className="mb-16">
            <h2 className="mt-4 mb-4 text-2xl sm:text-3xl font-extrabold text-brand-ink">
              13. Customer preparation
            </h2>
            <p className="text-brand-mute leading-relaxed mb-6">
              A short list of what to do before we show up. Everything below shortens the visit and
              keeps the crew focused on the actual cleaning.
            </p>
            <ul className="grid gap-2 sm:grid-cols-2">
              {CUSTOMER_PREP.map((c) => (
                <li
                  key={c}
                  className="flex items-start gap-2 rounded-lg border border-brand-line bg-bg-elevated/30 p-3 text-sm text-brand-mute"
                >
                  <span aria-hidden="true" className="mt-0.5 text-brand-accent">
                    ✓
                  </span>
                  <span>{c}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* ────────────────────────────  14. EXPECTATIONS  ──────────────────────────── */}
          <section id="expectations" className="mb-16">
            <h2 className="mt-4 mb-4 text-2xl sm:text-3xl font-extrabold text-brand-ink">
              14. What we promise — and what we do not
            </h2>
            <p className="text-brand-mute leading-relaxed mb-6">
              Brick Labor aims for the best safely achievable cleaning result on your surfaces.
              Sometimes the professional result is intentionally less aggressive than it could be.
              Here is where the line sits.
            </p>
            <div className="grid gap-5 md:grid-cols-2">
              <div className="rounded-xl border border-brand-line bg-bg-elevated/40 p-5">
                <p className="eyebrow mb-3 text-brand-accent">We will</p>
                <ul className="list-disc space-y-2 pl-5 text-sm text-brand-mute">
                  {CUSTOMER_EXPECTATIONS_PROMISE.map((p) => (
                    <li key={p}>{p}</li>
                  ))}
                </ul>
              </div>
              <div className="rounded-xl border border-brand-line bg-bg-elevated/40 p-5">
                <p className="eyebrow mb-3 text-brand-accent">We will not promise</p>
                <ul className="list-disc space-y-2 pl-5 text-sm text-brand-mute">
                  {CUSTOMER_EXPECTATIONS_LIMITS.map((p) => (
                    <li key={p}>{p}</li>
                  ))}
                </ul>
              </div>
            </div>
          </section>

          {/* ────────────────────────────  15. FAQ  ──────────────────────────── */}
          <section id="faq" className="mb-16">
            <h2 className="mt-4 mb-4 text-2xl sm:text-3xl font-extrabold text-brand-ink">
              15. Frequently asked questions
            </h2>
            <p className="text-brand-mute leading-relaxed mb-6">
              Straight answers to what customers ask most — the same policy as the rest of this
              page: what we can do, and what we will not overpromise.
            </p>
            <dl className="grid gap-3" data-testid="faq-list">
              {FAQ_ITEMS.map((f) => (
                <div
                  key={f.q}
                  className="rounded-xl border border-brand-line bg-bg-elevated/40 p-5"
                >
                  <dt className="font-semibold text-brand-ink mb-2">{f.q}</dt>
                  <dd className="text-sm text-brand-mute leading-relaxed">{f.a}</dd>
                </div>
              ))}
            </dl>
          </section>

          {/* ────────────────────────────  16. FIELD CHECKLIST  ──────────────────────────── */}
          <section id="field-checklist" className="mb-16">
            <h2 className="mt-4 mb-4 text-2xl sm:text-3xl font-extrabold text-brand-ink">
              16. Employee quick field checklist
            </h2>
            <p className="text-brand-mute leading-relaxed mb-4">
              The one-page card. Printable. If you can only remember one section, remember this one
              — it is the master workflow compressed into names.
            </p>
            <div className="rounded-xl border border-brand-line bg-bg-elevated/40 p-5 print:border-black print:bg-transparent print:text-black">
              <ol className="grid gap-1 sm:grid-cols-2 lg:grid-cols-3 text-sm">
                {FIELD_CHECKLIST.map((step, i) => (
                  <li key={step} className="flex items-baseline gap-2">
                    <span className="font-mono text-xs text-brand-accent print:text-black">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <span className="text-brand-mute print:text-black">{step}</span>
                  </li>
                ))}
              </ol>
            </div>
            <div className="mt-4 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => window.print()}
                className="rounded-md border border-brand-accent bg-brand-accent px-4 py-2 text-sm font-semibold text-black hover:bg-brand-accentHover print:hidden"
              >
                Print quick reference
              </button>
              <a
                href="#top"
                className="rounded-md border border-brand-line bg-bg-elevated/40 px-4 py-2 text-sm text-brand-mute hover:text-brand-accent print:hidden"
                onClick={(e) => {
                  e.preventDefault();
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
              >
                Back to top
              </a>
            </div>
          </section>

          <CtaBand testid="cta-bottom" heading="Rather we just handle it?" />

          <p className="mt-16 border-t border-brand-line pt-6 text-center text-xs text-brand-mute">
            Systematic, not aggressive. Least aggressive effective method — every job, every time.
          </p>
        </div>
      </article>
    </>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
 * Local components
 * ─────────────────────────────────────────────────────────────────────── */

/** Smooth-scroll to a section, honoring prefers-reduced-motion. */
function scrollToId(e: MouseEvent<HTMLAnchorElement>, id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  e.preventDefault();
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  el.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
  history.replaceState(null, '', `#${id}`);
}

function Breadcrumb() {
  return (
    <nav aria-label="Breadcrumb" className="mb-4" data-testid="breadcrumb">
      <ol className="flex flex-wrap items-center gap-1.5 text-xs text-brand-mute">
        {CRUMBS.map((c, i) => (
          <li key={c.label} className="flex items-center gap-1.5">
            {c.href ? (
              <a href={c.href} className="underline-hover hover:text-brand-accent">
                {c.label}
              </a>
            ) : (
              <span className="text-brand-ink" aria-current="page">
                {c.label}
              </span>
            )}
            {i < CRUMBS.length - 1 && (
              <span aria-hidden="true" className="text-brand-mute/50">
                /
              </span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}

function CtaBand({
  testid,
  heading = 'Want this done, not read?',
}: {
  testid?: string;
  heading?: string;
}) {
  return (
    <aside
      data-testid={testid}
      className="my-10 rounded-2xl border border-brand-accent/40 bg-brand-accent/10 p-6 sm:p-7"
    >
      <p className="text-lg font-bold text-brand-ink mb-1">{heading}</p>
      <p className="text-sm text-brand-mute leading-relaxed mb-4 max-w-2xl">
        Skip the manual — a Brick Labor crew brings the machines, chemistry, and this exact process
        to your property. Hourly, one-hour minimum, no surprises.
      </p>
      <div className="flex flex-wrap gap-3">
        <a
          href={BOOK_URL}
          className="inline-flex min-h-11 items-center rounded-md border border-brand-accent bg-brand-accent px-5 py-2.5 text-sm font-semibold text-black hover:bg-brand-accentHover"
          data-bcl-cta="book-power-washing"
        >
          Book a power-washing crew
        </a>
        <a
          href={SERVICE_URL}
          className="inline-flex min-h-11 items-center rounded-md border border-brand-line bg-bg-elevated/40 px-5 py-2.5 text-sm text-brand-mute hover:text-brand-accent"
          data-bcl-cta="power-washing-pricing"
        >
          See pricing & details
        </a>
      </div>
    </aside>
  );
}

function SequenceCard({ seq }: { seq: CleaningSequence }) {
  const machine = MACHINES.find((m) => m.id === seq.machine)!;
  const surface = SURFACES.find((s) => s.id === seq.surfaceId)!;
  const contam = CONTAMINANTS.find((c) => c.id === seq.contaminantId)!;
  return (
    <div className="rounded-xl border border-brand-line bg-bg-elevated/40 p-5 sm:p-6">
      <div className="flex flex-wrap items-baseline gap-3 mb-3">
        <h3 className="text-base font-bold text-brand-ink">{seq.title}</h3>
        <span className="rounded-full border border-brand-line bg-bg-primary px-2 py-0.5 text-[10px] uppercase tracking-wider text-brand-mute">
          {surface.name}
        </span>
        <span className="rounded-full border border-brand-line bg-bg-primary px-2 py-0.5 text-[10px] uppercase tracking-wider text-brand-mute">
          {contam.name}
        </span>
        <span className="rounded-full border border-brand-accent/40 bg-brand-accent/10 px-2 py-0.5 text-[10px] uppercase tracking-wider text-brand-accent">
          {machine.shortName}
        </span>
      </div>
      <ol className="mb-4 grid gap-1 pl-5 text-sm text-brand-mute [counter-reset:step]">
        {seq.steps.map((step, i) => (
          <li
            key={i}
            className="list-decimal marker:font-mono marker:text-xs marker:text-brand-accent"
          >
            {step}
          </li>
        ))}
      </ol>
      {seq.warning && (
        <aside
          role="note"
          className="mb-3 rounded-md border border-amber-400/40 bg-amber-400/10 p-3 text-sm text-amber-100"
        >
          <strong className="font-bold">Warning: </strong>
          {seq.warning}
        </aside>
      )}
      <p className="text-xs text-brand-mute">
        <span className="uppercase tracking-wider text-brand-mute/70">Expected result: </span>
        {seq.expected}
      </p>
    </div>
  );
}

function TechniqueCard({ title, body }: { title: string; body: string }) {
  return (
    <div className="mb-4 rounded-xl border border-brand-line bg-bg-elevated/40 p-5">
      <p className="eyebrow mb-2 text-brand-accent">{title}</p>
      <p className="text-sm text-brand-mute leading-relaxed">{body}</p>
    </div>
  );
}

function filterButtonClasses(active: boolean): string {
  const base = 'rounded-full border px-3 py-1 text-xs uppercase tracking-wider transition-colors';
  if (active) {
    return `${base} border-brand-accent bg-brand-accent/10 text-brand-accent`;
  }
  return `${base} border-brand-line bg-bg-elevated/40 text-brand-mute hover:text-brand-accent`;
}

/* ─────────────────────────────────────────────────────────────────────────
 * Local metadata helpers — copied from the shape used across Privacy /
 * Terms / policy pages. No shared usePageMeta exists in this repo.
 * ─────────────────────────────────────────────────────────────────────── */

function setMeta(name: string, content: string, attr: 'name' | 'property' = 'name') {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.head.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}

export default GuidePowerWashing;
export const THEME_TOOLS_POWER_WASH_PROTOCOLS_COUNT = Object.keys(POWER_WASH_PROTOCOLS).length;
