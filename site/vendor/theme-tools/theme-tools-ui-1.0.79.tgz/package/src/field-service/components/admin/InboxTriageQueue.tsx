import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { useCallback, useEffect, useState } from 'react';

/**
 * InboxTriageQueue — renders the `inbound_emails` table populated by the
 * Resend inbound webhook (`/api/resend-inbound`).
 *
 * Graceful-degrades: if the list endpoint 404s (table not yet wired), the
 * panel shows a configuration nudge instead of a broken state.
 *
 * Optimistic dismiss: "Mark handled" hides the row from local state
 * immediately. No backing endpoint yet — the row reappears on next refresh
 * until the dismiss API ships.
 */

type Severity = 'low' | 'normal' | 'high' | 'urgent';
type Category =
  | 'lead'
  | 'support'
  | 'complaint'
  | 'invoice'
  | 'spam'
  | 'partner'
  | 'press'
  | 'other';

interface InboundEmail {
  id: string;
  from_email: string;
  from_name: string | null;
  subject: string;
  received_at: string;
  category: Category | null;
  severity: Severity | null;
  ai_draft_reply: string | null;
  snippet: string | null;
}

interface ListResponse {
  ok: boolean;
  emails?: InboundEmail[];
  error?: string;
}

const SEVERITY_DOT: Record<Severity, string> = {
  low: 'bg-brand-mute',
  normal: 'bg-brand-accent',
  high: 'bg-amber-400',
  urgent: 'bg-red-500',
};

const CATEGORY_BADGE: Record<Category, string> = {
  lead: 'border-brand-accent/50 bg-brand-accent/10 text-brand-accent',
  support: 'border-brand-line bg-bg-primary text-brand-ink',
  complaint: 'border-red-500/50 bg-red-500/10 text-red-300',
  invoice: 'border-amber-400/50 bg-amber-400/10 text-amber-300',
  spam: 'border-brand-line bg-bg-primary text-brand-mute line-through',
  partner: 'border-emerald-400/50 bg-emerald-400/10 text-emerald-300',
  press: 'border-violet-400/50 bg-violet-400/10 text-violet-300',
  other: 'border-brand-line bg-bg-primary text-brand-mute',
};

export function InboxTriageQueue({ bearer }: { bearer: string }) {
  useThemeToolsSurface('inbox-triage-queue');
  const [rows, setRows] = useState<InboundEmail[]>([]);
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(false);
  const [tableMissing, setTableMissing] = useState(false);

  const headers = useCallback(
    (): HeadersInit => ({
      'content-type': 'application/json',
      authorization: `Bearer ${bearer}`,
    }),
    [bearer],
  );

  const refresh = useCallback(async () => {
    if (!bearer) return;
    setLoading(true);
    setStatus('');
    try {
      const res = await fetch('/api/admin/inbound-emails?limit=50', { headers: headers() });
      if (res.status === 404) {
        setTableMissing(true);
        setRows([]);
        return;
      }
      const json = (await res.json()) as ListResponse;
      if (!res.ok || !json.ok) {
        setStatus(json.error ?? `HTTP ${res.status}`);
        setRows([]);
      } else {
        setTableMissing(false);
        setRows(json.emails ?? []);
      }
    } catch (err) {
      setStatus((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, [bearer, headers]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  function dismiss(id: string) {
    setDismissed((prev) => {
      const next = new Set(prev);
      next.add(id);
      return next;
    });
  }

  const visible = rows.filter((r) => !dismissed.has(r.id));

  if (!bearer) {
    return (
      <section className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
        <h2 className="text-xl font-bold text-brand-ink">Inbox triage</h2>
        <p className="mt-2 text-sm text-brand-mute">
          Add the owner key above to load inbound mail.
        </p>
      </section>
    );
  }

  return (
    <section className="rounded-2xl border border-brand-line bg-bg-elevated p-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-brand-ink">Inbox triage</h2>
          <p className="mt-1 text-sm text-brand-mute">
            Inbound mail classified by AI. Reply drafts pre-staged.
          </p>
        </div>
        <button
          type="button"
          onClick={() => void refresh()}
          disabled={loading}
          className="rounded-md border border-brand-line bg-bg-primary px-3 py-1.5 text-xs text-brand-ink hover:border-brand-accent disabled:opacity-50"
        >
          {loading ? 'Loading…' : 'Refresh'}
        </button>
      </div>

      {tableMissing && (
        <div className="mt-4 rounded-md border border-dashed border-brand-line p-4 text-sm text-brand-mute">
          Configure the Resend webhook to populate this queue — see{' '}
          <a href="/sources" className="text-brand-accent underline">
            /sources
          </a>{' '}
          for setup details.
        </div>
      )}

      {!tableMissing && visible.length === 0 && !loading && (
        <div className="mt-4 rounded-md border border-dashed border-brand-line p-4 text-sm text-brand-mute">
          Inbox empty — every triaged item has been handled.
        </div>
      )}

      {visible.length > 0 && (
        <ul className="mt-4 space-y-3">
          {visible.map((m) => {
            const sev = m.severity ?? 'normal';
            const cat = m.category ?? 'other';
            return (
              <li
                key={m.id}
                className="rounded-md border border-brand-line bg-bg-primary p-3 text-sm"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        aria-label={`severity ${sev}`}
                        className={`inline-block h-2 w-2 rounded-full ${SEVERITY_DOT[sev]}`}
                      />
                      <span
                        className={`rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-widest ${CATEGORY_BADGE[cat]}`}
                      >
                        {cat}
                      </span>
                      <span className="truncate font-semibold text-brand-ink">
                        {m.from_name ?? m.from_email}
                      </span>
                      <span className="font-mono text-[10px] text-brand-mute">
                        {new Date(m.received_at).toLocaleString()}
                      </span>
                    </div>
                    <p className="mt-1 truncate text-brand-ink">{m.subject}</p>
                    {m.snippet && (
                      <p className="mt-1 line-clamp-2 text-xs text-brand-mute">{m.snippet}</p>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => dismiss(m.id)}
                    className="shrink-0 rounded-md border border-brand-line bg-bg-elevated px-2 py-1 text-xs text-brand-ink hover:border-brand-accent"
                  >
                    Mark handled
                  </button>
                </div>
                {m.ai_draft_reply && (
                  <details className="mt-2">
                    <summary className="cursor-pointer font-mono text-[10px] uppercase tracking-widest text-brand-accent">
                      AI draft reply
                    </summary>
                    <pre className="mt-2 whitespace-pre-wrap rounded-md border border-brand-line bg-bg-elevated p-2 font-mono text-xs text-brand-ink">
                      {m.ai_draft_reply}
                    </pre>
                  </details>
                )}
              </li>
            );
          })}
        </ul>
      )}

      {status && <p className="mt-3 text-xs text-brand-mute">{status}</p>}
    </section>
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
