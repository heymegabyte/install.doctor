import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useState } from 'react';
import { useFeatureFlag } from '../use-feature-flag.js';

interface CaseStudyCardProps {
  bookingId: string;
  /** Human-readable service name, e.g. "Moving Help". */
  jobType?: string;
  /** ISO date string for the job date. */
  jobDate?: string;
}

/**
 * CaseStudyCard — download-card for the case-study PDF on job detail pages.
 *
 * Gated behind `case_study_pdf` flag. Exists only to offer the download;
 * the PDF is generated server-side by the job-complete hook.
 *
 * States:
 *  idle   → card with download CTA
 *  loading → spinner + disabled button
 *  error  → fallback message with contact prompt
 */
export default function CaseStudyCard({ bookingId, jobType, jobDate }: CaseStudyCardProps) {
  useThemeToolsSurface('case-study-card');
  const enabled = useFeatureFlag('case_study_pdf');
  const [downloading, setDownloading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!enabled) return null;

  const handleDownload = async () => {
    setDownloading(true);
    setError(null);
    try {
      const res = await fetch(`/api/case-study-pdf/booking/${encodeURIComponent(bookingId)}.pdf`, {
        credentials: 'same-origin',
      });
      if (!res.ok) throw new Error(`status ${res.status}`);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `bricklabor-case-study-${bookingId.slice(0, 8)}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch {
      setError("Your case study isn't available yet. Try again in a moment.");
    } finally {
      setDownloading(false);
    }
  };

  const formattedDate = jobDate
    ? new Date(jobDate).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      })
    : '';

  return (
    <section data-testid="case-study-card">
      <div className="rounded-2xl border border-brand-line bg-gradient-to-br from-brand-accent/5 to-transparent p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center gap-4">
        {/* PDF icon */}
        <div
          className="shrink-0 flex h-12 w-12 items-center justify-center rounded-xl border border-brand-accent/30 bg-brand-accent/10"
          aria-hidden="true"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            className="h-6 w-6 text-brand-accent"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z"
            />
          </svg>
        </div>

        {/* Text + meta */}
        <div className="min-w-0 flex-1 space-y-1">
          <p className="text-sm font-bold text-brand-ink">Download your project case study</p>
          {(jobType || formattedDate) && (
            <p className="text-xs text-brand-mute">
              {[jobType?.replace(/-/g, ' '), formattedDate].filter(Boolean).join(' · ')}
            </p>
          )}
          <p className="text-[11px] text-brand-mute/70 leading-relaxed">
            A 1-page recap of what we did — share it with a neighbor for $25 off their first job.
          </p>
        </div>

        {/* Action */}
        <div className="shrink-0 self-stretch sm:self-center flex items-center">
          <button
            type="button"
            onClick={handleDownload}
            disabled={downloading}
            data-testid="case-study-download"
            className="inline-flex items-center gap-2 rounded-lg border border-brand-accent bg-brand-accent px-4 py-2 text-sm font-bold text-brand-bg hover:opacity-90 transition-all duration-[333ms] disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {downloading ? (
              <>
                <svg
                  className="h-4 w-4 animate-spin"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
                  />
                </svg>
                <span>Generating…</span>
              </>
            ) : (
              <>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                  className="h-4 w-4"
                  aria-hidden="true"
                >
                  <path d="M10.75 2.75a.75.75 0 00-1.5 0v8.614L6.295 8.235a.75.75 0 10-1.09 1.03l4.25 4.5a.75.75 0 001.09 0l4.25-4.5a.75.75 0 00-1.09-1.03l-2.955 3.129V2.75z" />
                  <path d="M3.5 12.75a.75.75 0 00-1.5 0v2.5A2.75 2.75 0 004.75 18h10.5A2.75 2.75 0 0018 15.25v-2.5a.75.75 0 00-1.5 0v2.5c0 .69-.56 1.25-1.25 1.25H4.75c-.69 0-1.25-.56-1.25-1.25v-2.5z" />
                </svg>
                <span>Download PDF</span>
              </>
            )}
          </button>
        </div>
      </div>

      {error && (
        <p
          role="alert"
          data-testid="case-study-error"
          className="mt-2 text-xs text-amber-300/90"
        >
          {error}
        </p>
      )}
    </section>
  );
}
