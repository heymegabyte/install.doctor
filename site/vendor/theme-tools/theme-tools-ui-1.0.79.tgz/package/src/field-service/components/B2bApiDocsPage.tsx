import { useThemeToolsSurface } from '../../field-service-primitives.js';
import { useEffect } from 'react';
import { JsonLd } from './seo/index.js';

const TITLE = 'B2B API — white-label labor dispatch · Brick Labor';
const DESC =
  'Drop Brick Labor crews into your relocation platform. Bearer-auth REST API, JSON in, tracker URL out. Volume-based pricing for movers and property tech.';

const CURL_SAMPLE = String.raw`curl -X POST https://bricklabor.com/api/b2b/dispatch \
  -H "Authorization: Bearer $PARTNER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "partnerId": "prt_abc123",
    "externalRef": "ORDER-12345",
    "customer": {
      "name": "Jane Doe",
      "email": "jane@example.com",
      "phone": "+19735551234"
    },
    "service": {
      "address": "123 Broad St",
      "city": "Newark",
      "zip": "07102",
      "services": ["haul"],
      "preferredDate": "2026-06-12",
      "preferredTime": "09:00",
      "hours": 4,
      "crew": 2,
      "notes": "Two-bedroom apartment, ground floor."
    }
  }'`;

const NODE_SAMPLE = String.raw`const res = await fetch('https://bricklabor.com/api/b2b/dispatch', {
  method: 'POST',
  headers: {
    Authorization: \`Bearer \${process.env.PARTNER_TOKEN}\`,
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    partnerId: 'prt_abc123',
    externalRef: 'ORDER-12345',
    customer: { name: 'Jane Doe', email: 'jane@example.com', phone: '+19735551234' },
    service: {
      address: '123 Broad St',
      city: 'Newark',
      zip: '07102',
      services: ['haul'],
      preferredDate: '2026-06-12',
      preferredTime: '09:00',
      hours: 4,
      crew: 2,
      notes: 'Two-bedroom apartment, ground floor.',
    },
  }),
});
const data = await res.json(); // { ok, bookingId, trackerUrl, totalCents, surge }`;

const RESPONSE_SAMPLE = String.raw`{
  "ok": true,
  "bookingId": "8f3e1c20-2f4b-4e2a-9c75-7a1c9c3a1f2b",
  "trackerUrl": "https://bricklabor.com/track/8f3e1c20-2f4b-4e2a-9c75-7a1c9c3a1f2b",
  "totalCents": 41200,
  "surge": {
    "multiplier": 1.03,
    "cents": 1200,
    "reasons": [{"kind": "peak-hours", "factor": 1.03, "label": "Peak hours", "detail": "9am start"}]
  }
}`;

/**
 * /b2b — public docs page for the white-label dispatch API. Shows the
 * endpoint, code samples, error envelope, rate limits, and pricing posture.
 * Tone: technical, no marketing fluff. Treats integrators as competent.
 *
 * Pricing copy is intentionally directional ("volume-based monthly fee +
 * per-move flat") — Brian sets actual numbers per contract.
 */
export function B2bApiDocsPage(): JSX.Element {
  useThemeToolsSurface('b2b-api-docs-page');
  useEffect(() => {
    document.title = TITLE;
    setMeta('description', DESC);
    setLink('canonical', 'https://bricklabor.com/b2b');
    setMeta('robots', 'index,follow', 'name');
    setMeta('og:title', TITLE, 'property');
    setMeta('og:description', DESC, 'property');
    setMeta('og:url', 'https://bricklabor.com/b2b', 'property');
  }, []);

  return (
    <article className="section">
      <div className="container-pad max-w-4xl">
        <p className="eyebrow mb-3">B2B API</p>
        <h1 className="text-4xl sm:text-5xl font-extrabold">
          White-label labor dispatch in <span className="text-brand-accent">one POST</span>.
        </h1>
        <p className="mt-4 text-lg text-brand-mute">
          Built for relocation platforms, moving brokers, property tech, and storage operators who
          want a vetted crew on the ground in Newark and the broader NJ + NYC metro without building
          dispatch themselves.
        </p>

        <nav className="mt-8 flex flex-wrap gap-3 text-sm">
          <a href="#auth" className="text-brand-accent underline-hover">
            Auth
          </a>
          <a href="#dispatch" className="text-brand-accent underline-hover">
            Dispatch
          </a>
          <a href="#response" className="text-brand-accent underline-hover">
            Response
          </a>
          <a href="#errors" className="text-brand-accent underline-hover">
            Errors
          </a>
          <a href="#rate-limits" className="text-brand-accent underline-hover">
            Rate limits
          </a>
          <a href="#pricing" className="text-brand-accent underline-hover">
            Pricing
          </a>
        </nav>

        <section id="auth" className="mt-10">
          <h2 className="text-2xl font-extrabold mb-3">Authentication</h2>
          <p className="text-brand-mute leading-relaxed">
            Every request requires an{' '}
            <code className="rounded bg-bg-elevated px-1.5 py-0.5">Authorization: Bearer</code>{' '}
            header. Tokens are issued per integration; rotate them by emailing{' '}
            <a
              href="mailto:hey@bricklabor.com?subject=B2B%20token%20rotation"
              className="text-brand-accent underline-hover"
            >
              hey@bricklabor.com
            </a>
            . Token compare is constant-time on our side.
          </p>
          <p className="text-brand-mute leading-relaxed mt-3">
            The body also carries a <code>partnerId</code> (your{' '}
            <code className="rounded bg-bg-elevated px-1.5 py-0.5">prt_*</code> id from{' '}
            <a href="/partners" className="text-brand-accent underline-hover">
              /partners
            </a>{' '}
            signup). The bearer authenticates the channel; partnerId identifies which downstream
            partner you're dispatching for — useful when one integrator routes dispatches for many
            sub-accounts.
          </p>
        </section>

        <section id="dispatch" className="mt-10">
          <h2 className="text-2xl font-extrabold mb-3">POST /api/b2b/dispatch</h2>
          <p className="text-brand-mute leading-relaxed">
            Drops a labor request into our dispatch queue. Returns a tracker URL you can hand to
            your end-user.
          </p>

          <h3 className="text-base font-extrabold mt-6 mb-2">Body schema</h3>
          <ul className="text-sm text-brand-mute leading-relaxed space-y-1">
            <li>
              <code>partnerId</code> — required, your <code>prt_*</code> id.
            </li>
            <li>
              <code>externalRef</code> — optional, your internal order id; surfaced in our admin and
              on operator alerts.
            </li>
            <li>
              <code>customer.name</code>, <code>customer.email</code> — required.{' '}
              <code>customer.phone</code> — optional, E.164 strongly preferred.
            </li>
            <li>
              <code>service.address</code> — required service address. <code>service.city</code> /{' '}
              <code>service.zip</code> — optional.
            </li>
            <li>
              <code>service.services</code> — array of{' '}
              <code>power-wash | lawn | haul | repairs | cleanout | seasonal | other</code>.
            </li>
            <li>
              <code>service.preferredDate</code> — <code>YYYY-MM-DD</code>.{' '}
              <code>service.preferredTime</code> — <code>HH:MM</code> 24-hour or label (
              <code>morning</code> / <code>afternoon</code> / <code>flexible</code>).
            </li>
            <li>
              <code>service.hours</code> — 1-12. <code>service.crew</code> — 1-20.
            </li>
          </ul>

          <h3 className="text-base font-extrabold mt-6 mb-2">curl</h3>
          <CodeBlock code={CURL_SAMPLE} lang="bash" />

          <h3 className="text-base font-extrabold mt-6 mb-2">Node 22 / Bun</h3>
          <CodeBlock code={NODE_SAMPLE} lang="ts" />
        </section>

        <section id="response" className="mt-10">
          <h2 className="text-2xl font-extrabold mb-3">Response</h2>
          <p className="text-brand-mute leading-relaxed">
            <code className="rounded bg-bg-elevated px-1.5 py-0.5">200 OK</code> on accept. The
            booking is now in our dispatch queue and your <code>trackerUrl</code> is shareable
            immediately.
          </p>
          <CodeBlock code={RESPONSE_SAMPLE} lang="json" />
        </section>

        <section id="errors" className="mt-10">
          <h2 className="text-2xl font-extrabold mb-3">Errors</h2>
          <p className="text-brand-mute leading-relaxed mb-3">
            Error envelope is always{' '}
            <code className="rounded bg-bg-elevated px-1.5 py-0.5">
              {`{ ok: false, error: string, code: string }`}
            </code>
            .
          </p>
          <ul className="text-sm text-brand-mute leading-relaxed space-y-1">
            <li>
              <code>401 unauthorized</code> — bearer missing or wrong.
            </li>
            <li>
              <code>403 partner_inactive</code> — partner exists but is paused or offboarded.
            </li>
            <li>
              <code>404 unknown_partner</code> — <code>partnerId</code> not on file.
            </li>
            <li>
              <code>400 invalid_input</code> — schema validation failed; the <code>error</code>{' '}
              field contains the failing path.
            </li>
            <li>
              <code>429 rate_limit</code> — 100 calls / hour / partner exceeded.
            </li>
            <li>
              <code>503 b2b_not_configured</code> — endpoint disabled for this environment.
            </li>
          </ul>
        </section>

        <section id="rate-limits" className="mt-10">
          <h2 className="text-2xl font-extrabold mb-3">Rate limits</h2>
          <p className="text-brand-mute leading-relaxed">
            100 dispatches per hour per <code>partnerId</code>. Need more? Email{' '}
            <a
              href="mailto:hey@bricklabor.com?subject=B2B%20rate%20limit"
              className="text-brand-accent underline-hover"
            >
              hey@bricklabor.com
            </a>{' '}
            with your projected daily volume.
          </p>
        </section>

        <section id="pricing" className="mt-10">
          <h2 className="text-2xl font-extrabold mb-3">Pricing</h2>
          <p className="text-brand-mute leading-relaxed">
            Volume-based monthly fee plus a per-move flat rate. Exact numbers depend on geography,
            crew size mix, and SLA. Email{' '}
            <a
              href="mailto:hey@bricklabor.com?subject=B2B%20pricing"
              className="text-brand-accent underline-hover"
            >
              hey@bricklabor.com
            </a>{' '}
            with your monthly move volume and we'll send a one-page quote within a business day.
          </p>
        </section>

        <section className="mt-10 rounded-xl border border-brand-line p-6 bg-bg-elevated/40">
          <h2 className="text-xl font-extrabold">Related</h2>
          <ul className="mt-2 space-y-1 text-brand-mute">
            <li>
              <a href="/partners" className="text-brand-accent underline-hover">
                /partners
              </a>{' '}
              — get your <code>partnerId</code> + tracked Dub link.
            </li>
            <li>
              <a href="/integrations" className="text-brand-accent underline-hover">
                /integrations
              </a>{' '}
              — live partner ecosystem.
            </li>
            <li>
              <a href="/property-managers" className="text-brand-accent underline-hover">
                /property-managers
              </a>{' '}
              — Free-Move concierge product.
            </li>
          </ul>
        </section>
      </div>

      <JsonLd
        data={{
          '@context': 'https://schema.org',
          '@type': 'TechArticle',
          '@id': 'https://bricklabor.com/b2b',
          url: 'https://bricklabor.com/b2b',
          name: TITLE,
          headline: 'White-label labor dispatch API',
          description: DESC,
          articleSection: 'API documentation',
          inLanguage: 'en-US',
          publisher: { '@id': 'https://bricklabor.com/#org' },
        }}
      />
    </article>
  );
}

function CodeBlock({ code, lang }: { code: string; lang: string }): JSX.Element {
  return (
    <pre className="mt-2 overflow-x-auto rounded-lg border border-brand-line bg-bg-elevated p-4 text-xs leading-relaxed text-brand-ink">
      <code className={`language-${lang}`}>{code}</code>
    </pre>
  );
}

function setMeta(name: string, content: string, attr: 'name' | 'property' = 'name') {
  let el = document.querySelector<HTMLMetaElement>(`meta[${attr}="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string) {
  let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}
