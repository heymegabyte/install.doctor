import { useThemeToolsSurface } from '../../../../field-service-primitives.js';
import { FIELD_SERVICE_PLATFORM_PILLARS } from '@theme-tools/shared-utils/field-service-platform-standards';
import { WidgetShell } from './WidgetShell.js';

interface Cohort {
  cohort: string;
  size: number;
  retention: number[];
}

export default function CohortRetention({ adminKey }: { adminKey: string }) {
  useThemeToolsSurface('cohort-retention');
  return (
    <WidgetShell
      title="Cohort retention (monthly)"
      endpoint="/cohort-retention"
      adminKey={adminKey}
      render={(raw) => {
        const d = raw as { empty?: boolean; cohorts?: Cohort[] };
        if (d.empty || !d.cohorts || d.cohorts.length === 0)
          return <p style={{ color: '#888' }}>No cohorts yet.</p>;
        return (
          <div style={{ overflowX: 'auto', fontSize: 11 }}>
            <table style={{ borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={{ padding: 4, textAlign: 'left' }}>cohort</th>
                  <th style={{ padding: 4 }}>n</th>
                  {Array.from({ length: 6 }, (_, i) => (
                    <th key={i} style={{ padding: 4 }}>
                      M{i}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {d.cohorts.slice(-12).map((c) => (
                  <tr key={c.cohort}>
                    <td style={{ padding: 4 }}>{c.cohort}</td>
                    <td style={{ padding: 4 }}>{c.size}</td>
                    {Array.from({ length: 6 }, (_, i) => {
                      const v = c.retention[i];
                      const pct = v == null ? '' : `${Math.round(v * 100)}%`;
                      const bg = v == null ? 'transparent' : `rgba(124,58,237,${Math.min(1, v)})`;
                      return (
                        <td
                          key={i}
                          style={{ padding: 4, background: bg, textAlign: 'center', minWidth: 32 }}
                        >
                          {pct}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      }}
    />
  );
}
export const THEME_TOOLS_PILLAR_COUNT = FIELD_SERVICE_PLATFORM_PILLARS.length;
