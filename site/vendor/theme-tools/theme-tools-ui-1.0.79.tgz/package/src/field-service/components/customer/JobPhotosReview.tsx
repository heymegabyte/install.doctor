import { useThemeToolsSurface } from '../../../field-service-primitives.js';
import { UNIVERSAL_PREP } from '@theme.tools/forms/field-service-checklists';
import { useEffect, useMemo, useState } from 'react';
import PhotoGallery from '../jobs/PhotoGallery.js';
import RecapPdfButton from '../jobs/RecapPdfButton.js';
import type { JobPhoto, JobPhotosResponse } from '@theme.tools/scheduling/field-service/photo-types';
import { REQUIRED_PHOTOS_PER_KIND } from '@theme.tools/scheduling/field-service/photo-types';

interface JobPhotosReviewProps {
  readonly bookingId: string;
  /** Override fetch impl for tests. */
  readonly fetchImpl?: typeof fetch;
  /**
   * Approval callback fires when the customer presses "Approve & release
   * payment". Caller should POST to `/api/jobs/:id/complete` (already wired)
   * OR the dedicated approval endpoint (Wave 4G). Defaults to a soft no-op
   * when omitted so the component is safe to render in a story/preview.
   */
  readonly onApprove?: () => Promise<void> | void;
  /** Same shape for damage flag. */
  readonly onFlagDamage?: (note: string) => Promise<void> | void;
}

/**
 * Customer-facing approval gate shown after the crew uploads 4+ end-phase
 * photos. The customer sees the 4 completion photos, can approve (releases
 * the remainder payment via Square) OR flag damage (opens a free-text note
 * + escalates to ops). When the booking is already locked, the gate shows a
 * read-only confirmation panel + recap PDF button.
 */
export default function JobPhotosReview({
  bookingId,
  fetchImpl,
  onApprove,
  onFlagDamage,
}: JobPhotosReviewProps) {
  useThemeToolsSurface('job-photos-review');
  const f = fetchImpl ?? fetch;
  const [photos, setPhotos] = useState<readonly JobPhoto[]>([]);
  const [counts, setCounts] = useState<{ start: number; end: number; required: number } | null>(
    null,
  );
  const [lockedAt, setLockedAt] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<'approve' | 'flag' | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [showFlagForm, setShowFlagForm] = useState(false);
  const [flagNote, setFlagNote] = useState('');

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await f(`/api/jobs/${encodeURIComponent(bookingId)}/photos`, {
          credentials: 'include',
        });
        if (!res.ok) {
          if (!cancelled)
            setError(res.status === 401 ? 'Sign in to review job photos.' : `http_${res.status}`);
          return;
        }
        const data = (await res.json()) as JobPhotosResponse;
        if (!cancelled) {
          setPhotos(data.photos);
          setCounts(data.counts);
          setLockedAt(data.completionLockedAt);
        }
      } catch (err) {
        if (!cancelled) setError((err as Error).message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [bookingId, f]);

  const endPhotos = useMemo(() => photos.filter((p) => p.kind === 'end'), [photos]);
  const enoughEnd =
    (counts?.end ?? endPhotos.length) >= (counts?.required ?? REQUIRED_PHOTOS_PER_KIND);
  const anyDamage = endPhotos.some((p) => p.ai.damage);

  const handleApprove = async () => {
    setBusy('approve');
    setError(null);
    try {
      if (onApprove) {
        await onApprove();
      } else {
        const res = await f(`/api/jobs/${encodeURIComponent(bookingId)}/complete`, {
          method: 'POST',
          credentials: 'include',
        });
        if (!res.ok) {
          const data = (await res.json().catch(() => ({}))) as { error?: string };
          throw new Error(data.error ?? `http_${res.status}`);
        }
        const data = (await res.json()) as { completionLockedAt?: number };
        if (data.completionLockedAt) setLockedAt(data.completionLockedAt);
      }
      setSuccess('Approved. Payment released to the crew. Thanks for the work.');
    } catch (err) {
      setError((err as Error).message || 'Approval failed.');
    } finally {
      setBusy(null);
    }
  };

  const handleFlag = async () => {
    setBusy('flag');
    setError(null);
    try {
      if (onFlagDamage) {
        await onFlagDamage(flagNote.trim());
      } else {
        // Fallback: post to the incidents endpoint so ops triages it.
        await f('/api/incidents', {
          method: 'POST',
          credentials: 'include',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            bookingId,
            kind: 'property_damage',
            severity: 'medium',
            body: flagNote.trim() || 'Customer flagged damage from end-phase photos.',
          }),
        }).catch(() => undefined);
      }
      setSuccess('Damage flagged. Our ops team will reach out within 24 hours.');
      setShowFlagForm(false);
    } catch (err) {
      setError((err as Error).message || 'Failed to flag damage.');
    } finally {
      setBusy(null);
    }
  };

  if (loading) {
    return <p className="text-brand-mute">Loading job recap…</p>;
  }
  if (error && !photos.length) {
    return (
      <p role="alert" className="text-brand-err">
        {error}
      </p>
    );
  }

  if (lockedAt) {
    return (
      <section className="space-y-6" data-testid="job-photos-review">
        <div className="rounded-xl border border-brand-ok/40 bg-brand-ok/10 p-4 text-brand-ink">
          <p className="font-display font-bold">Job approved.</p>
          <p className="text-sm text-brand-mute">
            Locked at {new Date(lockedAt).toLocaleString()}.
          </p>
        </div>
        <RecapPdfButton bookingId={bookingId} fetchImpl={f} />
        <PhotoGallery bookingId={bookingId} initialPhotos={photos} fetchImpl={f} />
      </section>
    );
  }

  return (
    <section className="space-y-6" data-testid="job-photos-review">
      <header className="space-y-2">
        <h2 className="text-2xl font-display font-bold text-brand-ink">Review your job</h2>
        <p className="text-brand-mute">
          The crew uploaded {endPhotos.length} completion photo{endPhotos.length === 1 ? '' : 's'}.
          Approve to release the remainder payment, or flag damage if something looks off.
        </p>
      </header>

      {anyDamage && (
        <div
          role="alert"
          className="rounded-xl border border-brand-warn/40 bg-brand-warn/10 p-4 text-brand-ink"
        >
          Our vision review noticed possible damage in {endPhotos.filter((p) => p.ai.damage).length}{' '}
          photo(s). Look closely before approving.
        </div>
      )}

      <PhotoGallery bookingId={bookingId} initialPhotos={photos} fetchImpl={f} />

      <div className="flex flex-wrap gap-3">
        <button
          type="button"
          onClick={handleApprove}
          disabled={!enoughEnd || busy !== null}
          className="btn-primary"
          data-testid="approve-button"
        >
          {busy === 'approve' ? 'Approving…' : 'Approve & release payment'}
        </button>
        <button
          type="button"
          onClick={() => setShowFlagForm((v) => !v)}
          disabled={busy !== null}
          className="btn-ghost"
          data-testid="flag-damage-button"
        >
          Flag damage
        </button>
        <RecapPdfButton bookingId={bookingId} fetchImpl={f} />
      </div>

      {!enoughEnd && (
        <p className="text-sm text-brand-mute">
          Waiting on {REQUIRED_PHOTOS_PER_KIND - endPhotos.length} more completion photo
          {REQUIRED_PHOTOS_PER_KIND - endPhotos.length === 1 ? '' : 's'} before you can approve.
        </p>
      )}

      {showFlagForm && (
        <form
          onSubmit={(ev) => {
            ev.preventDefault();
            void handleFlag();
          }}
          className="space-y-3 rounded-xl border border-brand-line bg-bg-elevated p-4"
        >
          <label className="block">
            <span className="text-sm font-display font-semibold text-brand-ink">
              What looks off?
            </span>
            <textarea
              value={flagNote}
              onChange={(ev) => setFlagNote(ev.target.value)}
              maxLength={1000}
              rows={4}
              className="mt-1 w-full rounded-lg border border-brand-line bg-bg-primary p-3 text-brand-ink placeholder:text-brand-mute focus:border-brand-accent focus:outline-none"
              placeholder="Describe the damage or concern…"
              data-testid="flag-note-input"
            />
          </label>
          <button
            type="submit"
            disabled={busy !== null}
            className="btn-primary"
            data-testid="flag-submit"
          >
            {busy === 'flag' ? 'Sending…' : 'Send to ops'}
          </button>
        </form>
      )}

      {error && (
        <p role="alert" className="text-sm text-brand-err">
          {error}
        </p>
      )}
      {success && (
        <p role="status" className="text-sm text-brand-ok">
          {success}
        </p>
      )}
    </section>
  );
}
export const THEME_TOOLS_UNIVERSAL_PREP_COUNT = UNIVERSAL_PREP.length;
