import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * LiveCrewTrackMap.tsx — the customer's "your crew is on the way" map on /track.
 *
 * The worker's `GET /api/track/:id` snapshot already serves a `liveMap` payload
 * (destination coords + the lead crew's live GPS position from `CrewLocationDO`)
 * whenever the `live_job_map` flag is on — but nothing rendered it, so the
 * customer only ever saw the text ETA pill (`LiveEtaTracker`). This component
 * closes that mounted-backend-no-frontend gap: it turns the same snapshot into
 * the Uber/Lyft live map — a dark Mapbox image with the destination pin + the
 * moving crew pin(s), auto-fit to both.
 *
 * The map refreshes whenever `TrackBooking` re-polls — which `subscribeTrackEvents`
 * fires on every dispatch transition (en route → arrived → …) plus a 30s
 * heartbeat — so the crew marker walks toward the destination without any extra
 * socket on this page. A token-free OSM static image (not a GL canvas) keeps the
 * heavy GL bundle off this money-path page (TTFR-safe), mirroring `LiveCrewMapPage`.
 *
 * Renders `null` when the flag is off (`liveMap.enabled === false`) or there is
 * no marker to show. Fails soft to an "unavailable" line if the URL can't be
 * built — never a broken image.
 */

import type { StatusLocale } from '@theme.tools/scheduling/field-service/booking-status';
import { trackCopy } from '@theme.tools/i18n-a11y/field-service/track-copy';
import { buildTrackStaticMapUrl } from '../track-map.js';

export interface TrackLiveMapCrew {
  readonly workerId?: string;
  readonly lat: number;
  readonly lng: number;
  readonly heading?: number | null;
  readonly ts?: number;
  readonly etaSeconds?: number | null;
  readonly distanceMeters?: number | null;
}

export interface TrackLiveMap {
  readonly enabled: boolean;
  readonly dest?: { lat: number; lng: number; address?: string } | null;
  readonly crewPositions?: readonly TrackLiveMapCrew[];
}

interface Props {
  readonly liveMap?: TrackLiveMap | null;
  readonly locale?: StatusLocale;
}

const MAP_W = 640;
const MAP_H = 400;

export function LiveCrewTrackMap({ liveMap, locale = 'en' }: Props): JSX.Element | null {
  useThemeToolsSurface('live-crew-track-map');
  const t = trackCopy(locale);

  const enabled = !!liveMap?.enabled;
  const dest = liveMap?.dest ?? null;
  const crew = liveMap?.crewPositions ?? [];
  const hasMarkers =
    (!!dest && Number.isFinite(dest.lat) && Number.isFinite(dest.lng)) || crew.length > 0;

  if (!enabled || !hasMarkers) return null;

  const crewLive = crew.length > 0;
  const url = buildTrackStaticMapUrl({
    dest:
      dest && Number.isFinite(dest.lat) && Number.isFinite(dest.lng)
        ? { lat: dest.lat, lng: dest.lng }
        : null,
    crew: crew
      .filter((c) => Number.isFinite(c.lat) && Number.isFinite(c.lng))
      .map((c) => ({ lat: c.lat, lng: c.lng, heading: c.heading ?? null })),
    width: MAP_W,
    height: MAP_H,
  });

  return (
    <section
      className="overflow-hidden rounded-2xl border border-white/10 bg-black/30 shadow-md transition-all duration-[333ms]"
      data-testid="live-crew-track-map"
      aria-label={t.liveMapTitle}
    >
      <header className="flex items-center justify-between px-5 pb-3 pt-4">
        <h3 className="text-sm uppercase tracking-wider text-brand-accent">{t.liveMapTitle}</h3>
        <span
          className={`rounded-full px-3 py-1 text-xs font-semibold transition-all duration-[333ms] ${
            crewLive
              ? 'bg-brand-accent/15 text-brand-accent'
              : 'bg-white/10 text-white/70'
          }`}
          role="status"
          aria-live="polite"
        >
          {crewLive ? t.liveMapCrewLive : t.liveMapWaiting}
        </span>
      </header>

      {url ? (
        <img
          src={url}
          alt={crewLive ? t.liveMapCrewAlt : t.liveMapDestAlt}
          width={MAP_W}
          height={MAP_H}
          loading="lazy"
          decoding="async"
          className="block aspect-[16/10] w-full object-cover"
        />
      ) : (
        <p className="px-5 pb-6 text-sm text-white/60">{t.liveMapUnavailable}</p>
      )}
    </section>
  );
}
