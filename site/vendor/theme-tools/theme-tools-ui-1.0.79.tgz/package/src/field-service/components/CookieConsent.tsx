import { useThemeToolsSurface } from '../../field-service-primitives.js';
/**
 * CookieConsent — NJDPA-compliant cookie/analytics consent banner.
 *
 * New Jersey Data Privacy Act (cure period sunsets Jul 1 2026) requires that a
 * site running cross-context behavioral analytics (GA4 + PostHog autocapture)
 * (a) offers a clear opt-out at least as easy as opt-in and (b) honors a
 * Global Privacy Control browser signal. Pure logic lives in
 * `src/shared/consent.ts`; this component is the UI + the bridge to the inline
 * analytics loader (`window.__bclLoadAnalytics` defined in index.html).
 *
 * Behavior:
 *   - GPC detected → analytics already suppressed by the inline gate; we show
 *     NO banner (re-prompting defeats the universal opt-out). The footer
 *     "Cookie preferences" link still opens a panel confirming the opt-out.
 *   - undecided + no GPC → banner with equal-prominence Accept / Decline.
 *   - Accept → persist + boot analytics immediately. Decline → persist, stay off.
 *   - Footer dispatches `bcl:open-cookie-preferences` to reopen at any time.
 *
 * Accessibility: role=region + aria-label, aria-live polite, focus-visible
 * brand ring, 44px targets, motion gated by prefers-reduced-motion.
 */
import { useCallback, useEffect, useState } from 'react';
import {
  CONSENT_STORAGE_KEY,
  type ConsentDecision,
  type ConsentState,
  detectGpc,
  parseStoredConsent,
  resolveConsentState,
  serializeConsent,
} from '@theme.tools/notifications/field-service/consent';
import { useUndo } from './providers/UndoProvider.js';

/** Custom event the footer "Cookie preferences" link dispatches to reopen. */
export const OPEN_PREFERENCES_EVENT = 'bcl:open-cookie-preferences';

declare global {
  interface Window {
    /** Idempotent GA4 + PostHog loader, defined by the index.html inline gate. */
    __bclLoadAnalytics?: () => void;
    /** True when GA4/PostHog keys are configured — i.e. there's tracking to consent to. */
    __bclAnalyticsAvailable?: boolean;
  }
}

/** Whether any analytics is configured this build (keys present in index.html). */
function analyticsAvailable(): boolean {
  return typeof window !== 'undefined' && window.__bclAnalyticsAvailable === true;
}

function readState(): ConsentState {
  if (typeof window === 'undefined') {
    return { source: 'undecided', bannerVisible: false, analyticsAllowed: false };
  }
  let stored;
  try {
    stored = parseStoredConsent(window.localStorage.getItem(CONSENT_STORAGE_KEY));
  } catch {
    stored = undefined;
  }
  return resolveConsentState({ gpc: detectGpc(window.navigator), stored });
}

export function CookieConsent() {
  useThemeToolsSurface('cookie-consent');
  const [state, setState] = useState<ConsentState>(() => ({
    source: 'undecided',
    bannerVisible: false,
    analyticsAllowed: false,
  }));
  // `forced` = the visitor reopened preferences manually (overrides bannerVisible).
  const [forcedOpen, setForcedOpen] = useState(false);
  const { registerUndo } = useUndo();

  // Resolve real state after mount (window/localStorage only exist client-side;
  // keeping the initial render inert avoids an SSR/hydration mismatch).
  useEffect(() => {
    setState(readState());
  }, []);

  // Footer "Cookie preferences" → reopen the panel with the live state.
  useEffect(() => {
    const onOpen = () => {
      setState(readState());
      setForcedOpen(true);
    };
    window.addEventListener(OPEN_PREFERENCES_EVENT, onOpen);
    return () => window.removeEventListener(OPEN_PREFERENCES_EVENT, onOpen);
  }, []);

  const persist = useCallback(
    (decision: ConsentDecision) => {
      // Snapshot the prior stored value so the choice is reversible (Undo).
      let priorRaw: string | null = null;
      try {
        priorRaw = window.localStorage.getItem(CONSENT_STORAGE_KEY);
      } catch {
        priorRaw = null;
      }
      try {
        window.localStorage.setItem(CONSENT_STORAGE_KEY, serializeConsent(decision));
      } catch {
        /* private mode / storage disabled — choice holds for the session only */
      }
      if (decision === 'granted') {
        try {
          window.__bclLoadAnalytics?.();
        } catch {
          /* swallow — analytics is best-effort, never a hard dependency */
        }
      }
      setState(
        resolveConsentState({ gpc: detectGpc(window.navigator), stored: { decision, v: 1 } }),
      );
      setForcedOpen(false);

      // Offer a brief Undo. Reverting restores the prior preference (or clears it,
      // re-showing the banner). Analytics that already booted this session can't be
      // un-booted, but the stored preference — what the next page load honors — reverts.
      registerUndo(
        decision === 'granted' ? 'Accepted optional cookies' : 'Declined optional cookies',
        () => {
          try {
            if (priorRaw === null) {
              window.localStorage.removeItem(CONSENT_STORAGE_KEY);
            } else {
              window.localStorage.setItem(CONSENT_STORAGE_KEY, priorRaw);
            }
          } catch {
            /* storage disabled — nothing to revert */
          }
          setState(readState());
          setForcedOpen(false);
        },
      );
    },
    [registerUndo],
  );

  const gpcLocked = state.source === 'gpc';
  const noTracking = !analyticsAvailable();
  // Auto-show only when there's real tracking to consent to AND it's undecided.
  // The footer "Cookie preferences" link (forcedOpen) always opens the panel so
  // a visitor can review or withdraw, even when no analytics is configured.
  const visible = forcedOpen || (state.bannerVisible && !noTracking);
  if (!visible) return null;
  // No buttons when there's nothing to toggle (GPC opt-out OR no analytics at all).
  const informationalOnly = gpcLocked || noTracking;

  return (
    <div
      role="region"
      aria-label="Cookie consent"
      aria-live="polite"
      data-testid="cookie-consent"
      className="fixed inset-x-0 bottom-0 z-[60] flex justify-center px-3 pb-3 sm:px-4 sm:pb-4 motion-safe:animate-fade-up"
    >
      <div className="pointer-events-auto w-full max-w-2xl rounded-2xl border border-brand-line bg-bg-elevated/95 p-5 shadow-2xl backdrop-blur supports-[backdrop-filter]:bg-bg-elevated/80">
        <div className="flex items-start justify-between gap-3">
          <h2 className="text-sm font-bold text-brand-ink sm:text-base">
            We respect your privacy
          </h2>
          {forcedOpen && (
            <button
              type="button"
              onClick={() => setForcedOpen(false)}
              aria-label="Close cookie preferences"
              className="-mt-1 grid h-9 w-9 place-items-center rounded-full text-brand-mute transition-colors duration-[333ms] hover:text-brand-ink focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-accent"
            >
              <span aria-hidden="true" className="text-lg leading-none">
                ×
              </span>
            </button>
          )}
        </div>

        <p className="mt-1.5 text-[13px] leading-relaxed text-brand-mute">
          {gpcLocked ? (
            <>
              Your browser&rsquo;s <strong className="text-brand-ink">Global Privacy Control</strong>{' '}
              signal is on, so we&rsquo;ve <strong className="text-brand-ink">opted you out</strong>{' '}
              of analytics &amp; ad-targeting cookies. Only the essential cookies that make booking
              and login work are active.
            </>
          ) : noTracking ? (
            <>
              We currently set <strong className="text-brand-ink">only essential cookies</strong>{' '}
              that make booking and login work. No analytics or ad-targeting cookies are active on
              this site.
            </>
          ) : (
            <>
              We use a few essential cookies to run booking and login, plus optional analytics
              cookies (Google&nbsp;Analytics, PostHog) to understand how the site is used. You can
              opt out of the optional ones &mdash; nothing breaks if you do.
            </>
          )}
        </p>

        {/* Category pills — never a comma-joined string (gorgeous-by-default). */}
        <ul
          aria-label="Cookie categories"
          className="mt-3 flex flex-wrap gap-2"
        >
          <li className="inline-flex items-center gap-1.5 rounded-full border border-brand-accent/40 bg-brand-accent/10 px-3 py-1.5 text-[11px] font-semibold text-brand-accent">
            <span aria-hidden="true">●</span> Essential&nbsp;&middot;&nbsp;always on
          </li>
          <li
            className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-semibold transition-colors duration-[333ms] ${
              state.analyticsAllowed
                ? 'border-brand-accent/40 bg-brand-accent/10 text-brand-accent'
                : 'border-brand-line bg-bg-primary text-brand-mute'
            }`}
          >
            <span aria-hidden="true">{state.analyticsAllowed ? '●' : '○'}</span> Analytics&nbsp;&amp;
            ads&nbsp;&middot;&nbsp;{state.analyticsAllowed ? 'on' : 'off'}
          </li>
        </ul>

        {!informationalOnly && (
          <div className="mt-4 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <button
              type="button"
              onClick={() => persist('denied')}
              data-testid="cookie-decline"
              className="min-h-[44px] rounded-lg border border-brand-line bg-bg-primary px-5 py-2.5 text-sm font-semibold text-brand-ink transition-all duration-[333ms] hover:border-brand-accent hover:text-brand-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-accent active:translate-y-0"
            >
              Decline optional
            </button>
            <button
              type="button"
              onClick={() => persist('granted')}
              data-testid="cookie-accept"
              className="min-h-[44px] rounded-lg bg-brand-accent px-5 py-2.5 text-sm font-bold text-bg-primary transition-all duration-[333ms] hover:bg-brand-accentHover hover:-translate-y-0.5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-accent active:translate-y-0"
            >
              Accept all
            </button>
          </div>
        )}

        <p className="mt-3 text-[11px] text-brand-mute">
          Read how we handle data in our{' '}
          <a href="/privacy" className="text-brand-accent underline hover:no-underline">
            Privacy&nbsp;Policy
          </a>
          .
        </p>
      </div>
    </div>
  );
}
