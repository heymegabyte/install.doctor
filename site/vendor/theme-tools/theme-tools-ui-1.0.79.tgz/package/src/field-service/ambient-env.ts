/// <reference types="google.maps" />

declare global {
  interface Window {
    trustedTypes?: {
      createPolicy: (
        name: string,
        rules: { createHTML?: (input: string) => string }
      ) => { createHTML: (input: string) => string };
    };
    google?: typeof google;
  }

  interface ImportMetaEnv {
    readonly [key: string]: string | undefined;
  }

  interface ImportMeta {
    readonly env: ImportMetaEnv;
  }
}

export {};
