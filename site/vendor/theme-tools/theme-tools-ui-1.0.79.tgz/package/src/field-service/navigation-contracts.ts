export interface FieldServiceNavItem<TRole extends string = string> {
  readonly label: string;
  readonly route: string;
  readonly icon?: string;
  readonly section?: string;
  readonly badge?: string;
  readonly roles?: readonly TRole[];
  readonly flag?: string;
}

export interface FieldServicePaletteCommand {
  readonly id: string;
  readonly label: string;
  readonly hint?: string;
  readonly group?: string;
}

/** Keep navigation, permissions, feature flags, and command palettes on one contract. */
export function visibleFieldServiceNavItems<TRole extends string>(
  items: readonly FieldServiceNavItem<TRole>[],
  role: TRole | null,
  flags: Readonly<Record<string, boolean>> = {},
): FieldServiceNavItem<TRole>[] {
  return items.filter(
    (item) =>
      (!item.roles || (role !== null && item.roles.includes(role))) &&
      (!item.flag || flags[item.flag] === true),
  );
}

export function fieldServiceNavItemsToCommands<TRole extends string>(
  items: readonly FieldServiceNavItem<TRole>[],
): FieldServicePaletteCommand[] {
  return items.map((item) => ({
    id: item.route,
    label: item.label,
    hint: item.route,
    group: item.section,
  }));
}
