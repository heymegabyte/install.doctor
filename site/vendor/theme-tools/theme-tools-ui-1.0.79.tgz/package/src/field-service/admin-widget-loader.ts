import { lazy, type ComponentType, type LazyExoticComponent } from "react";

export type WidgetCategory =
  | "finance"
  | "conversion"
  | "reviews"
  | "seo"
  | "ops"
  | "people"
  | "compliance"
  | "sandbox"
  | "queries";

export interface WidgetEntry {
  kind: string;
  title: string;
  category: WidgetCategory;
  Component: LazyExoticComponent<ComponentType<{ adminKey: string }>>;
}

export const WIDGET_CATEGORIES: WidgetCategory[] = [
  "finance",
  "conversion",
  "ops",
  "seo",
  "reviews",
  "people",
  "compliance",
  "sandbox",
  "queries",
];

export function defineAdminWidgetRegistry(entries: readonly WidgetEntry[]): WidgetEntry[] {
  return [...entries];
}

export const WIDGET_REGISTRY: WidgetEntry[] = [
  // Finance / reconciliation
  {
    kind: 'square-reconciliation',
    title: 'Square reconciliation',
    category: 'finance',
    Component: lazy(() => import('./components/admin/widgets/SquareReconciliation.js')),
  },
  {
    kind: 'tip-summary',
    title: 'Tip summary',
    category: 'finance',
    Component: lazy(() => import('./components/admin/widgets/TipSummary.js')),
  },
  {
    kind: 'payout-queue',
    title: 'Payout queue',
    category: 'finance',
    Component: lazy(() => import('./components/admin/widgets/PayoutQueue.js')),
  },
  {
    kind: '1099-status',
    title: '1099 status',
    category: 'finance',
    Component: lazy(() => import('./components/admin/widgets/Status1099.js')),
  },
  {
    kind: 'payroll-preview',
    title: 'Payroll preview',
    category: 'finance',
    Component: lazy(() => import('./components/admin/widgets/PayrollPreview.js')),
  },
  {
    kind: 'mileage',
    title: 'Mileage report',
    category: 'finance',
    Component: lazy(() => import('./components/admin/widgets/Mileage.js')),
  },
  {
    kind: 'per-job-profit',
    title: 'Per-job profit',
    category: 'finance',
    Component: lazy(() => import('./components/admin/widgets/PerJobProfit.js')),
  },
  {
    kind: 'discount-history',
    title: 'Discount + surge history',
    category: 'finance',
    Component: lazy(() => import('./components/admin/widgets/DiscountHistory.js')),
  },
  {
    kind: 'cause-fund',
    title: 'Cause fund',
    category: 'finance',
    Component: lazy(() => import('./components/admin/widgets/CauseFund.js')),
  },

  // Sandbox / experiments
  {
    kind: 'surge-sandbox',
    title: 'Surge sandbox',
    category: 'sandbox',
    Component: lazy(() => import('./components/admin/widgets/SurgeSandbox.js')),
  },
  {
    kind: 'pricing-experiments',
    title: 'Pricing experiments',
    category: 'sandbox',
    Component: lazy(() => import('./components/admin/widgets/PricingExperiments.js')),
  },
  {
    kind: 'ab-results',
    title: 'A/B results',
    category: 'sandbox',
    Component: lazy(() => import('./components/admin/widgets/AbResults.js')),
  },

  // Conversion / acquisition
  {
    kind: 'conversion-funnel',
    title: 'Conversion funnel',
    category: 'conversion',
    Component: lazy(() => import('./components/admin/widgets/ConversionFunnel.js')),
  },
  {
    kind: 'cohort-retention',
    title: 'Cohort retention',
    category: 'conversion',
    Component: lazy(() => import('./components/admin/widgets/CohortRetention.js')),
  },
  {
    kind: 'ltv',
    title: 'LTV per customer',
    category: 'conversion',
    Component: lazy(() => import('./components/admin/widgets/Ltv.js')),
  },
  {
    kind: 'cac-by-channel',
    title: 'CAC by channel',
    category: 'conversion',
    Component: lazy(() => import('./components/admin/widgets/CacByChannel.js')),
  },
  {
    kind: 'channel-attribution',
    title: 'Channel attribution',
    category: 'conversion',
    Component: lazy(() => import('./components/admin/widgets/ChannelAttribution.js')),
  },
  {
    kind: 'lead-quality',
    title: 'Lead quality',
    category: 'conversion',
    Component: lazy(() => import('./components/admin/widgets/LeadQuality.js')),
  },
  {
    kind: 'lead-to-quote-latency',
    title: 'Lead → quote latency',
    category: 'conversion',
    Component: lazy(() => import('./components/admin/widgets/LeadToQuoteLatency.js')),
  },
  {
    kind: 'quote-to-booking-latency',
    title: 'Quote → booking latency',
    category: 'conversion',
    Component: lazy(() => import('./components/admin/widgets/QuoteToBookingLatency.js')),
  },
  {
    kind: 'speed-to-lead',
    title: 'Speed-to-lead',
    category: 'conversion',
    Component: lazy(() => import('./components/admin/widgets/SpeedToLead.js')),
  },

  // Ops / messaging / observability
  {
    kind: 'sms-deliverability',
    title: 'SMS deliverability',
    category: 'ops',
    Component: lazy(() => import('./components/admin/widgets/SmsDeliverability.js')),
  },
  {
    kind: 'email-deliverability',
    title: 'Email deliverability',
    category: 'ops',
    Component: lazy(() => import('./components/admin/widgets/EmailDeliverability.js')),
  },
  {
    kind: 'posthog-replays',
    title: 'PostHog replays',
    category: 'ops',
    Component: lazy(() => import('./components/admin/widgets/PosthogReplays.js')),
  },
  {
    kind: 'sentry-errors',
    title: 'Sentry errors',
    category: 'ops',
    Component: lazy(() => import('./components/admin/widgets/SentryErrors.js')),
  },
  {
    kind: 'workers-tracing',
    title: 'Workers Tracing',
    category: 'ops',
    Component: lazy(() => import('./components/admin/widgets/WorkersTracing.js')),
  },
  {
    kind: 'csp-reports',
    title: 'CSP reports',
    category: 'ops',
    Component: lazy(() => import('./components/admin/widgets/CspReports.js')),
  },
  {
    kind: 'console-errors',
    title: 'Console errors',
    category: 'ops',
    Component: lazy(() => import('./components/admin/widgets/ConsoleErrors.js')),
  },
  {
    kind: 'lighthouse',
    title: 'Lighthouse history',
    category: 'ops',
    Component: lazy(() => import('./components/admin/widgets/Lighthouse.js')),
  },
  {
    kind: 'webvitals',
    title: 'Core Web Vitals',
    category: 'ops',
    Component: lazy(() => import('./components/admin/widgets/WebVitals.js')),
  },

  // SEO
  {
    kind: 'seo-health',
    title: 'SEO health card',
    category: 'seo',
    Component: lazy(() => import('./components/admin/widgets/SeoHealth.js')),
  },
  {
    kind: 'seo-ranks',
    title: 'SEO ranks',
    category: 'seo',
    Component: lazy(() => import('./components/admin/widgets/SeoRanks.js')),
  },
  {
    kind: 'backlinks',
    title: 'Backlinks',
    category: 'seo',
    Component: lazy(() => import('./components/admin/widgets/Backlinks.js')),
  },
  {
    kind: 'competitor-watch',
    title: 'Competitor watch',
    category: 'seo',
    Component: lazy(() => import('./components/admin/widgets/CompetitorWatch.js')),
  },
  {
    kind: 'press-mentions',
    title: 'Press mentions',
    category: 'seo',
    Component: lazy(() => import('./components/admin/widgets/PressMentions.js')),
  },

  // Reviews / sentiment
  {
    kind: 'review-feed',
    title: 'Review feed',
    category: 'reviews',
    Component: lazy(() => import('./components/admin/widgets/ReviewFeed.js')),
  },
  {
    kind: 'sentiment-trend',
    title: 'Sentiment trend',
    category: 'reviews',
    Component: lazy(() => import('./components/admin/widgets/SentimentTrend.js')),
  },
  {
    kind: 'review-response-queue',
    title: 'Review response queue',
    category: 'reviews',
    Component: lazy(() => import('./components/admin/widgets/ReviewResponseQueue.js')),
  },
  {
    kind: 'negative-escalations',
    title: 'Negative escalations',
    category: 'reviews',
    Component: lazy(() => import('./components/admin/widgets/NegativeEscalations.js')),
  },
  {
    kind: 'top-praise',
    title: 'Top praise',
    category: 'reviews',
    Component: lazy(() => import('./components/admin/widgets/TopPraise.js')),
  },
  {
    kind: 'word-cloud',
    title: 'Word cloud',
    category: 'reviews',
    Component: lazy(() => import('./components/admin/widgets/WordCloud.js')),
  },
  {
    kind: 'nps',
    title: 'NPS',
    category: 'reviews',
    Component: lazy(() => import('./components/admin/widgets/Nps.js')),
  },
  {
    kind: 'campaign-suggester',
    title: 'AI campaign suggester',
    category: 'reviews',
    Component: lazy(() => import('./components/admin/widgets/CampaignSuggester.js')),
  },

  // People / capacity
  {
    kind: 'holiday-impact',
    title: 'Holiday impact',
    category: 'people',
    Component: lazy(() => import('./components/admin/widgets/HolidayImpact.js')),
  },
  {
    kind: 'capacity-planner',
    title: 'Capacity planner',
    category: 'people',
    Component: lazy(() => import('./components/admin/widgets/CapacityPlanner.js')),
  },
  {
    kind: 'worker-schedule',
    title: 'Worker schedule',
    category: 'people',
    Component: lazy(() => import('./components/admin/widgets/WorkerSchedule.js')),
  },
  {
    kind: 'time-off-requests',
    title: 'Time-off requests',
    category: 'people',
    Component: lazy(() => import('./components/admin/widgets/TimeOffRequests.js')),
  },
  {
    kind: 'onboarding-pipeline',
    title: 'Onboarding pipeline',
    category: 'people',
    Component: lazy(() => import('./components/admin/widgets/OnboardingPipeline.js')),
  },
  {
    kind: 'bg-check-board',
    title: 'BG-check board',
    category: 'people',
    Component: lazy(() => import('./components/admin/widgets/BgCheckBoard.js')),
  },
  {
    kind: 'training-rates',
    title: 'Training rates',
    category: 'people',
    Component: lazy(() => import('./components/admin/widgets/TrainingRates.js')),
  },
  {
    kind: 'worker-coach-recs',
    title: 'Worker coach recs',
    category: 'people',
    Component: lazy(() => import('./components/admin/widgets/WorkerCoachRecs.js')),
  },

  // Compliance / customers / queries
  {
    kind: 'customer-tags',
    title: 'Customer tags',
    category: 'people',
    Component: lazy(() => import('./components/admin/widgets/CustomerTags.js')),
  },
  {
    kind: 'segments',
    title: 'Custom segments',
    category: 'queries',
    Component: lazy(() => import('./components/admin/widgets/Segments.js')),
  },
  {
    kind: 'compliance-checklist',
    title: 'Compliance',
    category: 'compliance',
    Component: lazy(() => import('./components/admin/widgets/ComplianceChecklist.js')),
  },
  {
    kind: 'cert-renewals',
    title: 'Cert renewals',
    category: 'compliance',
    Component: lazy(() => import('./components/admin/widgets/CertRenewals.js')),
  },
  {
    kind: 'domain-renewals',
    title: 'Domain renewals',
    category: 'compliance',
    Component: lazy(() => import('./components/admin/widgets/DomainRenewals.js')),
  },
  {
    kind: 'saved-queries',
    title: 'Saved queries',
    category: 'queries',
    Component: lazy(() => import('./components/admin/widgets/SavedQueries.js')),
  },
];
