/**
 * bolt.diy KV Browser — mounted in the projectsites.dev editor bottom panel.
 * Browse KV keys, view values (JSON-syntax-highlighted), inline edit, delete,
 * namespace switcher, bulk import/export.
 *
 * Requires: KV binding proxy at /api/admin/kv (bricklabor.com worker provides this).
 * This component only handles the UI. No KV access from the browser directly.
 */
import { useState, useEffect, useCallback } from 'react';

interface KvEntry {
  key: string;
  expiration?: number;
  metadata?: Record<string, unknown>;
}

interface KvBrowserProps {
  namespace: string;
  /** All available namespace names for the switcher dropdown */
  namespaces?: string[];
  apiBase: string;
  dark?: boolean;
  /** Called when the user switches namespace via the dropdown */
  onNamespaceChange?: (ns: string) => void;
}

export function KvBrowser({ namespace, namespaces, apiBase, dark = true, onNamespaceChange }: KvBrowserProps) {
  const [keys, setKeys] = useState<KvEntry[]>([]);
  const [selectedKey, setSelectedKey] = useState<string | null>(null);
  const [value, setValue] = useState<string>('');
  const [editing, setEditing] = useState(false);
  const [editValue, setEditValue] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [bulkImportText, setBulkImportText] = useState('');
  const [bulkImporting, setBulkImporting] = useState(false);

  const listUrl = `${apiBase}/kv/keys`;
  const getByKeyUrl = (key: string) => `${apiBase}/kv/get/${encodeURIComponent(key)}`;
  const delUrl = (key: string) => `${apiBase}/kv/del/${encodeURIComponent(key)}`;
  const setUrl = `${apiBase}/kv/set`;

  const fetchKeys = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${listUrl}?prefix=${encodeURIComponent(search)}&limit=100`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json() as { keys: KvEntry[] };
      setKeys(data.keys || []);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, [listUrl, search]);

  useEffect(() => { fetchKeys(); }, [fetchKeys]);

  const selectKey = async (key: string) => {
    setSelectedKey(key);
    setEditing(false);
    setConfirmDelete(null);
    try {
      const res = await fetch(getByKeyUrl(key));
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json() as { value: string };
      setValue(data.value || '');
    } catch (err) {
      setError((err as Error).message);
      setValue('');
    }
  };

  const saveEdit = async () => {
    if (!selectedKey) return;
    try {
      const res = await fetch(setUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: selectedKey, value: editValue }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setValue(editValue);
      setEditing(false);
    } catch (err) {
      setError((err as Error).message);
    }
  };

  const deleteKey = async (key: string) => {
    try {
      const res = await fetch(delUrl(key), { method: 'DELETE' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setKeys(prev => prev.filter(k => k.key !== key));
      if (selectedKey === key) { setSelectedKey(null); setValue(''); }
      setConfirmDelete(null);
    } catch (err) {
      setError((err as Error).message);
    }
  };

  /** Bulk import: parse JSON and POST /set for each key. */
  const bulkImport = async () => {
    setBulkImporting(true);
    setError(null);
    try {
      const obj = JSON.parse(bulkImportText) as Record<string, string>;
      for (const [key, val] of Object.entries(obj)) {
        await fetch(setUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ key, value: val }),
        });
      }
      setBulkImportText('');
      await fetchKeys();
    } catch (err) {
      setError(`Bulk import failed: ${(err as Error).message}`);
    } finally {
      setBulkImporting(false);
    }
  };

  /** Bulk export: fetch all keys+values and download as JSON. */
  const bulkExport = async () => {
    try {
      const result: Record<string, string> = {};
      for (const k of keys) {
        try {
          const res = await fetch(getByKeyUrl(k.key));
          if (res.ok) {
            const data = await res.json() as { value: string };
            result[k.key] = data.value;
          }
        } catch {}
      }
      const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `kv-${namespace}-export-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      setError((err as Error).message);
    }
  };

  const bg = dark ? '#060610' : '#fff';
  const fg = dark ? '#F5F5F5' : '#111';
  const accent = '#00E5FF';
  const mute = dark ? '#A0A0B0' : '#666';
  const card = dark ? '#0A0E14' : '#f5f5f5';
  const line = dark ? '#1E1E2E' : '#e0e0e0';
  const danger = '#ef4444';

  const nsList = namespaces && namespaces.length > 0 ? namespaces : [namespace];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', fontFamily: 'JetBrains Mono, monospace', fontSize: 13, background: bg, color: fg }}>
      {/* Toolbar: namespace switcher + search + bulk actions */}
      <div style={{ display: 'flex', gap: 8, padding: 8, borderBottom: `1px solid ${line}`, flexWrap: 'wrap', alignItems: 'center' }}>
        {nsList.length > 1 && (
          <select
            value={namespace}
            onChange={e => { onNamespaceChange?.(e.target.value); }}
            style={{ background: card, color: fg, border: `1px solid ${line}`, borderRadius: 4, padding: '4px 8px', fontSize: 12, fontFamily: 'JetBrains Mono, monospace' }}
          >
            {nsList.map(ns => <option key={ns} value={ns}>{ns}</option>)}
          </select>
        )}
        {nsList.length <= 1 && (
          <span style={{ color: accent, fontSize: 12, fontWeight: 600, padding: '4px 0' }}>{namespace}</span>
        )}
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search keys..."
          style={{ background: card, color: fg, border: `1px solid ${line}`, borderRadius: 4, padding: '4px 8px', fontSize: 12, fontFamily: 'JetBrains Mono, monospace', width: 200 }}
        />
        <button onClick={fetchKeys} style={btnStyle(accent, dark)}>↻</button>
        <button onClick={bulkExport} disabled={keys.length === 0} style={{ ...btnStyle(mute, dark), opacity: keys.length === 0 ? 0.4 : 1 }}>↓ Export</button>
        <span style={{ color: mute, fontSize: 11, marginLeft: 'auto' }}>{keys.length} key{keys.length !== 1 ? 's' : ''}</span>
      </div>

      {/* Bulk import section (collapsed by default) */}
      <details style={{ padding: '0 8px', borderBottom: `1px solid ${line}20` }}>
        <summary style={{ cursor: 'pointer', color: mute, fontSize: 11, padding: '4px 0' }}>Bulk Import</summary>
        <textarea
          value={bulkImportText}
          onChange={e => setBulkImportText(e.target.value)}
          rows={6}
          placeholder='{"key1": "value1", "key2": "value2"}'
          style={{ width: '100%', background: card, color: fg, border: `1px solid ${line}`, borderRadius: 4, padding: 8, fontFamily: 'JetBrains Mono, monospace', fontSize: 12, resize: 'vertical', marginBottom: 8 }}
        />
        <button onClick={bulkImport} disabled={bulkImporting || !bulkImportText.trim()} style={{ ...btnStyle(accent, dark), marginBottom: 8, opacity: bulkImporting ? 0.6 : 1 }}>
          {bulkImporting ? 'Importing...' : 'Import JSON'}
        </button>
      </details>

      {/* Error banner */}
      {error && <div style={{ color: danger, padding: '6px 10px', background: `${danger}10`, fontSize: 12 }}>{error} <button onClick={() => setError(null)} style={{ background: 'transparent', border: 'none', color: danger, cursor: 'pointer' }}>×</button></div>}

      {/* Main split: key list | value viewer */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Key list */}
        <div style={{ width: 280, borderRight: `1px solid ${line}`, overflow: 'auto', flexShrink: 0 }}>
          {loading && <div style={{ color: mute, padding: 20 }}>Loading...</div>}
          {!loading && keys.length === 0 && <div style={{ color: mute, padding: 20 }}>No keys found</div>}
          {keys.map(k => (
            <div
              key={k.key}
              onClick={() => selectKey(k.key)}
              style={{
                padding: '6px 10px', cursor: 'pointer', borderBottom: `1px solid ${line}20`,
                background: selectedKey === k.key ? `${accent}15` : 'transparent',
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
              }}
            >
              {k.key}
              {k.expiration && <span style={{ color: mute, fontSize: 10, marginLeft: 6 }}>⏱</span>}
            </div>
          ))}
        </div>

        {/* Value viewer */}
        <div style={{ flex: 1, overflow: 'auto', padding: 10 }}>
          {!selectedKey && <div style={{ color: mute, padding: 20 }}>Select a key to view its value</div>}
          {selectedKey && (
            <>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                <span style={{ color: accent, fontWeight: 600, wordBreak: 'break-all' }}>{selectedKey}</span>
                <div style={{ display: 'flex', gap: 6 }}>
                  {!editing && (
                    <button onClick={() => { setEditValue(value); setEditing(true); }} style={btnStyle(mute, dark)}>Edit</button>
                  )}
                  {editing && (
                    <>
                      <button onClick={saveEdit} style={btnStyle(accent, dark)}>Save</button>
                      <button onClick={() => setEditing(false)} style={btnStyle(mute, dark)}>Cancel</button>
                    </>
                  )}
                  {confirmDelete === selectedKey ? (
                    <>
                      <button onClick={() => deleteKey(selectedKey)} style={{ ...btnStyle(danger, dark), fontWeight: 700 }}>Confirm Delete</button>
                      <button onClick={() => setConfirmDelete(null)} style={btnStyle(mute, dark)}>Cancel</button>
                    </>
                  ) : (
                    <button onClick={() => setConfirmDelete(selectedKey)} style={btnStyle(danger, dark)}>Delete</button>
                  )}
                </div>
              </div>
              {editing ? (
                <textarea
                  value={editValue}
                  onChange={e => setEditValue(e.target.value)}
                  rows={20}
                  style={{ width: '100%', background: card, color: fg, border: `1px solid ${accent}`, borderRadius: 4, padding: 8, fontFamily: 'JetBrains Mono, monospace', fontSize: 13, resize: 'vertical' }}
                />
              ) : (
                <pre style={{ background: card, padding: 12, borderRadius: 4, overflow: 'auto', maxHeight: 'calc(100vh - 220px)', fontSize: 13, whiteSpace: 'pre-wrap', wordBreak: 'break-all', margin: 0 }}>
                  {tryFormatJson(value)}
                </pre>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function tryFormatJson(raw: string): string {
  try {
    const parsed = JSON.parse(raw);
    return JSON.stringify(parsed, null, 2);
  } catch {
    return raw;
  }
}

function btnStyle(color: string, _dark: boolean): React.CSSProperties {
  return {
    padding: '4px 10px', borderRadius: 4, border: `1px solid ${color}`,
    background: 'transparent', color, cursor: 'pointer', fontSize: 12,
    fontFamily: 'JetBrains Mono, monospace',
  };
}
