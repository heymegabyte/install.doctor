/**
 * Roving-tabindex keyboard navigation for custom ARIA `role="menu"` widgets.
 *
 * The ARIA Authoring Practices menu/menubar pattern requires a `role="menu"` to
 * be a SINGLE tab stop: only one `menuitem` carries `tabIndex=0`, the rest are
 * `tabIndex=-1`, ArrowDown/ArrowUp move focus between items (wrapping at the
 * ends), and Home/End jump to the extremes. A naive `role="menu"` whose items
 * are `onClick`-only `<button role="menuitem">`/`<a role="menuitem">` rows — each
 * independently Tab-focusable, with no arrow handling — FAILS the pattern: a
 * keyboard-only user must Tab through every item and can't arrow between them.
 * axe-core does NOT detect this (it is an interaction-pattern gap, not a static
 * attribute one), so it must be unit-pinned instead.
 *
 * A vertical menu navigates with ArrowDown/ArrowUp ONLY — ArrowLeft/ArrowRight
 * are reserved by APG for menubars/submenus and must pass through (return null)
 * so they never hijack focus in a plain dropdown.
 *
 * This module is pure + framework-free so the worker, the React widgets, and the
 * unit suite can all share one implementation — no React import, no DOM. The
 * roving `tabIndex` math is shared with the radio/tablist pattern via
 * {@link rovingTabIndex} in `./radio-keynav` (one source of truth).
 */

/** Keys that move focus DOWN one item in a vertical menu. */
const MENU_NEXT_KEYS = new Set(['ArrowDown']);
/** Keys that move focus UP one item in a vertical menu. */
const MENU_PREV_KEYS = new Set(['ArrowUp']);

/**
 * Compute the index a vertical `role="menu"` should move FOCUS to for a key press.
 *
 * Unlike a radio group, a menu has no persistent "selected" item — this returns
 * the next item to FOCUS, and activation (Enter/Space/click) is a separate event.
 *
 * @param currentIndex - The index of the currently-focused menuitem.
 * @param count - Total number of menuitems (must be ≥ 1).
 * @param key - The `KeyboardEvent.key` value.
 * @returns The next focus index, or `null` when the key is not a menu-navigation
 *   key (caller must NOT preventDefault / move focus in that case — so Tab,
 *   Enter, Space, and ArrowLeft/ArrowRight keep their default behavior).
 * @example
 * nextMenuIndex(0, 3, 'ArrowDown') // → 1
 * nextMenuIndex(2, 3, 'ArrowDown') // → 0  (wraps to first)
 * nextMenuIndex(0, 3, 'ArrowUp')   // → 2  (wraps to last)
 * nextMenuIndex(1, 3, 'Home')      // → 0
 * nextMenuIndex(1, 3, 'End')       // → 2
 * nextMenuIndex(1, 3, 'ArrowLeft') // → null  (reserved for menubars)
 * nextMenuIndex(1, 3, 'Tab')       // → null
 */
export function nextMenuIndex(
  currentIndex: number,
  count: number,
  key: string,
): number | null {
  if (count <= 0) return null;
  const i = Math.min(Math.max(currentIndex, 0), count - 1);
  if (MENU_NEXT_KEYS.has(key)) return (i + 1) % count;
  if (MENU_PREV_KEYS.has(key)) return (i - 1 + count) % count;
  if (key === 'Home') return 0;
  if (key === 'End') return count - 1;
  return null;
}

/** Keys that OPEN a closed menu when its trigger button is focused (APG menu-button). */
const TRIGGER_OPEN_KEYS = new Set(['ArrowDown', 'ArrowUp']);

/**
 * Whether a key press on a `aria-haspopup="menu"` trigger button should OPEN the
 * menu. The ARIA Authoring Practices menu-button pattern opens the menu (and moves
 * focus to the first item — handled by `useRovingMenu`'s focus-on-open effect) when
 * the trigger is focused and the user presses ArrowDown or ArrowUp. Enter/Space are
 * already handled natively by the `<button>`, so they are NOT in this set.
 *
 * @param key - The `KeyboardEvent.key` value.
 * @returns `true` only for ArrowDown / ArrowUp — the caller should then
 *   `preventDefault()` (so the page doesn't scroll) and open the menu.
 * @example
 * menuTriggerOpensOn('ArrowDown') // → true
 * menuTriggerOpensOn('ArrowUp')   // → true
 * menuTriggerOpensOn('Enter')     // → false  (native button handles it)
 * menuTriggerOpensOn('a')         // → false
 */
export function menuTriggerOpensOn(key: string): boolean {
  return TRIGGER_OPEN_KEYS.has(key);
}
