// Wrapper around the page-level GA4 + PostHog snippets so component code can
// fire conversion-funnel events without caring which (or both) are loaded.
// Both are loaded synchronously by the inline snippet in index.html — by the
// time React mounts they are either present or definitively absent.

type EventProps = Record<string, string | number | boolean | null | undefined>;

interface PostHogShim {
  capture?: (event: string, props?: EventProps) => void;
  identify?: (id: string, props?: EventProps) => void;
}

interface GtagShim {
  (command: 'event', name: string, params?: EventProps): void;
}

interface SentryShim {
  addBreadcrumb: (b: {
    category?: string;
    message: string;
    data?: EventProps;
    level?: string;
  }) => void;
}

declare global {
  interface Window {
    posthog?: PostHogShim;
    gtag?: GtagShim;
    Sentry?: SentryShim;
  }
}

export function track(event: string, props?: EventProps): void {
  if (typeof window === 'undefined') return;
  try {
    window.posthog?.capture?.(event, props);
  } catch {
    /* swallow */
  }
  try {
    window.gtag?.('event', event, props);
  } catch {
    /* swallow */
  }
  try {
    window.Sentry?.addBreadcrumb({
      category: 'analytics',
      message: event,
      data: props,
      level: 'info',
    });
  } catch {
    /* swallow */
  }
  // #18 /book conversion: mirror every money-path beat into ONE unified
  // `booking_funnel_step` event so PostHog renders the whole booking funnel as a
  // single insight (break down by `step`/`ordinal`) instead of stitching six
  // differently-named events. `source`/`service` flow through from the beat's
  // own props. Non-recursive: `booking_funnel_step` is not itself a mapped beat,
  // so this never loops.
  const fs = funnelStepFor(event);
  if (fs) {
    const stepProps: EventProps = { ...props, step: fs.step, ordinal: fs.ordinal };
    try {
      window.posthog?.capture?.('booking_funnel_step', stepProps);
    } catch {
      /* swallow */
    }
    try {
      window.gtag?.('event', 'booking_funnel_step', stepProps);
    } catch {
      /* swallow */
    }
  }
}

export function pageview(path: string): void {
  if (typeof window === 'undefined') return;
  try {
    window.gtag?.('event', 'page_view', { page_path: path });
  } catch {
    /* swallow */
  }
  try {
    window.posthog?.capture?.('$pageview', { path });
  } catch {
    /* swallow */
  }
}

export function identify(id: string, props?: EventProps): void {
  if (typeof window === 'undefined') return;
  try {
    window.posthog?.identify?.(id, props);
  } catch {
    /* swallow */
  }
}

export const FUNNEL = {
  bookingStarted: 'booking_started',
  datePicked: 'booking_date_picked',
  slotPicked: 'booking_slot_picked',
  detailsOpened: 'booking_details_opened',
  submitted: 'booking_submitted',
  paid: 'booking_paid',
  contactSubmitted: 'contact_submitted',
  quoteSaved: 'quote_saved',
  quoteShared: 'quote_shared',
  // Highest-LTV funnel beat: the booker converts a one-time job into a
  // standing daily/weekly/biweekly/monthly contract — the business's recurring
  // "subscription" revenue. Carries { plan, discountPct } so the operator can
  // see which cadence converts and at what margin.
  recurringSelected: 'booking_recurring_selected',
} as const;

/**
 * Canonical funnel event-name union. Import this type (not a bare string) when
 * a function parameter must be a known funnel event so a typo is a compile
 * error rather than a silently-dropped analytics call on the revenue funnel.
 */
export type FunnelEvent = (typeof FUNNEL)[keyof typeof FUNNEL];

/**
 * #18 /book conversion — the ordered money-path beats, each mapped to a stable
 * `step` name + `ordinal`. `track()` emits a single unified
 * `booking_funnel_step` event for every one of these, so PostHog renders the
 * WHOLE booking funnel as ONE funnel insight (break down by `step`) instead of
 * stitching six differently-named events. Recurring-contract selection stays a
 * separate beat (`recurringSelected`) — it's a conversion *upgrade*, not a
 * linear funnel stage, so it never carries an ordinal here.
 */
export const FUNNEL_STEPS: Readonly<Record<string, { step: string; ordinal: number }>> = {
  [FUNNEL.bookingStarted]: { step: 'started', ordinal: 1 },
  [FUNNEL.datePicked]: { step: 'date', ordinal: 2 },
  [FUNNEL.slotPicked]: { step: 'slot', ordinal: 3 },
  [FUNNEL.detailsOpened]: { step: 'details', ordinal: 4 },
  [FUNNEL.submitted]: { step: 'submitted', ordinal: 5 },
  [FUNNEL.paid]: { step: 'paid', ordinal: 6 },
};

/**
 * Resolve the funnel-step descriptor for an event name, or `undefined` when the
 * event is not a linear money-path beat. Pure — safe to call anywhere.
 */
export function funnelStepFor(
  event: string,
): { step: string; ordinal: number } | undefined {
  return FUNNEL_STEPS[event];
}
