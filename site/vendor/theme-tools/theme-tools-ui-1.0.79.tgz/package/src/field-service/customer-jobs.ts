import { useCallback, useEffect, useRef, useState } from 'react';

// Wave 13B — typed client hooks for /api/customer/jobs.
//
// SWR-lite: in-memory cache keyed by URL, 60s stale-while-revalidate, manual
// `refresh()` for explicit reload, automatic refetch on `focus` events.
// No external dep (no `swr`, no `react-query`) — keep the SPA bundle slim.

export interface JobListItem {
  id: string;
  service: string;
  services: string[];
  preferredDate: string;
  preferredTime: string;
  hours: number;
  crew: number;
  totalCents: number;
  status: string;
  /** Includes 'defunct' (§13b — past-dated upcoming job never paid). */
  paymentStatus: 'pending' | 'confirmed' | 'paid' | 'completed' | 'canceled' | 'defunct';
  address: string;
  city: string;
  completedAt: string | null;
  customerVisibleAt: string | null;
  canceledAt: string | null;
  photoCount: { before: number; after: number; other: number };
  /**
   * §13c — one signed thumb URL per kind, baked in by the list endpoint so
   * the inline 2-up strip on every job row renders without an N+1 fetch.
   * Tokens expire in 10 min; the page-level SWR refresh re-mints them.
   */
  photoThumbs: {
    before: { id: string; url: string } | null;
    after: { id: string; url: string } | null;
  };
  hasRecap: boolean;
  createdAt: string;
}

export interface JobListPayload {
  ok: boolean;
  contact: string;
  channel: 'sms' | 'email';
  items: JobListItem[];
  nextCursor: string | null;
}

export interface CrewMember {
  workerId: string;
  firstName: string;
  lastInitial: string;
  avatarUrl: string | null;
  isLead: boolean;
  status: string;
}

export interface RentalLineDto {
  id: string;
  label: string;
  qty: number;
  priceCents: number;
}

export interface JobDetail {
  id: string;
  status: string;
  paymentStatus: 'pending' | 'confirmed' | 'paid' | 'completed' | 'canceled';
  customerFirstName: string;
  preferredDate: string;
  preferredTime: string;
  hours: number;
  crew: number;
  services: string[];
  address: string;
  city: string;
  zip: string;
  notes: string;
  pricing: {
    totalCents: number;
    baseLaborCents: number;
    rentalsCents: number;
    rentals: RentalLineDto[];
    surgeMultiplier: number;
    surgeCents: number;
    surgeReasons: string[];
    tipCents: number;
    rushCents: number;
    afterHoursCents: number;
    extrasCsv: string[];
    extrasFlatCents: number;
  };
  timeline: {
    scheduledAt: string | null;
    paidAt: string | null;
    paidInFullAt: string | null;
    completedAt: string | null;
    customerVisibleAt: string | null;
    canceledAt: string | null;
  };
  crewMembers: CrewMember[];
  photoCount: { before: number; after: number; other: number };
  hasRecap: boolean;
  receiptUrl: string | null;
}

export interface JobPhoto {
  id: string;
  kind: string;
  mime: string;
  width: number | null;
  height: number | null;
  caption: string | null;
  aiDescription: string | null;
  capturedAt: string | null;
  uploadedAt: string;
  url: string;
  expiresInSec: number;
}

export interface PhotosPayload {
  ok: boolean;
  bookingId: string;
  counts: { before: number; after: number; other: number };
  items: JobPhoto[];
}

// Tiny in-memory cache. Survives only within the SPA's lifetime; refresh on
// hard-reload is intentional (we want fresh signed URLs anyway).
const cache = new Map<string, { at: number; data: unknown }>();
const TTL_MS = 60_000;

interface FetchState<T> {
  data: T | null;
  error: string | null;
  loading: boolean;
}

async function fetchJson<T>(url: string): Promise<T> {
  const res = await fetch(url, { credentials: 'same-origin' });
  if (res.status === 401) throw new Error('unauthorized');
  if (!res.ok) {
    const body = (await res.json().catch(() => ({}))) as { error?: string };
    throw new Error(body.error ?? `http_${res.status}`);
  }
  return (await res.json()) as T;
}

function useCachedFetch<T>(url: string | null): FetchState<T> & { refresh: () => Promise<void> } {
  const [state, setState] = useState<FetchState<T>>({ data: null, error: null, loading: true });
  const mounted = useRef(true);

  const load = useCallback(
    async (skipCache: boolean) => {
      if (!url) {
        setState({ data: null, error: null, loading: false });
        return;
      }
      const hit = !skipCache && cache.get(url);
      if (hit && Date.now() - hit.at < TTL_MS) {
        setState({ data: hit.data as T, error: null, loading: false });
        return;
      }
      setState((s) => ({ ...s, loading: true }));
      try {
        const data = await fetchJson<T>(url);
        cache.set(url, { at: Date.now(), data });
        if (mounted.current) setState({ data, error: null, loading: false });
      } catch (err) {
        if (mounted.current) {
          setState({ data: null, error: (err as Error).message, loading: false });
        }
      }
    },
    [url],
  );

  useEffect(() => {
    mounted.current = true;
    void load(false);
    const onFocus = () => void load(true);
    window.addEventListener('focus', onFocus);
    return () => {
      mounted.current = false;
      window.removeEventListener('focus', onFocus);
    };
  }, [load]);

  return { ...state, refresh: () => load(true) };
}

/**
 * Hook: paginated list of the signed-in customer's bookings. Filter is one of
 * 'all' | 'upcoming' | 'past'. Returns SWR-style { data, error, loading,
 * refresh } plus a stable identity per filter.
 */
export function useCustomerJobs(filter: 'all' | 'upcoming' | 'past' = 'all') {
  const url = `/api/customer/jobs?filter=${filter}&limit=50`;
  return useCachedFetch<JobListPayload>(url);
}

/**
 * Hook: full detail for a single booking (crew, breakdown, photo counts).
 * Returns null if `bookingId` is empty (so the caller can guard on selection).
 */
export function useJobDetail(bookingId: string | null) {
  const url = bookingId ? `/api/customer/jobs/${encodeURIComponent(bookingId)}` : null;
  return useCachedFetch<{ ok: boolean; booking: JobDetail }>(url);
}

/**
 * Hook: signed photo URLs for a booking. URLs expire in 10 minutes; if the
 * panel stays open beyond that, the caller should call `refresh()`.
 */
export function useJobPhotos(bookingId: string | null) {
  const url = bookingId ? `/api/customer/jobs/${encodeURIComponent(bookingId)}/photos` : null;
  return useCachedFetch<PhotosPayload>(url);
}

/**
 * Mutator: POST /api/customer/jobs/:id/rebook. Resolves with the rebook URL
 * the caller can navigate to (canonical /book?service=...&crew=...&hours=...&address=...).
 */
export async function requestRebook(
  bookingId: string,
  source = 'me_page',
): Promise<{ ok: boolean; rebookUrl: string | null; error?: string }> {
  try {
    const res = await fetch(`/api/customer/jobs/${encodeURIComponent(bookingId)}/rebook`, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ source }),
    });
    if (!res.ok) {
      const body = (await res.json().catch(() => ({}))) as { error?: string };
      return { ok: false, rebookUrl: null, error: body.error ?? `http_${res.status}` };
    }
    const data = (await res.json()) as { ok: boolean; rebook?: { url: string } };
    return { ok: data.ok, rebookUrl: data.rebook?.url ?? null };
  } catch (err) {
    return { ok: false, rebookUrl: null, error: (err as Error).message };
  }
}

/** Format `1234` cents as `$12.34`. */
export function formatMoney(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}

/** Format an ISO date `YYYY-MM-DD` to e.g. `Sun, Mar 9, 2026`. Returns "—"
 * for any malformed input — never the raw garbage string. */
export function formatJobDate(d: string | null | undefined): string {
  if (!d) return '—';
  const m = String(d)
    .trim()
    .match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return '—';
  const y = Number(m[1]);
  const mo = Number(m[2]);
  const day = Number(m[3]);
  if (!Number.isFinite(y) || !Number.isFinite(mo) || !Number.isFinite(day)) return '—';
  const dt = new Date(y, mo - 1, day);
  if (Number.isNaN(dt.getTime())) return '—';
  return dt.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function paymentStatusLabel(s: JobListItem['paymentStatus']): string {
  switch (s) {
    case 'paid':
      return 'Paid';
    case 'confirmed':
      return 'Confirmed';
    case 'completed':
      return 'Completed';
    case 'canceled':
      return 'Canceled';
    case 'defunct':
      return 'Defunct';
    case 'pending':
    default:
      return 'Pending';
  }
}

export function paymentStatusBadgeClass(s: JobListItem['paymentStatus']): string {
  switch (s) {
    case 'paid':
      return 'bg-emerald-500/20 text-emerald-200 border-emerald-500/40';
    case 'completed':
      return 'bg-emerald-500/20 text-emerald-200 border-emerald-500/40';
    case 'confirmed':
      return 'bg-blue-500/20 text-blue-200 border-blue-500/40';
    case 'canceled':
      return 'bg-zinc-500/20 text-zinc-300 border-zinc-500/40';
    case 'defunct':
      return 'bg-orange-500/20 text-orange-200 border-orange-500/40';
    case 'pending':
    default:
      return 'bg-yellow-500/20 text-yellow-200 border-yellow-500/40';
  }
}
