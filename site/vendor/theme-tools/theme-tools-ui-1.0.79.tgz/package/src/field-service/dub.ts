// Dub.co click attribution on the frontend. Dub appends `?dub_id=XXX` when a
// short-link redirect lands on our domain. We capture it once on landing,
// store it in localStorage + a 60-day cookie, and the booking form reads it
// back on submit so the worker can fire a `lead` + `sale` event with the
// matching clickId. No tracking script, no third-party JS — one cookie.

const KEY = 'bcl-dub-id';
const COOKIE_DAYS = 60;

export function captureDubIdIfPresent(): void {
  if (typeof window === 'undefined') return;
  const params = new URLSearchParams(window.location.search);
  const dubId = params.get('dub_id') || params.get('via') || '';
  if (!dubId || !/^[a-zA-Z0-9_-]{1,60}$/.test(dubId)) return;
  try {
    localStorage.setItem(KEY, dubId);
    const expires = new Date(Date.now() + COOKIE_DAYS * 86400 * 1000).toUTCString();
    document.cookie = `${KEY}=${dubId}; expires=${expires}; path=/; SameSite=Lax`;
  } catch {
    /* localStorage disabled — silently no-op */
  }
}

export function getDubId(): string {
  if (typeof window === 'undefined') return '';
  try {
    const fromStorage = localStorage.getItem(KEY);
    if (fromStorage && /^[a-zA-Z0-9_-]{1,60}$/.test(fromStorage)) return fromStorage;
  } catch {
    /* fall through to cookie */
  }
  const match = document.cookie.match(new RegExp(`(?:^|; )${KEY}=([^;]+)`));
  return match?.[1] && /^[a-zA-Z0-9_-]{1,60}$/.test(match[1]) ? match[1] : '';
}
