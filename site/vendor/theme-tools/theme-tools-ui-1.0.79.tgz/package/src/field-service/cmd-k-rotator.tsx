/**
 * Unified Cmd+K rotator (Wave 13D).
 *
 * Replaces three independent listeners that used to fight for focus:
 *   1. `AiChat.tsx` — opened the side chat panel.
 *   2. `cmd-k.tsx` — opened a global command palette dialog.
 *   3. `admin/QuickActionPalette.tsx` — opened an admin-only palette.
 *
 * The rotator collapses them into ONE keybinding that cycles through three
 * states:
 *
 *     closed → palette → chat → closed → …
 *
 * Esc closes the current open thing without advancing the cycle. Pressing
 * Cmd+K (or Ctrl+K) while typing in a text input ALWAYS works as a global
 * shortcut — we preventDefault the key event so the page rotates regardless
 * of focus. This is the intended UX: even mid-message, Cmd+K cycles.
 *
 * The pure state-machine functions (`advanceState`, `escState`) are
 * exported so the rotator can be unit-tested in a Node environment without
 * a DOM. The rest of the file is a thin React layer on top.
 */

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type JSX,
  type ReactNode,
} from 'react';
import {
  DEFAULT_COMMANDS,
  filterCommandsForContext,
  groupCommands,
  searchCommands,
  type CmdKCommand,
  type CmdKContext,
} from './cmd-k-commands.js';

const useIsomorphicLayoutEffect = typeof window === 'undefined' ? useEffect : useLayoutEffect;

// ─────────────────────────────────────────────────────────────────────────────
// Pure state machine — exported for tests
// ─────────────────────────────────────────────────────────────────────────────

export type CmdKState = 'closed' | 'palette' | 'chat';

/** Cycle Cmd+K presses through closed → palette → chat → closed. */
export function advanceState(state: CmdKState): CmdKState {
  if (state === 'closed') return 'palette';
  if (state === 'palette') return 'chat';
  return 'closed';
}

/** Esc always returns to closed regardless of current state. */
export function escState(_state: CmdKState): CmdKState {
  return 'closed';
}

/** Open a specific target (used by buttons and external callers). */
export function openTarget(target: 'palette' | 'chat'): CmdKState {
  return target;
}

// ─────────────────────────────────────────────────────────────────────────────
// Module-level singleton store
//
// The store doubles as the React-context default value: components calling
// `useCmdKState()` without a surrounding provider still get a working
// listener + state, which keeps the surface ready before the App.tsx
// integrator wires the provider in a follow-up commit.
// ─────────────────────────────────────────────────────────────────────────────

interface StoreSnapshot {
  state: CmdKState;
  commands: readonly CmdKCommand[];
}

type Listener = (snapshot: StoreSnapshot) => void;

interface RotatorStore {
  getSnapshot: () => StoreSnapshot;
  subscribe: (l: Listener) => () => void;
  advance: () => void;
  open: (target: 'palette' | 'chat') => void;
  close: () => void;
  registerCommands: (extra: readonly CmdKCommand[]) => () => void;
}

/** Build a fresh store. Each provider instance owns one. */
function createRotatorStore(): RotatorStore {
  let snapshot: StoreSnapshot = {
    state: 'closed',
    commands: DEFAULT_COMMANDS,
  };
  const listeners = new Set<Listener>();
  const extraSets = new Set<readonly CmdKCommand[]>();

  function emit(): void {
    for (const l of listeners) l(snapshot);
  }

  function recomputeCommands(): void {
    const merged: CmdKCommand[] = [...DEFAULT_COMMANDS];
    const seen = new Set(merged.map((c) => c.id));
    for (const set of extraSets) {
      for (const c of set) {
        if (seen.has(c.id)) continue;
        merged.push(c);
        seen.add(c.id);
      }
    }
    snapshot = { ...snapshot, commands: merged };
  }

  return {
    getSnapshot: () => snapshot,
    subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    advance() {
      snapshot = { ...snapshot, state: advanceState(snapshot.state) };
      emit();
    },
    open(target) {
      snapshot = { ...snapshot, state: openTarget(target) };
      emit();
    },
    close() {
      if (snapshot.state === 'closed') return;
      snapshot = { ...snapshot, state: 'closed' };
      emit();
    },
    registerCommands(extra) {
      extraSets.add(extra);
      recomputeCommands();
      emit();
      return () => {
        extraSets.delete(extra);
        recomputeCommands();
        emit();
      };
    },
  };
}

const singletonStore: RotatorStore = createRotatorStore();

// ─────────────────────────────────────────────────────────────────────────────
// React context
// ─────────────────────────────────────────────────────────────────────────────

const RotatorContext = createContext<RotatorStore>(singletonStore);
const RotatorProviderPresenceContext = createContext(false);

export interface CmdKRotatorProviderProps {
  readonly children: ReactNode;
  /** Override which command-context filters the palette uses. */
  readonly defaultContext?: CmdKContext;
}

/**
 * Wraps the app with a single rotator store + installs the global Cmd+K
 * listener once. Safe to omit — components fall back to a module-level
 * singleton that behaves identically.
 */
export function CmdKRotatorProvider({ children }: CmdKRotatorProviderProps): JSX.Element {
  // One store per provider instance. Default consumers use the singleton.
  const storeRef = useRef<RotatorStore | undefined>(undefined);
  if (!storeRef.current) storeRef.current = singletonStore;
  const store = storeRef.current;

  useGlobalHotkey(store);

  return (
    <RotatorProviderPresenceContext.Provider value={true}>
      <RotatorContext.Provider value={store}>{children}</RotatorContext.Provider>
    </RotatorProviderPresenceContext.Provider>
  );
}

export interface CmdKRotatorApi {
  readonly state: CmdKState;
  readonly commands: readonly CmdKCommand[];
  readonly advance: () => void;
  readonly open: (target: 'palette' | 'chat') => void;
  readonly close: () => void;
  readonly registerCommands: (extra: readonly CmdKCommand[]) => () => void;
}

/**
 * Subscribe to the rotator. Always returns a working API — falls back to
 * the module-level singleton when no provider is mounted.
 *
 * Also installs the global Cmd+K listener if it is the first subscriber.
 * Subsequent subscribers reuse the listener via the ref-counter below.
 */
export function useCmdKState(): CmdKRotatorApi {
  const store = useContext(RotatorContext);
  const hasProvider = useContext(RotatorProviderPresenceContext);
  const [snap, setSnap] = useState<StoreSnapshot>(() => store.getSnapshot());

  useEffect(() => {
    setSnap(store.getSnapshot());
    return store.subscribe(setSnap);
  }, [store]);

  // When no provider is mounted, useGlobalHotkey wasn't called by the
  // provider — register the listener here on first hook usage. We use
  // a ref-count via a module-level counter so the listener is only added
  // once even with many consumers.
  useFallbackHotkey(store, !hasProvider);

  return useMemo<CmdKRotatorApi>(
    () => ({
      state: snap.state,
      commands: snap.commands,
      advance: store.advance,
      open: store.open,
      close: store.close,
      registerCommands: store.registerCommands,
    }),
    [snap, store],
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Global hotkey installation
// ─────────────────────────────────────────────────────────────────────────────

/** Number of consumers currently relying on the fallback listener. */
let fallbackHotkeyRefs = 0;
let fallbackHotkeyTeardown: (() => void) | undefined;
let providerHotkeyActive = false;

function installHotkey(store: RotatorStore): () => void {
  if (typeof window === 'undefined') return () => {};
  const onKey = (e: globalThis.KeyboardEvent) => {
    const isMod = e.metaKey || e.ctrlKey;
    if (!isMod) return;
    if (e.key !== 'k' && e.key !== 'K') return;
    // Always intercept — Cmd+K is a global shortcut, even while typing.
    e.preventDefault();
    e.stopPropagation();
    store.advance();
  };
  const onEsc = (e: globalThis.KeyboardEvent) => {
    if (e.key !== 'Escape') return;
    const { state } = store.getSnapshot();
    if (state === 'closed') return;
    e.preventDefault();
    store.close();
  };
  window.addEventListener('keydown', onKey, { capture: true });
  window.addEventListener('keydown', onEsc);
  return () => {
    window.removeEventListener('keydown', onKey, { capture: true });
    window.removeEventListener('keydown', onEsc);
  };
}

/** Provider-side: install once for the lifetime of the provider. */
function useGlobalHotkey(store: RotatorStore): void {
  useIsomorphicLayoutEffect(() => {
    if (providerHotkeyActive) return;
    providerHotkeyActive = true;
    const teardown = installHotkey(store);
    // StrictMode performs a setup → cleanup → setup probe in development.
    // Publish readiness on the next frame so the probe's transient first setup
    // can never advertise a listener that is about to be removed.
    const readinessFrame = window.requestAnimationFrame(() => {
      document.documentElement.dataset.bclCmdKReady = 'true';
    });
    return () => {
      window.cancelAnimationFrame(readinessFrame);
      delete document.documentElement.dataset.bclCmdKReady;
      providerHotkeyActive = false;
      teardown();
    };
  }, [store]);
}

/** Hook-side fallback for consumers that mounted without a provider. */
function useFallbackHotkey(store: RotatorStore, enabled: boolean): void {
  useIsomorphicLayoutEffect(() => {
    if (!enabled) return;
    if (providerHotkeyActive) return;
    fallbackHotkeyRefs += 1;
    if (fallbackHotkeyRefs === 1) {
      fallbackHotkeyTeardown = installHotkey(store);
    }
    return () => {
      fallbackHotkeyRefs -= 1;
      if (fallbackHotkeyRefs === 0 && fallbackHotkeyTeardown) {
        fallbackHotkeyTeardown();
        fallbackHotkeyTeardown = undefined;
      }
    };
  }, [enabled, store]);
}

// ─────────────────────────────────────────────────────────────────────────────
// Unified palette UI
// ─────────────────────────────────────────────────────────────────────────────

/** Infer which command-context applies based on `location.pathname`. */
function contextFromPath(path: string): CmdKContext {
  if (path.startsWith('/admin')) return 'admin';
  if (path.startsWith('/work')) return 'worker';
  if (path.startsWith('/me') || path.startsWith('/track') || path.startsWith('/login'))
    return 'customer';
  return 'global';
}

function usePathContext(): CmdKContext {
  const [ctx, setCtx] = useState<CmdKContext>(() => {
    if (typeof window === 'undefined') return 'global';
    return contextFromPath(window.location.pathname);
  });
  useEffect(() => {
    const update = () => setCtx(contextFromPath(window.location.pathname));
    window.addEventListener('popstate', update);
    return () => window.removeEventListener('popstate', update);
  }, []);
  return ctx;
}

const RECENT_KEY = 'bcl_cmdk_recent_v1';
const RECENT_LIMIT = 4;

function loadRecent(): readonly string[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(RECENT_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw) as unknown;
    if (!Array.isArray(arr)) return [];
    return arr.filter((s): s is string => typeof s === 'string').slice(0, RECENT_LIMIT);
  } catch {
    return [];
  }
}

function saveRecent(ids: readonly string[]): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(RECENT_KEY, JSON.stringify(ids.slice(0, RECENT_LIMIT)));
  } catch {
    /* ignore quota errors */
  }
}

/**
 * Render the centered palette dialog when `state === 'palette'`. The chat
 * panel is rendered by `<AiChat />` directly — it reads the rotator state
 * and opens its own side panel when `state === 'chat'`, avoiding duplicate
 * mounts of the chat surface.
 */
export function UnifiedCmdK(): JSX.Element | null {
  const rotator = useCmdKState();
  const ctx = usePathContext();
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLUListElement>(null);
  const [query, setQuery] = useState('');
  const [activeIndex, setActiveIndex] = useState(0);
  const [recent, setRecent] = useState<readonly string[]>(() => loadRecent());

  const visibleCommands = useMemo(() => {
    const inCtx = filterCommandsForContext(rotator.commands, ctx);
    return searchCommands(inCtx, query);
  }, [rotator.commands, ctx, query]);

  const recentCommands = useMemo(() => {
    if (query.trim()) return [] as readonly CmdKCommand[];
    return recent
      .map((id) => visibleCommands.find((c) => c.id === id))
      .filter((c): c is CmdKCommand => Boolean(c));
  }, [recent, visibleCommands, query]);

  const grouped = useMemo(() => groupCommands(visibleCommands), [visibleCommands]);

  // Flatten the rendered order so keyboard navigation maps to real indices.
  const flat = useMemo<readonly CmdKCommand[]>(() => {
    const out: CmdKCommand[] = [];
    for (const c of recentCommands) out.push(c);
    for (const g of grouped) for (const c of g.items) out.push(c);
    return out;
  }, [recentCommands, grouped]);

  // Reset to top whenever the visible set changes.
  useEffect(() => {
    setActiveIndex(0);
  }, [visibleCommands.length, recentCommands.length]);

  // Focus the input the moment the palette opens.
  useEffect(() => {
    if (rotator.state !== 'palette') return;
    const id = window.requestAnimationFrame(() => {
      inputRef.current?.focus({ preventScroll: true });
    });
    return () => window.cancelAnimationFrame(id);
  }, [rotator.state]);

  // Reset transient UI state on close.
  useEffect(() => {
    if (rotator.state === 'closed') {
      setQuery('');
      setActiveIndex(0);
    }
  }, [rotator.state]);

  const runCommand = useCallback(
    (cmd: CmdKCommand) => {
      const nextRecent = [cmd.id, ...recent.filter((id) => id !== cmd.id)].slice(0, RECENT_LIMIT);
      setRecent(nextRecent);
      saveRecent(nextRecent);
      rotator.close();
      if (cmd.run) {
        cmd.run();
        return;
      }
      if (cmd.href && typeof window !== 'undefined') {
        if (cmd.href.startsWith('#') || cmd.href.startsWith('/#')) {
          window.location.href = cmd.href;
        } else {
          window.location.assign(cmd.href);
        }
      }
    },
    [recent, rotator],
  );

  const onKey = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActiveIndex((p) => (flat.length === 0 ? 0 : (p + 1) % flat.length));
      return;
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveIndex((p) => (flat.length === 0 ? 0 : (p - 1 + flat.length) % flat.length));
      return;
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      const cmd = flat[activeIndex];
      if (cmd) runCommand(cmd);
    }
  };

  if (rotator.state !== 'palette') return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Command palette"
      onKeyDown={onKey}
      className="fixed inset-0 z-[120] flex items-start justify-center pt-[12vh] px-4"
    >
      <button
        type="button"
        aria-label="Close command palette"
        onClick={() => rotator.close()}
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
      />
      <div
        className="relative w-full max-w-[600px] overflow-hidden rounded-2xl border border-brand-line bg-bg-primary shadow-2xl motion-safe:animate-[cmdk-pop_140ms_ease-out]"
        style={{ backgroundColor: '#0A0E14' }}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 opacity-[0.04] mix-blend-overlay"
          style={{
            backgroundImage:
              "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='100' height='100'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2'/></filter><rect width='100%' height='100%' filter='url(%23n)' opacity='0.5'/></svg>\")",
          }}
        />
        <div className="relative">
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="/help · / for commands · type to search"
            aria-label="Search commands"
            className="w-full border-b border-brand-line bg-transparent px-4 py-4 text-base text-brand-ink outline-none placeholder:text-brand-mute"
          />
          <div className="max-h-[60vh] overflow-y-auto">
            {recentCommands.length > 0 ? (
              <section className="border-b border-brand-line/60 p-2">
                <p className="px-3 py-1 text-[10px] font-mono uppercase tracking-wider text-brand-mute">
                  Recent
                </p>
                <ul ref={listRef}>
                  {recentCommands.map((c, idx) => (
                    <CmdRow
                      key={`recent-${c.id}`}
                      cmd={c}
                      active={idx === activeIndex}
                      onPick={() => runCommand(c)}
                      onHover={() => setActiveIndex(idx)}
                    />
                  ))}
                </ul>
              </section>
            ) : null}
            {grouped.length === 0 && recentCommands.length === 0 ? (
              <p className="p-6 text-center text-sm text-brand-mute">No matches.</p>
            ) : null}
            {grouped.map((g) => (
              <section key={g.category} className="p-2">
                <p className="px-3 py-1 text-[10px] font-mono uppercase tracking-wider text-brand-mute">
                  {g.category}
                </p>
                <ul>
                  {g.items.map((c) => {
                    const idx =
                      recentCommands.length +
                      grouped
                        .slice(0, grouped.indexOf(g))
                        .reduce((acc, gg) => acc + gg.items.length, 0) +
                      g.items.indexOf(c);
                    return (
                      <CmdRow
                        key={c.id}
                        cmd={c}
                        active={idx === activeIndex}
                        onPick={() => runCommand(c)}
                        onHover={() => setActiveIndex(idx)}
                      />
                    );
                  })}
                </ul>
              </section>
            ))}
          </div>
          <footer className="border-t border-brand-line px-4 py-2 font-mono text-[11px] text-brand-mute">
            <span className="mr-3">↑↓ Select</span>
            <span className="mr-3">↵ Run</span>
            <span className="mr-3">Esc Close</span>
            <span>⌘K Advance</span>
          </footer>
        </div>
      </div>
    </div>
  );
}

function CmdRow({
  cmd,
  active,
  onPick,
  onHover,
}: {
  cmd: CmdKCommand;
  active: boolean;
  onPick: () => void;
  onHover: () => void;
}): JSX.Element {
  return (
    <li>
      <button
        type="button"
        onMouseEnter={onHover}
        onFocus={onHover}
        onClick={onPick}
        aria-current={active ? 'true' : undefined}
        className={`flex w-full items-center justify-between gap-2 rounded-md px-3 py-2 text-left text-sm transition-colors ${
          active
            ? 'bg-brand-accent/15 text-brand-accent'
            : 'text-brand-ink/90 hover:bg-brand-accent/10'
        }`}
      >
        <span className="truncate font-semibold">{cmd.title}</span>
        {cmd.hint ? <span className="font-mono text-xs text-brand-mute">{cmd.hint}</span> : null}
      </button>
    </li>
  );
}
