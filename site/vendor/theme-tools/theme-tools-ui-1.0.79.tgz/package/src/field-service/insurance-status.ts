// Single source of truth for Brick Labor's insurance / operating-authority
// status. The site's CONTRACT (Terms §11) is the ground truth: Brick Labor is
// casual hourly labor — NOT a licensed contractor, crew are independent
// contractors NOT insured by Brick Labor, and any liability policy is "pending
// issuance" until a real certificate is on file. Every marketing surface that
// renders an insurance/coverage claim (the hero TrustBadges tile, referral
// pages, JSON-LD) MUST gate the claim on `hasActiveCoverage` so the site never
// asserts coverage it cannot substantiate. The proof is sourced live from
// GET /api/stats/insurance, which reads optional `INSURANCE_*` worker secrets;
// when those are unset every field is null and `hasActiveCoverage` is false —
// the badge self-arms the moment Brian provisions a real policy + COI.

/**
 * Live insurance / DOT proof shape shared by the worker stats route, the web
 * `insurance-proof` fetcher, and the `<TrustBadges />` renderer. One shape, no
 * drift (per zod-everywhere — single definition imported on both sides).
 */
export interface InsuranceProof {
  readonly usdot: string | null;
  readonly mcNumber: string | null;
  readonly certificateOfInsuranceUrl: string | null;
  readonly liabilityCoverageDollars: number | null;
  readonly cargoCoverageDollars: number | null;
  readonly carrierName: string | null;
  readonly asOf: string;
}

/** Carrier values that mean "no policy yet" — never treated as active coverage. */
const PENDING_CARRIERS = new Set(['', 'pending', 'pending issuance', 'none', 'n/a']);

/**
 * True only when a real, substantiable liability policy is on file: a named
 * carrier that is not a "pending" placeholder AND either a coverage amount or a
 * certificate-of-insurance URL. Anything short of that renders the honest
 * "damage-protected, coverage pending" surface instead of an insurance claim.
 *
 * @param p - the insurance proof (or any subset carrying carrier + coverage + COI)
 * @returns whether the site may truthfully assert active insurance coverage
 *
 * @example
 * hasActiveCoverage({ carrierName: 'Pending issuance', liabilityCoverageDollars: 1_000_000, certificateOfInsuranceUrl: null }) // false
 * hasActiveCoverage({ carrierName: 'Acme Mutual', liabilityCoverageDollars: 1_000_000, certificateOfInsuranceUrl: null })     // true
 */
export function hasActiveCoverage(
  p: Pick<InsuranceProof, 'carrierName' | 'liabilityCoverageDollars' | 'certificateOfInsuranceUrl'>,
): boolean {
  const carrier = (p.carrierName ?? '').trim().toLowerCase();
  if (PENDING_CARRIERS.has(carrier)) return false;
  return Boolean(p.liabilityCoverageDollars || p.certificateOfInsuranceUrl);
}

/**
 * Honest fallback proof — every field null, carrier null. `hasActiveCoverage`
 * returns false for this, so the site shows the truthful "coverage pending"
 * surface. NEVER seed this with placeholder dollar amounts: a fabricated
 * "$1M liability" on a policy that does not exist is a false-advertising claim.
 */
export const PENDING_PROOF: InsuranceProof = {
  usdot: null,
  mcNumber: null,
  certificateOfInsuranceUrl: null,
  liabilityCoverageDollars: null,
  cargoCoverageDollars: null,
  carrierName: null,
  asOf: '1970-01-01',
};
