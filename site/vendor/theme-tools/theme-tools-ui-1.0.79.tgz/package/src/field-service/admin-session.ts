import { useEffect, useState, useCallback } from 'react';
import { clearAdminToken, getAdminToken } from '@theme.tools/crm/field-service/admin-api';

// Client-side hook + types for the super-admin session. Fetches `/api/admin/auth/me`
// and falls back to the unified admin bearer token (`getAdminToken()`) when set.

export type AdminRole = 'super' | 'dispatcher' | 'support';

export interface AdminIdentity {
  readonly id: string;
  readonly role: AdminRole;
  readonly name: string;
}

export type AdminSessionState =
  | { readonly status: 'checking' }
  | { readonly status: 'anonymous' }
  | { readonly status: 'authenticated'; readonly admin: AdminIdentity };

interface MeResponse {
  authenticated?: boolean;
  admin?: AdminIdentity;
}

function tokenFallbackState(): AdminSessionState {
  const tok = getAdminToken();
  if (tok) {
    return {
      status: 'authenticated',
      admin: { id: 'operator', role: 'super', name: 'Operator' },
    };
  }
  return { status: 'anonymous' };
}

export function useAdminSession(): {
  readonly state: AdminSessionState;
  readonly refresh: () => Promise<void>;
} {
  const [state, setState] = useState<AdminSessionState>(() => {
    const tok = getAdminToken();
    if (tok) {
      return {
        status: 'authenticated',
        admin: { id: 'operator', role: 'super', name: 'Operator' },
      };
    }
    return { status: 'checking' };
  });

  const probe = useCallback(async (): Promise<void> => {
    try {
      const res = await fetch('/api/admin/auth/me', { credentials: 'include' });
      if (!res.ok) {
        setState(tokenFallbackState());
        return;
      }
      const body = (await res.json().catch(() => ({}))) as MeResponse;
      if (body.authenticated && body.admin) {
        setState({ status: 'authenticated', admin: body.admin });
      } else {
        setState(tokenFallbackState());
      }
    } catch {
      setState(tokenFallbackState());
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/api/admin/auth/me', { credentials: 'include' });
        if (cancelled) return;
        if (!res.ok) {
          setState(tokenFallbackState());
          return;
        }
        const body = (await res.json().catch(() => ({}))) as MeResponse;
        if (cancelled) return;
        if (body.authenticated && body.admin) {
          setState({ status: 'authenticated', admin: body.admin });
        } else {
          setState(tokenFallbackState());
        }
      } catch {
        if (!cancelled) setState(tokenFallbackState());
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  return { state, refresh: probe };
}

export async function adminLogout(redirect: string = '/admin/login'): Promise<void> {
  try {
    await fetch('/api/admin/auth/logout', {
      method: 'POST',
      credentials: 'include',
    });
  } catch {
    /* ignore — clearing local state matters more than the server ACK */
  }
  try {
    clearAdminToken();
  } catch {
    /* ignore */
  }
  window.location.replace(redirect);
}
