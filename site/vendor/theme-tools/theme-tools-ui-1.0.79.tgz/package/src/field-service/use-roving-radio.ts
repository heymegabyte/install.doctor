import { useRef } from 'react';
import type { KeyboardEvent } from 'react';
import { nextRadioIndex, rovingTabIndex } from "./radio-keynav.js";

/**
 * Props a single option in a custom `role="radio"` group spreads onto its
 * `<button>` to satisfy the ARIA roving-tabindex keyboard contract.
 */
export interface RovingRadioOptionProps {
  ref: (el: HTMLButtonElement | null) => void;
  tabIndex: 0 | -1;
  onKeyDown: (e: KeyboardEvent<HTMLButtonElement>) => void;
}

/**
 * React adapter over the pure `radio-keynav` helper. A custom `role="radiogroup"`
 * whose options are `onClick`-only `<button role="radio">` rows FAILS the ARIA
 * Authoring Practices pattern: every option is independently Tab-focusable and
 * arrows do nothing. axe-core cannot detect this interaction-pattern gap, so it
 * shipped green across several groups (Pricing, post-job rating, the booking
 * payment + truck pickers) even though +223 fixed the recurring-cadence one.
 *
 * Call once per group at component top; spread the returned getter on each option
 * button. The group becomes a single tab stop (only the selected option is
 * focusable) and arrow/Home/End move selection AND focus, wrapping at the ends.
 *
 * @param count - Total options in the group (≥ 1).
 * @param select - Called with the index the user navigated to (selects + focuses it).
 * @returns A getter `(index, isSelected) => props` to spread on each option button.
 * @example
 * const radio = useRovingRadio(3, (i) => setMode(MODES[i]));
 * // <button role="radio" aria-checked={active} {...radio(i, active)}>…</button>
 */
export function useRovingRadio(
  count: number,
  select: (index: number) => void,
): (index: number, isSelected: boolean) => RovingRadioOptionProps {
  const refs = useRef<(HTMLButtonElement | null)[]>([]);
  // Getter is rebuilt each render on purpose so `select` never goes stale
  // (truck selection reads live `truckPicks` qty). Spread-prop identity churn is
  // harmless; the persistent `refs` array is what carries focus targets.
  return (index, isSelected) => ({
    ref: (el) => {
      refs.current[index] = el;
    },
    tabIndex: rovingTabIndex(isSelected),
    onKeyDown: (e) => {
      const target = nextRadioIndex(index, count, e.key);
      if (target === null) return;
      e.preventDefault();
      select(target);
      refs.current[target]?.focus();
    },
  });
}

/**
 * Roving-tabindex keyboard navigation for a custom ARIA `role="tablist"`.
 *
 * An identical twin of {@link useRovingRadio}: the ARIA Authoring Practices
 * tablist pattern has the SAME single-tab-stop + arrow/Home/End roving contract
 * as a radio group — only the per-option ARIA attribute differs (`aria-selected`
 * on a `role="tab"` vs `aria-checked` on a `role="radio"`), and that is set by
 * the consumer's JSX, not by this hook. A `role="tab"` row that is `onClick`-only
 * with every tab independently Tab-focusable FAILS the pattern exactly the way an
 * un-roved radio group does, and axe-core cannot see it (it is an
 * interaction-pattern gap, not a static-attribute one). This alias exists so
 * tablist call sites read semantically (`useRovingTabs`) instead of borrowing the
 * radio name. Uses automatic activation (selection follows focus) — correct when
 * the panel is cheap to render (e.g. a client-side list filter).
 *
 * @param count - Total tabs in the list (≥ 1).
 * @param select - Called with the index the user navigated to (selects + focuses it).
 * @returns A getter `(index, isSelected) => props` to spread on each tab button.
 * @example
 * const tabs = useRovingTabs(cats.length, (i) => setCategory(cats[i]));
 * // <button role="tab" aria-selected={active} {...tabs(i, active)}>…</button>
 */
export const useRovingTabs = useRovingRadio;
