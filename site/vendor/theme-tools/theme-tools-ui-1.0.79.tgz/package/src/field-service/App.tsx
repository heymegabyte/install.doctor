import {
  lazy,
  startTransition,
  Suspense,
  useEffect,
  useState,
  type JSX,
  type ReactNode,
} from 'react';
import { htmlLangFor, localizedPath, stripLocalePrefix } from '@theme.tools/i18n-a11y/field-service/locale';
import { isKnownRoute } from '@theme.tools/seo-geo/field-service/known-routes';
import { prerenderedRoot } from './prerendered-root.js';
import { startSafeViewTransition, useThemeToolsSurface } from '../field-service-primitives.js';
import { Header } from './components/Header.js';
import { Hero } from './components/Hero.js';
import { Services } from './components/Services.js';
import { BeforeAfter } from './components/BeforeAfter.js';
import { FAQ } from './components/FAQ.js';
import { Footer } from './components/Footer.js';
import { MinimalFooter } from './components/MinimalFooter.js';
import { TrustBadges } from './components/TrustBadges.js';
import { Testimonials } from './components/Testimonials.js';
import { BackToTop } from './components/BackToTop.js';
import { CmdKRotatorProvider } from './cmd-k-rotator.js';
import { FloatingCallButton } from './components/FloatingCallButton.js';
import { ExitIntentRescue } from './components/ExitIntentRescue.js';
import { PwaInstallPrompt } from './components/customer/PwaInstallPrompt.js';
import { PushPermissionPrompt } from './components/PushPermissionPrompt.js';
import { useFeatureFlag } from './use-feature-flag.js';
import { AvatarProvider } from './avatar-context.js';
import { UndoProvider } from './components/providers/UndoProvider.js';
// IntegrationsPage + FollowupChat are route-only full pages ( /integrations and
// /me/followups ) — lazy()-loaded below so they leave the render-blocking entry
// chunk (perf budget; see tests/unit/route-page-lazy-loaded.test.ts).
import { StatStrip } from './components/StatStrip.js';
import { DonationCounter } from './components/DonationCounter.js';
import { AiFairMarket } from './components/AiFairMarket.js';
import { DashboardPromo } from './components/DashboardPromo.js';
import { BundlesBlock } from './components/CityConversion.js';
import { CmdKPalette } from './cmd-k.js';
// ImpersonationBanner mounts globally at app root → stays eager. FollowupChat
// (the /me/followups route page) is lazy()-loaded below, out of the entry chunk.
import { ImpersonationBanner } from './components/ImpersonationBanner.js';
import { CookieConsent } from './components/CookieConsent.js';
import { PRICING_BENCHMARKS } from './data/research.js';
import { getCityBySlug } from './data/cities.js';
import { findNeighborhood } from './data/neighborhoods.js';

/**
 * Lazy-loaded heavy components. Each lives in its own Vite chunk so the
 * initial JS payload stays slim — Booking + Admin + Dashboard together
 * account for ~500 KB of source and dwarf the first paint critical path.
 * Importing them on demand keeps LCP below 2 s on the homepage.
 *
 * AiChat (the unified AI surface — ~44 KB component + ~120 KB of ai-chat/
 * widget renderers, slash-command catalog, markdown) is lazy-loaded too: it's
 * a floating overlay, never above-the-fold, never the LCP element, often never
 * opened — so its tree belongs in its own chunk that loads AFTER first paint,
 * not in the entry bundle every homepage visitor downloads. The Cmd/Ctrl+K
 * hotkey (previously the only reason AiChat was eager) now installs at app
 * mount via <CmdKRotatorProvider>, which registers the global listener WITHOUT
 * subscribing to rotator state (no App re-render) — so Cmd+K stays instant even
 * before the AiChat chunk lands. The legacy ConciergePane was superseded by
 * AiChat in 2026-05 — the file is retained in src/web/components/ for archival
 * reference but is no longer mounted anywhere.
 */
const Booking = lazy(() => import('./components/Booking.js').then((m) => ({ default: m.Booking })));
const CoverageMap = lazy(() =>
  import('./components/CoverageMap.js').then((m) => ({ default: m.CoverageMap })),
);
const ResearchPanel = lazy(() =>
  import('./components/ResearchPanel.js').then((m) => ({ default: m.ResearchPanel })),
);
// Route-only leaf pages — never render on the homepage, so they ship in their own
// on-demand chunks (caught by the top-level <main> Suspense boundary below) instead of
// bloating the entry bundle every visitor downloads. Cuts the homepage's initial JS.
const Sources = lazy(() => import('./components/Sources.js').then((m) => ({ default: m.Sources })));
const NeighborhoodPage = lazy(() =>
  import('./components/NeighborhoodPage.js').then((m) => ({ default: m.NeighborhoodPage })),
);
const SplitPaymentPage = lazy(() => import('./components/SplitPaymentPage.js'));
const WorkLanding = lazy(() =>
  import('./components/WorkLanding.js').then((m) => ({ default: m.WorkLanding })),
);
const ClaimsBoard = lazy(() =>
  import('./components/ClaimsBoard.js').then((m) => ({ default: m.ClaimsBoard })),
);
const TcpaPolicy = lazy(() =>
  import('./components/TcpaPolicy.js').then((m) => ({ default: m.TcpaPolicy })),
);
const TakeRatePage = lazy(() =>
  import('./components/TakeRatePage.js').then((m) => ({ default: m.TakeRatePage })),
);
const CancellationPolicyPage = lazy(() =>
  import('./components/CancellationPolicyPage.js').then((m) => ({
    default: m.CancellationPolicyPage,
  })),
);
const PartnerLanding = lazy(() =>
  import('./components/PartnerLanding.js').then((m) => ({ default: m.PartnerLanding })),
);
const PropertyManagerPage = lazy(() =>
  import('./components/PropertyManagerPage.js').then((m) => ({ default: m.PropertyManagerPage })),
);
const SlackInstall = lazy(() => import('./components/integrations/SlackInstall.js'));
const ServicesIndex = lazy(() =>
  import('./components/ServicesIndex.js').then((m) => ({ default: m.ServicesIndex })),
);
const ServiceCategoryCalculator = lazy(() =>
  import('./components/services/ServiceCategoryCalculator.js').then((m) => ({
    default: m.ServiceCategoryCalculator,
  })),
);
const CustomerReferralPage = lazy(() =>
  import('./components/CustomerReferralPage.js').then((m) => ({ default: m.CustomerReferralPage })),
);
const CrewReferralWidget = lazy(() =>
  import('./components/CrewReferralWidget.js').then((m) => ({ default: m.CrewReferralWidget })),
);
const CrewProfilePublic = lazy(() =>
  import('./components/work/CrewProfilePublic.js').then((m) => ({ default: m.CrewProfilePublic })),
);
// Route-exclusive page components — lazy so their JS leaves the entry chunk that
// every visitor (homepage + /book money path) downloads. Each renders inside the
// top-level <main> Suspense boundary, so no per-branch fallback is needed.
const IntegrationsPage = lazy(() =>
  import('./components/integrations/IntegrationsPage.js').then((m) => ({
    default: m.IntegrationsPage,
  })),
);
const FollowupChat = lazy(() =>
  import('./components/customer/FollowupChat.js').then((m) => ({ default: m.FollowupChat })),
);
const CityPage = lazy(() => import('./components/CityPage.js').then((m) => ({ default: m.CityPage })));
const BlogIndex = lazy(() =>
  import('./components/BlogIndex.js').then((m) => ({ default: m.BlogIndex })),
);
const QuoteShare = lazy(() =>
  import('./components/QuoteShare.js').then((m) => ({ default: m.QuoteShare })),
);
const SchedulePage = lazy(() =>
  import('./components/FunnelPages.js').then((m) => ({ default: m.SchedulePage })),
);
const QuotePage = lazy(() =>
  import('./components/FunnelPages.js').then((m) => ({ default: m.QuotePage })),
);
const EmergencyLaborPage = lazy(() =>
  import('./components/FunnelPages.js').then((m) => ({ default: m.EmergencyLaborPage })),
);
const ContactPage = lazy(() =>
  import('./components/ContactPage.js').then((m) => ({ default: m.ContactPage })),
);
// Homepage-only below-the-fold section group (Reviews + OwnerBio + Contact),
// code-split so its JS leaves the entry chunk that every pSEO page downloads.
const HomeMidSections = lazy(() => import('./components/HomeMidSections.js'));
const Pricing = lazy(() => import('./components/Pricing.js').then((m) => ({ default: m.Pricing })));
const AiChat = lazy(() => import('./components/AiChat.js').then((m) => ({ default: m.AiChat })));
// BookingRecurring (the standalone /recurring form) was retired 2026-09-25 —
// recurring cadence now lives inline in the /book Booking form. /recurring 301s
// to /book at the worker edge; App keeps a client-side redirect for defense in depth.
const PhotoEstimatePage = lazy(() =>
  import('./components/PhotoEstimatePage.js').then((m) => ({ default: m.PhotoEstimatePage })),
);
const AdminAiToolsPage = lazy(() =>
  import('./components/AdminAiToolsPage.js').then((m) => ({ default: m.AdminAiToolsPage })),
);
const PlansPage = lazy(() =>
  import('./components/PlansPage.js').then((m) => ({ default: m.PlansPage })),
);
const SourcesPage = lazy(() =>
  import('./components/SourcesPage.js').then((m) => ({ default: m.SourcesPage })),
);
const HelpCenterPage = lazy(() =>
  import('./components/help/HelpCenterPage.js').then((m) => ({ default: m.HelpCenterPage })),
);
const VideoTestimonials = lazy(() =>
  import('./components/VideoTestimonials.js').then((m) => ({ default: m.VideoTestimonials })),
);
const WhatWeDontDoPage = lazy(() =>
  import('./components/services/WhatWeDontDoPage.js').then((m) => ({ default: m.WhatWeDontDoPage })),
);
const ReferPage = lazy(() =>
  import('./components/ReferPage.js').then((m) => ({ default: m.ReferPage })),
);
// NotFound404 is the SPA catch-all for paths that match no known route family
// (see `isKnownRoute` in `src/shared/known-routes.ts`). The worker serves those
// same paths 404 + `noindex`; the client renders the AI-suggested 404 instead
// of the homepage (which used to absorb every garbage URL as a soft-404).
// Legit dynamic trees (/c/foo, /blog/bar, /track/xyz) stay known → real pages.
const NotFound404 = lazy(() =>
  import('./components/NotFound404.js').then((m) => ({ default: m.NotFound404 })),
);
const UnifiedDashboard = lazy(() =>
  import('./components/UnifiedDashboard.js').then((m) => ({ default: m.UnifiedDashboard })),
);
const ApplyPage = lazy(() =>
  import('./components/ApplyPage.js').then((m) => ({ default: m.ApplyPage })),
);
const ServiceGuaranteePage = lazy(() =>
  import('./components/ServiceGuaranteePage.js').then((m) => ({ default: m.ServiceGuaranteePage })),
);
const StatusPage = lazy(() =>
  import('./components/StatusPage.js').then((m) => ({ default: m.StatusPage })),
);
const Admin = lazy(() => import('./components/Admin.js').then((m) => ({ default: m.Admin })));
const WorkerDashboard = lazy(() =>
  import('./components/WorkerDashboard.js').then((m) => ({ default: m.WorkerDashboard })),
);
const BlogPost = lazy(() => import('./components/BlogPost.js').then((m) => ({ default: m.BlogPost })));
const GuidePowerWashing = lazy(() =>
  import('./components/GuidePowerWashing.js').then((m) => ({ default: m.GuidePowerWashing })),
);
const SearchPage = lazy(() =>
  import('./components/SearchPage.js').then((m) => ({ default: m.SearchPage })),
);
const RateCrew = lazy(() => import('./components/RateCrew.js').then((m) => ({ default: m.RateCrew })));
const MePage = lazy(() => import('./components/MePage.js').then((m) => ({ default: m.MePage })));
const NeighborReferralPage = lazy(() =>
  import('./components/NeighborReferralPage.js').then((m) => ({ default: m.NeighborReferralPage })),
);
const PayPage = lazy(() => import('./components/PayPage.js').then((m) => ({ default: m.PayPage })));
const LandingMatrixPage = lazy(() =>
  import('./components/LandingMatrixPage.js').then((m) => ({ default: m.LandingMatrixPage })),
);

/**
 * Heavy route-only pages — each renders under exactly one route family and is
 * never on the homepage or a pSEO city page. Eager-importing them shipped
 * ~150 KB of source (LoginPage ~56 KB, Terms ~30 KB, ApiDocsPage ~31 KB,
 * TrackBooking ~31 KB, Privacy ~24 KB, B2bApiDocsPage ~13 KB) in the entry
 * chunk every crawler/marketing visitor downloaded. Lazy chunks keep that
 * weight off first paint → faster LCP on the SEO-critical pSEO surface.
 */
const LoginPage = lazy(() =>
  import('./components/LoginPage.js').then((m) => ({ default: m.LoginPage })),
);
const Privacy = lazy(() => import('./components/Privacy.js').then((m) => ({ default: m.Privacy })));
const Terms = lazy(() => import('./components/Terms.js').then((m) => ({ default: m.Terms })));
const TrackBooking = lazy(() =>
  import('./components/TrackBooking.js').then((m) => ({ default: m.TrackBooking })),
);
const ApiDocsPage = lazy(() =>
  import('./components/ApiDocsPage.js').then((m) => ({ default: m.ApiDocsPage })),
);
const B2bApiDocsPage = lazy(() =>
  import('./components/B2bApiDocsPage.js').then((m) => ({ default: m.B2bApiDocsPage })),
);

/**
 * Admin surfaces — render ONLY under /admin/* (inside AdminShell), never on any
 * public/marketing/pSEO route. The whole cluster (cockpit, entity browsers,
 * finance, ops, safety, marketing studio, channel inbox, AI-rules, 1099/fraud)
 * lived in the entry bundle that every homepage visitor downloaded; lazy chunks
 * load it only when an operator hits /admin. Wrapped by the top-level <main>
 * Suspense boundary, so no per-branch fallback is needed.
 */
const SuperAdminLogin = lazy(() =>
  import('./components/admin/SuperAdminLogin.js').then((m) => ({ default: m.SuperAdminLogin })),
);
const SuperAdminDashboard = lazy(() =>
  import('./components/admin/SuperAdminDashboard.js').then((m) => ({
    default: m.SuperAdminDashboard,
  })),
);
const JobsBrowser = lazy(() =>
  import('./components/admin/JobsBrowser.js').then((m) => ({ default: m.JobsBrowser })),
);
const CustomersBrowser = lazy(() =>
  import('./components/admin/CustomersBrowser.js').then((m) => ({ default: m.CustomersBrowser })),
);
const WorkersBrowser = lazy(() =>
  import('./components/admin/WorkersBrowser.js').then((m) => ({ default: m.WorkersBrowser })),
);
const ApplicantsBrowser = lazy(() =>
  import('./components/admin/ApplicantsBrowser.js').then((m) => ({ default: m.ApplicantsBrowser })),
);
const NotificationsInbox = lazy(() =>
  import('./components/admin/NotificationsInbox.js').then((m) => ({ default: m.NotificationsInbox })),
);
const AdminShell = lazy(() =>
  import('./components/admin/AdminShell.js').then((m) => ({ default: m.AdminShell })),
);
const AiRulesAdmin = lazy(() => import('./components/admin/AiRulesAdmin.js'));
const SuperAdminWidgetsTab = lazy(() =>
  import('./components/admin/SuperAdminWidgetsTab.js').then((m) => ({
    default: m.SuperAdminWidgetsTab,
  })),
);
const Wave20FeaturesGrid = lazy(() => import('./components/admin/Wave20FeaturesGrid.js'));
const SafetyDashboard = lazy(() =>
  import('./components/admin/safety/SafetyDashboard.js').then((m) => ({ default: m.SafetyDashboard })),
);
const FinanceDashboard = lazy(() => import('./components/admin/finance/FinanceDashboard.js'));
const Form1099NecPage = lazy(() => import('./components/admin/finance/Form1099NecPage.js'));
const FraudQueuePage = lazy(() => import('./components/admin/finance/FraudQueuePage.js'));
const OpsHealthDashboard = lazy(() => import('./components/admin/ops/OpsHealthDashboard.js'));
const MarketingStudio = lazy(() =>
  import('./components/admin/MarketingStudio.js').then((m) => ({ default: m.MarketingStudio })),
);
const ChannelInbox = lazy(() =>
  import('./components/admin/ChannelInbox.js').then((m) => ({ default: m.ChannelInbox })),
);

/**
 * Skeleton fallback while a lazy chunk loads. Reserves vertical space so the
 * Suspense swap doesn't introduce CLS — the booking widget is the biggest
 * offender so we hold ~600 px of room there.
 */
function LazyFallback({ minHeight = '40vh' }: { minHeight?: string }): JSX.Element {
  return (
    <div
      role="status"
      aria-live="polite"
      aria-busy="true"
      className="mx-auto my-8 w-full max-w-4xl animate-pulse rounded-lg border border-brand-line/40 bg-bg-elevated/30"
      style={{ minHeight }}
    >
      <span className="sr-only">Loading…</span>
    </div>
  );
}

function withSuspense(node: ReactNode, minHeight?: string): JSX.Element {
  return <Suspense fallback={<LazyFallback minHeight={minHeight} />}>{node}</Suspense>;
}

function getRoute(): string {
  if (typeof window === 'undefined') return '/';
  // Strip the /es or /pt mirror prefix so a localized landing page
  // (e.g. /es/services/power-washing) matches the SAME route branch as its
  // canonical English page. Without this, every prerendered mirror page falls
  // through to the homepage `else` branch the instant React hydrates.
  const { path } = stripLocalePrefix(window.location.pathname);
  return path.replace(/\/$/, '') || '/';
}

const HOME_HASHES = new Set([
  // §book-canonical (2026-05-28) — #book retired; the Booking form lives
  // only at /book now. Any in-flight #book hash from old marketing emails
  // or shared links is redirected to /book by the worker before reaching
  // the SPA.
  '#about',
  '#contact',
  '#coverage',
  '#services',
  '#pricing',
  '#faq',
  '#fair-market',
  '#dashboard',
]);

export function App() {
  const [route, setRoute] = useState(getRoute);
  // Browser-only overlays can read viewport, platform, and persisted state while
  // rendering. Keep them out of the server tree and the first hydration pass so
  // those client inputs cannot invalidate the stable marketing-page markup.
  const [clientReady, setClientReady] = useState(false);
  // Customer arrival-push opt-in. Gated by the `push_arrival_notifications`
  // flag; the prompt self-gates further (push-capable browser, 12s delay,
  // once-per-deploy localStorage). Default-off until promoted from /admin.
  const pushArrivalOn = useFeatureFlag('push_arrival_notifications');

  useEffect(() => {
    // The homepage contains streamed Suspense boundaries. Mark this update as a
    // transition so React can finish hydrating them before mounting client-only
    // overlays instead of forcing a boundary to abandon hydration (error 421).
    startTransition(() => setClientReady(true));
  }, []);

  useEffect(() => {
    // Wrap popstate route swaps in View Transitions when the browser
    // supports it. Chrome/Safari 18+ get a free cinematic cross-fade +
    // the named view-transition-name shared elements (header, hero H1,
    // hero CTA) from `src/web/styles/index.css` morph cleanly. Firefox
    // (no support) falls back to a plain setRoute, zero behavior change.
    const onPop = () => {
      const next = getRoute();
      if (
        'startViewTransition' in document &&
        !window.matchMedia('(prefers-reduced-motion: reduce)').matches
      ) {
        if (!startSafeViewTransition(document, () => setRoute(next))) setRoute(next);
      } else {
        setRoute(next);
      }
    };
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  // Set <html lang> from the URL's locale prefix on first mount so deep-linked
  // /es/* and /pt/* pages announce the right language to assistive tech and
  // crawlers immediately — before the footer LocaleSwitcher mounts.
  useEffect(() => {
    if (typeof document === 'undefined') return;
    const { locale } = stripLocalePrefix(window.location.pathname);
    document.documentElement.lang = htmlLangFor(locale);
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const { path: stripped } = stripLocalePrefix(window.location.pathname);
    const path = stripped.replace(/\/$/, '') || '/';
    const hash = window.location.hash;
    // Legacy /docs/power-washing → /guides/power-washing (2026-08-28). The worker
    // 301s this at the edge, but a stale cached shell can still be served from a
    // POP before the redirect propagates; this client-side fallback (same
    // defense-in-depth pattern as the /work/profile redirect) guarantees the
    // user still lands on the new URL. Preserve any query + hash.
    if (path === '/docs/power-washing') {
      window.location.replace('/guides/power-washing' + window.location.search + hash);
      return;
    }
    // §book-canonical (2026-05-28) — legacy #book hash (from old emails,
    // shared links, bookmarks) now redirects to /book regardless of which
    // page it landed on. The Booking form lives only at /book; the
    // homepage no longer hosts it.
    if (hash === '#book') {
      // In-app swap (NOT window.location.replace) — a full reload here could
      // loop if a stale cached shell re-introduced the hash; an in-app route
      // change cannot. Preserve the query (?service=, ?ml= magic-link, ?from=)
      // which a bare replace('/book') silently dropped. Strip the #book hash
      // so the URL is clean and the redirect is idempotent (never re-fires).
      const dest = '/book' + window.location.search;
      window.history.replaceState(null, '', dest);
      setRoute('/book');
      return;
    }
    // Bare /track, /review with no ID would render the homepage —
    // bounce to / so we don't ship duplicate content. ID-bearing routes
    // (/track/<id>, /review/<id>) still match below.
    // §quote-funnel (2026-05-26) — /quote is its own funnel landing page
    // (QuotePage in FunnelPages.tsx); it now hosts the service-area map and
    // pricing examples. Excluded from the bounce so bare /quote renders.
    if (path === '/track' || path === '/review') {
      window.location.replace('/');
    }
  }, []);

  // Hash → smooth scroll, with sticky-nav offset. Fires on first mount AND
  // any subsequent hashchange. For #book specifically, prefer the nested
  // #book-form anchor so the viewport lands ON the form, not above the
  // section eyebrow + intro. Two rAFs defer until React commits + sections
  // lay out. prefers-reduced-motion swaps smooth → instant.
  useEffect(() => {
    if (typeof window === 'undefined') return;
    let cancelled = false;
    let pendingTarget: MutationObserver | undefined;
    let generation = 0;
    function scrollToHash() {
      const currentGeneration = ++generation;
      pendingTarget?.disconnect();
      pendingTarget = undefined;
      if (cancelled) return;
      const hash = window.location.hash;
      if (!hash || hash === '#') return;
      const id = hash.slice(1);
      requestAnimationFrame(() => {
        if (cancelled || currentGeneration !== generation) return;
        requestAnimationFrame(() => {
          if (cancelled || currentGeneration !== generation) return;
          const el = document.getElementById(id);
          if (!el && HOME_HASHES.has(hash)) {
            const { locale, path } = stripLocalePrefix(window.location.pathname);
            if (path !== '/') {
              // A shared header can link to a homepage section absent here.
              // Handle both arrival and later native fragment navigation, while
              // preserving local sections, language and campaign attribution.
              window.location.replace(localizedPath(locale, '/') + window.location.search + hash);
              return;
            }
          }
          if (!el && HOME_HASHES.has(hash)) {
            // Homepage sections can arrive in a lazy chunk after this effect.
            // Observe insertion instead of losing a valid fragment on cold loads.
            pendingTarget = new MutationObserver(() => {
              if (cancelled || currentGeneration !== generation) return;
              if (document.getElementById(id)) scrollToHash();
            });
            pendingTarget.observe(document.body, { childList: true, subtree: true });
          }
          if (el) {
            const reduce =
              typeof window.matchMedia === 'function' &&
              window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            el.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
          }
        });
      });
    }
    scrollToHash();
    window.addEventListener('hashchange', scrollToHash);
    return () => {
      cancelled = true;
      generation++;
      pendingTarget?.disconnect();
      pendingTarget = undefined;
      window.removeEventListener('hashchange', scrollToHash);
    };
  }, [route]);

  // Gate finite-tree slugs on isKnownRoute so a FAKE city/blog slug
  // (`/c/jersey-city-nj`, `/blog/not-real`) falls through to the NotFound404
  // catch-all instead of React rendering an empty page over the worker's 404.
  const cityMatch = route.match(/^\/c\/([a-z0-9-]+)$/);
  const citySlug = cityMatch && isKnownRoute(route) ? cityMatch[1] : undefined;
  // Neighborhood pages live at /c/<city>/<neighborhood>. Matrix city×service
  // pages share the same shape but only the neighborhood pair appears in
  // neighborhoods.mjs — we gate via findNeighborhood so matrix routes fall
  // through to their prerendered HTML without React stomping the content.
  const nbMatch = route.match(/^\/c\/([a-z0-9-]+)\/([a-z0-9-]+)$/);
  const nbCitySlug = nbMatch?.[1];
  const nbSlugCandidate = nbMatch?.[2];
  const isNeighborhood = Boolean(
    nbCitySlug && nbSlugCandidate && findNeighborhood(nbCitySlug, nbSlugCandidate),
  );
  const nbSlug = isNeighborhood ? nbSlugCandidate : undefined;
  const blogMatch = route.match(/^\/blog\/([a-z0-9-]+)$/);
  const blogSlug = blogMatch && isKnownRoute(route) ? blogMatch[1] : undefined;
  const guidesMatch = route.match(/^\/guides\/([a-z0-9-]+)$/);
  const guidesSlug = guidesMatch && isKnownRoute(route) ? guidesMatch[1] : undefined;
  const crewMatch = route.match(/^\/crew\/([a-z0-9-]+)$/);
  const crewSlug = crewMatch?.[1];
  const trackMatch = route.match(/^\/track\/([a-zA-Z0-9_-]+)$/);
  const trackId = trackMatch?.[1];
  const quoteMatch = route.match(/^\/quote\/([a-zA-Z0-9_-]+)$/);
  const quoteId = quoteMatch?.[1];
  const reviewMatch = route.match(/^\/review\/([a-zA-Z0-9_-]+)$/);
  const reviewGigId = reviewMatch?.[1];
  // Wave 21D — /pay/split/<bookingId> for two-card split flow
  const splitPayMatch = route.match(/^\/pay\/split\/([a-zA-Z0-9_-]+)$/);
  const splitPayBookingId = splitPayMatch?.[1];
  // Tier-S idea #4 — /by/<slug> neighbor-referral landing page.
  const neighborMatch = route.match(/^\/by\/([a-z0-9]+(?:-[a-z0-9]+){0,3})$/);
  const neighborSlug = neighborMatch?.[1];
  // /vs + /vs/<competitor> — pure-static SSG comparison pages (no React twin).
  // Re-render the prerendered #root markup (captured at boot) so React doesn't
  // stomp them with NotFound404; gated on isKnownRoute so /vs/fake still 404s.
  const isServicePage =
    /^\/services\/[a-z-]+$/.test(route) && route !== '/services/not-us' && isKnownRoute(route);
  const isVsPage = route === '/vs' || (/^\/vs\/[a-z-]+$/.test(route) && isKnownRoute(route));
  const isBuildingPage =
    route === '/buildings' || (/^\/buildings\/[a-z0-9-]+$/.test(route) && isKnownRoute(route));
  const isPrerenderedCitySubpage =
    !isNeighborhood &&
    (/^\/c\/[a-z0-9-]+\/[a-z0-9-]+(?:\/data)?$/.test(route) ||
      /^\/c\/[a-z0-9-]+\/n\/[a-z0-9-]+(?:\/data)?$/.test(route)) &&
    isKnownRoute(route);
  const forMatch = route.match(/^\/for\/([a-z0-9-]+)$/);
  const forSlug = forMatch && isKnownRoute(route) ? forMatch[1] : undefined;
  const matrix3dMatch = route.match(/^\/c\/([a-z0-9-]+)\/([a-z0-9-]+)\/([a-z0-9-]+)$/);
  const isMatrix3dPage = Boolean(
    matrix3dMatch &&
      matrix3dMatch[2] !== 'n' &&
      matrix3dMatch[3] !== 'data' &&
      isKnownRoute(route),
  );

  let header: JSX.Element | null;
  let main: JSX.Element;
  let routeOrigin = 'home';
  let highlightCity: { name: string; state: string } | undefined;
  const isHomepage = route === '/' || route === '';
  const isLegalPage = route === '/privacy' || route === '/terms';
  // §minimal-footer (2026-05-26) — auth, checkout, dashboard, tracking, admin
  // get the single-row MinimalFooter; the giant 5-column marketing Footer is
  // reserved for browse/SEO surfaces where the site index adds value.
  const MARKETING_FOOTER_ROUTES = new Set([
    '/',
    '',
    '/services',
    '/about',
    '/sources',
    '/guarantee',
    '/privacy',
    '/terms',
    '/tcpa',
    '/take-rate',
    '/policy/cancellation',
    '/blog',
    '/partners',
    '/property-managers',
    '/integrations',
    '/b2b',
    '/refer',
    '/emergency-labor',
    '/schedule',
    '/claims',
    '/bundles',
    '/plans',
    '/pay',
    '/vs',
    '/buildings',
    '/for',
    // /apply is a dedicated recruiting content page (like /careers) — it gets
    // the full marketing Footer, not the compact MinimalFooter.
    '/apply',
  ]);
  const MARKETING_FOOTER_PREFIXES = [
    '/c/',
    '/blog/',
    '/crew/',
    '/services/',
    '/vs/',
    '/buildings/',
    '/for/',
    '/guides/',
    '/apply/',
  ];
  const useMarketingFooter =
    MARKETING_FOOTER_ROUTES.has(route) ||
    MARKETING_FOOTER_PREFIXES.some((p) => route.startsWith(p));
  const HIDE_BOTTOM_MAP_PREFIXES = [
    '/work',
    '/me',
    '/login',
    '/apply',
    '/admin',
    '/track',
    '/recurring',
    '/book',
    '/contact',
    '/for',
  ];
  const hideBottomMap =
    isHomepage ||
    isServicePage ||
    isLegalPage ||
    isMatrix3dPage ||
    HIDE_BOTTOM_MAP_PREFIXES.some((p) => route === p || route.startsWith(`${p}/`));
  // Admin pages run inside AdminShell which renders its own sidebar/footer —
  // hide the public Footer + BackToTop + Coverage map so the admin chrome
  // owns the visual identity.
  const isAdminRoute = route === '/admin' || route.startsWith('/admin/');
  const hidePublicChrome = isAdminRoute && route !== '/admin/login';
  // §10 — /track is a minimal "open from your email" surface. Hide the
  // floating AI chat launcher so the only chrome left is header + tracking
  // body + newsletter (inside Footer) + footer.
  const isTrackRoute = route === '/track' || route.startsWith('/track/');
  const hideAiChat = isTrackRoute;
  const hideFloatingCall = ['/admin', '/book', '/login', '/me', '/pay', '/track', '/work'].some(
    (prefix) => route === prefix || route.startsWith(`${prefix}/`),
  );
  // Crew surfaces register push through a separate worker path; the customer
  // arrival prompt mounts only on customer-facing chrome.
  const isWorkRoute = route === '/work' || route.startsWith('/work/');

  if (route === '/privacy') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <Privacy />;
    routeOrigin = 'privacy';
  } else if (route === '/claims') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <ClaimsBoard />;
    routeOrigin = 'claims';
  } else if (route === '/tcpa') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <TcpaPolicy />;
    routeOrigin = 'tcpa';
  } else if (route === '/take-rate') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <TakeRatePage />;
    routeOrigin = 'take-rate';
  } else if (route === '/policy/cancellation') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <CancellationPolicyPage />;
    routeOrigin = 'cancellation';
  } else if (route === '/services') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <ServicesIndex />;
    routeOrigin = 'services-index';
  } else if (route === '/schedule') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <SchedulePage />;
    routeOrigin = 'schedule';
  } else if (route === '/quote') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <QuotePage />;
    routeOrigin = 'quote';
  } else if (route === '/bundles') {
    // §bundles-standalone (2026-05-25) — direct organic-search target for
    // queries like "$299 driveway power wash NJ" / "move-out cleanout
    // Newark" — same three packages BundlesBlock renders on city pages,
    // city-agnostic eyebrow, every card links to /book?bundle=<slug>.
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = (
      <>
        <section className="section pt-12 pb-4">
          <div className="container-pad max-w-3xl">
            <p className="eyebrow mb-3">Prepay packages</p>
            <h1 className="text-4xl sm:text-5xl font-extrabold mb-3">
              Three jobs. Three flat prices. <span className="text-gradient">No meter.</span>
            </h1>
            <p className="text-lg text-brand-mute">
              For the property work we book most often across Newark + the NJ-NY corridor, we
              package the labor, gear, fuel, and disposal into a single locked price. Tap one below
              to book.
            </p>
          </div>
        </section>
        <BundlesBlock />
      </>
    );
    routeOrigin = 'bundles';
  } else if (route === '/dashboard') {
    // §unified-dashboard (2026-05-25) — single role-gated dashboard.
    // Admin / crew / customer / guest each see the right sections of the
    // same shell. Legacy /admin, /work, /me keep working — this is additive.
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<UnifiedDashboard />, '600px');
    routeOrigin = 'dashboard';
  } else if (route === '/sources') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<SourcesPage />, '600px');
    routeOrigin = 'sources';
  } else if (route === '/guarantee') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<ServiceGuaranteePage />, '600px');
    routeOrigin = 'guarantee';
  } else if (isServicePage) {
    // Service hubs preserve the generated service content through mounting and
    // mount the interactive ServiceCategoryCalculator below the prerendered guide.
    const prerendered = prerenderedRoot();
    const svcSlug = route.replace(/^\/services\//, '').replace(/\/$/, '');
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main =
      prerendered.length > 100 ? (
        <>
          <div data-bcl-prerendered="service" dangerouslySetInnerHTML={{ __html: prerendered }} />
          {withSuspense(<ServiceCategoryCalculator slug={svcSlug} />, '320px')}
        </>
      ) : (
        withSuspense(<NotFound404 />, '70vh')
      );
    routeOrigin = 'service';
  } else if (isVsPage || isBuildingPage || isPrerenderedCitySubpage) {
    // Pure-static SSG comparison, building, or city×service/neighborhood-data page —
    // re-render the prerendered #root markup (captured before createRoot wiped it)
    // wrapped in the normal chrome so React never stomps prerendered pSEO pages.
    const prerendered = prerenderedRoot();
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main =
      prerendered.length > 100 ? (
        <div
          data-bcl-prerendered={isVsPage ? 'vs' : isBuildingPage ? 'buildings' : 'city-matrix'}
          dangerouslySetInnerHTML={{ __html: prerendered }}
        />
      ) : (
        withSuspense(<NotFound404 />, '70vh')
      );
    routeOrigin = isVsPage ? 'vs' : isBuildingPage ? 'buildings' : 'city-matrix';
  } else if (route === '/for') {
    header = <Header showBack ctaHref="/book" />;
    main = withSuspense(<LandingMatrixPage />, '70vh');
    routeOrigin = 'for-index';
  } else if (forSlug) {
    header = <Header showBack ctaHref="/book" />;
    main = withSuspense(<LandingMatrixPage slug={forSlug} />, '70vh');
    routeOrigin = `for-${forSlug}`;
  } else if (isMatrix3dPage && matrix3dMatch) {
    header = <Header showBack ctaHref="/book" />;
    main = withSuspense(
      <LandingMatrixPage
        townSlug={matrix3dMatch[1]}
        workTypeSlug={matrix3dMatch[2]}
        slug={matrix3dMatch[3]}
      />,
      '70vh',
    );
    routeOrigin = `3d-${matrix3dMatch[1]}-${matrix3dMatch[2]}-${matrix3dMatch[3]}`;
  } else if (route === '/status') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<StatusPage />, '400px');
    routeOrigin = 'status';
  } else if (route === '/help') {
    // §help-center (2026-06-03) — /help knowledge base. HelpCenterPage is
    // flag-gated (help_center) → renders null until promoted; /help isn't linked
    // anywhere until then, so dark = harmless. view + slug/query from the QS.
    const hp = new URLSearchParams(typeof window !== 'undefined' ? window.location.search : '');
    const helpSlug = hp.get('slug') ?? undefined;
    const helpQuery = hp.get('q') ?? undefined;
    const helpView: 'home' | 'article' | 'search' = helpSlug
      ? 'article'
      : helpQuery
        ? 'search'
        : 'home';
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(
      <HelpCenterPage view={helpView} slug={helpSlug} query={helpQuery} />,
      '600px',
    );
    routeOrigin = 'help';
  } else if (route === '/services/not-us') {
    // §what-we-dont-do — honest "scope" page. WhatWeDontDoPage is flag-gated
    // (what_we_dont_do) → renders null until promoted; /services/not-us isn't
    // linked anywhere until then, so dark = harmless. Backend: /api/what-we-dont-do.
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<WhatWeDontDoPage />, '600px');
    routeOrigin = 'what-we-dont-do';
  } else if (route === '/testimonials') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<VideoTestimonials />, '600px');
    routeOrigin = 'testimonials';
  } else if (route === '/refer') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<ReferPage />, '400px');
    routeOrigin = 'refer';
  } else if (route === '/plans') {
    // §plans-standalone (2026-05-25) — recurring subscription catalog.
    // Customer picks Essential / Property / Seasonal, fills form, lands a
    // subscription instance via /api/subscriptions/subscribe. Square call
    // is best-effort — pending status is acceptable while operator activates.
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<PlansPage />, '600px');
    routeOrigin = 'plans';
  } else if (route === '/estimate') {
    // §photo-estimate (2026-05-25) — public AI photo→price preview. Lives on
    // its own route so the user can deep-link, share, and submit a photo
    // without entangling the Booking.tsx state machine.
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<PhotoEstimatePage />, '600px');
    routeOrigin = 'estimate';
  } else if (route === '/admin/ai') {
    header = null;
    main = (
      <AdminShell
        section="ai"
        title="AI copilot & digest"
        breadcrumb={[
          { label: 'Admin', href: '/admin/super-admin' },
          { label: 'System' },
          { label: 'AI copilot' },
        ]}
      >
        {withSuspense(<AdminAiToolsPage />, '600px')}
      </AdminShell>
    );
    routeOrigin = 'admin-ai';
  } else if (route === '/book') {
    // §book-standalone (2026-05-24) — dedicated one-time booking page.
    // Many surfaces (QuickSchedulePopover "More options", DashboardCallout
    // CTAs, city-page bundle cards, and the retired /recurring redirect) link to
    // /book directly. Until now those landed on a 404 → homepage; this
    // route renders the same lazy Booking component on its own page so
    // ?bundle=<slug> + ?date=<date> + ?time=<time> + ?coupon=<code>
    // query params thread through cleanly and the URL stays bookmarkable.
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<Booking />, '600px');
    routeOrigin = 'book';
  } else if (route === '/recurring') {
    // /recurring retired (2026-09-25) — recurring cadence now lives inline in the
    // /book Booking form (cadence pills + calendar start date + upcoming dates).
    // The worker 301s /recurring → /book; this is the client-side defense in depth
    // so a soft SPA navigation also lands on /book with its query preserved.
    if (typeof window !== 'undefined') {
      window.location.replace(`/book${window.location.search}`);
    }
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<Booking />, '600px');
    routeOrigin = 'book';
  } else if (route === '/emergency-labor') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <EmergencyLaborPage />;
    routeOrigin = 'emergency-labor';
  } else if (route === '/contact') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<ContactPage />, '600px');
    routeOrigin = 'contact';
  } else if (route === '/partners') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <PartnerLanding />;
    routeOrigin = 'partners';
  } else if (route === '/property-managers') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <PropertyManagerPage />;
    routeOrigin = 'property-managers';
  } else if (route === '/integrations') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<IntegrationsPage />, '600px');
    routeOrigin = 'integrations';
  } else if (route === '/integrations/slack') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <SlackInstall />;
    routeOrigin = 'integrations-slack';
  } else if (route === '/b2b') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <B2bApiDocsPage />;
    routeOrigin = 'b2b';
  } else if (route === '/refer') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <CustomerReferralPage />;
    routeOrigin = 'refer';
  } else if (route === '/work/refer') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <CrewReferralWidget />;
    routeOrigin = 'work-refer';
  } else if (route === '/admin/login') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <SuperAdminLogin />;
    routeOrigin = 'admin-login';
  } else if (route === '/admin/super-admin') {
    header = null;
    main = (
      <AdminShell
        section="super-admin"
        title="Operations cockpit"
        breadcrumb={[{ label: 'Admin', href: '/admin/super-admin' }, { label: 'Cockpit' }]}
      >
        <SuperAdminDashboard />
      </AdminShell>
    );
    routeOrigin = 'super-admin';
  } else if (route === '/admin/jobs') {
    header = null;
    main = (
      <AdminShell
        section="jobs"
        title="Jobs"
        breadcrumb={[
          { label: 'Admin', href: '/admin/super-admin' },
          { label: 'Operations' },
          { label: 'Jobs' },
        ]}
      >
        <JobsBrowser />
      </AdminShell>
    );
    routeOrigin = 'admin-jobs';
  } else if (route === '/admin/customers') {
    header = null;
    main = (
      <AdminShell
        section="customers"
        title="Customers"
        breadcrumb={[
          { label: 'Admin', href: '/admin/super-admin' },
          { label: 'Operations' },
          { label: 'Customers' },
        ]}
      >
        <CustomersBrowser />
      </AdminShell>
    );
    routeOrigin = 'admin-customers';
  } else if (route === '/admin/workers') {
    header = null;
    main = (
      <AdminShell
        section="workers"
        title="Crew"
        breadcrumb={[
          { label: 'Admin', href: '/admin/super-admin' },
          { label: 'Operations' },
          { label: 'Crew' },
        ]}
      >
        <WorkersBrowser />
      </AdminShell>
    );
    routeOrigin = 'admin-workers';
  } else if (route === '/admin/applicants') {
    header = null;
    main = (
      <AdminShell
        section="applicants"
        title="Crew applicants"
        breadcrumb={[
          { label: 'Admin', href: '/admin/super-admin' },
          { label: 'Operations' },
          { label: 'Applicants' },
        ]}
      >
        <ApplicantsBrowser />
      </AdminShell>
    );
    routeOrigin = 'admin-applicants';
  } else if (route === '/admin/rules') {
    header = null;
    main = (
      <AdminShell
        section="rules"
        title="AI rules engine"
        breadcrumb={[
          { label: 'Admin', href: '/admin/super-admin' },
          { label: 'System' },
          { label: 'AI rules' },
        ]}
      >
        <AiRulesAdmin
          adminToken={
            typeof window !== 'undefined' ? (localStorage.getItem('bcl_owner_key') ?? '') : ''
          }
        />
      </AdminShell>
    );
    routeOrigin = 'admin-rules';
  } else if (route === '/admin/widgets') {
    header = null;
    main = (
      <AdminShell
        section="widgets"
        title="Widgets"
        breadcrumb={[
          { label: 'Admin', href: '/admin/super-admin' },
          { label: 'System' },
          { label: 'Widgets' },
        ]}
      >
        <SuperAdminWidgetsTab />
      </AdminShell>
    );
    routeOrigin = 'admin-widgets';
  } else if (route === '/admin/wave20') {
    header = null;
    main = (
      <AdminShell
        section="wave20"
        title="Feature grid"
        breadcrumb={[
          { label: 'Admin', href: '/admin/super-admin' },
          { label: 'Overview' },
          { label: 'Feature grid' },
        ]}
      >
        <Wave20FeaturesGrid />
      </AdminShell>
    );
    routeOrigin = 'admin-wave20';
  } else if (route === '/admin/safety') {
    header = null;
    main = (
      <AdminShell
        section="safety"
        title="Safety + compliance"
        breadcrumb={[
          { label: 'Admin', href: '/admin/super-admin' },
          { label: 'System' },
          { label: 'Safety' },
        ]}
      >
        <SafetyDashboard />
      </AdminShell>
    );
    routeOrigin = 'admin-safety';
  } else if (route === '/admin/finance/1099') {
    header = null;
    main = (
      <AdminShell
        section="1099"
        title="1099-NEC e-file"
        breadcrumb={[
          { label: 'Admin', href: '/admin/super-admin' },
          { label: 'Finance', href: '/admin/finance' },
          { label: '1099-NEC' },
        ]}
      >
        <Form1099NecPage />
      </AdminShell>
    );
    routeOrigin = 'admin-finance-1099';
  } else if (route === '/admin/finance/fraud') {
    header = null;
    main = (
      <AdminShell
        section="fraud"
        title="Fraud refund queue"
        breadcrumb={[
          { label: 'Admin', href: '/admin/super-admin' },
          { label: 'Finance', href: '/admin/finance' },
          { label: 'Fraud queue' },
        ]}
      >
        <FraudQueuePage />
      </AdminShell>
    );
    routeOrigin = 'admin-finance-fraud';
  } else if (route === '/admin/finance') {
    header = null;
    main = (
      <AdminShell
        section="finance"
        title="Finance"
        breadcrumb={[{ label: 'Admin', href: '/admin/super-admin' }, { label: 'Finance' }]}
      >
        <FinanceDashboard />
      </AdminShell>
    );
    routeOrigin = 'admin-finance';
  } else if (route === '/admin/ops') {
    header = null;
    main = (
      <AdminShell
        section="ops"
        title="Ops health"
        breadcrumb={[
          { label: 'Admin', href: '/admin/super-admin' },
          { label: 'System' },
          { label: 'Ops health' },
        ]}
      >
        <OpsHealthDashboard />
      </AdminShell>
    );
    routeOrigin = 'admin-ops';
  } else if (route === '/admin/marketing') {
    header = null;
    main = (
      <AdminShell
        section="marketing"
        title="Marketing studio"
        breadcrumb={[{ label: 'Admin', href: '/admin/super-admin' }, { label: 'Marketing' }]}
      >
        <MarketingStudio
          token={typeof window !== 'undefined' ? (localStorage.getItem('bcl_owner_key') ?? '') : ''}
        />
      </AdminShell>
    );
    routeOrigin = 'admin-marketing';
  } else if (route === '/admin/channels') {
    header = null;
    main = (
      <AdminShell
        section="channels"
        title="Channel inbox"
        breadcrumb={[
          { label: 'Admin', href: '/admin/super-admin' },
          { label: 'Operations' },
          { label: 'Channels' },
        ]}
      >
        <ChannelInbox />
      </AdminShell>
    );
    routeOrigin = 'admin-channels';
  } else if (route === '/admin/notifications') {
    header = null;
    main = (
      <AdminShell
        section="notifications"
        title="Notifications"
        breadcrumb={[
          { label: 'Admin', href: '/admin/super-admin' },
          { label: 'Overview' },
          { label: 'Notifications' },
        ]}
      >
        <NotificationsInbox />
      </AdminShell>
    );
    routeOrigin = 'admin-notifications';
  } else if (route === '/api') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <ApiDocsPage />;
    routeOrigin = 'api-docs';
  } else if (route === '/me/followups') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<FollowupChat />, '600px');
    routeOrigin = 'me-followups';
  } else if (crewSlug) {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <CrewProfilePublic slug={crewSlug} />;
    routeOrigin = `crew-${crewSlug}`;
  } else if (route === '/terms') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <Terms />;
    routeOrigin = 'terms';
  } else if (route === '/sources') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <Sources />;
    routeOrigin = 'sources';
  } else if (route === '/admin') {
    // /admin → /admin/super-admin (Wave 4F supersedes the legacy Mission
    // Control paste-key gate). Legacy Admin component still reachable via
    // /admin/legacy if needed.
    if (typeof window !== 'undefined') {
      window.location.replace('/admin/super-admin');
    }
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<Admin />, '60vh');
    routeOrigin = 'admin';
  } else if (route === '/admin/legacy') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<Admin />, '60vh');
    routeOrigin = 'admin-legacy';
  } else if (route === '/work') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <WorkLanding />;
    routeOrigin = 'work-landing';
  } else if (route === '/careers') {
    // Public, indexable crew-recruiting landing. `/work` 308-redirects to the
    // authed Angular dashboard post-cutover, so it can't be the public hiring
    // page; `/careers` is the one indexable recruiting URL (prerendered with
    // JobPosting JSON-LD by scripts/build-legal-pages.mjs). This branch makes
    // the SPA render the same crew landing post-hydration so it doesn't swap to
    // NotFound404 after the prerendered shell paints.
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <WorkLanding />;
    routeOrigin = 'careers-landing';
  } else if (route === '/work/dashboard' || route === '/work/payouts') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    const initialTab = route === '/work/payouts' ? 'pay' : undefined;
    main = withSuspense(<WorkerDashboard initialTab={initialTab} />, '60vh');
    routeOrigin = route === '/work/payouts' ? 'work-payouts' : 'work-dashboard';
  } else if (route === '/work/profile' || route === '/work/login') {
    if (typeof window !== 'undefined') {
      window.location.replace('/login?as=crew&next=%2Fwork%2Fdashboard%23settings');
    }
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <LoginPage />;
    routeOrigin = 'login';
  } else if (route === '/login/customer' || route === '/login/crew' || route === '/login/admin') {
    // Unified /login — no separate per-role page. The worker edge 301s these
    // to /login?as=<role>&next=… (index.ts); this client-side replace defends
    // in depth so a bypassed edge (client nav / raw SPA-shell serve) still
    // lands on the single unified surface, never a distinct role page.
    const asRole =
      route === '/login/crew' ? 'crew' : route === '/login/admin' ? 'admin' : 'customer';
    const nextByRole =
      asRole === 'crew' ? '%2Fwork%2Fdashboard' : asRole === 'admin' ? '%2Fadmin' : '%2Fme';
    if (typeof window !== 'undefined') {
      window.location.replace(`/login?as=${asRole}&next=${nextByRole}`);
    }
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <LoginPage />;
    routeOrigin = 'login';
  } else if (route === '/login') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <LoginPage />;
    routeOrigin = 'login';
  } else if (route === '/apply' || route.startsWith('/apply/')) {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<ApplyPage route={route} />, '70vh');
    routeOrigin = 'apply';
  } else if (route === '/me') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<MePage />, '50vh');
    routeOrigin = 'me';
  } else if (isNeighborhood && nbCitySlug && nbSlug) {
    header = (
      <Header
        showBack
        navItems={[
          { href: '#services', label: 'Services' },
          { href: '#pricing', label: 'Pricing' },
          { href: '#coverage', label: 'Coverage' },
          { href: '#faq', label: 'FAQ' },
        ]}
      />
    );
    main = <NeighborhoodPage citySlug={nbCitySlug} nbSlug={nbSlug} />;
    routeOrigin = `nb-${nbCitySlug}-${nbSlug}`;
    const city = getCityBySlug(nbCitySlug);
    if (city) highlightCity = { name: city.name, state: city.state };
  } else if (citySlug) {
    header = (
      <Header
        showBack
        navItems={[
          { href: '#services', label: 'Services' },
          { href: '#pricing', label: 'Pricing' },
          { href: '#coverage', label: 'Coverage' },
          { href: '#faq', label: 'FAQ' },
        ]}
      />
    );
    main = <CityPage slug={citySlug} />;
    routeOrigin = `city-${citySlug}`;
    const city = getCityBySlug(citySlug);
    if (city) highlightCity = { name: city.name, state: city.state };
  } else if (route === '/search') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<SearchPage />, '70vh');
    routeOrigin = 'search';
  } else if (route === '/blog') {
    header = <Header showBack ctaHref="/book" />;
    main = <BlogIndex />;
    routeOrigin = 'blog-index';
  } else if (blogSlug) {
    header = <Header showBack ctaHref="/book" />;
    main = withSuspense(<BlogPost slug={blogSlug} />, '70vh');
    routeOrigin = `blog-${blogSlug}`;
  } else if (guidesSlug === 'power-washing') {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<GuidePowerWashing />, '600px');
    routeOrigin = `guides-${guidesSlug}`;
  } else if (trackId) {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <TrackBooking id={trackId} />;
    routeOrigin = 'track';
  } else if (quoteId) {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <QuoteShare id={quoteId} />;
    routeOrigin = 'quote';
  } else if (reviewGigId) {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<RateCrew gigId={reviewGigId} />, '50vh');
    routeOrigin = 'review';
  } else if (route === '/pay') {
    // §pay-page (2026-06-18) — transparent pricing + crew earnings + referral model
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<PayPage />, '600px');
    routeOrigin = 'pay';
  } else if (splitPayBookingId) {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = <SplitPaymentPage bookingId={splitPayBookingId} />;
    routeOrigin = 'pay-split';
  } else if (neighborSlug) {
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<NeighborReferralPage slug={neighborSlug} />, '70vh');
    routeOrigin = `neighbor-${neighborSlug}`;
  } else if (!isHomepage && !isKnownRoute(route)) {
    // Unknown path (segment matches no route family) — render the AI-suggested
    // 404 instead of the homepage. The worker already answered HTTP 404 +
    // `noindex` for this same request, so crawlers drop the URL.
    header = <Header navItems={[]} showBack ctaHref="/book" />;
    main = withSuspense(<NotFound404 />, '70vh');
    routeOrigin = 'not-found';
  } else {
    header = <Header />;
    main = (
      <>
        <Hero />
        <TrustBadges />
        <StatStrip />
        <DonationCounter />
        <AiFairMarket />
        <DashboardPromo />
        <Services />
        <BeforeAfter />
        <BundlesBlock />
        {clientReady ? withSuspense(<Pricing />, '720px') : <LazyFallback minHeight="720px" />}
        {/* Headline/intro/contextNote/eyebrow/refs are localized inside the
            component via researchPanelCopy(locale) (en/es/pt). Only the
            benchmark VALUES + citationIds are passed here (locale-invariant). */}
        {clientReady ? (
          withSuspense(<ResearchPanel facts={PRICING_BENCHMARKS} />, '520px')
        ) : (
          <LazyFallback minHeight="520px" />
        )}
        {clientReady ? (
          withSuspense(<CoverageMap origin="home" />, '560px')
        ) : (
          <LazyFallback minHeight="560px" />
        )}
        <Testimonials />
        {/* §book-canonical (2026-05-28) — Booking form moved off the
            homepage and now lives only at /book. Every CTA links there
            directly. Keeping the homepage lean reduces the initial JS
            payload AND lets us A/B-test the booking surface independently.
            Reviews + OwnerBio + Contact are code-split (HomeMidSections) so
            their JS never ships in the entry chunk pSEO pages download. */}
        {clientReady ? (
          withSuspense(<HomeMidSections />, '1400px')
        ) : (
          <LazyFallback minHeight="1400px" />
        )}
        <FAQ />
      </>
    );
  }

  // On /login the page is a short widget — make the chrome a flex column so
  // <main> grows and the footer clings to the bottom of the viewport instead
  // of floating with empty space beneath it. Height-agnostic (no magic numbers).
  const isLoginLayout = routeOrigin === 'login';
  const surfaceProps = useThemeToolsSurface(routeOrigin);
  // /contact is a full-height chat surface too: the shell becomes a flex column so
  // <main> grows, the minimal footer clings to the viewport bottom, and the chat
  // pushes it below the fold once enough messages have accumulated.
  const isFullHeightLayout = isLoginLayout || routeOrigin === 'contact';
  const shell = (
    <>
      {header}
      <main
        id="main"
        tabIndex={-1}
        className={isFullHeightLayout ? 'flex flex-1 flex-col' : undefined}
        data-theme-tools-surface={surfaceProps['data-theme-tools-surface']}
        data-theme-tools-pricing-model={surfaceProps['data-theme-tools-pricing-model']}
        data-theme-tools-packages={surfaceProps['data-theme-tools-packages']}
      >
        {/* Top-level Suspense boundary for any route whose component is lazy
            (admin cluster, legal pages, /login, /track, API docs). The homepage
            and pSEO city pages render fully-static trees here — they never
            suspend, so this boundary is inert on them while keeping the heavy
            admin/auth/legal chunks out of the entry bundle (LCP win on every
            crawled pSEO page). Routes with their own withSuspense() nest safely. */}
        <Suspense fallback={<LazyFallback minHeight="600px" />}>{main}</Suspense>
      </main>
      {clientReady && !hideBottomMap && !hidePublicChrome && (
        <Suspense fallback={null}>
          <CoverageMap origin={routeOrigin} highlightCity={highlightCity} />
        </Suspense>
      )}
      {!hidePublicChrome &&
        (useMarketingFooter ? <Footer minimal={isLegalPage} /> : <MinimalFooter />)}
    </>
  );

  return (
    <CmdKRotatorProvider>
      <AvatarProvider>
        <UndoProvider>
          <ImpersonationBanner />
          {/* NJDPA cookie-consent banner — renders on EVERY route (legal
            requirement, not gated by hidePublicChrome). Self-suppresses when a
            decision is stored or a GPC opt-out is detected. */}
          <CookieConsent />
          {isFullHeightLayout ? <div className="flex min-h-[100svh] flex-col">{shell}</div> : shell}
          {!hidePublicChrome && <BackToTop />}
          {/* Single, unified AI surface. AiChat owns the floating launcher, the
            side panel, and the Cmd/Ctrl+K rotator (palette↔chat↔closed) via
            UnifiedCmdK. Lazy-loaded (its ~164 KB tree leaves the entry chunk);
            <CmdKRotatorProvider> above keeps the Cmd+K hotkey instant regardless.
            fallback={null} — a floating overlay has nothing to reserve space for. */}
          {clientReady && !hideAiChat && (
            <Suspense fallback={null}>
              <AiChat />
            </Suspense>
          )}
          {/* Floating click-to-call (bottom-left). Replaces the old navbar phone
            CTA; suppressed on dashboard/auth/checkout per the canonical-chrome rule. */}
          {!hidePublicChrome && !hideFloatingCall && <FloatingCallButton />}
          {!hidePublicChrome && !isTrackRoute && <ExitIntentRescue />}
          {/* A2HS install banner — fully self-gating (2nd+ visit, 30-day cooldown,
            hidden when already installed/standalone). Off admin/checkout/auth. */}
          {!hidePublicChrome && <PwaInstallPrompt />}
          {/* Customer arrival-push opt-in (idea #13 — Live Activities). Pre-sells
            value before the OS prompt, then subscribes via /api/push/subscribe so
            the GigTracker DO can fan arrival/ETA pings to the device. Flag-gated +
            self-gating (capability + 12s delay + once-per-deploy). Off on crew /
            admin / track / checkout / editorial guide chrome so readers aren't ambushed. */}
          {pushArrivalOn &&
            !hidePublicChrome &&
            !isTrackRoute &&
            !isWorkRoute &&
            !isMatrix3dPage &&
            !forSlug &&
            route !== '/for' &&
            !blogSlug &&
            route !== '/blog' &&
            !guidesSlug && <PushPermissionPrompt role="customer" />}
          <CmdKPalette />
        </UndoProvider>
      </AvatarProvider>
    </CmdKRotatorProvider>
  );
}
