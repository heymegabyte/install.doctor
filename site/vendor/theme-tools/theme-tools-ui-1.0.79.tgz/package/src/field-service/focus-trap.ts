/**
 * Tab focus-trap math for modal dialogs.
 *
 * The ARIA Authoring Practices dialog pattern requires keyboard focus to stay
 * INSIDE an open modal: Tab past the last control wraps to the first, Shift+Tab
 * past the first wraps to the last, and focus that has somehow escaped onto the
 * page behind the (visually-covering but not always `inert`) backdrop is pulled
 * back in. A `fixed inset-0` dialog that merely restores focus on open/close
 * does NOT satisfy this — Tab from its last control silently moves focus to the
 * still-focusable page underneath. axe-core cannot detect this (it is an
 * interaction-pattern gap, not a static attribute one), so it is unit-pinned.
 *
 * This module is pure + framework-free (no React, no DOM globals) so the
 * worker, the React dialogs, and the unit suite share one implementation. The
 * DOM-touching part (querying focusable nodes) lives at each call site — only
 * the selector + the trap math are shared, keeping this file worker-safe.
 */

/**
 * CSS selector matching every natively-focusable element inside a dialog.
 * Excludes `[tabindex="-1"]` (programmatic-only focus) and disabled controls.
 */
export const FOCUSABLE_SELECTOR =
  'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

/** Minimal shape of a focusable element for the pure trap math (a DOM node satisfies it). */
export interface FocusableLike {
  focus(): void;
}

/**
 * Compute the element focus should move to when Tab would otherwise LEAVE the
 * trap. Returns `null` when the default Tab behaviour keeps focus inside the
 * dialog (the caller must NOT preventDefault in that case).
 *
 * Boundary cases that need an explicit jump:
 * - Tab forward while on the last control → wrap to first.
 * - Shift+Tab while on the first control → wrap to last.
 * - Active element is not in the trap at all (`activeIndex === -1`, i.e. focus
 *   escaped onto the page behind the backdrop) → pull it back to the first
 *   control (or last on Shift+Tab).
 *
 * @param focusables - Ordered list of focusable elements inside the dialog.
 * @param activeIndex - Index of the currently-focused element, or `-1` when the
 *   active element is outside the trap.
 * @param shiftKey - Whether Shift was held with Tab (reverse direction).
 * @returns The element to focus, or `null` to let the browser handle Tab.
 * @example
 * trapBoundaryTarget(els, 2, false) // 3-item list, on last → els[0]
 * trapBoundaryTarget(els, 0, true)  // on first, Shift+Tab → els[2]
 * trapBoundaryTarget(els, 1, false) // middle → null (natural Tab)
 * trapBoundaryTarget(els, -1, false)// escaped to page → els[0]
 */
export function trapBoundaryTarget<T extends FocusableLike>(
  focusables: readonly T[],
  activeIndex: number,
  shiftKey: boolean,
): T | null {
  if (focusables.length === 0) return null;
  const first = 0;
  const last = focusables.length - 1;
  if (activeIndex === -1) return focusables[shiftKey ? last : first] ?? null;
  if (!shiftKey && activeIndex === last) return focusables[first] ?? null;
  if (shiftKey && activeIndex === first) return focusables[last] ?? null;
  return null;
}

/**
 * Compute the element focus should move to for EVERY Tab press — the strict,
 * fully-explicit variant of {@link trapBoundaryTarget}. Where `trapBoundaryTarget`
 * returns `null` for the middle of the list (trusting the browser to advance
 * naturally), this ALWAYS returns the in-list neighbour, so the caller can
 * `preventDefault()` on every Tab and drive focus itself.
 *
 * Why it exists (SCAN-21, 2026-09-29): trusting the browser for the middle case
 * is unsafe for a `fixed`/`absolute`/transformed dialog mounted late in the DOM —
 * the browser's "natural" previous/next tabbable can resolve to an element
 * OUTSIDE the visually-overlapping dialog (observed: Shift+Tab off the exit-rescue
 * dialog's last control escaped to the AiChat FAB on mobile viewports). Cycling
 * explicitly through the dialog's own focusables closes that escape on every
 * viewport. Same wrap semantics as `trapBoundaryTarget` (first↔last), and
 * `activeIndex === -1` (focus already escaped) is pulled back to first/last.
 *
 * @param focusables - Ordered list of focusable elements inside the dialog.
 * @param activeIndex - Index of the currently-focused element, or `-1` when the
 *   active element is outside the trap.
 * @param shiftKey - Whether Shift was held with Tab (reverse direction).
 * @returns The element to focus next, or `null` only for an empty trap.
 * @example
 * nextTrapTarget(els, 1, true)  // 3-item list, middle, Shift+Tab → els[0]
 * nextTrapTarget(els, 2, false) // on last, Tab → els[0] (wrap)
 * nextTrapTarget(els, 0, true)  // on first, Shift+Tab → els[2] (wrap)
 * nextTrapTarget(els, -1, false)// escaped → els[0] (pull back)
 */
export function nextTrapTarget<T extends FocusableLike>(
  focusables: readonly T[],
  activeIndex: number,
  shiftKey: boolean,
): T | null {
  const n = focusables.length;
  if (n === 0) return null;
  const last = n - 1;
  if (activeIndex === -1) return focusables[shiftKey ? last : 0] ?? null;
  const delta = shiftKey ? -1 : 1;
  const nextIndex = (activeIndex + delta + n) % n;
  return focusables[nextIndex] ?? null;
}
