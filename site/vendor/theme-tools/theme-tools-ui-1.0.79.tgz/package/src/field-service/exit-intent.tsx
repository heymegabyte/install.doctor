import { useEffect, useState, type ReactElement } from 'react';
import { track } from './analytics.js';
import { createInternalNavWatcher } from './exit-intent-nav.js';
import { SmsConsentDisclosure } from './sms-consent-disclosure.js';

// Exit-intent bottom slide-up — explicitly NOT a modal. We never block the
// user's path off the page; we present one specific offer ("text me a quote")
// and let them dismiss with one tap.
//
// Trigger heuristics (desktop): mouse exits top of viewport while moving up.
// Trigger heuristics (mobile): rapid upward scroll near top of document
// (proxy for thumb reaching for the URL bar), or visibilitychange to hidden.
//
// Single-fire per session via sessionStorage flag.

export interface ExitIntentBarProps {
  /** Headline shown in the bar. */
  readonly headline?: string;
  /** CTA button label. */
  readonly ctaLabel?: string;
  /** Called when user accepts the offer (e.g. enter phone). */
  readonly onAccept?: () => void;
  /** Optional override: don't show even if triggered. */
  readonly disabled?: boolean;
  /** Storage key — bumped if we ever change the offer. */
  readonly storageKey?: string;
}

const DEFAULT_KEY = 'bcl-exit-intent-shown-v1';

interface BarState {
  readonly visible: boolean;
  readonly phone: string;
  readonly status: 'idle' | 'submitting' | 'ok' | 'err';
  readonly error: string;
}

/**
 * Renders a small, dismissible bar above the safe-area on mobile or pinned
 * to the bottom on desktop. Fires once per session, then never again unless
 * `sessionStorage` is cleared.
 */
export function ExitIntentBar({
  headline = 'Leaving? Text me a quote — no calls.',
  ctaLabel = 'Text me my quote',
  onAccept,
  disabled = false,
  storageKey = DEFAULT_KEY,
}: ExitIntentBarProps): ReactElement | null {
  const [state, setState] = useState<BarState>({
    visible: false,
    phone: '',
    status: 'idle',
    error: '',
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (disabled) return;
    try {
      if (sessionStorage.getItem(storageKey) === '1') return;
    } catch {
      /* noop */
    }

    const reduceMotion =
      typeof window.matchMedia === 'function' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const onMouseOut = (e: MouseEvent) => {
      // Top-edge exit only — moving toward the URL bar / close button.
      if (e.clientY > 5) return;
      if (e.relatedTarget) return;
      trigger();
    };

    let lastScroll = window.scrollY;
    let lastTime = performance.now();
    const onScroll = () => {
      const now = performance.now();
      const dy = window.scrollY - lastScroll;
      const dt = now - lastTime;
      lastScroll = window.scrollY;
      lastTime = now;
      // Rapid upward fling near the top of the page → URL bar reach.
      if (window.scrollY < 200 && dy < -120 && dt < 250) {
        trigger();
      }
    };

    // Records internal forward-navigation clicks so a `hidden` event caused by
    // clicking deeper (a conversion) isn't mistaken for a bounce.
    const navWatcher = createInternalNavWatcher();

    const onVisibility = () => {
      if (
        document.visibilityState === 'hidden' &&
        window.scrollY > 400 &&
        !navWatcher.recentlyNavigated()
      )
        trigger();
    };

    let triggered = false;
    function trigger() {
      if (triggered) return;
      triggered = true;
      try {
        sessionStorage.setItem(storageKey, '1');
      } catch {
        /* noop */
      }
      track('exit_intent_show', { reduceMotion });
      setState((s) => ({ ...s, visible: true }));
    }

    document.addEventListener('mouseout', onMouseOut, { passive: true });
    window.addEventListener('scroll', onScroll, { passive: true });
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      document.removeEventListener('mouseout', onMouseOut);
      window.removeEventListener('scroll', onScroll);
      document.removeEventListener('visibilitychange', onVisibility);
      navWatcher.cleanup();
    };
  }, [disabled, storageKey]);

  if (!state.visible) return null;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const raw = state.phone.trim();
    if (raw.replace(/\D/g, '').length < 10) {
      setState((s) => ({ ...s, status: 'err', error: 'Enter a valid US phone.' }));
      return;
    }
    setState((s) => ({ ...s, status: 'submitting', error: '' }));
    track('exit_intent_submit');
    try {
      const res = await fetch('/api/sms-inbound', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          source: 'exit-intent',
          phone: raw,
          opt_in: true,
          trigger: 'quote-request',
        }),
      });
      // Soft-success: even if the upstream is mocked we treat it as a lead.
      if (!res.ok && res.status >= 500) {
        setState((s) => ({ ...s, status: 'err', error: 'Try again in a moment.' }));
        return;
      }
      setState((s) => ({ ...s, status: 'ok' }));
      onAccept?.();
    } catch {
      setState((s) => ({ ...s, status: 'err', error: 'Network hiccup. Try again.' }));
    }
  }

  return (
    <div
      data-bcl-exit-intent
      className="fixed inset-x-0 bottom-0 z-50 px-3 pb-3 translate-y-0 transition-transform duration-[333ms] ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-none"
      style={{ paddingBottom: 'max(0.75rem, env(safe-area-inset-bottom))' }}
      role="region"
      aria-label="Quote by text"
    >
      <div className="mx-auto flex max-w-xl flex-col gap-2 rounded-2xl border border-brand-accent/40 bg-bg-elevated/95 px-4 py-3 shadow-2xl shadow-black/40 backdrop-blur-md sm:flex-row sm:items-center">
        <div className="flex-1">
          <p className="font-display text-sm font-bold text-brand-ink">{headline}</p>
          <SmsConsentDisclosure className="mt-0.5" />
        </div>
        {state.status === 'ok' ? (
          <p className="text-sm font-mono text-emerald-300">Got it — text incoming.</p>
        ) : (
          <form onSubmit={submit} className="flex w-full gap-2 sm:w-auto">
            <label className="sr-only" htmlFor="bcl-exit-phone">
              Mobile phone
            </label>
            <input
              id="bcl-exit-phone"
              type="tel"
              inputMode="tel"
              autoComplete="tel"
              placeholder="(555) 555-5555"
              value={state.phone}
              onChange={(e) => setState((s) => ({ ...s, phone: e.target.value }))}
              className="min-w-0 flex-1 rounded-md border border-brand-line bg-bg-primary px-3 py-2 text-sm text-brand-ink placeholder:text-brand-mute focus:border-brand-accent focus:outline-none"
            />
            <button
              type="submit"
              disabled={state.status === 'submitting'}
              className="shrink-0 rounded-md bg-brand-accent px-3 py-2 text-xs font-bold uppercase tracking-wider text-bg-primary hover:brightness-110 disabled:opacity-50"
            >
              {state.status === 'submitting' ? '…' : ctaLabel}
            </button>
          </form>
        )}
        <button
          type="button"
          aria-label="Dismiss"
          onClick={() => {
            track('exit_intent_dismiss');
            setState((s) => ({ ...s, visible: false }));
          }}
          className="absolute right-2 top-2 rounded-md p-1 text-brand-mute hover:text-brand-ink sm:static"
        >
          <span aria-hidden>✕</span>
        </button>
      </div>
      {state.error && <p className="mx-auto mt-1 max-w-xl text-xs text-amber-300">{state.error}</p>}
    </div>
  );
}
