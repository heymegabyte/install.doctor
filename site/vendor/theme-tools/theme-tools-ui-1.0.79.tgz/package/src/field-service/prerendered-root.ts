/**
 * Captures the server-prerendered `#root` innerHTML at boot, BEFORE React's
 * `createRoot()` clears the container.
 *
 * Why this exists: a handful of pages are PURE static SSG (built by the
 * `scripts/build-*-pages.mjs` generators) and have NO matching React component
 * — the `/vs/:slug` competitor-comparison pages are the canonical case. The SPA
 * mounts with `createRoot` (not `hydrateRoot`), so React wipes `#root` and, with
 * no route handler, would render the NotFound404 catch-all OVER the prerendered
 * comparison — the page renders for crawlers (no JS) but 404s for real visitors.
 *
 * Internal navigation to these pages is a FULL page load (App re-renders only on
 * `popstate`; there is no `<a>`-click interception), so a fresh server prerender
 * lands in `#root` on every visit. Capturing it here lets `App` re-render the
 * exact prerendered markup as `main` (wrapped in the normal Header/Footer) with
 * ZERO generator↔React duplication — the React render IS the SSG bytes.
 */
let captured = '';
let capturedPath: string | undefined;

/**
 * Record the prerendered `#root` markup. Call exactly once in `main.tsx`,
 * immediately before `createRoot()`.
 * @param html - The container's `innerHTML` at boot.
 */
export function capturePrerenderedRoot(html: string): void {
  captured = html;
  capturedPath = typeof window === 'undefined' ? undefined : window.location.pathname;
}

/**
 * The captured prerendered `#root` markup (empty string before capture).
 * @returns The server-rendered HTML string for the current document.
 */
export function prerenderedRoot(): string {
  // History navigation must never reuse another document's static content.
  if (typeof window !== 'undefined' && window.location.pathname !== capturedPath) return '';
  return captured;
}
