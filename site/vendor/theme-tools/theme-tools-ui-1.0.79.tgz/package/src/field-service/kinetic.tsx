import type { ReactNode } from 'react';

interface KineticProps {
  /** Children, typically the hero `<h1>` text or a span within it. */
  children: ReactNode;
  /** Optional extra Tailwind classes. */
  className?: string;
  /** Optional id (matches `view-transition-name` consumers). */
  id?: string;
  /**
   * Per-word stagger step in ms. When set, the `<h1>` carries `data-stagger`
   * so the shared `animate.ts` runtime gives each direct `[data-animate]` word
   * span a sequential `--anim-delay` (A2 kinetic word reveal). Omit for a
   * single static reveal.
   */
  stagger?: number;
}

/**
 * Kinetic typography wrapper for the hero `<h1>`.
 *
 * Pairs `text-wrap: balance` with the scroll-driven `bcl-hero-kinetic` keyframe
 * that scales the headline from 1.0 to ~0.92 as the page scrolls through the
 * hero. Inherits `prefers-reduced-motion` collapse and the Firefox 1ms fallback
 * from `styles/index.css`.
 *
 * The fluid type scale is applied via the inline `--type-hero` token consumed
 * in `Hero.tsx` so the wrapper is purely behavioural — copy size still lives
 * with the headline.
 */
export function Kinetic({ children, className, id, stagger }: KineticProps) {
  const cls = ['bcl-hero-kinetic', 'bcl-hero-h1', className].filter(Boolean).join(' ');
  return (
    <h1
      id={id}
      className={cls}
      data-stagger={stagger}
      style={{
        fontSize: 'clamp(2.5rem, 5vw + 1rem, 4rem)',
        textWrap: 'balance',
        lineHeight: 1.02,
      }}
    >
      {children}
    </h1>
  );
}
