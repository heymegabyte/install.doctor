const data: Record<string, { slug: string; src: string; bytes: number; chunks: number; voice: string; model: string } | undefined> = {
  "fifty-dollar-hour-per-person-philosophy": {
    "slug": "fifty-dollar-hour-per-person-philosophy",
    "src": "/blog-audio/fifty-dollar-hour-per-person-philosophy.mp3",
    "bytes": 4798464,
    "chunks": 3,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "casual-labor-vs-licensed-contractor": {
    "slug": "casual-labor-vs-licensed-contractor",
    "src": "/blog-audio/casual-labor-vs-licensed-contractor.mp3",
    "bytes": 4766976,
    "chunks": 3,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "evenings-and-weekends-newark-property-crew": {
    "slug": "evenings-and-weekends-newark-property-crew",
    "src": "/blog-audio/evenings-and-weekends-newark-property-crew.mp3",
    "bytes": 4250112,
    "chunks": 2,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "lawn-mowing-pricing-newark": {
    "slug": "lawn-mowing-pricing-newark",
    "src": "/blog-audio/lawn-mowing-pricing-newark.mp3",
    "bytes": 4273920,
    "chunks": 2,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "gutter-cleaning-newark": {
    "slug": "gutter-cleaning-newark",
    "src": "/blog-audio/gutter-cleaning-newark.mp3",
    "bytes": 4088448,
    "chunks": 2,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "appliance-haul-away-newark": {
    "slug": "appliance-haul-away-newark",
    "src": "/blog-audio/appliance-haul-away-newark.mp3",
    "bytes": 4452480,
    "chunks": 2,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "snow-shoveling-newark-on-call": {
    "slug": "snow-shoveling-newark-on-call",
    "src": "/blog-audio/snow-shoveling-newark-on-call.mp3",
    "bytes": 4873344,
    "chunks": 3,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "spring-property-prep-newark": {
    "slug": "spring-property-prep-newark",
    "src": "/blog-audio/spring-property-prep-newark.mp3",
    "bytes": 4429056,
    "chunks": 2,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "fence-repair-newark-light-carpentry": {
    "slug": "fence-repair-newark-light-carpentry",
    "src": "/blog-audio/fence-repair-newark-light-carpentry.mp3",
    "bytes": 4451712,
    "chunks": 2,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "driveway-power-washing-equipment": {
    "slug": "driveway-power-washing-equipment",
    "src": "/blog-audio/driveway-power-washing-equipment.mp3",
    "bytes": 5795712,
    "chunks": 3,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "tony-partnership-st-johns-soup-kitchen": {
    "slug": "tony-partnership-st-johns-soup-kitchen",
    "src": "/blog-audio/tony-partnership-st-johns-soup-kitchen.mp3",
    "bytes": 3663360,
    "chunks": 1,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "pulling-weeds-from-the-roots": {
    "slug": "pulling-weeds-from-the-roots",
    "src": "/blog-audio/pulling-weeds-from-the-roots.mp3",
    "bytes": 3694464,
    "chunks": 1,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "sofa-haul-away-as-low-as-200": {
    "slug": "sofa-haul-away-as-low-as-200",
    "src": "/blog-audio/sofa-haul-away-as-low-as-200.mp3",
    "bytes": 4777728,
    "chunks": 3,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "newark-property-owner-hiring-guide": {
    "slug": "newark-property-owner-hiring-guide",
    "src": "/blog-audio/newark-property-owner-hiring-guide.mp3",
    "bytes": 4488576,
    "chunks": 2,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "newark-power-washing-mistakes": {
    "slug": "newark-power-washing-mistakes",
    "src": "/blog-audio/newark-power-washing-mistakes.mp3?v=gemini25",
    "bytes": 4734380,
    "chunks": 16,
    "voice": "Maya(Aoede-Female)+Brian(Puck-Male)",
    "model": "gemini-2.5-flash-preview-tts"
  },
  "newark-hauling-disposal-guide": {
    "slug": "newark-hauling-disposal-guide",
    "src": "/blog-audio/newark-hauling-disposal-guide.mp3",
    "bytes": 3881088,
    "chunks": 1,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "newark-yard-care-calendar": {
    "slug": "newark-yard-care-calendar",
    "src": "/blog-audio/newark-yard-care-calendar.mp3",
    "bytes": 4456320,
    "chunks": 2,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "how-to-hire-property-crew-without-getting-burned": {
    "slug": "how-to-hire-property-crew-without-getting-burned",
    "src": "/blog-audio/how-to-hire-property-crew-without-getting-burned.mp3",
    "bytes": 4846080,
    "chunks": 3,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "twenty-four-seven-emergency-property-help-newark": {
    "slug": "twenty-four-seven-emergency-property-help-newark",
    "src": "/blog-audio/twenty-four-seven-emergency-property-help-newark.mp3",
    "bytes": 8003712,
    "chunks": 3,
    "voice": "ash",
    "model": "gpt-4o-mini-tts"
  },
  "newark-power-washing-free-sample-work": {
    "slug": "newark-power-washing-free-sample-work",
    "src": "/blog-audio/newark-power-washing-free-sample-work.mp3?v=gemini25",
    "bytes": 4602668,
    "chunks": 16,
    "voice": "Maya(Aoede-Female)+Brian(Puck-Male)",
    "model": "gemini-2.5-flash-preview-tts"
  }
};
export default data;
