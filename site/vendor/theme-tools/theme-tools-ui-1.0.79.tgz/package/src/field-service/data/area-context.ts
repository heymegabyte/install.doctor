import type { City } from './cities.js';
/** @typedef {{ slug: string; name: string; state: 'NJ'|'NY'|'DC'; county: string; population: number; lat: number; lng: number; zip?: string; primary?: boolean }} City */

const NEWARK_LAT = 40.7357;
const NEWARK_LNG = -74.1724;
const EARTH_KM = 6371;

/**
 * True when a city sits at (or within rounding of) Newark's own centroid — i.e.
 * the crew's home base. Newark rounds to 0 miles, and "0 mi from Newark" /
 * "Newark is 0 miles from Newark" reads as broken slop on the flagship pSEO
 * page, so every distance-bearing string branches on this to render a home-base
 * phrase instead. Takes the already-rounded distance so both renderers (the
 * prerender generator + the React `CityPage`) agree.
 * @param {number} distance rounded miles from Newark (from `distanceMiles`)
 * @returns {boolean}
 */
export function isHomeBase(distance: number): boolean {
  return distance <= 0;
}

/** @param {City} city @returns {number} */
export function distanceMiles(city: City): number {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(city.lat - NEWARK_LAT);
  const dLng = toRad(city.lng - NEWARK_LNG);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(NEWARK_LAT)) * Math.cos(toRad(city.lat)) * Math.sin(dLng / 2) ** 2;
  return Math.round(2 * EARTH_KM * Math.asin(Math.sqrt(a)) * 0.621371);
}

const ESSEX_LEAFY = new Set([
  'montclair',
  'maplewood',
  'south-orange',
  'glen-ridge',
  'verona',
  'caldwell',
  'cedar-grove',
  'west-orange',
  'livingston',
  'millburn',
]);

/**
 * Returns Newark-area-relevant context for a given city.
 * @param {City} city
 * @returns {{ headline: string; body: string; commute: string }}
 */
export function areaContext(city: City): { headline: string; body: string; commute: string } {
  const dist = distanceMiles(city);

  // Destination service area (Washington, D.C.) — a scheduled drive-to service,
  // NOT the same-day Newark-metro dispatch. Never inherit the local footprint's
  // "same Newark crew / minutes away / no surcharge" copy for a ~230-mile city.
  if (city.state === 'DC') {
    return {
      headline: 'Washington, D.C. power washing — Brick Labor travels here.',
      body: 'Power washing is scheduled, drive-to project work, and the D.C. area is on our route. We bring the same gas and electric rigs, the 24-inch surface cleaner, and the least-aggressive-effective-method process to D.C. brick rowhouses, marble stoops, concrete sidewalks, pavers, and painted siding. This is booked-ahead project work — not same-day dispatch — quoted per job before we travel.',
      commute: `Washington, D.C. is roughly ${dist} miles from our Newark base, so power-washing projects here are planned in advance rather than same-day. We confirm the date, scope, and price before the crew rolls.`,
    };
  }

  if (city.state === 'NY') {
    if (city.slug === 'manhattan')
      return {
        headline: 'Manhattan walkups, terraces, and apartment cleanouts.',
        body: 'Brick Labor handles Manhattan jobs the way the buildings demand: freight-elevator windows for cleanouts, ground-floor staging when the rig will not fit upstairs, and terrace power-washing on the schedule a co-op board will actually approve. Same flat $50/hr per person — no five-borough surcharge.',
        commute: 'Newark to Midtown is roughly 15 to 25 minutes via the Lincoln Tunnel.',
      };
    if (city.slug === 'brooklyn')
      return {
        headline: 'Brooklyn brownstones, stoops, and back yards.',
        body: 'Bed-Stuy parlor floors, Park Slope brownstones, Greenpoint waterfront — Brick Labor handles the kind of stoop-and-cellar work that wears out a single-person crew. Power washing the front steps, hauling out the basement, clearing the back garden. Same flat $50/hr per person, same Newark crew.',
        commute: `Newark to Brooklyn runs 35 to 50 minutes off-peak — about ${dist} miles.`,
      };
    if (city.slug === 'queens')
      return {
        headline: 'Queens driveways, side yards, and walkup cleanouts.',
        body: 'Astoria walk-ups, Jamaica driveways, Forest Hills back yards — Queens runs the full pattern. Long suburban drives that need power-washing, narrow side gardens, three-flight walkup cleanouts that a two-person crew can finish in an afternoon.',
        commute: `Newark to Queens, 40 to 55 minutes off-peak — about ${dist} miles via the GW Bridge or I-278.`,
      };
    if (city.slug === 'the-bronx')
      return {
        headline: 'Bronx cleanouts, stoops, and small-yard work.',
        body: 'Riverdale homes, Mott Haven walkups, Pelham Bay cottages — the Bronx mixes single-family yards with dense apartment-block cleanouts. Brick Labor handles both at the same flat $50/hr per person rate, same gear, same Newark dispatch.',
        commute: `Newark to the Bronx is roughly ${dist} miles via I-95 and the GW Bridge — 35 to 50 minutes off-peak.`,
      };
    if (city.slug === 'staten-island')
      return {
        headline: 'Staten Island driveways, decks, and yard cleanups.',
        body: 'Staten Island leans suburban — long driveways, decks that need power-washing, fall leaf cleanups, garage cleanouts. Same flat $50/hr per person rate the homeowners in Newark and Jersey City pay, no zone surcharge.',
        commute: `Newark to Staten Island via the Goethals Bridge runs 25 to 40 minutes — about ${dist} miles.`,
      };
  }

  if (city.county === 'Essex') {
    if (city.slug === 'newark')
      return {
        headline: 'Newark is home base — fastest dispatch in the area.',
        body: 'Brick Labor is a Newark crew. From the Ironbound to North Newark, Vailsburg to Forest Hill, we know the streets, the alternate-side rules, and which blocks have parking-pad access. Most Newark jobs get a same-week slot. Same $50/hr per person flat rate, no travel time inside the city.',
        commute: 'Same-day dispatch is normal in-Newark. Most jobs scheduled within the week.',
      };
    const leafy = ESSEX_LEAFY.has(city.slug);
    return {
      headline: `${city.name} is in our backyard — Essex County dispatch.`,
      body: leafy
        ? `${city.name} runs leafy and suburban — deeper driveways, slate walks, big back yards, mature trees that drop a lot of leaves. Brick Labor handles the seasonal cleanups, the deck and patio power-washing, the fall and spring hauls. Same $50/hr per person flat rate as the Newark side of the county.`
        : `${city.name} sits close to the Newark grid — tighter rowhouse stoops, basement cleanouts, shared-driveway power-washing, the same Essex County rhythm. Brick Labor pulls in from Newark fast and quotes the flat $50/hr per person every single time.`,
      commute: `Newark to ${city.name} is about ${dist} miles — usually under 20 minutes.`,
    };
  }

  if (city.county === 'Hudson')
    return {
      headline: `${city.name} brownstones, rowhouses, and waterfront work.`,
      body: `Hudson County is dense rowhouse and brownstone country — narrow side yards, stoop power-washing, parking-pad cleanouts, and basement hauls that need two people because the staircase turns hard. Brick Labor brings the right crew size for the building, not the other way around.`,
      commute: `Newark to ${city.name} runs 10 to 20 minutes off-peak — about ${dist} miles.`,
    };

  if (city.county === 'Bergen')
    return {
      headline: `${city.name} driveways, lawns, decks — Bergen County crew.`,
      body: `Bergen County leans suburban — wider lots, longer driveways, deck and patio power-washing, fall leaf hauls, gutter cleanouts. Brick Labor brings the same flat $50/hr per person rate the homeowners in Newark and Jersey City pay. No zone surcharge for Bergen.`,
      commute: `Newark to ${city.name} is about ${dist} miles — 20 to 35 minutes off-peak.`,
    };

  if (city.county === 'Passaic') {
    const dense = city.slug === 'paterson' || city.slug === 'passaic';
    return {
      headline: `${city.name} property work — power-wash, lawn, hauling.`,
      body: dense
        ? `${city.name} runs the urban-core pattern that looks a lot like Newark — rowhouse stoops, narrow side yards, basement cleanouts, alley hauls. Brick Labor handles all of it on the same flat $50/hr per person rate.`
        : `${city.name} is mostly suburban — full driveways, larger yards, decks and gutters that need seasonal attention. Same flat $50/hr per person rate the rest of the area pays.`,
      commute: `Newark to ${city.name} runs 20 to 30 minutes via Route 21 or I-80 — about ${dist} miles.`,
    };
  }

  if (city.county === 'Union')
    return {
      headline: `${city.name} suburban property work — Union County dispatch.`,
      body: `Union County jobs are mostly suburban patterns: driveway power-washing, lawn cleanups, garage and basement cleanouts, light fence and gutter work. Brick Labor pulls in from Newark fast and quotes the flat $50/hr per person every time.`,
      commute: `Newark to ${city.name} is about ${dist} miles — 15 to 25 minutes via Route 1/9 or the Parkway.`,
    };

  if (city.county === 'Middlesex')
    return {
      headline: `${city.name} property work — Middlesex County crew.`,
      body: `Middlesex jobs trend suburban — bigger lots, larger lawns, full driveways and decks that need power-washing, garage cleanouts that take two people half a day. Same flat $50/hr per person rate the rest of the area pays.`,
      commute: `Newark to ${city.name} runs 25 to 40 minutes via the NJ Turnpike — about ${dist} miles.`,
    };

  return {
    headline: `${city.name} property work — same Newark crew, flat rate.`,
    body: `Brick Labor dispatches from Newark to ${city.name} for power-washing, lawn care, hauling, and light repairs. Already inside our NJ + NYC coverage area at the standard $50/hr per person — no travel fee, no zone surcharge.`,
    commute: `Newark to ${city.name} is about ${dist} miles.`,
  };
}
