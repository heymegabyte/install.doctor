export interface TrustedTypePolicyOptionsLike {
  createHTML?: (s: string) => string;
  createScriptURL?: (s: string) => string;
  createScript?: (s: string) => string;
}

export interface TrustedTypesFactoryLike {
  createPolicy?: (name: string, rules: TrustedTypePolicyOptionsLike) => unknown;
  getPolicyNames?: () => string[];
}

let nonceCache: string | undefined;

export function readCspNonce(): string | undefined {
  if (typeof document === "undefined") return undefined;
  if (nonceCache !== undefined) return nonceCache || undefined;
  const meta = document.querySelector("meta[name=\"csp-nonce\"]");
  const v = meta?.getAttribute("content")?.trim() || "";
  nonceCache = v;
  return v || undefined;
}

function defaultSanitizeHtml(dirty: string): string {
  return dirty
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
    .replace(/\son\w+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, "");
}

let policiesInstalled = false;

export function installTrustedTypesPolicies(customSanitize?: (html: string) => string): void {
  if (policiesInstalled) return;
  policiesInstalled = true;
  if (typeof window === "undefined") return;
  const tt = (window as unknown as { trustedTypes?: TrustedTypesFactoryLike }).trustedTypes;
  if (!tt || typeof tt.createPolicy !== "function") return;
  const sanitize = customSanitize ?? defaultSanitizeHtml;
  const passThrough = (s: string): string => s;
  const hasPolicy = (name: string): boolean => {
    return typeof tt.getPolicyNames === "function" ? tt.getPolicyNames().includes(name) : false;
  };
  if (!hasPolicy("default")) {
    try {
      tt.createPolicy("default", {
        createHTML: passThrough,
        createScriptURL: passThrough,
        createScript: passThrough,
      });
    } catch {
      /* Policy already exists */
    }
  }
  if (!hasPolicy("bcl-md")) {
    try {
      tt.createPolicy("bcl-md", { createHTML: sanitize });
    } catch {
      /* Idempotent */
    }
  }
}

export function resetTrustedTypesPoliciesForTest(): void {
  policiesInstalled = false;
  nonceCache = undefined;
}
