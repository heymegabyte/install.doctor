/**
 * Section 2 — single canonical scroll-to helper.
 *
 * Every "next / continue / confirm" action that advances a step calls
 * `scrollToTop(element)` so the new section's top sits exactly under the
 * navbar with the same gap as the booking-flow side-panel gutter. Pulls
 * the offset from the `--scroll-offset` CSS variable so HTML + JS stay in
 * sync — adjust it once in `styles/index.css` and every page updates.
 *
 * Usage:
 *   scrollToTop(sectionRef.current);          // smooth, default offset
 *   scrollToTop('#book');                     // selector + smooth
 *   scrollToTop(el, { behavior: 'auto' });    // instant jump
 */

export interface ScrollToOpts {
  readonly behavior?: ScrollBehavior;
  /** Override the default offset (px). Rare — prefer the CSS var. */
  readonly extraOffsetPx?: number;
}

export const SCROLL_OFFSET_FALLBACK_PX = 96; // 72 navbar + 24 gap

function readScrollOffset(): number {
  if (typeof window === 'undefined') return SCROLL_OFFSET_FALLBACK_PX;
  const raw = getComputedStyle(document.documentElement).getPropertyValue('--scroll-offset').trim();
  if (!raw) return SCROLL_OFFSET_FALLBACK_PX;
  // Resolve the CSS calc by creating a probe element.
  const probe = document.createElement('div');
  probe.style.position = 'absolute';
  probe.style.visibility = 'hidden';
  probe.style.height = `var(--scroll-offset)`;
  document.body.appendChild(probe);
  const measured = probe.getBoundingClientRect().height;
  probe.remove();
  return measured > 0 ? measured : SCROLL_OFFSET_FALLBACK_PX;
}

export function scrollToTop(target: Element | string | null, opts: ScrollToOpts = {}): void {
  if (typeof window === 'undefined') return;
  const el = typeof target === 'string' ? document.querySelector(target) : target;
  if (!el) return;
  const behavior = opts.behavior ?? (prefersReducedMotion() ? 'auto' : 'smooth');
  const offset = readScrollOffset() + (opts.extraOffsetPx ?? 0);
  const top = el.getBoundingClientRect().top + window.scrollY - offset;
  window.scrollTo({ top: Math.max(0, top), behavior });
}

function prefersReducedMotion(): boolean {
  if (typeof window === 'undefined' || !window.matchMedia) return false;
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}
